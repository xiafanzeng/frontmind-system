---
name: frontmind-content-production-router
description: FrontMind 商业 GEO 内容资料统筹与单问题内容制作的唯一入口。接收 canonical KB v4/图片库或有效 Reference Pack，以及一个已在外部确认的问题，路由到资料包构建或 E0-E6 内容制作主线。
---

# FrontMind 内容制作总控

本工作流服务于内容生产，不承担问题发现、营销策略、发布运营或效果归因。开始任何动作前，完整读取：

1. [全局 SSOT](../Master_Control/FrontMind_Content_Workflow_Master.md)
2. [内容结构注册表](../shared/content-pattern-registry.json)
3. [写作政策](../shared/writing-policy.md)

## 1. 输入识别

把当前输入归入且只归入以下状态之一：

### A. 构建或刷新 Reference Pack

触发条件：存在通过 profile、manifest、index、tree 与哈希校验的 canonical KB v4 + 图片库，但不存在通过校验的 `reference_pack.json`。

动作：

1. 读取 `Strategy_Workflow/S0.策略编排师.skill/SKILL.md`；
2. canonical KB 通过校验后直接进入 R0，不重复运行或要求上传 S1；
3. 只运行服务于写作资料包的后续节点；
4. 生成根目录固定含 `reference_pack.json` 的 ZIP；
5. 使用 `shared/scripts/validate_package.py` 校验后再交付。

### B. 制作一个已确定问题的文章

触发条件：存在有效 Reference Pack、一个确定问题、与该问题匹配且可解析的答案表和信源表，以及明确的 E5 `optimizer_target`。问题必须能规范化为以下 canonical 值之一：

- `industry_ranking`（仅导入时接受别名 `industry`）
- `competitor_comparison`
- `reputation`
- `product_scenario`

动作：先按包根 [完整运行手册](../RUNBOOK.md) 执行 E0-A 安全暂存与任务正规化，再依次执行 `E0.5 -> E0-B -> E1 -> E2 -> E2.5 -> E3 -> E4 -> E5 -> E6`。

### C. 连续统筹并制作

触发条件：同时存在合法 canonical KB v4（含包内图库或配套图库）和一个确定问题，但尚无有效 Reference Pack。

动作：先完整完成 A；只在包校验通过后，以同一问题继续 B。

散乱原始企业资料不构成 A/C 的可执行输入。S1 仅可作为可选上游整理工具；S1 输出必须先经既有 KB Builder 生成 canonical KB v4 的 manifest、source index 与 knowledge tree，再重新进入本总控。R0 不得把 S1 输出伪装成 canonical KB。

## 2. 不得启动的状态

- 没有确定问题时，不生成问题、关键词池或选题建议；只可完成 Reference Pack。
- 只有散乱资料或 S1 输出、没有 canonical KB v4 时，不开始 Reference Pack；返回 KB Builder 补件要求。
- 只有问题、没有有效 Reference Pack 时，不开始写作；返回缺失输入清单。
- 需要真实企业图片但图片库没有合法素材时，不允许以网图或生成图冒充；由对应阶段输出补图清单。
- 答案表或信源表缺失、无法解析、为空，或与当前问题不匹配时，E0/E0.5 必须阻断并返回补件清单；不得绕过监控、套用预置结构或虚构 AI 回答、引用信源、竞品与标杆页面。
- Content Job 没有声明 `optimizer_target.dataset` 或 `optimizer_target.engine_llm` 时，E0 阻断；工具在运行时不可用可由 E5 明确跳过，但不能把“未声明目标”记录为完成优化。

## 3. 隐藏路由原则

用户只提交问题及其四类入口。E1 必须从 [唯一注册表](../shared/content-pattern-registry.json) 后台自动选择且只选择一个 `P01-P15`，把选择原因、证据门槛与降级条件写入 Article Blueprint。不得让用户从十五个模板菜单中挑选，也不得先指定模板再倒推内容任务。

## 4. 产出原则

- 资料统筹唯一交付：`S0_{brand_label}_reference_pack_v{N}.zip`（安全文件标签），ZIP 根目录含 `reference_pack.json`；正式品牌身份读取 Pack 内 canonical identity。
- 单篇内容唯一语义正本：`content_model.json`。
- 最终编辑交付：同源 `final.docx` 与 `final.html`，以及与可见正文一致的 `structured_data.json`。
- E5 的算法结果是 `optimized_candidate`，不能覆盖 `editorial_master`；E6 决定最终采用哪个版本。
- 机器契约不要求 PDF，不生成渠道计划、发布动作、内容日历或效果归因报告。

## 5. 终止条件

只有同时满足以下条件才可宣告完成：

1. `quality_report.overall_status` 为 `pass`；
2. DOCX 与 HTML 记录同一个 `content_model_sha256`；
3. 所有最终交付主张存在 claim/source 绑定；
4. E5 事实 diff 已审查，未引入实体、数字、时间、价格、比较结论或引用变化；
5. `delivery_manifest.json` 通过 schema 与文件哈希校验。
