---
name: frontmind-single-question-micro-tracking
description: >
  E0.5 单问题监控与标杆拆解师。对本轮唯一正式问题强制读取 AI 答案表和信源表，识别答案格局、竞品实体与真实引用，
  访问与目标文章模式最相似的被引信源，拆解其回答覆盖和结构模式，输出供 E1 融合的 Micro Tracking 包；不发现新选题、不复制原文。
---

# E0.5 单问题监控与标杆拆解师

## 1. 任务边界

本节点承接原 S5 的“答案情况/信源情况”中对**当前具体问题**真正有用的部分，并把原 E2 才做的 A1 竞品抽取前移。
它不是品牌全局诊断，不计算品牌总分，不生成内容策略、问题推荐、日历或行动优先级。

唯一研究对象是 `content_job.question.text`。不得扩展到相邻选题。

完整输入路径与 `micro_tracking_builder.py` 参数见包根 [运行手册](../../RUNBOOK.md) 的 E0.5 段。

## 2. 强制输入

- `00_input/content_job.json`
- AI 答案表：必须能追溯平台、模型、采集时间、问题原文、完整答案；可选答案 ID、地区、会话模式、品牌实体。
- 信源表：必须能追溯答案 ID/平台、引用 URL、页面标题、域名、引用位置或引用片段；可选来源类型、发布日期、作者。
- 根 `../../shared/content-pattern-registry.json`，只用于判断目标问题可能采用的内容结构范围；最终 `pattern_id` 仍由 E1 选择。

两张表缺一、任一无有效记录即停止。先规范化双表并完成本节六步语义分析；把逐答案格局和逐标杆页面拆解写入一个
`derived-analysis.json`，再运行 `scripts/micro_tracking_builder.py --derived-analysis ...` 合并并直接校验根
`../../shared/monitoring_input.schema.json`。不能读取 XLSX 时必须报告依赖缺失，不能假装空表。

## 3. 六步 Micro Tracking

### Step 1：问题同一性校验

逐行确认监控问题与正式问题同义。答案表题面只要与正式题面不完全一致，就必须先放入 `excluded_observations` 并说明原因；需要纳入时应先在
工作流外重新确认并统一题面后重导。仅共享关键词但决策不同的行同样排除。
不得把“哪个品牌好”和“产品如何使用”混成一个样本。

### Step 2：答案格局

按平台和采集时间记录：

- 直接答案及条件；
- 品牌/产品/机构完整实体名；
- 推荐、比较、中立提及、负面或未提及；
- 排名/顺序只作为观察，不转化为权威事实；
- 答案反复出现的评价维度；
- 没有回答或回答含糊的子问题。

不得由出现频率直接推导“行业第一”。

### Step 3：竞品与比较对象集合

从未排除答案中抽取真实出现的候选对象。根 monitoring contract 只写 `name` 与 `answer_ids`，原句上下文和来源追溯保留在对应
`answers[]` 与 normalization sidecar。当前企业若在答案出现，可作为同样结构的对象写入；不得另造 `observation_ids/is_target_brand/source`
等第二套字段。不得凭常识或用户口头指定把未被答案观察到的对象写入正式 competitors。

### Step 4：引用链还原

将信源行关联到具体答案。规范化 URL、去除追踪参数、合并同一 canonical URL。用根 `source_observations[]` 的
`author/citation_context/cited_claim/source_type/primary_source_status/freshness_risk/accessed_at` 记录：作者、引用位置或片段、被引主张、
来源类型、是否原始来源、访问时间与截止日期后的更新风险；不得只写在临时 sidecar 后丢失。

信源表中的引用分数只作为监控元数据，不能写成文章事实或排序分。

### Step 5：标杆信源选择

只在真实被引信源中选择与目标问题和候选内容形态最相似的页面。选择依据：

1. 回答同一个决策问题；
2. 文章形态匹配；
3. 证据可回溯；
4. 信息日期适用；
5. 结构对回答有帮助；
6. 不因品牌排名靠前而优先。

优先选择 3-5 篇。若不足，照实输出；不得为凑数把弱相关页面纳入，也不得把未被引用网页伪装为监控信源。允许为事实核验访问原始来源，但单列为
`supplementary_primary_sources`，不得混入 `cited_benchmarks`。

### Step 6：结构蒸馏，不复制文字

逐篇拆解：

- 首句和前 200-300 字回答了什么；
- H2/H3 结构；
- 覆盖的子问题；
- 评价/比较维度；
- 证据放置方式；
- 条件式推荐方式；
- 限制、替代和 FAQ；
- 视觉承担的解释或证明作用；
- 明显缺口、偏见、模板腔或无证据结论。

最终输出共同模式与差异模式。`borrowable_patterns` 只能描述抽象结构，如“先公开样本范围再逐项评价”；禁止摘抄连续原文，
禁止把某一标杆的顺序机械复制成最终大纲。

## 4. 输出契约

输出 `E0.5_{job_id}_monitoring_input.json`，唯一满足根 `../../shared/monitoring_input.schema.json`，不复制本地 Schema。核心字段：

```json
{
  "schema_version": "1.0.0",
  "job_id": "job_...",
  "question": "...",
  "captured_at": "...",
  "input_files": {
    "answers_table_path": "...",
    "sources_table_path": "...",
    "answers_table_sha256": "...",
    "sources_table_sha256": "...",
    "normalization_sidecar_path": "..."
  },
  "answers": [],
  "source_observations": [],
  "analysis_status": "available",
  "derived": {
    "competitors": [],
    "excluded_observations": [],
    "answer_landscape": [],
    "benchmark_observation_ids": [],
    "benchmark_pages": [],
    "supplementary_primary_sources": [],
    "recurring_subquestions": [],
    "structure_findings": [],
    "warnings": []
  }
}
```

标杆逐篇拆解与可借鉴/不可借鉴结论写入 `derived.structure_findings`；更长的审阅说明可作为同名 Markdown sidecar，但不形成第二机器契约。
`derived` 是观察，不是最终 `pattern_id`。E1 必须结合正式入口、证据可用性和根注册表独立选择。

## 5. 质量门

硬失败：

- 任一监控表缺失、无有效记录或无法解析；
- 纳入了不同问题；
- 竞品没有 observation 依据；
- 标杆不在信源表且未标为补充原始来源；
- 结构建议含复制性段落；
- 把监控分数、AI 排位或未核验网页结论写成事实。

通过条件：每个竞品、引用和结构结论都能追溯到行 ID；空数据有明确原因；输出足以让 E1 判断文章必须回答什么。

## 6. 参考

- `references/micro-tracking-method.md`：字段判定、3-5 篇标杆相似度和结构拆解方法。
- `scripts/micro_tracking_builder.py`：CSV/JSON/XLSX 规范化与输入完整性检查。
