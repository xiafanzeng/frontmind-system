# Micro Tracking 方法

## 1. 观察层与事实层分离

- `observed_in_ai_answer`：只能说明某模型在某次采集中如何回答。
- `cited_by_ai_answer`：只能说明某 URL 被答案引用。
- `verified_primary_fact`：必须回到企业资料或原始权威来源核验后才可进入文章主张。
- `benchmark_structure`：只用于回答组织，不携带标杆页面的事实所有权。

## 2. 标杆相似度

不生成虚假的综合权威分。只按以下条件分级：

- `high`：同一核心问题、同一内容形态、主要子问题重合、正文可访问；
- `medium`：核心决策相同但内容形态或对象范围不同；
- `low`：仅共享主题词，不进入主要标杆。

日期、作者、原始来源与商业利益关系单列，不揉成一个看似精确的数字。

## 3. 单篇拆解卡

```json
{
  "citation_id": "CIT-001",
  "similarity": "high",
  "opening_answer_function": [],
  "section_sequence": [],
  "covered_subquestions": [],
  "comparison_dimensions": [],
  "evidence_placement": [],
  "conditional_recommendation": [],
  "limitations_and_alternatives": [],
  "faq_topics": [],
  "visual_argument_roles": [],
  "strengths": [],
  "gaps": [],
  "borrowable_abstract_patterns": [],
  "non_borrowable_elements": []
}
```

## 4. 融合规则

E1 的蓝图以根 P 模式为骨架，以监控结构模式修正回答顺序，以 References 决定能写哪些事实。冲突时优先级是：

1. 固定问题真实决策需求；
2. 可核验证据；
3. 根注册表质量门；
4. 多篇标杆共同有效模式；
5. 单篇标杆的个别结构。

不得因标杆普遍省略限制、来源或方法说明而一起省略。

