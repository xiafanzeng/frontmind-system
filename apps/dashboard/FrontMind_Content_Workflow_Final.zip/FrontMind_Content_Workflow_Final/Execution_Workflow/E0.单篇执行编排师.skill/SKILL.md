---
name: frontmind-single-article-orchestrator
description: >
  E0 单篇执行编排师。接收一个已确定的正式问题、企业内容参考包、企业图片库、该问题的 AI 答案表与信源表，
  严格按 E0-A→E0.5→E0-B→E1→E2→E2.5→E3→E4→E5→E6 生产一篇可交付文章。只允许四个正式问题入口，
  文章模式由根 shared/content-pattern-registry.json 在后台自动选择 P01-P15 中恰好一个；不做选题发现、内容日历、分发、CMS 或监测运营。
---

# E0 单篇执行编排师

## 1. 定位与继承

本节点由原 E0 执行编排师迁移而来，保留其输入校验、企业图片库校验、资产登记、逐阶段质量门、失败阻断与打包能力；
删除原先对 S1-S9 全景策略包、24 类内容菜单、内容节奏、渠道与分发的依赖。原完整规则保存在
`references/legacy-E0-execution-orchestrator-v11.md`，仅用于迁移追溯，不再作为运行契约。

执行层的单位永远是：**一个企业、一个正式问题、一个 canonical content model、一个最终文章**。

从安全 staging 到 E6 双交付的全部可复制命令与正式文件名，以包根 [运行手册](../../RUNBOOK.md) 为准；本 Skill 只补充 E0 编排语义。

## 2. 唯一允许的四个入口

`content_job.question.category` 必须是根级注册表
`../../shared/content-pattern-registry.json` 中 `canonical_question_categories` 的一个有效 ID。当前业务入口仅有：

- `industry_ranking`
- `competitor_comparison`
- `reputation`
- `product_scenario`

入口是用户问题意图，不是文章模板。E0 不向用户展示 P01-P15 菜单，也不接受用户直接拼装模板。E1 必须按注册表
`routing` 与 `selection_contract` 自动选出 `exactly_one` 个 `pattern_id`。用户只需确认四入口；当入口为产品场景时，工程师可在 E0 根据题面提示
`product_scenario_subintent`；缺失不是 E0 阻断项，由 E1 结合题面、监控和证据自动判定并写入蓝图。
E1 无法唯一判定时才阻断澄清，不能把子意图变成用户菜单。

## 3. 强制输入契约

### 3.0 S0 ZIP 安全落地

S0 的正式交接物是 `S0_{brand_label}_reference_pack_v{N}.zip`（安全文件标签），E0 不假设用户已手工解压。先运行活动工具：

```bash
python3 E0.单篇执行编排师.skill/scripts/stage_reference_pack.py \
  --zip /path/to/S0_brand_label_reference_pack_v1.zip \
  --output-dir /path/to/job/reference \
  --manifest-output /path/to/job/00_input/reference_pack_staging.json \
  --job-package-root /path/to/job
```

该工具先执行 ZIP 成员安全预检与根 `validate_package.py` 语义校验，再解压到新建的临时目录；拒绝重复/大小写冲突路径、
绝对路径、`..`、反斜线、symlink/特殊文件、加密成员、单文件/总体积超限和压缩比异常。解压后再运行一次 canonical 校验，
只在双校验通过后原子落到持久的 job-local `reference/`。目标已存在时必须停止，不使用 `unzip -o`。

随后先正规化 Content Job、确认原始双表物理存在并运行 E0.5。E0.5 产出 canonical `E0.5_{job_id}_monitoring_input.json` 后，E0-B intake 才消费这个
持久目录；`intake_validator.py` 不是 E0.5 之前可运行的脚本：

```bash
python3 E0.单篇执行编排师.skill/scripts/intake_validator.py \
  --content-job /path/to/job/00_input/content_job.json \
  --reference-pack /path/to/job/reference/reference_pack.json \
  --monitoring-input /path/to/job/01_monitoring/E0.5_job_xxx_monitoring_input.json \
  --staging-receipt /path/to/job/00_input/reference_pack_staging.json \
  --source-zip /path/to/S0_brand_label_reference_pack_v1.zip \
  --package-root /path/to/job \
  --report /path/to/job/00_input/E0_intake_report.json
```

每轮先建立 `content_job.raw.json`，再运行 `scripts/normalize_content_job.py` 输出 canonical `00_input/content_job.json` 与正规化回执。该导入门是
旧别名 `industry → industry_ranking` 唯一允许发生的位置；canonical 文件必须直接满足 `../../shared/content_job.schema.json`：

```json
{
  "schema_version": "1.0.0",
  "job_id": "job_stable_id",
  "pack_id": "rp_stable_pack_id",
  "created_at": "2026-08-10T00:00:00+08:00",
  "question": {
    "text": "本轮唯一正式问题",
    "category": "industry_ranking",
    "product_scenario_subintent": null,
    "confirmed_outside_workflow": true,
    "target_region": "中国",
    "target_audience": "本题实际决策人群",
    "time_scope": "截至2026年8月"
  },
  "monitoring_input_path": "01_monitoring/E0.5_job_stable_id_monitoring_input.json",
  "optimizer_target": {
    "dataset": "明确的数据集标识",
    "engine_llm": "明确的目标问答引擎/模型"
  },
  "deliverables": {"docx": true, "html": true},
  "editorial_profile": "third_party_objective_with_evidence_based_brand_promotion",
  "user_constraints": []
}
```

`reference_pack.json` 通过 `pack_id` 绑定，不在 Content Job 内再复制路径。E0.5 先把用户上传的答案表和信源表规范化为
`E0.5_{job_id}_monitoring_input.json`，再将其路径写入 `monitoring_input_path`。原始双表路径和 SHA256 保留在该文件的 `input_files`，不向
Content Job 添加根 Schema 之外的字段。

### 3.1 不可缺失项

以下任一缺失都必须阻断，不得以推测、网络搜索或旧 S5 快照代替：

1. 唯一 `primary_question`；不得含两个以“以及/同时/另一个”连接的独立决策问题。
2. 四入口之一的 `question_category`。
3. `pack_id` 对应的完整 References Pack；其中必须包含 knowledge/source/claim/image 四个根级 Registry、品牌事实与写作资产。
4. **该问题的 AI 答案表**。
5. **该问题的信源表**。
6. 可核验的时间范围、地区和目标人群；未提供语言时按根模型固定 `zh-CN`。
7. `optimizer_target.dataset` 与 `optimizer_target.engine_llm`，用于让 E5 明确优化目标；它们不代表允许 E5 改写事实。

答案表和信源表是 Micro Tracking 的共同输入，缺一不可，且每张表至少有一条合法记录。空表、仅有表头、无法关联的伪记录和
“未上传”都必须阻断；不得把“没有观察”伪装成可执行的监控输入。

企业图库不再是 Pack 外的第四套强制输入：默认从 References Pack 的 canonical `image_registry_path` 建立一次 job-local runtime
image registry。已签名 Pack 永远只读；补图、生成图和去重结果只能写入 runtime registry，不得写回 staged Pack。若 Logo、客户案例或
长期复用事实图需要改变，必须回到 R0/S7/S10 生成新版 Pack。图片不足时可继续正文，但 E3 必须输出缺图清单，禁止伪造企业实拍。

### 3.2 参考包只承担内容资产职责

参考包可以包含：品牌事实、产品/服务事实、定位、话语规范、案例、价格/版本、资质、专家信息、趋势观点、问答池、图片索引。
它不得包含或触发：广域问题发现、内容日历、12 周计划、渠道建议、业务行动优先级、CMS 发布任务。

## 4. 唯一机器契约

全流程必须引用根级 SSOT，不在本目录复制 P01-P15 定义：

- `../../shared/content-pattern-registry.json`：四入口、P01-P15、路由、结构和质量门。
- `../../shared/content-pattern-guide.md`：人类可读解释。
- `../../shared/content_job.schema.json`：单篇任务唯一入口契约。
- `../../shared/content_model.schema.json`：唯一正文语义模型。
- `../../shared/article_blueprint.schema.json`：E1 唯一蓝图契约。
- `../../shared/reference_pack.schema.json`：第一部分 References 包契约。
- `../../shared/monitoring_input.schema.json`：答案表/信源表及 Micro Tracking 派生结果规范。
- `../../shared/registries.schema.json`：knowledge/source/claim/image 四类唯一 Registry 契约。
- `../../shared/runtime_evidence_extension.schema.json`：当前问题新增来源、主张与证据文件的 job-local 追加契约。

如任一必需 SSOT 不存在或 Schema 版本不兼容，E0 必须阻断并输出 `contract_failure.json`，不得生成自创枚举。

图片在执行层只使用根 `image_registry.images[].sha256`。旧 `entries/file_hash`、`assets/file_hash` 不得进入活动流程；历史素材必须在
References Pack 制作阶段完成一次性迁移。运行 `scripts/seed_runtime_image_registry.py` 将签名 base registry 复制到 job-local 路径并
生成绑定回执；单篇补充图片由 E3 登记器去重后只追加到该 runtime registry。E3 Manifest 绑定 base、runtime 和 seed receipt 三个 hash。

运行 `scripts/intake_validator.py` 机器核验 Content Job、pack_id、References Pack 文件哈希、四类 Registry 及交叉引用、
monitoring input 与原始双表哈希、题面一致性和标杆访问状态。报告未通过时不得进入 E1。

## 5. 固定阶段顺序与交接

### E0 Step 0：Reference Pack 安全落地

必须先运行 `scripts/stage_reference_pack.py`，得到持久的 job-local `reference/` 和其外部 `reference_pack_staging.json` 回执；
回执内 ZIP SHA256、`pack_id`、版本及解压前/后 canonical 校验均为 pass 后，才创建 Content Job 和原始双表输入。
不存在“直接跳到已解包 `reference_pack.json`”的默认通道；已落地 Pack 的重试必须复用已校验回执，不覆盖目录。

### E0.5 单问题监控与标杆拆解

输入固定问题、答案表、信源表。输出根契约 `E0.5_{job_id}_monitoring_input.json`，在 `derived` 中写入排除记录、逐答案格局、竞品、优先 3-5 个
真实被引标杆的逐页结构拆解、补充原始信源、重复子问题、结构发现和限制；真实不足时允许少于 3 篇但必须警告，不得凑数。
实际答案与实际被引信源保留在 `answers` 与 `source_observations`。

### E0-B 全契约 intake 与 runtime 证据/图片表

E0.5 完成后运行 `scripts/intake_validator.py`，同时验证 Content Job、staging receipt、原始 ZIP、签名 Pack、canonical monitoring input、原始双表哈希、题面与标杆访问证据。
通过后运行 `scripts/build_runtime_evidence_bundle.py` 与 `scripts/seed_runtime_image_registry.py`。新增网页也必须保存为 job-local 快照/摘录文件并进入
`evidence_files` 哈希清单，不能靠 URL 和自填 verified 状态自证。后续 E2-E6 使用 runtime claim/source registries；E3/E4/E6 使用 job-local
runtime image registry；签名 Pack 始终保持原样。即使没有新增证据，也要生成空 extension 与绑定回执。

### E1 文章蓝图

读取根注册表并选择恰好一个 `pattern_id`。输出一个 `article_blueprint.json`，锁定 1 个主问题、5-8 个必要子问题、
5-8 个最终 FAQ 候选、误解、顾虑、反对意见、证据需求、品牌自然介入点、结构和标题约束。

### E2 正文制作

从蓝图和 References 生成一个 `E2_{job_id}_content_model.draft.json` 与可审阅 Markdown。正文不含表格；不写流程元话语；
每个实质性主张必须有 `claim_id`。

### E2.5 证据预检

在视觉和润色成本投入前检查问题覆盖、主张证据、竞品同维度公平性、时间/地区/币种/版本、案例完整性。
出现 unsupported material claim 必须回 E2。

### E3 视觉论证

只为已通过预检的正文生产视觉。每张图必须绑定 `supports_claim_ids`，角色为 `explain/prove/navigate`；装饰图不能计入论证图。

### E4 编辑终审

执行完整的内容、事实、竞品、类型、文风、视觉和发布质量检查。通过后冻结
`E4_{job_id}_safe_content_model.json`。**E4 是不可被后续静默覆盖的安全正本。**

### E5 AutoGEO 候选优化

仅调用 `autogeo` 生成候选与 diff。库不可用、调用失败或候选不安全时沿用 E4，禁止全局词语替换 fallback。

### E6 回归终审与双格式交付

对 E5 候选逐项回归；只有完全通过才升级为 approved model，否则回退 E4。DOCX 与 HTML 必须从同一个 approved model 渲染。

## 6. 全流程内容硬规则

E0 必须向每个下游阶段传递以下不可降级约束：

1. 一篇只解决一个核心决策，不争夺多个无关主题。
2. 5-8 个必要子问题；FAQ 只选与本题最相关的 5-8 个真实问题。
3. 内容真实更新到目标年份时，标题才可使用年份；高变动主题进一步写明月份或季度。
4. 标题可使用明确形态词，但不得承诺正文没有回答的内容。
5. 首句 40-80 个汉字直接回答标题问题。
6. 前 200-300 个中文字符构成可独立引用的微型答案，含完整实体、结论、关键依据、适合对象、时间/地区限定。
7. 删除“随着时代发展、近年来越来越多、众所周知”等无信息开头。
8. 各节按“结论—证据—建议”，一段一个主要观点，每段 2-4 句。
9. 概念解释包含定义、用途、适合与不适合；教程步骤包含输入、动作、预期结果和检查方法。
10. 排名公开范围、指标、来源、统计日期和排序依据；对比对所有对象使用相同维度。
11. 全文不用正文表格；比较内容改写为结构一致的分项段落。
12. 重要事实标原始来源名称；统计数据写时间、样本量、单位、地区/人群和口径。
13. 至少一项有授权、可核验的原创信息；没有则显式降级，禁止伪造。
14. 使用完整品牌、机构、产品、型号、版本名。
15. 价格和规格写币种、套餐、地区、版本、有效日期及附加条件。
16. 每个方案写真实限制、不适用情况和门槛；案例含背景、问题、动作、结果数据与周期。
17. 专家观点注明姓名、机构、身份及适用范围。
18. 结尾只总结推荐结果、适用对象和下一步，不新增未展开观点。
19. 文风为“第三方客观报道 + 企业品牌事实表达”的分析报告腔；写真实条件和风险，不暴露审稿过程。
20. 禁止“资料较完整、相关资料显示、以审核为准、服务边界、信息边界、保持克制、用户提交资料、需要说明、不构成对……”等内部式表达。

## 7. 标题与 HTML/DOCX 约束

- 蓝图和正文模型保留恰好 5 个同题标题候选；`metadata.title`/`h1` 始终锁定其中一个工作标题，E6 只可从这 5 个中确认最终标题。
- HTML 恰好一个 H1；正文只用 H2/H3，最多三级、不跳级；每个 H2 必须是以 `？/?` 结尾的完整用户问题。
- Web Title、H1、Meta Description 必须回答同一主题。
- Article、FAQPage、HowTo、Product、Review 仅在可见正文满足相应条件时生成，JSON-LD 不得包含正文没有的信息。
- DOCX 与 HTML 的段落、事实、数字、实体、FAQ 和图片语义必须同源；格式差异不得导致内容漂移。
- 不输出 PDF 作为机器必需物，也不输出分发、渠道、CMS 或回滚计划。

## 8. 阶段门和失败语义

编排检查清单按下列阶段门推进；这是流程语义，不额外制造无人维护的 `execution_state.json`：

`PACK_STAGED → TRACKING_READY → INPUT_VALIDATED → RUNTIME_EVIDENCE_READY → RUNTIME_IMAGES_READY → BLUEPRINT_READY → DRAFT_READY → EVIDENCE_PASSED → VISUAL_READY → E4_SAFE → E5_CANDIDATE_OR_SKIPPED → DELIVERED`

任一质量门失败时，在该阶段真实报告中记录失败规则、修复责任阶段与恢复入口。不得用空字符串、静默 fallback 或伪造成功推进。

## 9. 客户交付与内部审计边界

E0.5 monitoring、E1 blueprint、E2.5 evidence、E3 Manifest、E4 audit、E5 report/diff 和 E6 regression 都保留在 job-local **内部审计目录**，
不得把原始监控表、客户知识库或内部生产记录误装进客户稿。E6 的客户交付目录只登记其真实生成文件：

```text
delivery/
├── approved_content_model.json
├── approved_source.md
├── final.docx
├── final.html
├── metadata.json
├── structured_data.json
├── title_selection_receipt.json
├── E6_quality_report.json
├── render_audit.json
├── images/（仅实际使用时）
└── delivery_manifest.json
```

交付包不得含日历、渠道建议、分发计划、CMS 状态或内部思维链。

## 10. 活动资产导航

- `scripts/stage_reference_pack.py`：E0 Step 0，将 S0 ZIP 安全校验并持久落地，产出 staging receipt。
- `scripts/normalize_content_job.py`：E0-A 导入正规化；输出 canonical Content Job 与 alias 转换回执。
- `scripts/intake_validator.py`：E0-B，消费已落地 Pack、Content Job 和 E0.5 canonical monitoring input 并执行 intake 硬门。
- `scripts/build_runtime_evidence_bundle.py`：建立只追加、证据文件哈希绑定的 job-local claim/source registries 与回执。
- `scripts/seed_runtime_image_registry.py`：从只读 base registry 建立 job-local runtime registry 与种子回执，绝不修改已签 Pack。
- `references/legacy-*` 与 `references/legacy-runtime-v11/`：只读迁移证据，不得作为活动脚本、Schema 或模板调用。
