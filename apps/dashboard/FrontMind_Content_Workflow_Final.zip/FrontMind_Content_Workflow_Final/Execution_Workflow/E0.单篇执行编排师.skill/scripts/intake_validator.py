#!/usr/bin/env python3
"""Validate a single-article job, Reference Pack, registries, and monitoring input."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "shared"))
from schema_validation import validate_root, validate_schema  # noqa: E402


JOB_REQUIRED = {
    "schema_version", "job_id", "pack_id", "created_at", "question", "monitoring_input_path",
    "optimizer_target", "deliverables", "editorial_profile",
}
JOB_ALLOWED = JOB_REQUIRED | {"user_constraints"}
QUESTION_CATEGORIES = {"industry_ranking", "competitor_comparison", "reputation", "product_scenario"}
PRODUCT_SUBINTENTS = {
    "offering_definition", "feature_mechanism", "scenario_fit", "delivery_usage", "support_boundary", "price_selection",
}
REGISTRY_PATHS = {
    "knowledge_registry_path": "knowledge_registry",
    "source_registry_path": "source_registry",
    "claim_registry_path": "claim_registry",
    "image_registry_path": "image_registry",
}


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain an object")
    return value


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_sha256(value: dict[str, Any]) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def resolve_inside(root: Path, stored: str, errors: list[str], label: str) -> Path | None:
    candidate = Path(stored)
    if candidate.is_absolute() or ".." in candidate.parts or "\\" in stored:
        errors.append(f"{label}: path must be package-relative without traversal: {stored}")
        return None
    resolved = (root / candidate).resolve()
    try:
        resolved.relative_to(root.resolve())
    except ValueError:
        errors.append(f"{label}: path escapes package root: {stored}")
        return None
    return resolved


def validate_job(job: dict[str, Any], errors: list[str]) -> None:
    missing, extras = JOB_REQUIRED - set(job), set(job) - JOB_ALLOWED
    if missing or extras:
        errors.append(f"content_job fields mismatch: missing={sorted(missing)}, extras={sorted(extras)}")
    if job.get("schema_version") != "1.0.0" or not str(job.get("job_id", "")).startswith("job_"):
        errors.append("content_job schema_version/job_id invalid")
    question = job.get("question") if isinstance(job.get("question"), dict) else {}
    question_required = {
        "text", "category", "confirmed_outside_workflow",
        "target_region", "target_audience", "time_scope",
    }
    question_allowed = question_required | {"product_scenario_subintent", "target_region", "target_audience", "time_scope"}
    if question_required - set(question) or set(question) - question_allowed:
        errors.append("content_job.question fields do not match the root contract")
    if not 4 <= len(str(question.get("text", "")).strip()) <= 300:
        errors.append("content_job.question.text must contain 4-300 Unicode characters")
    for key in ("target_region", "target_audience", "time_scope"):
        if not str(question.get(key, "")).strip():
            errors.append(f"content_job.question.{key} is required")
    category, subintent = question.get("category"), question.get("product_scenario_subintent")
    if category not in QUESTION_CATEGORIES or question.get("confirmed_outside_workflow") is not True:
        errors.append("content_job question category/confirmation invalid")
    if category == "product_scenario" and subintent is not None and subintent not in PRODUCT_SUBINTENTS:
        errors.append("product_scenario_subintent, when supplied, must be canonical; E1 may infer a missing value")
    if category != "product_scenario" and subintent is not None:
        errors.append("non-product question requires null product_scenario_subintent")
    target = job.get("optimizer_target") if isinstance(job.get("optimizer_target"), dict) else {}
    if {"dataset", "engine_llm"} - set(target) or set(target) - {"dataset", "engine_llm", "extra_options"}:
        errors.append("content_job.optimizer_target fields do not match the root contract")
    if not str(target.get("dataset", "")).strip() or not str(target.get("engine_llm", "")).strip():
        errors.append("optimizer_target.dataset and engine_llm are required")
    if job.get("deliverables") != {"docx": True, "html": True}:
        errors.append("deliverables must request both docx and html")
    if job.get("editorial_profile") != "third_party_objective_with_evidence_based_brand_promotion":
        errors.append("editorial_profile is not the canonical profile")
    constraints = job.get("user_constraints")
    if constraints is not None and (not isinstance(constraints, list) or any(not isinstance(value, str) or len(value) > 500 for value in constraints)):
        errors.append("content_job.user_constraints must be an array of strings up to 500 characters")


def validate_registry_links(
    registries: dict[str, dict[str, Any]], registry_paths: dict[str, Path],
    pack_root: Path, errors: list[str],
) -> None:
    sources = {item.get("source_id") for item in registries["source_registry"].get("sources", []) if isinstance(item, dict)}
    claims = registries["claim_registry"].get("claims", [])
    images = {item.get("asset_id"): item for item in registries["image_registry"].get("images", []) if isinstance(item, dict)}
    pack_file_records = {
        str(item.get("path")): item for item in registries.get("__pack_files__", {}).get("files", [])
        if isinstance(item, dict)
    }
    for claim in claims:
        if not isinstance(claim, dict):
            errors.append("claim_registry contains a non-object")
            continue
        for source_id in claim.get("source_ids", []):
            if source_id not in sources:
                errors.append(f"claim {claim.get('claim_id')} references unknown source {source_id}")
        original = claim.get("original_evidence")
        if isinstance(original, dict):
            for source_id in original.get("source_ids", []):
                if source_id not in sources:
                    errors.append(f"claim {claim.get('claim_id')} original_evidence references unknown source {source_id}")
            for record_ref in original.get("record_refs", []):
                ref_path = resolve_inside(pack_root, str(record_ref), errors, f"claim {claim.get('claim_id')}.original_evidence.record_refs")
                record = pack_file_records.get(str(record_ref))
                if not record:
                    errors.append(f"claim {claim.get('claim_id')} original_evidence record_ref is not a signed Pack file: {record_ref}")
                elif not ref_path or not ref_path.is_file() or sha256(ref_path) != record.get("sha256"):
                    errors.append(f"claim {claim.get('claim_id')} original_evidence record_ref missing/hash mismatch: {record_ref}")
    for asset_id, asset in images.items():
        for source_id in asset.get("source_ids", []):
            if source_id not in sources:
                errors.append(f"image {asset_id} references unknown source {source_id}")
        stored, expected = asset.get("file_path"), asset.get("sha256")
        if stored and expected:
            image_path = resolve_inside(pack_root, str(stored), errors, f"image_registry.images[{asset_id}].file_path")
            if not image_path or not image_path.is_file():
                errors.append(f"image {asset_id} file missing")
            elif sha256(image_path) != expected:
                errors.append(f"image {asset_id} SHA256 mismatch")
    for unit in registries["knowledge_registry"].get("knowledge_units", []):
        if not isinstance(unit, dict):
            continue
        unknown_sources = set(unit.get("source_ids", [])) - sources
        unknown_assets = set(unit.get("asset_ids", [])) - set(images)
        if unknown_sources:
            errors.append(f"knowledge {unit.get('knowledge_id')} references unknown sources {sorted(unknown_sources)}")
        if unknown_assets:
            errors.append(f"knowledge {unit.get('knowledge_id')} references unknown assets {sorted(unknown_assets)}")


def run_root_pack_validator(pack_path: Path, errors: list[str]) -> dict[str, Any]:
    """Run the workflow's canonical package validator; never maintain a second package contract here."""
    if pack_path.name != "reference_pack.json":
        errors.append("--reference-pack must point to the canonical reference_pack.json entrypoint")
        return {"status": "fail", "errors": ["invalid entrypoint"]}
    validator = Path(__file__).resolve().parents[3] / "shared" / "scripts" / "validate_package.py"
    if not validator.is_file():
        errors.append(f"canonical Reference Pack validator missing: {validator}")
        return {"status": "fail", "errors": ["validator missing"]}
    process = subprocess.run(
        [sys.executable, "-B", str(validator), str(pack_path.parent)],
        text=True, capture_output=True, check=False,
        env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
    )
    try:
        result = json.loads(process.stdout)
    except json.JSONDecodeError:
        errors.append(f"canonical Reference Pack validator emitted invalid JSON: {process.stderr or process.stdout}")
        return {"status": "fail", "errors": ["invalid validator output"]}
    if result.get("status") != "pass" or process.returncode != 0:
        errors.extend(f"reference_pack canonical validation: {item}" for item in result.get("errors", []))
    return result


def validate_pack(pack: dict[str, Any], pack_path: Path, job: dict[str, Any], errors: list[str]) -> tuple[dict[str, dict[str, Any]], dict[str, Path]]:
    if pack.get("schema_version") != "1.0.0" or pack.get("profile") != "frontmind-content-reference-pack-v1":
        errors.append("reference_pack schema_version/profile invalid")
    if pack.get("pack_id") != job.get("pack_id"):
        errors.append("content_job.pack_id does not match reference_pack.pack_id")
    root = pack_path.parent
    file_records = {item.get("path"): item for item in pack.get("files", []) if isinstance(item, dict)}
    for stored, record in file_records.items():
        path = resolve_inside(root, str(stored), errors, f"reference_pack.files[{stored}]")
        if path and (not path.is_file() or sha256(path) != record.get("sha256")):
            errors.append(f"reference_pack file missing/hash mismatch: {stored}")
    registries: dict[str, dict[str, Any]] = {}
    paths: dict[str, Path] = {}
    registry_mapping = pack.get("registries") if isinstance(pack.get("registries"), dict) else {}
    for path_key, registry_type in REGISTRY_PATHS.items():
        stored = registry_mapping.get(path_key)
        path = resolve_inside(root, str(stored or ""), errors, path_key)
        if not path or not path.is_file():
            errors.append(f"required registry missing: {path_key}")
            continue
        record = file_records.get(stored)
        if not record or record.get("role") != registry_type:
            errors.append(f"registry is missing matching file record/role: {stored}")
        value = load(path)
        if value.get("schema_version") != "1.0.0" or value.get("registry_type") != registry_type:
            errors.append(f"registry contract invalid: {stored}")
        registries[registry_type], paths[registry_type] = value, path
    for key in ("approval_receipt_path", "brand_facts_path"):
        stored = pack.get(key)
        path = resolve_inside(root, str(stored or ""), errors, key)
        if not path or not path.is_file() or stored not in file_records:
            errors.append(f"reference_pack required approved artifact missing: {key}")
    if set(registries) == set(REGISTRY_PATHS.values()):
        registries["__pack_files__"] = {"files": pack.get("files", [])}
        validate_registry_links(registries, paths, root, errors)
        registries.pop("__pack_files__", None)
    return registries, paths


def validate_monitoring(monitoring: dict[str, Any], monitoring_path: Path, package_root: Path,
                        job: dict[str, Any], errors: list[str]) -> None:
    if monitoring.get("schema_version") != "1.0.0" or monitoring.get("job_id") != job.get("job_id"):
        errors.append("monitoring_input schema_version/job_id invalid")
    if monitoring.get("question") != job.get("question", {}).get("text"):
        errors.append("monitoring_input.question differs from content_job.question.text")
    if monitoring.get("analysis_status") not in {"available", "partial"}:
        errors.append("monitoring_input.analysis_status invalid")
    answers, observations = monitoring.get("answers", []), monitoring.get("source_observations", [])
    if not isinstance(answers, list) or not answers or not isinstance(observations, list) or not observations:
        errors.append("monitoring_input requires at least one answer and one source observation")
    files = monitoring.get("input_files") if isinstance(monitoring.get("input_files"), dict) else {}
    for path_key, hash_key in (("answers_table_path", "answers_table_sha256"), ("sources_table_path", "sources_table_sha256")):
        stored = str(files.get(path_key) or "")
        path = resolve_inside(package_root, stored, errors, f"monitoring_input.{path_key}")
        if not path or not path.is_file() or sha256(path) != files.get(hash_key):
            errors.append(f"monitoring physical input missing/hash mismatch: {path_key}")
    derived = monitoring.get("derived") if isinstance(monitoring.get("derived"), dict) else {}
    answer_ids = {str(item.get("answer_id")) for item in answers if isinstance(item, dict)}
    observation_ids = {str(item.get("observation_id")) for item in observations if isinstance(item, dict)}
    excluded = {
        str(item.get("record_id")) for item in derived.get("excluded_observations", []) if isinstance(item, dict)
    }
    if not (answer_ids - excluded):
        errors.append("monitoring_input has no unexcluded answer for the exact question")
    landscape_ids = {
        str(item.get("answer_id")) for item in derived.get("answer_landscape", []) if isinstance(item, dict)
    }
    if not landscape_ids or landscape_ids - (answer_ids - excluded):
        errors.append("answer_landscape must reference one or more unexcluded answers only")
    for competitor in derived.get("competitors", []):
        if isinstance(competitor, dict):
            competitor_ids = {str(value) for value in competitor.get("answer_ids", [])}
            if not competitor_ids or competitor_ids - (answer_ids - excluded):
                errors.append(f"competitor references unknown/excluded answers: {competitor.get('name')}")
    pages = derived.get("benchmark_pages", [])
    if not isinstance(pages, list) or not 1 <= len(pages) <= 5:
        errors.append("monitoring derived benchmark_pages must contain 1-5 real pages")
    observation_index = {item.get("observation_id"): item for item in observations if isinstance(item, dict)}
    page_ids = {item.get("observation_id") for item in pages if isinstance(item, dict)}
    if set(derived.get("benchmark_observation_ids", [])) != page_ids:
        errors.append("benchmark_observation_ids differ from benchmark_pages")
    for observation_id in page_ids:
        if str(observation_id) not in observation_ids or str(observation_id) in excluded:
            errors.append(f"benchmark observation is unknown or excluded: {observation_id}")
        observation = observation_index.get(observation_id, {})
        if observation.get("retrieval_status") != "retrieved":
            errors.append(f"benchmark observation was not retrieved: {observation_id}")
        missing_retrieval_evidence = [
            key for key in (
                "accessed_at", "body_excerpt", "citation_context", "cited_claim",
                "source_type", "primary_source_status", "freshness_risk",
            ) if not observation.get(key)
        ]
        if missing_retrieval_evidence:
            errors.append(
                f"benchmark observation lacks independent retrieval evidence/classification: {observation_id}: "
                f"{', '.join(missing_retrieval_evidence)}"
            )
    stored_monitoring = str(job.get("monitoring_input_path") or "")
    expected = resolve_inside(package_root, stored_monitoring, errors, "content_job.monitoring_input_path")
    if expected and expected.resolve() != monitoring_path.resolve():
        errors.append("content_job.monitoring_input_path does not resolve to supplied monitoring file")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--content-job", type=Path, required=True)
    parser.add_argument("--reference-pack", type=Path, required=True)
    parser.add_argument("--monitoring-input", type=Path, required=True)
    parser.add_argument("--staging-receipt", type=Path, required=True)
    parser.add_argument("--source-zip", type=Path, required=True)
    parser.add_argument("--package-root", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    for path in (args.content_job, args.reference_pack, args.monitoring_input, args.staging_receipt, args.source_zip):
        if not path.is_file():
            raise FileNotFoundError(path)
    package_root = args.package_root.resolve()
    if not package_root.is_dir():
        raise FileNotFoundError(package_root)
    errors: list[str] = []
    for supplied, label in (
        (args.content_job, "--content-job"),
        (args.reference_pack, "--reference-pack"),
        (args.monitoring_input, "--monitoring-input"),
        (args.staging_receipt, "--staging-receipt"),
    ):
        try:
            supplied.resolve().relative_to(package_root)
        except ValueError:
            errors.append(f"{label} must be staged inside --package-root")
    job, pack, monitoring = load(args.content_job), load(args.reference_pack), load(args.monitoring_input)
    staging_receipt = load(args.staging_receipt)
    try:
        validate_schema(
            staging_receipt,
            Path(__file__).resolve().parents[1] / "templates" / "staged_reference_pack.schema.json",
            "E0 staging receipt",
        )
    except ValueError as exc:
        errors.append(str(exc))
    expected_entrypoint = (package_root / str(staging_receipt.get("reference_pack_path") or "")).resolve()
    expected_staged_dir = (package_root / str(staging_receipt.get("staged_package_dir") or "")).resolve()
    if (
        staging_receipt.get("pack_id") != pack.get("pack_id")
        or staging_receipt.get("pack_version") != pack.get("version")
        or expected_staged_dir != args.reference_pack.parent.resolve()
        or expected_entrypoint != args.reference_pack.resolve()
        or staging_receipt.get("source_zip_file") != args.source_zip.name
        or staging_receipt.get("source_zip_sha256") != sha256(args.source_zip)
        or staging_receipt.get("canonical_pre_validation") != "pass"
        or staging_receipt.get("canonical_post_validation") != "pass"
    ):
        errors.append("staging receipt/ZIP/package root/reference_pack binding mismatch")
    for value, schema_name, label in (
        (job, "content_job.schema.json", "content_job"),
        (pack, "reference_pack.schema.json", "reference_pack"),
        (monitoring, "monitoring_input.schema.json", "monitoring_input"),
    ):
        try:
            validate_root(value, schema_name, label)
        except ValueError as exc:
            errors.append(str(exc))
    validate_job(job, errors)
    canonical_pack_report = run_root_pack_validator(args.reference_pack, errors)
    registries, _ = validate_pack(pack, args.reference_pack, job, errors)
    validate_monitoring(monitoring, args.monitoring_input, package_root, job, errors)
    pattern_registry_path = resolve_inside(
        args.reference_pack.parent, str(pack.get("content_pattern_registry_path") or ""), errors,
        "reference_pack.content_pattern_registry_path",
    )
    pattern_registry_sha256 = None
    if pattern_registry_path and pattern_registry_path.is_file():
        pattern_registry_sha256 = canonical_sha256(load(pattern_registry_path))
    report = {
        "schema_version": "1.0.0", "job_id": job.get("job_id"), "stage": "E0_intake",
        "status": "failed" if errors else "passed",
        "checks": {
            "content_job": "passed" if not any("content_job" in item for item in errors) else "failed",
            "reference_pack": "passed" if not any("reference_pack" in item or "registry" in item for item in errors) else "failed",
            "monitoring_input": "passed" if not any("monitoring" in item or "benchmark" in item for item in errors) else "failed",
            "registry_types_loaded": sorted(registries),
            "canonical_reference_pack_validator": canonical_pack_report.get("status"),
        },
        "reference_pack_sha256": canonical_sha256(pack),
        "staging_receipt_sha256": canonical_sha256(staging_receipt),
        "content_pattern_registry_sha256": pattern_registry_sha256,
        "signed_pack_files": {
            str(item.get("path")): str(item.get("sha256"))
            for item in pack.get("files", []) if isinstance(item, dict)
        },
        "registry_sha256": {
            registry_type: canonical_sha256(value)
            for registry_type, value in sorted(registries.items())
        },
        "errors": errors,
        "warnings": [],
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
