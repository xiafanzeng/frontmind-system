#!/usr/bin/env python3
"""Normalize the one Dashboard legacy category alias at the E0-A boundary."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "shared"))
from schema_validation import validate_root, validate_schema  # noqa: E402


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_sha256(value: dict[str, Any]) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def atomic_json(path: Path, value: dict[str, Any]) -> None:
    if path.exists() or path.is_symlink():
        raise FileExistsError(f"refusing to overwrite content-job artifact: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2)
            handle.flush(); os.fsync(handle.fileno())
        os.replace(temporary, path)
    except Exception:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True, help="raw Dashboard/API Content Job JSON")
    parser.add_argument("--output", type=Path, required=True, help="new canonical Content Job JSON")
    parser.add_argument("--receipt", type=Path, required=True)
    args = parser.parse_args()
    source = args.input.resolve()
    if not source.is_file():
        raise FileNotFoundError(source)
    if len({source, args.output.resolve(strict=False), args.receipt.resolve(strict=False)}) != 3:
        raise ValueError("input, canonical output and receipt must be three distinct paths")
    value = json.loads(source.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("Content Job must be a JSON object")
    question = value.get("question")
    if not isinstance(question, dict):
        raise ValueError("Content Job.question must be an object")
    normalized_aliases: list[dict[str, str]] = []
    category = question.get("category")
    if category == "industry":
        question["category"] = "industry_ranking"
        normalized_aliases.append({"path": "question.category", "from": "industry", "to": "industry_ranking"})
    validate_root(value, "content_job.schema.json", "normalized Content Job")
    receipt = {
        "schema_version": "1.0.0", "job_id": value.get("job_id"),
        "stage": "E0_content_job_normalization", "status": "passed",
        "normalized_at": datetime.now(timezone.utc).isoformat(),
        "source_file": source.name, "source_sha256": file_sha256(source),
        "canonical_file": args.output.name, "canonical_sha256": canonical_sha256(value),
        "normalized_aliases": normalized_aliases,
    }
    validate_schema(
        receipt, Path(__file__).resolve().parents[1] / "templates" / "content_job_normalization_receipt.schema.json",
        "Content Job normalization receipt",
    )
    atomic_json(args.output, value)
    atomic_json(args.receipt, receipt)
    print(json.dumps({"status": "passed", "job_id": value.get("job_id"), "normalized_aliases": normalized_aliases}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
