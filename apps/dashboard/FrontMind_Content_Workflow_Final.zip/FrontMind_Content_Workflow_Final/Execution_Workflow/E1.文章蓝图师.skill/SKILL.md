---
name: frontmind-single-article-blueprint-architect
description: >
  E1 文章蓝图师。读取一个正式问题、Micro Tracking 包、企业 References 与根内容模式注册表，后台自动选择 P01-P15 中恰好一个模式，
  将问题深挖为可执行的答案蓝图、证据计划、FAQ 与视觉论证计划；不做广域问题发现、24 类菜单、内容日历、渠道规划或正文写作。
---

# E1 文章蓝图师

## 1. 从原 E1 继承什么

保留原 E1 的专业内容框架、问题—意图—文章结构转换、类型专属结构、标题锚点、品牌话语与视觉计划能力；删除：

- 一次生成 24 类完整菜单；
- A/B/C/D 全覆盖要求；
- 固定 A1/C1b 优先级；
- 90 天/季度/月度内容节奏；
- 渠道匹配和分发预规划；
- 从 S2/S5/S8/S9 发现或推荐新问题。

原规则保存在 `references/legacy-E1-content-strategist-v11.md`。旧模板的专业结构迁移说明见
`references/professional-structure-migration.md`；根 `../../shared/content-pattern-registry.json` 是模式定义唯一 SSOT。

## 2. 强制输入

1. `00_input/content_job.json`：唯一问题和四入口。
2. `01_monitoring/E0.5_{job_id}_monitoring_input.json`：答案、竞品、引用标杆和结构蒸馏。
3. `reference_pack.json` 及其可访问内容文件；默认从 Pack 的 `registries.image_registry_path` 读取企业图片资产。
4. job-local runtime evidence/image registries 与绑定回执；单篇补充只能追加到 runtime 层，绝不写回签名 Pack。
5. `../../shared/content-pattern-registry.json` 与 `../../shared/content-pattern-guide.md`。
6. 根 `../../shared/writing-policy.md` 与 `../../shared/html-structured-data-policy.md`；执行层 shared 中旧 publication 文档只作迁移参考。

禁止读取旧 S9 行动菜单决定文章；禁止自行复制 P01-P15 枚举。注册表不存在或无合法路由时阻断。

## 3. 后台模式路由

### 3.1 路由原则

E1 根据以下信息选择恰好一个 `pattern_id`：

- 正式 `question_category`，以及 E1 从题面、监控和证据自动识别的产品场景子意图；
- `primary_question` 的唯一决策动作；
- Micro Tracking 的答案结构和内容形态；
- References 中实际可用证据；
- 注册表中每个模式的 purpose、required_evidence、structure、quality_gates。

模式选择是后台动作，不向用户展示 P01-P15 菜单。不得为“多覆盖”选择两个模式；若证据不足，选择能诚实完成的模式或阻断补证，
不能用另一个无关模式绕过证据要求。

### 3.2 选择记录

将选择结果直接写入根蓝图的 `pattern_id` 与 `routing_reason`，不要另造 `pattern_selection` 顶层字段：

```json
{
  "question_category": "industry_ranking",
  "primary_question": "用户确认的问题",
  "product_scenario_subintent": null,
  "pattern_id": "来自根注册表的唯一 ID",
  "routing_reason": "用决策动作、监控信号、可用证据和拒绝其他候选的理由说明唯一选择"
}
```

按包根 [运行手册](../../RUNBOOK.md) 的 E1 完整命令运行 `scripts/pattern_router.py validate`。验证器检查：ID 存在、入口/产品子意图兼容且只有一个，
并核验 `benchmark_fusion.monitoring_input_sha256`、逐篇标杆采用/部分采用/拒绝决定和引用的结构发现索引；不建立临时 selection JSON。

## 4. 问题深挖

### Step 1：锁定核心决策

用一句话说明“读者读完后能做什么决定”。如问题同时包含两个独立决策，必须回 E0 要求拆分，不能在一篇里拼接。

### Step 2：建立必要子问题

只选择 5-8 个回答主问题不可缺少的子问题。来源优先级：

1. 原正式问题的隐含决策条件；
2. Micro Tracking 中多次出现或明显未回答的问题；
3. 客户咨询/销售记录/S8 真实问答池；
4. 根模式结构要求。

通常检查价格、优势、限制、适合对象、案例、替代方案，但不得机械把六项全部塞给每种文章。

将 5-8 个子问题写入 `question_contract.necessary_subquestions`；为每个子问题确定对应的 `section_plan.section_id`、证据与降级方式。
同时自动写 `primary_intent_tag` 和最多 3 个 `secondary_intent_tags`，只能从推荐、价格、对比、教程、评价、风险、替代七类机器标签中选择；
这不是给用户新增入口。

### Step 3：误解、顾虑与反对意见

区分：

- `misconceptions`：需要纠正的事实或概念误解；
- `decision_concerns`：价格、门槛、风险、适配等决策顾虑；
- `objections`：读者可能反对结论的合理理由；
- `alternatives`：不适合主方案时的真实替代路径。

只写与主问题有关且有证据处理的项。

### Step 4：证据需求与品牌介入

先定义回答所需证据，再决定企业品牌在哪个位置自然介入。品牌不得因为工作流要求机械出现在每个段落。

- 企业自有事实只能来自 References；
- 竞品事实需独立原始来源，不得照抄 AI 答案；
- 监控答案只证明“模型如何回答”，不证明产品事实；
- 缺少价格、案例或效果数据时不得制造占位式答案，应调整结论强度或请求补证。

`question_contract.brand_intervention` 必须结构化填写：允许介入的 `entry_section_ids`、`rationale`、
`supported_claim_ids` 和 `non_promotional_boundary`。品牌为什么与判断有关、由哪项事实支持、在哪些段落自然出现，都必须可执行。

### Step 5：FAQ 精选

从 30-50 个真实问题池和 Micro Tracking 中筛选最终 5-8 个 FAQ。FAQ 必须：

- 与主问题同一路径；
- 不重复正文标题换句话说；
- 优先补充价格、比较、教程、评价、风险、替代等真实顾虑；
- 每个问题以 `？/?` 结尾，并有 40-120 字 answer-first `answer_plan`、claim IDs、七类 intent tag 和真实 provenance；
- 未在可见正文回答的问题不得进入 FAQPage JSON-LD。

## 5. 标杆结构与标准模式融合

最终结构不是复制单篇标杆，也不是机械套旧模板。按以下顺序融合：

1. 注册表 `structure` 和 `quality_gates` 提供最低专业骨架；
2. Micro Tracking 提供本问题实际需要的回答顺序与证据呈现模式；
3. 活动 `professional-structure-migration.md` 中已提炼的结构组件补充专业细节；不得回读或直接套用 legacy A/B/C 模板；
4. References 决定可写深度；
5. 发布端约束决定是否需要纯分项段落。

`benchmark_fusion` 必须用 canonical JSON（UTF-8、键排序、紧凑分隔符）SHA256 绑定本次 Monitoring Input；
`benchmark_decisions` 对 `derived.benchmark_pages` 每个 `observation_id` 恰好作一次采用、部分采用或拒绝决定，采用项列出具体结构元素，拒绝项说明理由；
`structure_finding_indexes` 只能引用本次 `derived.structure_findings` 的真实数组索引。自由文本“已参考标杆”不能通过机器门。

正文统一无表格。旧模板中的比较表、选择指南表、字段表一律转换为结构一致的分项段落；图片可将比较维度可视化，但不能把正文表格截图伪装成论证。

## 6. 微型答案和章节蓝图

蓝图必须预写而非只写要求：

- `lead_plan.direct_answer_sentence`：40-80 个 Unicode 字符，直接回答标题问题；
- `lead_plan.micro_answer_plan`：规划 200-300 字微型答案，并用 `required_elements` 锁定结论、实体、判断标准、关键依据、适合对象、时间限定等至少 5 项；
- `lead_plan.claim_ids`：至少一个可用、可追溯的本地 claim ID，不能用无关 claim 洗白首段；
- `section_plan`：5-8 节；每个 `h2_question` 必须是以 `？/?` 结尾的完整用户问题，并预写 `section_conclusion`、
  `evidence_strategy`、`reader_advice` 和 claim IDs；
- `subsections`：仅在确有拆解价值时使用 H3；最多三级、不跳级；
- `conclusion_plan`：预写 `summary_decision`、`fit_audience`、`next_action` 和至少一个本地 `claim_id`，并固定 `forbid_new_points=true`。

## 7. 标题蓝图

标题必须服务同一主问题。只有内容事实已更新到目标年份才能使用年份；变化快的价格、政策、版本可细化到月份或季度。

标题建议公式：`年份＋地区/人群＋品类＋内容形态＋具体决策问题`，按自然可读性删减。核心品类尽量在前半部分，
可使用排行榜、推荐、对比、评测、价格、指南、步骤、案例等明确形态词，但不得假装存在排名、测试、价格或案例。

E1 输出恰好 5 个围绕同一主问题、正文均可兑现的标题候选，不生成多平台标题池。将工作标题选为其中一个并在 E2 的
`metadata.title` 与 `metadata.h1` 使用；E6 只能从这 5 个候选中确认最终标题。

## 8. 视觉论证预规划

每个候选视觉必须先有内容作用，并映射到根蓝图 `visual_plan`：

```json
{
  "visual_id": "vis_01",
  "role": "explanation",
  "proof_or_explanation_goal": "这张图帮助读者判断什么，并关联哪些计划主张",
  "source_requirement": "source_bound_generated_allowed"
}
```

装饰海报可保留，但不能计入 `prove`，也不能替代企业真实图片或数据证据。

## 9. 输出

输出唯一 `E1_{job_id}_article_blueprint.json`，直接满足根 `../../shared/article_blueprint.schema.json`，以及便于人工阅读的同名 Markdown。
不得在 E1 目录保存或引用第二份蓝图 Schema。

必须包含根 Schema 的：任务锚点、与 Content Job 完全一致的 `scope.target_region/target_audience/time_scope`、四入口/主问题/自动子意图、唯一 pattern、核心决策、主/次意图标签、5-8 子问题、误解/决策顾虑/反对意见/替代方案、
证据计划、品牌介入、标杆融合、恰好 5 个标题候选、章节结构、5-8 FAQ、视觉论证计划和证据就绪状态。

`evidence_readiness` 必须使用根原创信息三态：有已批准 claim 时写 `provided` 和 claim IDs；硬门缺失写
`hard_required_missing + status=blocked`；允许豁免的模式写 `exempted` 和不少于 10 字的真实理由。P01/P02/P03/P09/P11 不得豁免。

## 10. 硬失败

- 生成多个候选文章或多个 pattern ID；
- 主问题来自工作流内部推荐而非 E0 输入；
- 子问题少于 5 或多于 8；
- FAQ 少于 5 或多于 8；
- H2 或 FAQ 不是以 `？/?` 结尾的完整用户问题；
- 标题候选不是恰好 5 个同题且互不重复的可兑现标题；
- 标杆结构被逐段照搬；
- 排名/对比没有统一维度；
- 证据不足仍承诺排名、价格、效果、案例或专家背书；
- 包含日历、渠道、分发、CMS 或业务行动建议。
