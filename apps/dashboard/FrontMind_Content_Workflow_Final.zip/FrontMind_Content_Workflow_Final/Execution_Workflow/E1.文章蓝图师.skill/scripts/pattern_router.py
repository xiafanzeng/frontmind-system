#!/usr/bin/env python3
"""Validate one root article_blueprint directly against the root pattern registry."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "shared"))
from schema_validation import validate_root  # noqa: E402
from text_quality import question_key_tokens, substantive_text_errors  # noqa: E402


TOP_REQUIRED = {
    "schema_version", "job_id", "question_category", "primary_question", "pattern_id", "routing_reason",
    "scope",
    "question_contract", "benchmark_fusion", "title_plan", "lead_plan", "section_plan", "claim_plan",
    "visual_plan", "faq_plan", "conclusion_plan", "evidence_readiness",
}
TOP_ALLOWED = TOP_REQUIRED | {"product_scenario_subintent"}
INTENT_TAGS = {"recommendation", "price", "comparison", "tutorial", "evaluation", "risk", "alternative"}


def exact_object(value: Any, required: set[str], allowed: set[str], label: str, errors: list[str]) -> dict[str, Any]:
    if not isinstance(value, dict):
        errors.append(f"{label} must be an object")
        return {}
    missing, extras = required - set(value), set(value) - allowed
    if missing or extras:
        errors.append(f"{label} fields mismatch: missing={sorted(missing)}, extras={sorted(extras)}")
    return value


def valid_strings(value: Any, minimum: int = 0, maximum: int | None = None, unique: bool = False) -> bool:
    if not isinstance(value, list) or len(value) < minimum or (maximum is not None and len(value) > maximum):
        return False
    if not all(isinstance(item, str) and item.strip() for item in value):
        return False
    return not unique or len(value) == len(set(value))


def validate_blueprint_contract(blueprint: dict[str, Any], errors: list[str]) -> None:
    exact_object(blueprint, TOP_REQUIRED, TOP_ALLOWED, "blueprint", errors)
    if not str(blueprint.get("job_id", "")).startswith("job_"):
        errors.append("blueprint.job_id must start with job_")
    primary = str(blueprint.get("primary_question", "")).strip()
    if not 4 <= len(primary) <= 300:
        errors.append("primary_question must contain 4-300 Unicode characters")
    if len(str(blueprint.get("routing_reason", "")).strip()) < 20:
        errors.append("routing_reason must contain at least 20 Unicode characters")

    question_required = {
        "primary_question", "primary_intent_tag", "secondary_intent_tags", "direct_decision",
        "necessary_subquestions", "misconceptions", "decision_concerns", "objections", "alternatives",
        "evidence_needed", "brand_intervention",
    }
    question = exact_object(blueprint.get("question_contract"), question_required, question_required, "question_contract", errors)
    if question.get("primary_question") != primary:
        errors.append("question_contract.primary_question must equal blueprint.primary_question")
    if question.get("primary_intent_tag") not in INTENT_TAGS:
        errors.append("question_contract.primary_intent_tag is invalid")
    secondary = question.get("secondary_intent_tags")
    if not isinstance(secondary, list) or len(secondary) > 3 or len(secondary) != len(set(secondary or [])) or set(secondary or []) - INTENT_TAGS:
        errors.append("question_contract.secondary_intent_tags is invalid")
    if len(str(question.get("direct_decision", "")).strip()) < 10:
        errors.append("question_contract.direct_decision is too short")
    for key, minimum, maximum, unique in (
        ("necessary_subquestions", 5, 8, True), ("misconceptions", 0, 8, False),
        ("decision_concerns", 1, 8, True), ("objections", 0, 8, False),
        ("alternatives", 0, 8, True), ("evidence_needed", 1, None, False),
    ):
        if not valid_strings(question.get(key), minimum, maximum, unique):
            errors.append(f"question_contract.{key} has invalid type/count/values")
    brand_required = {"entry_section_ids", "rationale", "supported_claim_ids", "non_promotional_boundary"}
    brand = exact_object(question.get("brand_intervention"), brand_required, brand_required, "brand_intervention", errors)
    if not valid_strings(brand.get("entry_section_ids"), 1, None, True):
        errors.append("brand_intervention.entry_section_ids must be non-empty and unique")
    if len(str(brand.get("rationale", "")).strip()) < 10 or len(str(brand.get("non_promotional_boundary", "")).strip()) < 10:
        errors.append("brand_intervention rationale/boundary is too short")
    if not isinstance(brand.get("supported_claim_ids"), list) or len(brand.get("supported_claim_ids", [])) != len(set(brand.get("supported_claim_ids", []))):
        errors.append("brand_intervention.supported_claim_ids must be a unique array")

    benchmark_required = {
        "status", "monitoring_input_sha256", "benchmark_decisions", "structure_finding_indexes",
        "retained_template_elements", "benchmark_elements_adopted", "elements_rejected", "final_structure_rationale",
    }
    benchmark = exact_object(blueprint.get("benchmark_fusion"), benchmark_required, benchmark_required, "benchmark_fusion", errors)
    if benchmark.get("status") not in {"available", "partial"} or len(str(benchmark.get("final_structure_rationale", "")).strip()) < 10:
        errors.append("benchmark_fusion status/rationale invalid")
    for key in ("retained_template_elements", "benchmark_elements_adopted", "elements_rejected"):
        if not isinstance(benchmark.get(key), list) or not all(isinstance(item, str) for item in benchmark.get(key, [])):
            errors.append(f"benchmark_fusion.{key} must be a string array")
    if not re.fullmatch(r"[a-f0-9]{64}", str(benchmark.get("monitoring_input_sha256", ""))):
        errors.append("benchmark_fusion.monitoring_input_sha256 is invalid")
    if not isinstance(benchmark.get("benchmark_decisions"), list) or not benchmark.get("benchmark_decisions"):
        errors.append("benchmark_fusion.benchmark_decisions must be non-empty")
    if not isinstance(benchmark.get("structure_finding_indexes"), list):
        errors.append("benchmark_fusion.structure_finding_indexes must be an array")

    title = exact_object(blueprint.get("title_plan"), {"title_formula", "title_candidates"}, {"title_formula", "title_candidates"}, "title_plan", errors)
    candidates = title.get("title_candidates")
    if not valid_strings(candidates, 5, 5, True) or any(not 6 <= len(item) <= 120 for item in candidates or []):
        errors.append("title_plan.title_candidates must contain five unique 6-120 character titles")
    if not str(title.get("title_formula", "")).strip():
        errors.append("title_plan.title_formula is required")

    lead_required = {"direct_answer_sentence", "micro_answer_plan", "required_elements", "claim_ids"}
    lead = exact_object(blueprint.get("lead_plan"), lead_required, lead_required, "lead_plan", errors)
    if not 40 <= len(str(lead.get("direct_answer_sentence", "")).strip()) <= 80:
        errors.append("lead_plan.direct_answer_sentence must contain 40-80 Unicode characters")
    direct_plan = str(lead.get("direct_answer_sentence", "")).strip()
    errors.extend(substantive_text_errors(
        direct_plan, label="lead_plan.direct_answer_sentence", minimum=30, ratio=0.55, minimum_unique=8,
    ))
    tokens = question_key_tokens(primary)
    if not tokens or not any(token in direct_plan.lower() for token in tokens):
        errors.append("lead_plan.direct_answer_sentence must contain a primary-question/entity key token")
    if not 40 <= len(str(lead.get("micro_answer_plan", "")).strip()) <= 600:
        errors.append("lead_plan.micro_answer_plan must contain 40-600 Unicode characters")
    errors.extend(substantive_text_errors(
        str(lead.get("micro_answer_plan", "")), label="lead_plan.micro_answer_plan",
        minimum=30, ratio=0.55, minimum_unique=8,
    ))
    required_elements = lead.get("required_elements")
    allowed_elements = {"explicit_conclusion", "judgment_criteria", "key_data", "fit_audience", "time_scope", "necessary_qualification", "named_entities"}
    if not isinstance(required_elements, list) or len(required_elements) < 5 or len(required_elements) != len(set(required_elements or [])) or set(required_elements or []) - allowed_elements:
        errors.append("lead_plan.required_elements is invalid")
    if not valid_strings(lead.get("claim_ids"), 1, None, True) or any(not str(value).startswith("clm_") for value in lead.get("claim_ids", [])):
        errors.append("lead_plan.claim_ids must contain at least one unique clm_ ID")

    sections = blueprint.get("section_plan")
    if not isinstance(sections, list) or not 5 <= len(sections) <= 8:
        errors.append("section_plan must contain 5-8 items")
        sections = []
    section_required = {"section_id", "h2_question", "answer_goal", "section_conclusion", "evidence_strategy", "reader_advice", "claim_ids", "suggested_length"}
    section_ids: list[str] = []
    for index, item in enumerate(sections):
        section = exact_object(item, section_required, section_required, f"section_plan[{index}]", errors)
        section_id = str(section.get("section_id", "")); section_ids.append(section_id)
        if not re.fullmatch(r"sec_[a-z0-9_-]+", section_id):
            errors.append(f"section_plan[{index}].section_id invalid")
        if not str(section.get("h2_question", "")).strip().endswith(("？", "?")):
            errors.append(f"section_plan[{index}].h2_question must be a complete question")
        for key, minimum in (("answer_goal", 10), ("section_conclusion", 10), ("evidence_strategy", 10), ("reader_advice", 5)):
            if len(str(section.get(key, "")).strip()) < minimum:
                errors.append(f"section_plan[{index}].{key} is too short")
        if not isinstance(section.get("claim_ids"), list) or len(section.get("claim_ids", [])) != len(set(section.get("claim_ids", []))):
            errors.append(f"section_plan[{index}].claim_ids must be unique")
        length = section.get("suggested_length")
        if not isinstance(length, int) or isinstance(length, bool) or not 100 <= length <= 4000:
            errors.append(f"section_plan[{index}].suggested_length invalid")
    if len(section_ids) != len(set(section_ids)):
        errors.append("section_plan.section_id values must be unique")
    if set(brand.get("entry_section_ids", [])) - set(section_ids):
        errors.append("brand_intervention.entry_section_ids reference unknown sections")

    claim_plan = blueprint.get("claim_plan")
    if not isinstance(claim_plan, list) or len(claim_plan) != len(set(claim_plan or [])) or any(not str(value).startswith("clm_") for value in claim_plan or []):
        errors.append("claim_plan must be a unique clm_ array")
        claim_plan = []
    referenced_claims = set(brand.get("supported_claim_ids", []))
    referenced_claims.update(value for section in sections for value in section.get("claim_ids", []) if isinstance(section, dict))

    visuals = blueprint.get("visual_plan")
    if not isinstance(visuals, list):
        errors.append("visual_plan must be an array"); visuals = []
    visual_required = {"visual_id", "role", "proof_or_explanation_goal", "source_requirement"}
    visual_ids = []
    for index, item in enumerate(visuals):
        visual = exact_object(item, visual_required, visual_required, f"visual_plan[{index}]", errors)
        visual_ids.append(visual.get("visual_id"))
        if not str(visual.get("visual_id", "")).startswith("vis_") or visual.get("role") not in {"cover", "proof", "comparison", "process", "data", "explanation"}:
            errors.append(f"visual_plan[{index}] id/role invalid")
        if len(str(visual.get("proof_or_explanation_goal", "")).strip()) < 10 or visual.get("source_requirement") not in {"client_submitted_required", "source_bound_generated_allowed", "optional"}:
            errors.append(f"visual_plan[{index}] goal/source requirement invalid")
    if len(visual_ids) != len(set(visual_ids)):
        errors.append("visual_plan.visual_id values must be unique")

    faqs = blueprint.get("faq_plan")
    if not isinstance(faqs, list) or not 5 <= len(faqs) <= 8:
        errors.append("faq_plan must contain 5-8 items"); faqs = []
    faq_required = {"question", "answer_plan", "claim_ids", "intent_tag", "provenance"}
    for index, item in enumerate(faqs):
        faq = exact_object(item, faq_required, faq_required, f"faq_plan[{index}]", errors)
        if not str(faq.get("question", "")).strip().endswith(("？", "?")) or not 40 <= len(str(faq.get("answer_plan", "")).strip()) <= 120:
            errors.append(f"faq_plan[{index}] question/answer_plan invalid")
        if faq.get("intent_tag") not in INTENT_TAGS or not isinstance(faq.get("claim_ids"), list):
            errors.append(f"faq_plan[{index}] intent_tag/claim_ids invalid")
        referenced_claims.update(faq.get("claim_ids", []) if isinstance(faq.get("claim_ids"), list) else [])
        provenance = exact_object(faq.get("provenance"), {"kind", "reference_ids"}, {"kind", "reference_ids"}, f"faq_plan[{index}].provenance", errors)
        if provenance.get("kind") not in {"faq_library", "monitoring", "customer_consultation", "sales_record", "ai_search_suggestion", "derived_from_primary_question"}:
            errors.append(f"faq_plan[{index}].provenance.kind invalid")
        if not isinstance(provenance.get("reference_ids"), list) or len(provenance.get("reference_ids", [])) != len(set(provenance.get("reference_ids", []))):
            errors.append(f"faq_plan[{index}].provenance.reference_ids invalid")

    conclusion_required = {"summary_decision", "fit_audience", "next_action", "forbid_new_points", "claim_ids"}
    conclusion = exact_object(blueprint.get("conclusion_plan"), conclusion_required, conclusion_required, "conclusion_plan", errors)
    if len(str(conclusion.get("summary_decision", "")).strip()) < 10 or len(str(conclusion.get("fit_audience", "")).strip()) < 5 or len(str(conclusion.get("next_action", "")).strip()) < 5 or conclusion.get("forbid_new_points") is not True:
        errors.append("conclusion_plan is incomplete")
    if not valid_strings(conclusion.get("claim_ids"), 1, None, True) or any(not str(value).startswith("clm_") for value in conclusion.get("claim_ids", [])):
        errors.append("conclusion_plan.claim_ids must contain at least one unique clm_ ID")

    readiness_required = {"status", "missing_evidence", "original_information_status", "original_information_claim_ids", "exemption_reason"}
    readiness = exact_object(blueprint.get("evidence_readiness"), readiness_required, readiness_required, "evidence_readiness", errors)
    if readiness.get("status") not in {"ready", "ready_with_narrowed_claims", "blocked"} or not isinstance(readiness.get("missing_evidence"), list):
        errors.append("evidence_readiness status/missing_evidence invalid")
    original_ids = readiness.get("original_information_claim_ids")
    if not isinstance(original_ids, list) or len(original_ids) != len(set(original_ids or [])):
        errors.append("evidence_readiness.original_information_claim_ids must be unique")
        original_ids = []
    referenced_claims.update(original_ids)
    referenced_claims.update(lead.get("claim_ids", []))
    referenced_claims.update(conclusion.get("claim_ids", []))
    if referenced_claims - set(claim_plan):
        errors.append(f"blueprint references claim IDs absent from claim_plan: {sorted(referenced_claims - set(claim_plan))}")
    original_status = readiness.get("original_information_status")
    reason = readiness.get("exemption_reason")
    if original_status == "provided" and (not original_ids or reason is not None):
        errors.append("provided original information requires IDs and null exemption_reason")
    elif original_status == "hard_required_missing" and (readiness.get("status") != "blocked" or original_ids or reason is not None):
        errors.append("hard_required_missing state is invalid")
    elif original_status == "exempted" and (original_ids or len(str(reason or "").strip()) < 10):
        errors.append("exempted state is invalid")
    elif original_status not in {"provided", "hard_required_missing", "exempted"}:
        errors.append("original_information_status is invalid")


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain an object")
    return value


def ids(registry: dict[str, Any], key: str) -> set[str]:
    return {str(item.get("id")) for item in registry.get(key, []) if isinstance(item, dict) and item.get("id")}


def canonical_sha256(value: dict[str, Any]) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def validate(
    registry: dict[str, Any], blueprint: dict[str, Any], monitoring: dict[str, Any], content_job: dict[str, Any],
) -> dict[str, Any]:
    errors: list[str] = []
    try:
        validate_root(blueprint, "article_blueprint.schema.json", "E1 article_blueprint")
    except ValueError as exc:
        errors.append(str(exc))
    validate_blueprint_contract(blueprint, errors)
    try:
        validate_root(content_job, "content_job.schema.json", "E1 content_job")
    except ValueError as exc:
        errors.append(str(exc))
    question = content_job.get("question") if isinstance(content_job.get("question"), dict) else {}
    if content_job.get("job_id") != blueprint.get("job_id"):
        errors.append("content_job job_id does not bind this blueprint")
    for job_key, blueprint_key in (
        ("text", "primary_question"), ("category", "question_category"),
        ("product_scenario_subintent", "product_scenario_subintent"),
    ):
        if question.get(job_key) != blueprint.get(blueprint_key):
            # Missing product subintent is intentionally inferred by E1.
            if not (job_key == "product_scenario_subintent" and question.get(job_key) is None):
                errors.append(f"content_job question {job_key} differs from blueprint {blueprint_key}")
    scope = blueprint.get("scope") if isinstance(blueprint.get("scope"), dict) else {}
    for key in ("target_region", "target_audience", "time_scope"):
        if scope.get(key) != question.get(key):
            errors.append(f"blueprint.scope.{key} differs from content_job.question.{key}")
    try:
        validate_root(monitoring, "monitoring_input.schema.json", "E1 monitoring_input")
    except ValueError as exc:
        errors.append(str(exc))
    if monitoring.get("schema_version") != "1.0.0" or monitoring.get("job_id") != blueprint.get("job_id"):
        errors.append("monitoring_input schema/job does not bind this blueprint")
    if monitoring.get("question") != blueprint.get("primary_question"):
        errors.append("monitoring_input question does not equal blueprint.primary_question")
    benchmark = blueprint.get("benchmark_fusion") if isinstance(blueprint.get("benchmark_fusion"), dict) else {}
    monitoring_sha256 = canonical_sha256(monitoring)
    if benchmark.get("monitoring_input_sha256") != monitoring_sha256:
        errors.append("benchmark_fusion.monitoring_input_sha256 mismatch")
    derived = monitoring.get("derived") if isinstance(monitoring.get("derived"), dict) else {}
    benchmark_ids = {
        str(item.get("observation_id")) for item in derived.get("benchmark_pages", []) if isinstance(item, dict)
    }
    decisions = benchmark.get("benchmark_decisions") if isinstance(benchmark.get("benchmark_decisions"), list) else []
    decision_ids = [str(item.get("observation_id")) for item in decisions if isinstance(item, dict)]
    if len(decision_ids) != len(set(decision_ids)) or set(decision_ids) != benchmark_ids:
        errors.append("benchmark_decisions must cover every and only monitoring benchmark page exactly once")
    for index, decision in enumerate(decisions):
        if not isinstance(decision, dict):
            errors.append(f"benchmark_decisions[{index}] must be an object")
            continue
        disposition = decision.get("disposition")
        elements = decision.get("adopted_elements")
        if disposition in {"adopted", "partially_adopted"} and (not isinstance(elements, list) or not elements):
            errors.append(f"benchmark_decisions[{index}] adopted decision needs adopted_elements")
        if disposition == "rejected" and elements:
            errors.append(f"benchmark_decisions[{index}] rejected decision must not adopt elements")
    findings = derived.get("structure_findings") if isinstance(derived.get("structure_findings"), list) else []
    finding_indexes = benchmark.get("structure_finding_indexes")
    if not isinstance(finding_indexes, list) or any(
        not isinstance(value, int) or isinstance(value, bool) or value < 0 or value >= len(findings)
        for value in finding_indexes or []
    ):
        errors.append("benchmark_fusion.structure_finding_indexes references missing monitoring findings")
    category, subintent, pattern_id = (
        blueprint.get("question_category"), blueprint.get("product_scenario_subintent"), blueprint.get("pattern_id")
    )
    if registry.get("schema_version") != "1.0.0" or blueprint.get("schema_version") != "1.0.0":
        errors.append("registry and blueprint must use schema_version=1.0.0")
    if category not in ids(registry, "canonical_question_categories"):
        errors.append(f"unknown question_category: {category}")
    if category == "product_scenario":
        if subintent not in ids(registry, "product_scenario_subintents"):
            errors.append(f"invalid product_scenario_subintent: {subintent}")
    elif subintent is not None:
        errors.append("non-product blueprint must set product_scenario_subintent=null")
    patterns = {str(item.get("id")): item for item in registry.get("patterns", []) if isinstance(item, dict)}
    if not isinstance(pattern_id, str) or pattern_id not in patterns:
        errors.append(f"blueprint must select exactly one valid pattern_id: {pattern_id}")
    route = registry.get("routing", {}).get(category, {}) if isinstance(registry.get("routing"), dict) else {}
    category_allowed = set(route.get("primary_patterns", [])) | set(route.get("secondary_patterns", []))
    if pattern_id and pattern_id not in category_allowed:
        errors.append(f"pattern {pattern_id} is not routed for category {category}")
    if category == "product_scenario" and pattern_id in set(route.get("primary_patterns", [])):
        subintent_allowed = set(route.get("subintent_routing", {}).get(subintent, []))
        if pattern_id not in subintent_allowed:
            errors.append(f"primary pattern {pattern_id} is incompatible with product subintent {subintent}")
    if not str(blueprint.get("routing_reason", "")).strip():
        errors.append("routing_reason is required")
    evidence = blueprint.get("evidence_readiness") if isinstance(blueprint.get("evidence_readiness"), dict) else {}
    original_status = evidence.get("original_information_status")
    hard_patterns = set(registry.get("original_information_gate", {}).get("hard_required_patterns", []))
    if pattern_id in hard_patterns and original_status == "exempted":
        errors.append(f"hard-required pattern {pattern_id} cannot exempt original information")
    if original_status == "provided" and not evidence.get("original_information_claim_ids"):
        errors.append("provided original information requires claim IDs")
    if original_status == "hard_required_missing" and evidence.get("status") != "blocked":
        errors.append("hard_required_missing requires evidence_readiness.status=blocked")
    if original_status == "exempted" and len(str(evidence.get("exemption_reason") or "").strip()) < 10:
        errors.append("exempted original information requires a substantive exemption_reason")
    return {
        "schema_version": "1.0.0", "job_id": blueprint.get("job_id"), "stage": "E1_pattern_validation",
        "valid": not errors, "pattern_id": pattern_id, "question_category": category,
        "product_scenario_subintent": subintent, "registry_schema_version": registry.get("schema_version"), "errors": errors,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command", required=True)
    command = subparsers.add_parser("validate")
    command.add_argument("--registry", type=Path, required=True)
    command.add_argument("--blueprint", type=Path, required=True)
    command.add_argument("--monitoring-input", type=Path, required=True)
    command.add_argument("--content-job", type=Path, required=True)
    command.add_argument("--report", type=Path)
    args = parser.parse_args()
    result = validate(
        load(args.registry), load(args.blueprint), load(args.monitoring_input), load(args.content_job),
    )
    rendered = json.dumps(result, ensure_ascii=False, indent=2)
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(rendered, encoding="utf-8")
    print(rendered)
    return 0 if result["valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
