---
name: frontmind-evidence-preflight-editor
description: >
  E2.5 证据预检师。在正文投入视觉和最终编辑前，逐项核对问题覆盖、主张证据、原始来源、数据限定、竞品同维度公平、价格版本、案例与专家信息，
  输出机器可执行的证据预检报告。任何重要无证据主张都打回 E2；不改写正文、不生成视觉、不做最终发布审核。
---

# E2.5 证据预检师

## 1. 为什么单独存在

旧流程把大量证据检查留到 E4，导致图片已经制作、正文已经组装后才发现根本事实不足。本节点将证据门前移，但不取代 E4 的编辑终审。

## 2. 输入

- E0 content job；
- E0.5 根 monitoring input；
- E1 article blueprint；
- E2 根 canonical content model draft；
- References 原文件、job-local runtime claim/source registries 与 E0 runtime evidence receipt；
- 符合 `templates/evidence_semantic_review.schema.json` 的逐主张语义复核回执，绑定正文 evidence projection、claim/source Registry 与可选竞品矩阵哈希；
- 根 P 注册表中当前模式的 `required_evidence` 和 `quality_gates`。

## 3. 七项预检

### Gate A：主问题和子问题覆盖

建立 `question_coverage`：主问题必须由第一句和微型答案直接回答；E1 的 5-8 个必要子问题逐项出现在
Content Model 的 `subquestion_coverage`，且绑定存在的 `section_id` 与正文 block。
仅出现关键词不算回答，必须有结论、证据或明确无数据的诚实处理；5-8 个 H2 和 FAQ 问题均必须是以 `？/?` 结尾的完整问题。

### Gate B：主张—来源闭环

逐个检查所有 material claim，而非抽样五项。每项必须：

- 有 source ID；
- source ID 对应真实可访问文件或 URL；
- 摘录或结构化事实实际支持主张；
- 主张强度不超过来源；
- 企业自述、第三方观点、监控观察和原始数据类型没有混淆。
- Lead、block、FAQ 和 conclusion 使用各自字段上的 claim IDs；`factual_claim/analysis/factual_answer` 必须非空，advice/instruction
  出现数字、价格、年份、排名、研究结果或实体能力断言时也必须绑定；
- claim 文本/摘录与被绑定字段共享实体和充分语义锚点。合法但与本句无关的 claim 同样失败；R0 新产 claim 必须填写非空 `about_entities`。

找不到依据时状态为 `fail`，不能自动改成“相关资料显示”。

### Gate C：数据、价格、规格和专家

- 统计数据：时间、样本量、单位、地区/人群、统计口径；
- 价格：币种、套餐、地区、版本、有效日期、附加条件；
- 规格：完整产品/型号/版本与适用条件；
- 专家：姓名、机构、身份、观点适用范围和原始出处。

缺少必要限定时打回或降低为定性描述。

### Gate D：竞品公平

凡涉及两个以上对象，输出符合 `templates/competitor_dimension_matrix.schema.json` 的 `competitor_dimension_matrix`。每个对象×维度单元都要写
`availability/value/source_ids/as_of/scope/conditions`：有数据时值、来源、日期和范围均不得为空；无公开数据/不适用时 value 必须为 null 并说明原因。
所有对象使用完全相同维度和同一维度的相同时间点，不能用空对象或字段名存在假装完成覆盖。

禁止：自有品牌固定详写、竞品固定简写；只写竞品缺点；用竞品未公开数据证明其能力较差；把 AI 答案顺序当排名；改变币种/套餐造成虚假对比。

### Gate E：排名与原创信息

排名/推荐必须有样本范围、入选标准、评价维度、来源、统计日期和排序依据。若声称原创测试、调查、价格采样或项目记录，
必须在根 claim 的 `original_evidence` 中保留原始文件或记录、方法、范围、采集时间和公开授权；否则删除“原创/实测/调研”表述。

按根 Registry 的 `original_information_gate.machine_contract` 执行：P01/P02/P03/P09/P11 至少有 1 个被正文实际引用、
`authorization_status=public_approved|anonymized_approved` 且可追溯的原创证据 claim；P06 在比较两个以上对象的价格/套餐/总成本时同样是硬门。
其他模式只有提供明确豁免原因并撤掉“独立测试、最佳、领先、权威排名、原创数据结论”等主张后才可豁免。

### Gate F：案例完整性

案例至少有背景、问题、动作、结果、周期及授权状态。结果数据需有单位、基线/比较点和时间。匿名案例也必须说明可披露范围，
不能虚构客户名或把一般能力写成已完成项目。

### Gate G：引用完整性

重要事实在可见正文附近出现原始来源名称；文末 source ledger 提供完整信息。不能只写裸序号、内部路径或“据有关数据”。
文末可见 references 集合必须与正文实际使用 claim 的来源集合完全相等；额外“垫权威”来源、隐藏原创来源或只有内部 record path 而无可公开来源身份，均为阻断项。

## 4. 输出与修复循环

输出 `E2.5_{job_id}_evidence_preflight.json`，满足本阶段 `templates/evidence_preflight.schema.json`；该报告不是 Content Model 或根 Registry 的替代品：

- `status=passed|repair_required|blocked`；原创信息硬门失败必须是 `blocked`；
- `question_coverage`；
- `claim_checks`；
- `source_checks`；
- `competitor_dimension_matrix`；
- `special_evidence_checks`；
- `blocking_findings`；
- `repair_instructions`。

语义复核不能在脚本之后以口头方式补做。证据编辑必须先逐项审阅正文实际使用的全部 claim，填写 `supported/not_supported` 与理由；
`scripts/evidence_preflight.py` 同时校验该回执的完整覆盖、结论与所有 canonical SHA-256，并把 `semantic_review_sha256/status` 写入预检报告。
E4 和 E6 都会再次消费同一回执；复制旧 job 回执或仅填写合法 claim ID 均不能通过。

报告同时保留 draft 的 `content_model_sha256` 和 `evidence_projection_sha256`。后者以 canonical JSON（UTF-8、键排序、紧凑分隔符）计算，
包含全部非视觉正文和 claim 结构，只排除 `revision` 与 E3 所有的 `visual_placements`。因此 E3 可以补视觉；正文、标题、FAQ、claim IDs 或来源
发生变化则必须重跑 E2.5。E4 以该投影核验 E3 没有偷改正文。

`repair_required` 时只能回 E2：补来源、删除/限定主张、补齐公平维度或调整结构。E2 修改后必须重新完整运行 E2.5，禁止只复查单项。

## 5. 进入 E3 的条件

- 所有 material claims 为 supported 或有明确、读者可见的合理限定；
- 主问题和全部必要子问题均有覆盖；
- 排名/对比/价格/案例等模式专项证据满足根注册表；
- 竞品公平矩阵无 asymmetric treatment；
- 视觉计划中的 prove 图只绑定已通过的 claim IDs。

按包根 [运行手册](../../RUNBOOK.md) 的 E2.5 完整参数运行 `scripts/evidence_preflight.py`，其中 `--semantic-review`、runtime receipt、双 package roots 和
`competitor_matrix`（适用时）不可省略。脚本与语义回执必须共同通过，才可进入 E3。
