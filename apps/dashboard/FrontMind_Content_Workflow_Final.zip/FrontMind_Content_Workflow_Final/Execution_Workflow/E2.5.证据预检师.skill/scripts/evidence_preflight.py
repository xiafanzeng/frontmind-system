#!/usr/bin/env python3
"""Deterministic evidence preflight for root Content Model + registries."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

sys.dont_write_bytecode = True
from matrix_contract import competitor_matrix_requirement, validate_competitor_matrix

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "shared"))
from schema_validation import validate_root, validate_schema  # noqa: E402
from text_quality import material_claim_binding_errors  # noqa: E402
from content_projections import evidence_projection_sha256  # noqa: E402
from registry_binding import canonical_sha256, validate_registry_binding  # noqa: E402
from reference_equivalence import reference_source_contract  # noqa: E402


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain an object")
    return value


def digest(value: dict[str, Any]) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def file_digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def resolve_inside(root: Path, stored: str) -> Path | None:
    path = Path(stored)
    if not stored or path.is_absolute() or ".." in path.parts or "\\" in stored:
        return None
    resolved = (root / path).resolve()
    try:
        resolved.relative_to(root.resolve())
    except ValueError:
        return None
    return resolved


def safe_web_url(value: Any) -> bool:
    if value is None:
        return True
    if not isinstance(value, str) or not value.strip() or any(char.isspace() for char in value):
        return False
    try:
        parsed = urlsplit(value)
    except ValueError:
        return False
    return parsed.scheme.lower() in {"http", "https"} and bool(parsed.hostname)


def referenced_claim_ids(model: dict[str, Any]) -> set[str]:
    result: set[str] = set()
    lead = model.get("lead", {})
    if isinstance(lead, dict):
        result.update(str(value) for value in lead.get("claim_ids", []))
    for section in model.get("sections", []):
        if not isinstance(section, dict):
            continue
        groups = [section.get("blocks", [])]
        groups += [item.get("blocks", []) for item in section.get("subsections", []) if isinstance(item, dict)]
        for blocks in groups:
            for block in blocks:
                if isinstance(block, dict):
                    result.update(str(value) for value in block.get("claim_ids", []))
    for item in model.get("faq", []):
        if isinstance(item, dict):
            result.update(str(value) for value in item.get("claim_ids", []))
    conclusion = model.get("conclusion", {})
    if isinstance(conclusion, dict):
        result.update(str(value) for value in conclusion.get("claim_ids", []))
    return result


def visible_text(model: dict[str, Any]) -> str:
    metadata, lead = model.get("metadata", {}), model.get("lead", {})
    chunks: list[str] = [
        str(metadata.get("title", "")), str(metadata.get("h1", "")), str(metadata.get("meta_description", "")),
        str(lead.get("direct_answer_sentence", "")), str(lead.get("micro_answer", "")),
    ]
    for section in model.get("sections", []):
        if not isinstance(section, dict):
            continue
        chunks.append(str(section.get("h2_question", "")))
        groups = [section.get("blocks", [])] + [item.get("blocks", []) for item in section.get("subsections", []) if isinstance(item, dict)]
        for group in groups:
            for block in group:
                if isinstance(block, dict):
                    chunks.append(str(block.get("text", "")))
                    chunks.extend(str(value) for value in block.get("items", []) or [])
    for item in model.get("faq", []):
        if isinstance(item, dict):
            chunks.extend((str(item.get("question", "")), str(item.get("answer", ""))))
    conclusion = model.get("conclusion") or {}
    if isinstance(conclusion, dict):
        chunks.extend(str(conclusion.get(key, "")) for key in ("summary", "fit", "next_action"))
    return "\n".join(chunks)


def check_context(claim: dict[str, Any]) -> list[str]:
    missing: list[str] = []
    claim_type = claim.get("claim_type")
    if claim_type == "statistic":
        context = claim.get("statistical_context") or {}
        for key in ("sample_size", "unit", "region_or_population", "methodology"):
            if not context.get(key):
                missing.append(f"statistical_context.{key}")
        if not claim.get("as_of"):
            missing.append("as_of")
    elif claim_type == "price":
        context = claim.get("commercial_context") or {}
        for key in ("currency", "plan", "region", "version", "valid_until", "conditions"):
            if not context.get(key):
                missing.append(f"commercial_context.{key}")
    elif claim_type in {"specification", "case_result", "expert_opinion", "event"}:
        if not claim.get("scope"):
            missing.append("scope")
        if not claim.get("as_of"):
            missing.append("as_of")
        if not claim.get("evidence_excerpt"):
            missing.append("evidence_excerpt")
    return missing


def check(model: dict[str, Any], blueprint: dict[str, Any], claim_registry: dict[str, Any],
          source_registry: dict[str, Any], pattern_registry: dict[str, Any],
          competitor_matrix: dict[str, Any] | None, content_job: dict[str, Any],
          intake_report: dict[str, Any], runtime_evidence_receipt: dict[str, Any],
          semantic_review: dict[str, Any],
          base_package_root: Path, job_package_root: Path) -> dict[str, Any]:
    findings: list[dict[str, Any]] = []
    for value, schema_name, label in (
        (model, "content_model.schema.json", "E2.5 content_model"),
        (blueprint, "article_blueprint.schema.json", "E2.5 article_blueprint"),
        (claim_registry, "registries.schema.json", "E2.5 claim_registry"),
        (source_registry, "registries.schema.json", "E2.5 source_registry"),
        (content_job, "content_job.schema.json", "E2.5 content_job"),
    ):
        try:
            validate_root(value, schema_name, label)
        except ValueError as exc:
            findings.append({"code": "CANONICAL_SCHEMA_FAILURE", "message": str(exc)})
    try:
        validate_schema(
            runtime_evidence_receipt,
            Path(__file__).resolve().parents[2] / "E0.单篇执行编排师.skill" / "templates" / "runtime_evidence_bundle_receipt.schema.json",
            "E2.5 runtime evidence receipt",
        )
        validate_registry_binding(
            intake_report=intake_report, job_id=model.get("job_id"),
            claim_registry=claim_registry, source_registry=source_registry,
            runtime_receipt=runtime_evidence_receipt,
        )
    except ValueError as exc:
        findings.append({"code": "REGISTRY_BINDING_FAILURE", "message": str(exc)})
    pattern_registry_sha256 = canonical_sha256(pattern_registry)
    if intake_report.get("content_pattern_registry_sha256") != pattern_registry_sha256:
        findings.append({"code": "PATTERN_REGISTRY_BINDING_FAILURE"})
    question = content_job.get("question") if isinstance(content_job.get("question"), dict) else {}
    if content_job.get("job_id") != model.get("job_id"):
        findings.append({"code": "CONTENT_JOB_ID_MISMATCH"})
    for key in ("target_region", "target_audience", "time_scope"):
        if (
            model.get("metadata", {}).get(key) != blueprint.get("scope", {}).get(key)
            or model.get("metadata", {}).get(key) != question.get(key)
        ):
            findings.append({"code": "SCOPE_MISMATCH", "field": key})
    if competitor_matrix:
        try:
            validate_schema(
                competitor_matrix,
                Path(__file__).resolve().parents[1] / "templates" / "competitor_dimension_matrix.schema.json",
                "E2.5 competitor_dimension_matrix",
            )
        except ValueError as exc:
            findings.append({"code": "COMPETITOR_MATRIX_SCHEMA_FAILURE", "message": str(exc)})
    claims = {str(item.get("claim_id")): item for item in claim_registry.get("claims", []) if isinstance(item, dict)}
    sources = {str(item.get("source_id")): item for item in source_registry.get("sources", []) if isinstance(item, dict)}
    used = referenced_claim_ids(model)
    try:
        validate_schema(
            semantic_review,
            Path(__file__).resolve().parents[1] / "templates" / "evidence_semantic_review.schema.json",
            "E2.5 evidence semantic review",
        )
    except ValueError as exc:
        findings.append({"code": "SEMANTIC_REVIEW_SCHEMA_FAILURE", "message": str(exc)})
    semantic_claim_reviews = [
        item for item in semantic_review.get("claim_reviews", []) if isinstance(item, dict)
    ]
    semantic_claim_ids = [str(item.get("claim_id")) for item in semantic_claim_reviews]
    semantic_identity_ok = (
        semantic_review.get("job_id") == model.get("job_id")
        and semantic_review.get("evidence_projection_sha256") == evidence_projection_sha256(model)
        and semantic_review.get("claim_registry_sha256") == canonical_sha256(claim_registry)
        and semantic_review.get("source_registry_sha256") == canonical_sha256(source_registry)
        and semantic_review.get("competitor_matrix_sha256") == (
            canonical_sha256(competitor_matrix) if competitor_matrix else None
        )
    )
    semantic_decisions_ok = (
        len(semantic_claim_ids) == len(set(semantic_claim_ids))
        and set(semantic_claim_ids) == used
        and all(item.get("decision") == "supported" for item in semantic_claim_reviews)
        and semantic_review.get("scope_and_limitations_passed") is True
        and semantic_review.get("unbound_material_claims_absent") is True
        and semantic_review.get("competitor_fairness_status") in {"passed", "not_applicable"}
        and semantic_review.get("original_information_status") in {"passed", "not_applicable"}
        and semantic_review.get("overall_status") == "passed"
    )
    if not semantic_identity_ok or not semantic_decisions_ok:
        findings.append({
            "code": "SEMANTIC_EVIDENCE_REVIEW_REQUIRED_OR_FAILED",
            "identity_ok": semantic_identity_ok,
            "reviewed_claim_ids": sorted(semantic_claim_ids),
            "used_claim_ids": sorted(used),
        })
    findings.extend(
        {"code": "UNBOUND_MATERIAL_CLAIM", "path": item}
        for item in material_claim_binding_errors(model, claim_registry, require_content_function=True)
    )
    claim_checks = []
    authorized_original_claims: list[str] = []
    signed_files = intake_report.get("signed_pack_files") if isinstance(intake_report.get("signed_pack_files"), dict) else {}
    runtime_files = {
        str(item.get("path")): item for item in runtime_evidence_receipt.get("evidence_files", []) if isinstance(item, dict)
    }
    for claim_id in sorted(used):
        claim = claims.get(claim_id)
        reasons: list[str] = []
        if not claim:
            reasons.append("unknown claim id")
            claim = {}
        else:
            if claim.get("verification_status") in {"needs_verification", "disallowed"}:
                reasons.append(f"verification_status={claim.get('verification_status')}")
            if claim.get("allowed_usage") in {"internal_only", "do_not_use"}:
                reasons.append(f"allowed_usage={claim.get('allowed_usage')}")
            source_ids = [str(value) for value in claim.get("source_ids", [])]
            if claim.get("allowed_usage") in {"public_fact", "public_with_qualification"} and not source_ids:
                reasons.append("public claim requires at least one source_id")
            missing_sources = [value for value in source_ids if value not in sources]
            if missing_sources:
                reasons.append(f"unknown sources: {missing_sources}")
            reasons.extend(f"missing {value}" for value in check_context(claim))
            original = claim.get("original_evidence")
            if isinstance(original, dict) and original.get("authorization_status") in {"public_approved", "anonymized_approved"}:
                original_sources = [str(value) for value in original.get("source_ids", [])]
                original_records = [str(value).strip() for value in original.get("record_refs", []) if str(value).strip()]
                original_missing = [key for key in ("type", "methodology", "scope", "collected_at") if not original.get(key)]
                unknown_original_sources = [value for value in original_sources if value not in sources]
                if not (original_sources or original_records):
                    original_missing.append("source_ids_or_record_refs")
                if unknown_original_sources:
                    original_missing.append(f"unknown_original_sources={unknown_original_sources}")
                for record_ref in original_records:
                    expected = signed_files.get(record_ref)
                    root = base_package_root
                    if expected is None and record_ref in runtime_files:
                        expected = runtime_files[record_ref].get("sha256")
                        root = job_package_root
                        if runtime_files[record_ref].get("authorization_status") not in {"public_approved", "anonymized_approved"}:
                            original_missing.append(f"runtime_record_not_publicly_authorized={record_ref}")
                    path = resolve_inside(root, record_ref)
                    if expected is None or path is None or not path.is_file() or file_digest(path) != expected:
                        original_missing.append(f"unbound_or_changed_record_ref={record_ref}")
                if original_missing:
                    reasons.extend(f"invalid original_evidence: {value}" for value in original_missing)
                else:
                    authorized_original_claims.append(claim_id)
        status = "failed" if reasons else "passed"
        if reasons:
            findings.append({"code": "CLAIM_EVIDENCE_FAILURE", "claim_id": claim_id, "reasons": reasons})
        claim_checks.append({"claim_id": claim_id, "status": status, "source_ids": claim.get("source_ids", []), "reasons": reasons})

    model_sections = {str(item.get("section_id")): item for item in model.get("sections", []) if isinstance(item, dict)}
    blueprint_sections = {str(item.get("section_id")): item for item in blueprint.get("section_plan", []) if isinstance(item, dict)}
    question_coverage = []
    for section_id, planned in blueprint_sections.items():
        actual = model_sections.get(section_id)
        covered = bool(actual and actual.get("blocks"))
        item = {"section_id": section_id, "question": planned.get("h2_question"), "covered": covered}
        question_coverage.append(item)
        if not covered:
            findings.append({"code": "PLANNED_SECTION_NOT_COVERED", **item})
        elif actual.get("h2_question") != planned.get("h2_question"):
            findings.append({"code": "SECTION_QUESTION_DRIFT", "section_id": section_id})
        if actual and not re.search(r"[？?]$", str(actual.get("h2_question", "")).strip()):
            findings.append({"code": "H2_NOT_COMPLETE_QUESTION", "section_id": section_id})
    planned_subquestions = blueprint.get("question_contract", {}).get("necessary_subquestions", [])
    if not 5 <= len(planned_subquestions) <= 8:
        findings.append({"code": "BLUEPRINT_SUBQUESTION_COUNT", "actual": len(planned_subquestions)})
    actual_coverage = model.get("subquestion_coverage", [])
    if not isinstance(actual_coverage, list) or not 5 <= len(actual_coverage) <= 8:
        findings.append({"code": "CONTENT_SUBQUESTION_COVERAGE_COUNT", "actual": len(actual_coverage) if isinstance(actual_coverage, list) else "invalid"})
    else:
        actual_questions = {str(item.get("subquestion")) for item in actual_coverage if isinstance(item, dict)}
        missing_questions = sorted(set(str(value) for value in planned_subquestions) - actual_questions)
        extra_questions = sorted(actual_questions - set(str(value) for value in planned_subquestions))
        if missing_questions or extra_questions:
            findings.append({"code": "SUBQUESTION_BLUEPRINT_DRIFT", "missing": missing_questions, "extra": extra_questions})
        for item in actual_coverage:
            if not isinstance(item, dict):
                findings.append({"code": "INVALID_SUBQUESTION_COVERAGE_ITEM"})
                continue
            missing_sections = sorted(set(str(value) for value in item.get("section_ids", [])) - set(model_sections))
            if missing_sections:
                findings.append({"code": "SUBQUESTION_REFERENCES_UNKNOWN_SECTION", "subquestion": item.get("subquestion"), "section_ids": missing_sections})

    for key in ("job_id", "question_category", "primary_question", "product_scenario_subintent", "pattern_id"):
        if model.get(key) != blueprint.get(key):
            findings.append({"code": "BLUEPRINT_MODEL_IDENTITY_MISMATCH", "field": key})
    planned_faq = [item.get("question") for item in blueprint.get("faq_plan", []) if isinstance(item, dict)]
    actual_faq = [item.get("question") for item in model.get("faq", []) if isinstance(item, dict)]
    if planned_faq != actual_faq:
        findings.append({"code": "FAQ_BLUEPRINT_DRIFT", "planned": planned_faq, "actual": actual_faq})
    if any(not re.search(r"[？?]$", str(value or "").strip()) for value in actual_faq):
        findings.append({"code": "FAQ_NOT_COMPLETE_QUESTION"})

    # E2 contains prose only. E1 visual_plan defines the slots and evidence
    # requirements; E3 is the first stage allowed to select asset IDs and write
    # materialized visual_placements. Requiring equality here makes the normal
    # E2 -> E2.5 -> E3 lifecycle impossible.
    if model.get("visual_placements"):
        findings.append({"code": "VISUAL_PLACEMENTS_MUST_BE_EMPTY_BEFORE_E3"})

    matrix = competitor_matrix or {}
    matrix_required, matrix_reasons, comparison_subjects = competitor_matrix_requirement(
        model, blueprint, claim_registry,
    )
    if matrix_required:
        if not matrix:
            findings.append({
                "code": "COMPETITOR_DIMENSION_MATRIX_REQUIRED",
                "pattern_id": model.get("pattern_id"),
                "question_category": model.get("question_category"),
                "reasons": matrix_reasons,
                "comparison_subjects": comparison_subjects,
            })
        else:
            findings.extend(validate_competitor_matrix(
                matrix, set(sources), str(model.get("job_id")), str(model.get("pattern_id")),
                set(comparison_subjects),
            ))
    elif matrix:
        findings.extend(validate_competitor_matrix(
            matrix, set(sources), str(model.get("job_id")), str(model.get("pattern_id")),
            set(comparison_subjects),
        ))

    original_gate = pattern_registry.get("original_information_gate", {})
    hard_patterns = set(original_gate.get("hard_required_patterns", []))
    pattern_id = str(model.get("pattern_id"))
    p06_price_comparison = False
    if pattern_id == "P06":
        price_claim_ids = [claim_id for claim_id in used if claims.get(claim_id, {}).get("claim_type") == "price"]
        price_entities = {
            str(entity).strip()
            for claim_id in price_claim_ids
            for entity in claims.get(claim_id, {}).get("about_entities", [])
            if str(entity).strip()
        }
        article_text = visible_text(model)
        visible_price_entities = {entity for entity in price_entities if entity in article_text}
        visible_price_mentions = re.findall(
            r"(?:[¥￥$]\s*\d+(?:\.\d+)?|\d+(?:\.\d+)?\s*(?:元|人民币|美元|USD|CNY|RMB)(?![A-Za-z]))",
            article_text, flags=re.I,
        )
        dimensions_text = " ".join(str(value).lower() for value in matrix.get("dimensions", []))
        matrix_price_comparison = len(matrix.get("objects", [])) >= 2 and any(
            value in dimensions_text for value in ("价格", "套餐", "成本", "price", "plan", "cost")
        )
        # A composite price claim can bind multiple objects, so claim count is
        # not a reliable comparison detector.  Treat two visible, named priced
        # entities as a comparison even when both values live in one claim.
        visible_composite_comparison = len(visible_price_entities) >= 2 and len(visible_price_mentions) >= 2
        p06_price_comparison = matrix_price_comparison or len(price_claim_ids) >= 2 or visible_composite_comparison
        if p06_price_comparison and not matrix_price_comparison:
            findings.append({
                "code": "P06_PRICE_COMPARISON_MATRIX_REQUIRED",
                "price_claim_ids": sorted(price_claim_ids),
                "visible_price_entities": sorted(visible_price_entities),
                "visible_price_mentions": visible_price_mentions,
            })
    original_required = pattern_id in hard_patterns or p06_price_comparison
    readiness = blueprint.get("evidence_readiness") if isinstance(blueprint.get("evidence_readiness"), dict) else {}
    declared_status = readiness.get("original_information_status")
    declared_claims = set(str(value) for value in readiness.get("original_information_claim_ids", []))
    authorized_set = set(authorized_original_claims)
    if declared_status == "provided":
        if not declared_claims or not declared_claims.issubset(used) or not declared_claims.issubset(authorized_set):
            findings.append({
                "code": "DECLARED_ORIGINAL_INFORMATION_NOT_AUTHORIZED_OR_USED",
                "declared_claim_ids": sorted(declared_claims), "authorized_used_claim_ids": sorted(authorized_set),
            })
    elif declared_status == "hard_required_missing":
        if readiness.get("status") != "blocked" or declared_claims or readiness.get("exemption_reason") is not None:
            findings.append({"code": "INVALID_HARD_REQUIRED_MISSING_STATE"})
    elif declared_status == "exempted":
        reason = str(readiness.get("exemption_reason") or "").strip()
        if original_required:
            findings.append({"code": "ORIGINAL_INFORMATION_EXEMPTION_NOT_ALLOWED", "pattern_id": pattern_id})
        if declared_claims or len(reason) < 10:
            findings.append({"code": "INVALID_ORIGINAL_INFORMATION_EXEMPTION"})
        forbidden_patterns = (
            r"独立测试|独立实测|原创(?:数据|研究|调研)|权威排名|行业第一|最(?:佳|优)|领先",
            r"\bindependent\s+test\b|\bbest\b|\bleading\b|authoritative\s+ranking",
        )
        # The gate governs what the published article asserts.  A registry claim
        # may point to an entire approved KB leaf containing words such as
        # “领先” in unrelated source context; scanning that whole leaf creates a
        # false block even when the article never makes the statement.
        scan_text = visible_text(model)
        matches = sorted({match.group(0) for pattern in forbidden_patterns for match in re.finditer(pattern, scan_text, flags=re.I)})
        if matches:
            findings.append({"code": "EXEMPTION_FORBIDDEN_CLAIM", "matches": matches})
    else:
        findings.append({"code": "INVALID_ORIGINAL_INFORMATION_STATUS", "value": declared_status})

    original_blocked = original_required and (not authorized_original_claims or declared_status != "provided")
    if original_blocked:
        findings.append({
            "code": "ORIGINAL_INFORMATION_REQUIRED",
            "pattern_id": pattern_id,
            "requirement": "at least one used claim with authorized and traceable original_evidence",
        })

    used_sources = {str(value) for claim_id in used for value in claims.get(claim_id, {}).get("source_ids", [])}
    reference_contract = reference_source_contract(model, claim_registry)
    for message in reference_contract["errors"]:
        findings.append({"code": "VISIBLE_REFERENCE_SOURCE_SET_MISMATCH", "message": message})
    source_checks: list[dict[str, Any]] = []
    for source_id in sorted(used_sources):
        source = sources.get(source_id, {})
        source_errors: list[str] = []
        if not safe_web_url(source.get("url")):
            source_errors.append("source URL must use http/https")
        stored = str(source.get("file_path") or "").strip()
        expected_sha: str | None = None
        access_mode: str
        if stored:
            access_mode = "base_pack_file"
            expected_sha = signed_files.get(stored)
            root = base_package_root
            if expected_sha is None and stored in runtime_files:
                access_mode = "runtime_job_file"
                expected_sha = str(runtime_files[stored].get("sha256") or "")
                root = job_package_root
                if runtime_files[stored].get("authorization_status") not in {"public_approved", "anonymized_approved"}:
                    source_errors.append("runtime source file is not approved for public use")
            path = resolve_inside(root, stored)
            if expected_sha is None:
                source_errors.append("source file is absent from signed Pack/runtime evidence receipt")
            elif path is None or not path.is_file():
                source_errors.append("source file is missing or has an unsafe path")
            elif file_digest(path) != expected_sha:
                source_errors.append("source file hash changed after approval")
        else:
            access_mode = "url"
            if not source.get("url") or not source.get("accessed_at") or not str(source.get("origin") or "").strip():
                source_errors.append("URL source requires url/accessed_at/origin")
        if source_errors:
            findings.append({
                "code": "SOURCE_EVIDENCE_FAILURE", "source_id": source_id, "reasons": source_errors,
            })
        source_checks.append({
            "source_id": source_id,
            "source_type": source.get("source_type"),
            "access_mode": access_mode,
            "file_path": stored or None,
            "file_sha256": expected_sha,
            "url": source.get("url"),
            "accessed_at": source.get("accessed_at"),
            "access_verified": not source_errors,
            "reasons": source_errors,
        })
    return {
        "schema_version": "1.0.0",
        "job_id": model.get("job_id"),
        "content_model_sha256": digest(model),
        "evidence_projection_sha256": evidence_projection_sha256(model),
        "article_blueprint_sha256": digest(blueprint),
        "e0_intake_report_sha256": canonical_sha256(intake_report),
        "runtime_evidence_receipt_sha256": canonical_sha256(runtime_evidence_receipt),
        "claim_registry_sha256": canonical_sha256(claim_registry),
        "source_registry_sha256": canonical_sha256(source_registry),
        "content_pattern_registry_sha256": pattern_registry_sha256,
        "status": "blocked" if original_blocked else "repair_required" if findings else "passed",
        "question_coverage": question_coverage,
        "claim_checks": claim_checks,
        "semantic_review_sha256": canonical_sha256(semantic_review),
        "semantic_review_status": "passed" if semantic_identity_ok and semantic_decisions_ok else "failed",
        "source_checks": source_checks,
        "competitor_dimension_matrix": matrix,
        "special_evidence_checks": [{
            "check": "original_information_gate",
            "required": original_required,
            "blueprint_status": declared_status,
            "authorized_claim_ids": sorted(authorized_original_claims),
            "status": "blocked" if original_blocked else "passed" if original_required else "not_applicable",
        }],
        "blocking_findings": findings,
        "repair_instructions": [
            {"owner": "E2", "finding_code": item["code"], "action": "repair and rerun the complete E2.5 gate"}
            for item in findings
        ],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--blueprint", type=Path, required=True)
    parser.add_argument("--claims", type=Path, required=True)
    parser.add_argument("--sources", type=Path, required=True)
    parser.add_argument("--pattern-registry", type=Path, required=True)
    parser.add_argument("--content-job", type=Path, required=True)
    parser.add_argument("--intake-report", type=Path, required=True)
    parser.add_argument("--runtime-evidence-receipt", type=Path, required=True)
    parser.add_argument("--semantic-review", type=Path, required=True,
                        help="human evidence-support review bound to this model projection and registries")
    parser.add_argument("--base-package-root", type=Path, required=True)
    parser.add_argument("--job-package-root", type=Path, required=True)
    parser.add_argument("--competitor-matrix", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if not args.base_package_root.is_dir() or not args.job_package_root.is_dir():
        raise FileNotFoundError("--base-package-root and --job-package-root must both exist")
    result = check(
        load(args.model), load(args.blueprint), load(args.claims), load(args.sources), load(args.pattern_registry),
        load(args.competitor_matrix) if args.competitor_matrix else None,
        load(args.content_job), load(args.intake_report),
        load(args.runtime_evidence_receipt),
        load(args.semantic_review),
        args.base_package_root.resolve(), args.job_package_root.resolve(),
    )
    validate_schema(
        result, Path(__file__).resolve().parents[1] / "templates" / "evidence_preflight.schema.json",
        "E2.5 evidence_preflight receipt",
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
