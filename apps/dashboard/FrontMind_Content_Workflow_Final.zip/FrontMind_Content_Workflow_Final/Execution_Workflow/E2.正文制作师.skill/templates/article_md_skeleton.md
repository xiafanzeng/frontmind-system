<!-- 此文件是 canonical content model 的审阅视图模板，不是第二份内容源。 -->

# {{h1}}

{{direct_answer_sentence}}{{micro_answer_remainder}}

## {{section_1_user_question}}

{{section_1_conclusion}}

{{section_1_evidence_and_qualification}}

{{section_1_advice}}

## {{section_2_user_question}}

{{section_2_body}}

<!-- 按蓝图继续 5-8 个必要子问题；仅必要时使用 H3；禁止正文表格。 -->

## 围绕这个决策还需要了解哪些常见问题？

### {{faq_question_1}}

{{faq_answer_1}}

<!-- 共 5-8 个真实高相关 FAQ。 -->

## 最后应该如何判断和行动？

{{approved_conclusion_only}}
