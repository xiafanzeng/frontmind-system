---
name: frontmind-visual-argument-producer
description: >
  E3 视觉论证师。继承原企业图片库、AIGC Prompt、图片校验和去重能力，只为已通过 E2.5 的文章生产与主张绑定的解释/证明/导航视觉；
  企业实图仅来自 canonical 图片库，生成图不得伪装事实证据。输出视觉论证 Manifest 并回写同一 canonical content model，不改写正文。
---

# E3 视觉论证师

## 1. 继承与修正

保留原 E3 的企业实图检索、S7/品牌视觉 Prompt、AIGC 质量检查、尺寸检查、文件哈希、感知哈希去重、图片注册和缺图阻断。
原技能全文位于 `references/legacy-E3-visual-producer-v11.md`。

修正旧链路的三类问题：

1. 图片不再只有装饰用途，必须说明帮助读者判断什么；
2. 不再并存 `entries/file_hash` 与 `images/sha256`，运行时只读根 canonical asset contract；
3. 不再把网络图库或 AIGC 场景图当企业真实案例、团队、产品、证书或环境证明。

## 2. 强制输入

- E2 canonical content model draft；
- E2.5 `status=passed` 的证据预检；
- E1 根 `visual_plan`；
- References Pack 内只读 base image registry，以及由 E0-B 建立的 job-local runtime image registry 与 seed receipt；单篇补充图片只追加到 runtime 层；
- 品牌视觉资产、Logo 和可选 S7 视觉规范；
- 当前 runtime claim/source registries、E2.5 evidence/semantic review、image registries 与 Content Model `visual_placements`。

若 E2.5 未通过，禁止开始。E3 不补写新的事实，也不为图片创造新 claim。

## 3. 视觉角色

每张最终图使用根 Content Model 的角色 `cover/proof/comparison/process/data/explanation`，并另标一个论证功能：

- `explain`：解释机制、步骤、结构、选择逻辑或概念关系；
- `prove`：展示已核验事实对应的企业实图、证书、项目记录、原始数据可视化；
- `navigate`：帮助识别主题或章节，如品牌封面；不能计入事实证明。

纯装饰图应删除；确需品牌封面时标为 `navigate`，不得写“证明品牌实力”。

## 4. 可用来源

### 4.1 企业真实图片

只从根 `image_registry.images` 选择，保留 `asset_id`、`file_path`、原始 64 位 `sha256`、`mime_type`、正整数 `width/height`、`source_kind`、
`rights_status`、`source_ids`、`semantic_tags` 和 `allowed_roles`。不得从官网热链、搜索图片或图库人物替代企业实图。
实际进入文章的资产缺少正整数宽高时硬失败；SVG 优先采用显式 `width/height`，响应式 SVG 则在登记时从正值 `viewBox` 提取尺寸，
不得到 E6 才猜测版式尺寸。

检索条件读取 E1 的 `visual_plan.role`、`proof_or_explanation_goal` 与 `source_requirement`。最终模型只写一个 `asset_id`；
视觉 Manifest 另写 `reader_question` 与 `supports_claim_ids`。

### 4.2 生成式解释图

允许生成品牌封面、流程/机制图、维度图和基于已核验数据的可视化。Prompt 必须引用 claim IDs 与来源，不得加入正文没有的数字、人物、
客户 Logo、证书、界面或产品外观。生成解释图的 `source_kind=generated_explanatory`；生成数据图为 `generated_data_chart` 且必须有 `source_ids`。

Logo 永远不进入 img2img，也不得由模型重绘。生成底图时禁用 Logo 参考；成图通过质量检查后，按
`logo_overlay_asset_id` 读取 Registry 中已批准的原始 Logo 文件并做确定性叠加。该资产还必须同时存在于 S7
`brand_constraints.logo_asset_refs`，且其 `asset_usage.usage_mode=overlay_only` 并允许当前槽位；不能把任意 rights approved 图片当 Logo。
最后对合成文件重新计算 SHA256、尺寸和 MIME。

### 4.3 不可替代原则

- 缺客户案例图 → 输出缺图，不生成“客户现场”；
- 缺产品截图 → 输出缺图，不生成虚构 UI；
- 缺证书图 → 只用已核验证书文字事实，不生成证书；
- 缺数据 → 不画无来源数据图；
- 缺 Logo → 阻断品牌封面，不生成近似 Logo。

## 5. 逐图制作流程

1. 读取 visual slot 与 `supports_claim_ids`；确认每个 claim 已在 E2.5 通过。
2. 写 `reader_question`：读者看完图能更快判断什么。
3. 选择 `explain/prove/navigate`。
4. 决定企业资产或生成解释图；查询企业资产时使用 Registry 的 `file_path` 和 `sha256`。
5. 生成/选择后运行尺寸、清晰度、哈希、重复、Logo/文字、人物、事实一致性检查。
6. 写事实性 Caption 和可访问 Alt；Caption 不增加新主张。
7. 记录根模型插入位置 `after_section_id`。
8. 回写 canonical model 的 `visual_placements`，正文 `sections[].blocks` 不复制或改写。

## 6. 视觉质量门

### 内容门

- claim 绑定存在且通过 E2.5；
- 图片真实内容与 claim 一致；
- `prove` 图有来源资产或可复算数据；
- 比较图对所有对象使用同一维度；
- 流程图每步与正文的输入、动作、结果、检查方法一致；
- 图片没有虚构文字、乱码或未经授权的品牌元素。

### 技术门

- 文件可打开、尺寸适合 DOCX/HTML、色彩正常；
- SHA256 与感知哈希检查完成；
- 同一篇不重复使用近似图；
- file path、SHA256、MIME、宽高、生成 Prompt/模型信息完整；
- 外部字体、热链和临时 URL 不进入交付。

### 语义门

- Caption、Alt、正文相邻段落表达同一事实；
- `navigate` 不被描述为证据；
- 删除图片后若主张失去唯一证据，必须回 E2/E2.5，而不是让图片单独承担未写明的事实。

## 7. 输出

- `E3_{brand_label}_{job_id}_visual_argument_manifest.json`，满足 `templates/visual_argument_manifest.schema.json`；
- 最终图片文件；
- 图片验证报告与缺图清单；
- 回写 `visual_placements` 后的 canonical content model，同一正文内容不得发生变化；图片事实写入根 `registries.schema.json` 的 image registry。

生成图先建立符合 `templates/prompt_plan_schema.json` 的 `images[]` 计划，按 `visual_pattern_id` 读取 S7
`visual_patterns[].prompt_scaffold`；只允许 `no_text/no_aigc`。完整命令以包根 [运行手册](../../RUNBOOK.md) 的 E3 段为准：

- `visual_claim_validator.py` 同时接收只读 base root、job root、base/runtime image registries、runtime receipt、claims/sources 和 E2.5 evidence；
- `image_dedup_checker.py` 只向 job-local runtime registry 追加；
- `aigc_invoker.py` 只从 base root 读取签名原始 Logo，用于确定性 overlay。

machine artifact 的 `file_path` 按对应 Pack root 或 job root 解析，禁止按 Registry 所在目录猜路径。工具调用是否可用必须诚实记录；只有 Prompt 不等于已生成图片。

## 8. 硬失败

- explain/prove 视觉没有 claim IDs，或任一视觉没有 reader question；
- `prove` 绑定 unsupported claim；
- AIGC/网络图冒充企业实拍；
- 图片中的数字与 claim/source 不一致；
- 使用旧双 Registry 字段导致无法追溯；
- 实际使用的 Registry 图片缺少正整数 `width/height`；
- 图片只是装饰却计入必需配图；
- 为了满足固定图数而生成无意义图片。
