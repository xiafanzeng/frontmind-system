#!/usr/bin/env python3
"""Check and optionally register an image in the root canonical image_registry.

The registry remains schema-compatible: perceptual hashes are computed at run
time and only appear in the dedup report, never as extra registry fields.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
import mimetypes
import re
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "shared"))
from schema_validation import validate_root  # noqa: E402

from PIL import Image


VALID_SOURCE_KINDS = {
    "client_submitted", "first_party_download", "first_party_reference",
    "licensed_third_party", "generated_explanatory", "generated_data_chart",
}
VALID_RIGHTS = {"approved", "approved_with_credit", "restricted_not_allowed", "unknown"}
VALID_ROLES = {
    "cover", "entity_proof", "product_proof", "case_proof", "event_proof",
    "comparison", "process_explanation", "data_evidence", "decorative",
}
PROOF_ROLES = {"entity_proof", "product_proof", "case_proof", "event_proof", "data_evidence"}
VALID_MIME = {"image/png", "image/jpeg", "image/webp", "image/svg+xml"}


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain an object")
    return value


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def perceptual_hash(path: Path, size: int = 16) -> str | None:
    if path.suffix.lower() == ".svg":
        return None
    try:
        image = Image.open(path).convert("L").resize((size + 1, size), Image.Resampling.LANCZOS)
    except Exception:
        return None
    pixels = list(image.getdata())
    bits = []
    for row in range(size):
        for column in range(size):
            left = pixels[row * (size + 1) + column]
            right = pixels[row * (size + 1) + column + 1]
            bits.append(1 if left > right else 0)
    value = 0
    for bit in bits:
        value = (value << 1) | bit
    return format(value, f"0{size * size // 4}x")


def similarity(left: str | None, right: str | None) -> float:
    if not left or not right or len(left) != len(right):
        return 0.0
    differing = (int(left, 16) ^ int(right, 16)).bit_count()
    return 1.0 - differing / (len(left) * 4)


def resolve_asset(package_root: Path, stored_path: Any) -> Path | None:
    if not isinstance(stored_path, str) or not stored_path.strip():
        return None
    path = Path(stored_path)
    if path.is_absolute() or ".." in path.parts or "\\" in stored_path:
        raise ValueError(f"image_registry.file_path must be package-relative without traversal: {stored_path}")
    resolved = (package_root / path).resolve()
    try:
        resolved.relative_to(package_root.resolve())
    except ValueError as exc:
        raise ValueError(f"image_registry.file_path escapes package root: {stored_path}") from exc
    return resolved


def validate_registry(registry: dict[str, Any]) -> None:
    validate_root(registry, "registries.schema.json", "E3 image_registry")
    if registry.get("schema_version") != "1.0.0" or registry.get("registry_type") != "image_registry":
        raise ValueError("registry must use schema_version=1.0.0 and registry_type=image_registry")
    if not isinstance(registry.get("images"), list):
        raise ValueError("image_registry.images must be an array")
    if "entries" in registry:
        raise ValueError("legacy entries/file_hash registry is not accepted")
    for asset in registry["images"]:
        if not isinstance(asset, dict):
            continue
        allowed = set(asset.get("allowed_roles", []))
        if asset.get("source_kind") == "generated_explanatory" and allowed & PROOF_ROLES:
            raise ValueError(f"generated_explanatory asset cannot declare proof roles: {asset.get('asset_id')}")
        if asset.get("source_kind") == "generated_data_chart" and not asset.get("source_ids"):
            raise ValueError(f"generated_data_chart asset requires source_ids: {asset.get('asset_id')}")


def check(
    image_path: Path, registry_path: Path, base_registry: dict[str, Any],
    base_package_root: Path, job_package_root: Path, threshold: float, job_id: str,
) -> dict[str, Any]:
    registry = load(registry_path)
    validate_registry(registry)
    current_sha, current_phash = sha256(image_path), perceptual_hash(image_path)
    comparisons: list[dict[str, Any]] = []
    exact_match = None
    maximum = 0.0
    most_similar = None
    skipped_files = []
    base_ids = {str(item.get("asset_id")) for item in base_registry.get("images", []) if isinstance(item, dict)}
    for asset in registry["images"]:
        if not isinstance(asset, dict):
            continue
        asset_id = str(asset.get("asset_id", "unknown"))
        if asset.get("sha256") == current_sha:
            exact_match = asset_id
            maximum, most_similar = 1.0, asset_id
            comparisons.append({"asset_id": asset_id, "similarity": 1.0, "exact": True})
            continue
        asset_root = base_package_root if asset_id in base_ids else job_package_root
        stored = resolve_asset(asset_root, asset.get("file_path"))
        if not stored or not stored.is_file():
            skipped_files.append(asset_id)
            continue
        score = similarity(current_phash, perceptual_hash(stored))
        comparisons.append({"asset_id": asset_id, "similarity": round(score, 6), "exact": False})
        if score > maximum:
            maximum, most_similar = score, asset_id
    return {
        "schema_version": "1.0.0",
        "job_id": job_id,
        "stage": "E3_image_dedup",
        "image_path": image_path.resolve().relative_to(job_package_root.resolve()).as_posix(),
        "sha256": current_sha,
        "perceptual_hash_runtime_only": current_phash,
        "checked_assets": len(registry["images"]),
        "exact_match_asset_id": exact_match,
        "max_similarity": round(maximum, 6),
        "most_similar_asset_id": most_similar,
        "threshold": threshold,
        "passed": exact_match is None and maximum < threshold,
        "skipped_registry_files": skipped_files,
        "comparisons": sorted(comparisons, key=lambda item: item["similarity"], reverse=True)[:10],
    }


def image_facts(path: Path) -> tuple[str, int | None, int | None]:
    mime = mimetypes.guess_type(path.name)[0]
    if mime == "image/jpg":
        mime = "image/jpeg"
    if mime not in VALID_MIME:
        raise ValueError(f"unsupported image MIME: {mime}")
    if mime == "image/svg+xml":
        text = path.read_text(encoding="utf-8", errors="ignore")[:8192]
        root = re.search(r"<svg\b(?P<attrs>[^>]*)>", text, flags=re.IGNORECASE | re.DOTALL)
        if not root:
            return mime, None, None
        attrs = root.group("attrs")

        def attribute(name: str) -> str | None:
            match = re.search(rf"\b{name}\s*=\s*([\"'])(.*?)\1", attrs, flags=re.IGNORECASE | re.DOTALL)
            return match.group(2) if match else None

        def length(value: str | None) -> int | None:
            if not value:
                return None
            match = re.fullmatch(
                r"\s*\+?((?:\d+(?:\.\d*)?)|(?:\.\d+))\s*(px|pt|pc|mm|cm|in)?\s*",
                value,
                flags=re.IGNORECASE,
            )
            if not match:
                return None
            number = float(match.group(1))
            if number <= 0:
                return None
            unit = (match.group(2) or "px").lower()
            factors = {"px": 1.0, "pt": 96 / 72, "pc": 16.0, "mm": 96 / 25.4, "cm": 96 / 2.54, "in": 96.0}
            return max(1, math.ceil(number * factors[unit]))

        explicit = (length(attribute("width")), length(attribute("height")))
        if all(value is not None for value in explicit):
            return mime, explicit[0], explicit[1]
        view_box = attribute("viewBox")
        if view_box:
            try:
                values = [part for part in re.split(r"[\s,]+", view_box.strip()) if part]
                if len(values) == 4:
                    width_value, height_value = float(values[2]), float(values[3])
                    if width_value > 0 and height_value > 0:
                        return mime, max(1, math.ceil(width_value)), max(1, math.ceil(height_value))
            except (ValueError, OverflowError):
                pass
        return mime, None, None
    with Image.open(path) as image:
        return mime, image.width, image.height


def register(image_path: Path, registry_path: Path, job_package_root: Path, record_path: Path) -> dict[str, Any]:
    registry, record = load(registry_path), load(record_path)
    validate_registry(registry)
    required = {"asset_id", "asset_kind", "file_path", "mime_type", "source_kind", "rights_status", "semantic_tags", "allowed_roles"}
    missing = sorted(key for key in required if key not in record)
    if missing:
        raise ValueError(f"asset record missing fields: {', '.join(missing)}")
    if any(item.get("asset_id") == record.get("asset_id") for item in registry["images"] if isinstance(item, dict)):
        raise ValueError(f"asset_id already exists: {record.get('asset_id')}")
    if not str(record.get("asset_id", "")).startswith("img_"):
        raise ValueError("asset_id must start with img_")
    stored = resolve_asset(job_package_root, record.get("file_path"))
    if not stored or stored.resolve() != image_path.resolve():
        raise ValueError("asset record file_path must be the image path relative to --job-package-root")
    mime, width, height = image_facts(image_path)
    if record.get("mime_type") != mime:
        raise ValueError(f"asset record mime_type={record.get('mime_type')} differs from file MIME={mime}")
    if record.get("source_kind") not in VALID_SOURCE_KINDS or record.get("rights_status") not in VALID_RIGHTS:
        raise ValueError("invalid source_kind or rights_status")
    if record.get("asset_kind") not in {"logo", "product", "case", "event", "data_visual", "brand_image", "decorative", "unknown"}:
        raise ValueError("invalid asset_kind")
    if record.get("rights_status") == "approved_with_credit" and not str(record.get("attribution_text", "")).strip():
        raise ValueError("approved_with_credit asset requires attribution_text")
    if not isinstance(record.get("semantic_tags"), list) or not isinstance(record.get("allowed_roles"), list):
        raise ValueError("semantic_tags and allowed_roles must be arrays")
    if not record["allowed_roles"] or set(record["allowed_roles"]) - VALID_ROLES:
        raise ValueError("allowed_roles contains invalid values")
    if record.get("source_kind") == "generated_explanatory" and set(record["allowed_roles"]) & PROOF_ROLES:
        raise ValueError("generated_explanatory asset cannot declare proof roles")
    if record.get("source_kind") == "generated_data_chart" and not record.get("source_ids"):
        raise ValueError("generated_data_chart asset requires source_ids")
    allowed_fields = {
        "asset_id", "asset_kind", "file_path", "url", "sha256", "mime_type", "width", "height", "source_kind",
        "rights_status", "source_ids", "semantic_tags", "allowed_roles", "depicts_real_event_or_case",
        "caption", "alt_text", "origin", "source_document_id", "ownership", "evidence_status",
        "content_status", "evidence_precision", "aliases", "attribution_text", "license_name", "license_url",
    }
    extras = sorted(set(record) - allowed_fields)
    if extras:
        raise ValueError(f"asset record contains non-canonical fields: {', '.join(extras)}")
    record["sha256"] = sha256(image_path)
    record["width"], record["height"] = width, height
    registry["images"].append(record)
    validate_root(registry, "registries.schema.json", "E3 updated image_registry")
    registry_path.write_text(json.dumps(registry, ensure_ascii=False, indent=2), encoding="utf-8")
    return record


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--image", type=Path, required=True)
    parser.add_argument("--registry", type=Path, required=True)
    parser.add_argument("--base-registry", type=Path, required=True)
    parser.add_argument("--base-package-root", type=Path, required=True)
    parser.add_argument("--job-package-root", type=Path, required=True)
    parser.add_argument("--job-id", required=True)
    parser.add_argument("--threshold", type=float, default=0.85)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--register", action="store_true")
    parser.add_argument("--asset-record", type=Path,
                        help="full root image record JSON; required with --register")
    args = parser.parse_args()
    if not args.image.is_file() or not args.registry.is_file():
        raise FileNotFoundError("--image and --registry must both exist")
    if args.image.stat().st_size < 10 * 1024:
        raise ValueError("image is smaller than 10 KB")
    base_package_root = args.base_package_root.resolve()
    job_package_root = args.job_package_root.resolve()
    if not base_package_root.is_dir() or not job_package_root.is_dir():
        raise FileNotFoundError("--base-package-root and --job-package-root must both exist")
    base_registry = load(args.base_registry)
    validate_registry(base_registry)
    try:
        args.image.resolve().relative_to(job_package_root)
        args.registry.resolve().relative_to(job_package_root)
    except ValueError as exc:
        raise ValueError("--image and --registry must both be staged inside --job-package-root") from exc
    result = check(
        args.image, args.registry, base_registry, base_package_root, job_package_root, args.threshold, args.job_id,
    )
    if args.register:
        if not args.asset_record:
            raise ValueError("--asset-record is required with --register")
        if not result["passed"]:
            raise ValueError("duplicate/similar image cannot be registered")
        result["registered_record"] = register(args.image, args.registry, job_package_root, args.asset_record)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
