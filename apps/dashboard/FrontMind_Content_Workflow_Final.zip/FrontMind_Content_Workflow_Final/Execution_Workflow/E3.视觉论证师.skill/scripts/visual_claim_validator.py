#!/usr/bin/env python3
"""Validate Content Model visual placements against claim/image registries."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "shared"))
from schema_validation import validate_root, validate_schema  # noqa: E402
from content_projections import visual_projection_sha256  # noqa: E402
from visual_semantics import visual_claim_relevance_errors, visual_semantic_errors  # noqa: E402
from registry_binding import canonical_sha256 as canonical_registry_sha256  # noqa: E402


ROLE_COMPATIBILITY = {
    "cover": {"cover", "decorative"},
    "proof": {"entity_proof", "product_proof", "case_proof", "event_proof", "data_evidence"},
    "comparison": {"comparison"},
    "process": {"process_explanation"},
    "data": {"data_evidence"},
    "explanation": {"process_explanation", "comparison"},
}
ROLE_ARGUMENT_COMPATIBILITY = {
    "cover": {"navigate"},
    "proof": {"prove"},
    "comparison": {"explain", "prove"},
    "process": {"explain"},
    "data": {"explain", "prove"},
    "explanation": {"explain"},
}
PROOF_ASSET_ROLES = {"entity_proof", "product_proof", "case_proof", "event_proof", "data_evidence"}


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain an object")
    return value


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_sha256(value: dict[str, Any]) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def resolve_file(package_root: Path, stored: str) -> Path:
    path = Path(stored)
    if not stored or path.is_absolute() or ".." in path.parts or "\\" in stored:
        raise ValueError(f"image_registry.file_path must be package-relative without traversal: {stored!r}")
    resolved = (package_root / path).resolve()
    try:
        resolved.relative_to(package_root.resolve())
    except ValueError as exc:
        raise ValueError(f"image_registry.file_path escapes package root: {stored}") from exc
    return resolved


def has_positive_dimensions(asset: dict[str, Any]) -> bool:
    """True only for explicit positive integer registry dimensions."""
    width, height = asset.get("width"), asset.get("height")
    return (
        isinstance(width, int) and not isinstance(width, bool) and width > 0
        and isinstance(height, int) and not isinstance(height, bool) and height > 0
    )


def validate(model: dict[str, Any], blueprint: dict[str, Any], manifest: dict[str, Any], claim_registry: dict[str, Any],
             source_registry: dict[str, Any], evidence: dict[str, Any], image_registry: dict[str, Any],
             base_image_registry: dict[str, Any], runtime_receipt: dict[str, Any],
             base_package_root: Path, job_package_root: Path) -> dict[str, Any]:
    claims = {str(item.get("claim_id")): item for item in claim_registry.get("claims", []) if isinstance(item, dict)}
    images = {str(item.get("asset_id")): item for item in image_registry.get("images", []) if isinstance(item, dict)}
    source_ids = {str(item.get("source_id")) for item in source_registry.get("sources", []) if isinstance(item, dict)}
    passed_claim_ids = {
        str(item.get("claim_id")) for item in evidence.get("claim_checks", [])
        if isinstance(item, dict) and item.get("status") == "passed"
    }
    sections = {str(item.get("section_id")) for item in model.get("sections", []) if isinstance(item, dict)}
    placements = {str(item.get("visual_id")): item for item in model.get("visual_placements", []) if isinstance(item, dict)}
    blueprint_visuals = {str(item.get("visual_id")): item for item in blueprint.get("visual_plan", []) if isinstance(item, dict)}
    errors: list[str] = []
    for value, schema_name, label in (
        (model, "content_model.schema.json", "E3 content_model"),
        (blueprint, "article_blueprint.schema.json", "E3 article_blueprint"),
        (claim_registry, "registries.schema.json", "E3 claim_registry"),
        (source_registry, "registries.schema.json", "E3 source_registry"),
        (image_registry, "registries.schema.json", "E3 image_registry"),
        (base_image_registry, "registries.schema.json", "E3 base image_registry"),
    ):
        try:
            validate_root(value, schema_name, label)
        except ValueError as exc:
            errors.append(f"canonical_schema_failure:{exc}")
    try:
        validate_schema(
            manifest,
            Path(__file__).resolve().parents[1] / "templates" / "visual_argument_manifest.schema.json",
            "E3 visual_argument_manifest",
        )
    except ValueError as exc:
        errors.append(f"visual_manifest_schema_failure:{exc}")
    try:
        validate_schema(
            runtime_receipt,
            Path(__file__).resolve().parents[2] / "E0.单篇执行编排师.skill" / "templates" / "runtime_image_registry_receipt.schema.json",
            "E3 runtime image registry receipt",
        )
    except ValueError as exc:
        errors.append(f"runtime_registry_receipt_schema_failure:{exc}")
    if model.get("schema_version") != "1.0.0" or manifest.get("schema_version") != "1.0.0":
        errors.append("model_and_manifest_schema_version_must_be_1.0.0")
    if claim_registry.get("schema_version") != "1.0.0" or claim_registry.get("registry_type") != "claim_registry":
        errors.append("invalid_claim_registry_contract")
    if source_registry.get("schema_version") != "1.0.0" or source_registry.get("registry_type") != "source_registry":
        errors.append("invalid_source_registry_contract")
    if evidence.get("schema_version") != "1.0.0" or evidence.get("job_id") != model.get("job_id") or evidence.get("status") != "passed":
        errors.append("evidence_receipt_not_clean_pass")
    if evidence.get("claim_registry_sha256") != canonical_registry_sha256(claim_registry):
        errors.append("evidence_claim_registry_hash_mismatch")
    if evidence.get("source_registry_sha256") != canonical_registry_sha256(source_registry):
        errors.append("evidence_source_registry_hash_mismatch")
    if image_registry.get("schema_version") != "1.0.0" or image_registry.get("registry_type") != "image_registry":
        errors.append("invalid_image_registry_contract")
    registry_sha256 = canonical_sha256(image_registry)
    base_registry_sha256 = canonical_sha256(base_image_registry)
    receipt_sha256 = canonical_sha256(runtime_receipt)
    base_records = {str(item.get("asset_id")): item for item in base_image_registry.get("images", []) if isinstance(item, dict)}
    runtime_records = {str(item.get("asset_id")): item for item in image_registry.get("images", []) if isinstance(item, dict)}
    if runtime_receipt.get("job_id") != model.get("job_id"):
        errors.append("runtime_registry_receipt_job_mismatch")
    if runtime_receipt.get("base_registry_sha256") != base_registry_sha256:
        errors.append("runtime_registry_receipt_base_hash_mismatch")
    if runtime_receipt.get("seeded_runtime_sha256") != base_registry_sha256:
        errors.append("runtime_registry_seed_hash_mismatch")
    if runtime_receipt.get("base_asset_ids") != sorted(base_records):
        errors.append("runtime_registry_receipt_base_asset_ids_mismatch")
    for asset_id, base_record in base_records.items():
        if runtime_records.get(asset_id) != base_record:
            errors.append(f"runtime_registry_modified_signed_base_asset:{asset_id}")
    if manifest.get("base_image_registry_sha256") != base_registry_sha256:
        errors.append("manifest_base_image_registry_sha256_mismatch")
    if manifest.get("runtime_registry_receipt_sha256") != receipt_sha256:
        errors.append("manifest_runtime_registry_receipt_sha256_mismatch")
    if manifest.get("image_registry_sha256") != registry_sha256:
        errors.append("manifest_image_registry_sha256_mismatch")
    if manifest.get("job_id") != model.get("job_id"):
        errors.append("manifest_model_job_id_mismatch")
    if blueprint.get("schema_version") != "1.0.0" or blueprint.get("job_id") != model.get("job_id"):
        errors.append("blueprint_model_schema_or_job_mismatch")
    for key in ("question_category", "primary_question", "product_scenario_subintent", "pattern_id"):
        if blueprint.get(key) != model.get(key):
            errors.append(f"blueprint_model_identity_mismatch:{key}")
    canonical = json.dumps(model, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    if manifest.get("content_model_sha256") != hashlib.sha256(canonical).hexdigest():
        errors.append("manifest_content_model_sha256_mismatch")
    projection_sha256 = visual_projection_sha256(model)
    if manifest.get("visual_projection_sha256") != projection_sha256:
        errors.append("manifest_visual_projection_sha256_mismatch")
    if manifest.get("missing_assets"):
        errors.append("manifest_contains_missing_required_assets")
    seen_assets: dict[str, str] = {}
    seen_visual_ids: set[str] = set()
    for item in manifest.get("visuals", []):
        if not isinstance(item, dict):
            errors.append("invalid_visual_item")
            continue
        visual_id = str(item.get("visual_id", "unknown"))
        if visual_id in seen_visual_ids:
            errors.append(f"{visual_id}:duplicate_visual_id")
        seen_visual_ids.add(visual_id)
        placement = placements.get(visual_id)
        if not placement:
            errors.append(f"{visual_id}:missing_content_model_placement")
            continue
        for key in ("role", "asset_id", "alt_text"):
            if item.get(key) != placement.get(key):
                errors.append(f"{visual_id}:manifest_model_mismatch:{key}")
        if item.get("after_section_id") != placement.get("after_section_id"):
            errors.append(f"{visual_id}:manifest_model_mismatch:after_section_id")
        section_id = item.get("after_section_id")
        if section_id is not None and str(section_id) not in sections:
            errors.append(f"{visual_id}:unknown_section:{section_id}")

        argument = item.get("argument_function")
        role = str(item.get("role"))
        planned = blueprint_visuals.get(visual_id)
        if not planned or planned.get("role") != role:
            errors.append(f"{visual_id}:blueprint_manifest_role_mismatch")
        claim_ids = [str(value) for value in item.get("supports_claim_ids", [])]
        if argument in {"explain", "prove"} and not claim_ids:
            errors.append(f"{visual_id}:argument_visual_without_claim")
        if argument == "navigate" and claim_ids:
            errors.append(f"{visual_id}:navigate_visual_must_not_claim_proof")
        for claim_id in claim_ids:
            claim = claims.get(claim_id)
            if not claim:
                errors.append(f"{visual_id}:unknown_claim:{claim_id}")
            elif claim.get("verification_status") in {"needs_verification", "disallowed"} or claim.get("allowed_usage") in {"internal_only", "do_not_use"}:
                errors.append(f"{visual_id}:unusable_claim:{claim_id}")
        errors.extend(visual_claim_relevance_errors(
            visual_id=visual_id, role=role, argument=argument, after_section_id=item.get("after_section_id"),
            claim_ids=claim_ids, model=model, passed_claim_ids=passed_claim_ids,
        ))

        asset_id = str(item.get("asset_id", ""))
        asset = images.get(asset_id)
        if not asset:
            errors.append(f"{visual_id}:unknown_asset:{asset_id}")
            continue
        if not has_positive_dimensions(asset):
            errors.append(f"{visual_id}:asset_missing_positive_dimensions:{asset_id}")
        if asset.get("rights_status") not in {"approved", "approved_with_credit"}:
            errors.append(f"{visual_id}:asset_rights_not_approved:{asset.get('rights_status')}")
        if item.get("rights_status") != asset.get("rights_status"):
            errors.append(f"{visual_id}:manifest_registry_rights_status_mismatch")
        for field in ("attribution_text", "license_name", "license_url"):
            if item.get(field) != asset.get(field):
                errors.append(f"{visual_id}:manifest_registry_{field}_mismatch")
        if asset.get("rights_status") == "approved_with_credit":
            attribution = str(asset.get("attribution_text", "")).strip()
            if not attribution:
                errors.append(f"{visual_id}:approved_with_credit_missing_attribution_text")
            elif attribution not in str(item.get("caption", "")):
                errors.append(f"{visual_id}:caption_missing_required_attribution")
        errors.extend(visual_semantic_errors(
            visual_id=visual_id, role=role, argument=argument, asset=asset,
            claim_ids=claim_ids, claims=claims, known_source_ids=source_ids,
        ))
        try:
            asset_root = base_package_root if asset_id in base_records else job_package_root
            path = resolve_file(asset_root, str(asset.get("file_path", "")))
        except ValueError as exc:
            errors.append(f"{visual_id}:unsafe_file_path:{exc}")
            continue
        if not path.is_file():
            errors.append(f"{visual_id}:missing_file:{asset.get('file_path')}")
        elif sha256(path) != asset.get("sha256"):
            errors.append(f"{visual_id}:sha256_mismatch")
        if asset_id in seen_assets:
            errors.append(f"{visual_id}:duplicate_asset_with:{seen_assets[asset_id]}")
        seen_assets[asset_id] = visual_id
        if not str(item.get("reader_question", "")).strip() or not str(item.get("caption", "")).strip():
            errors.append(f"{visual_id}:missing_reader_question_or_caption")
    manifest_ids = {str(item.get("visual_id")) for item in manifest.get("visuals", []) if isinstance(item, dict)}
    planned_ids = {str(item.get("visual_id")) for item in blueprint.get("visual_plan", []) if isinstance(item, dict)}
    if set(placements) != manifest_ids:
        errors.append("content_model_and_manifest_visual_sets_differ")
    if planned_ids != manifest_ids:
        errors.append("blueprint_and_manifest_visual_sets_differ")
    return {
        "schema_version": "1.0.0", "job_id": model.get("job_id"), "stage": "E3_visual_claim_validation",
        "valid": not errors, "errors": errors, "checked_visuals": len(manifest.get("visuals", [])),
        "image_registry_sha256": registry_sha256,
        "base_image_registry_sha256": base_registry_sha256,
        "runtime_registry_receipt_sha256": receipt_sha256,
        "visual_projection_sha256": projection_sha256,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--blueprint", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--claims", type=Path, required=True)
    parser.add_argument("--sources", type=Path, required=True)
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--images", type=Path, required=True)
    parser.add_argument("--base-images", type=Path, required=True,
                        help="signed Reference Pack image_registry; never modified")
    parser.add_argument("--runtime-registry-receipt", type=Path, required=True)
    parser.add_argument("--base-package-root", type=Path, required=True,
                        help="read-only staged Reference Pack root for signed base assets")
    parser.add_argument("--job-package-root", type=Path, required=True,
                        help="job-local root for supplemental/generated runtime assets")
    parser.add_argument("--report", type=Path)
    parser.add_argument("--validated-manifest", type=Path,
                        help="write a copy with machine-derived validation_status and per-visual validation")
    args = parser.parse_args()
    base_package_root = args.base_package_root.resolve()
    job_package_root = args.job_package_root.resolve()
    if not base_package_root.is_dir() or not job_package_root.is_dir():
        raise FileNotFoundError("--base-package-root and --job-package-root must both exist")
    model, blueprint, manifest = load(args.model), load(args.blueprint), load(args.manifest)
    result = validate(
        model, blueprint, manifest, load(args.claims), load(args.sources), load(args.evidence),
        load(args.images), load(args.base_images), load(args.runtime_registry_receipt),
        base_package_root, job_package_root,
    )
    rendered = json.dumps(result, ensure_ascii=False, indent=2)
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(rendered, encoding="utf-8")
    if args.validated_manifest:
        validated = json.loads(json.dumps(manifest, ensure_ascii=False))
        validated["image_registry_sha256"] = result["image_registry_sha256"]
        validated["base_image_registry_sha256"] = result["base_image_registry_sha256"]
        validated["runtime_registry_receipt_sha256"] = result["runtime_registry_receipt_sha256"]
        validated["visual_projection_sha256"] = result["visual_projection_sha256"]
        validated["validation_status"] = "passed" if result["valid"] else "repair_required"
        for item in validated.get("visuals", []):
            if isinstance(item, dict):
                prefix = f"{item.get('visual_id')}:"
                item_errors = [value for value in result["errors"] if value.startswith(prefix)]
                item["validation"] = {"status": "passed" if not item_errors else "repair_required", "errors": item_errors}
        args.validated_manifest.parent.mkdir(parents=True, exist_ok=True)
        args.validated_manifest.write_text(json.dumps(validated, ensure_ascii=False, indent=2), encoding="utf-8")
    print(rendered)
    return 0 if result["valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
