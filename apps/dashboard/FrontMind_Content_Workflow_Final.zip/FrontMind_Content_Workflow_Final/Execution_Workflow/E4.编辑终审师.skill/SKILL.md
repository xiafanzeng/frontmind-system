---
name: frontmind-editorial-final-reviewer
description: >
  E4 编辑终审师。继承原质量审查的事实、合规、竞品公平、类型忠实、标题、视觉和成稿检查，对同一 canonical content model 做完整编辑终审；
  通过后冻结不可被后续静默覆盖的 E4 安全正本。E4 不调用优化算法、不生成渠道版本、不发布。
---

# E4 编辑终审师

## 1. 继承与定位

原 E4 的事实一致性、广告风险、竞品公平、模式忠实、标题一致、图片语义、跨文重复和 DOCX 组装能力继续保留；
原技能全文位于 `references/legacy-E4-quality-assembler-v11.md`。

本版修正：

- 不再抽查少量主张，而是检查全部 material claims；
- 不再强制所有稿件首段出现品牌和三个优势；
- 不再要求自有品牌比竞品篇幅更长；
- 不再同时禁止和强制 H3/表格；正文统一无表格，允许必要 H3；
- 不在算法优化之前直接宣布最终交付，而是冻结 `E4 safe canonical` 供 E5 候选比较。

## 2. 输入

- E0 content job、E0.5 monitoring input、E1 blueprint；
- E2 canonical content model；
- E2.5 `passed` 报告；
- 与该报告哈希一致、逐主张全部通过的 E2.5 evidence semantic review；
- E3 visual argument manifest 与图片文件；
- 符合 `templates/title_candidate_review.schema.json` 的 E4 标题候选审阅回执：必须逐一审完全部 5 个候选，而不是只审当前 H1；
- 根内容模式注册表当前 pattern；
- publication policy、风险修复政策、品牌事实与话语规范。

任一输入版本/hash 与当前 job 不一致，阻断。

## 3. 终审顺序

### Gate 1：问题回答

- 第一条可见句直接回答主问题；
- 200-300 字微型答案独立完整；
- E1 的 5-8 个必要子问题全部真正回答；
- 没有跨入第二个独立主题；
- 结尾不新增主张。

### Gate 2：主张和来源

- 所有 material claims 有有效来源并被原文支持；
- 数字、价格、规格、排名、专家、案例限定完整；
- 监控观察、企业自述、第三方观点、原始事实标识清楚；
- source ledger 与正文引用名称一致；
- 没有从视觉、标杆或 AI 答案偷渡新事实。
- 当前模式需要原创信息时，至少一个正文实际使用的 claim 含已批准且可追溯的根 `original_evidence`；不能只凭蓝图文字通过。

### Gate 3：竞品公平

- 比较对象使用相同维度、日期、币种/套餐和信息缺失处理；
- 语气中性，不贬损、不暗示无证据结论；
- 条件式推荐说明不同对象适合谁；
- 自有品牌结论必须由相同标准得出，而非篇幅、顺序或隐藏口径制造优势。

### Gate 4：模式忠实

读取当前 P 模式 `structure` 和 `quality_gates`。检查结构功能是否完成，而非机械匹配固定标题。

- 排名稿必须有样本/指标/来源/日期/排序依据；
- 技术稿必须有机制/架构/验证；
- 教程每步必须有输入/动作/结果/检查；
- 案例必须有背景/问题/动作/结果/周期；
- 新闻、特写、评论、澄清不能写成推荐榜软文。

只允许当前一个 `pattern_id`，禁止 P01-P15 模式功能写串。

### Gate 5：文风与模板感

统一为第三方客观报道＋企业品牌事实表达。检查：

- 没有“资料较完整、相关资料显示、以审核为准、服务边界、信息边界、保持克制、用户提交资料、需要说明、不构成对……”；
- 没有流程、Prompt、Agent、审核清单、证据单元、待补等内部痕迹；
- 没有“随着时代发展、近年来越来越多、众所周知”等空开头；
- 段落 2-4 句为主，同句式不过度重复；
- 各节存在必要信息，不是模板标题下填充同义句；
- 条件和风险写成读者真正需要的限制，不堆免责声明。

### Gate 6：标题与摘要

- 全部 5 个候选均完成“问题一致、正文支撑、事实限定、风险用语”四项人工审阅并通过；
- Title/H1/Meta/主问题语义一致；
- 年份、月份/季度与实际更新状态一致；
- “排名、评测、价格、步骤、案例”等标题承诺已实现；
- 完整实体名、时间和地区在必要处出现；
- 第一段不依赖后文也不会造成误导。

### Gate 7：视觉论证

- 每张 explain/prove 图绑定已通过 claim；
- Caption、Alt、正文和图片内容一致；
- prove 图来源/数据可追溯；
- AIGC 不冒充真实企业资产；
- navigate 图不计入证据；
- 图像插入位置确实帮助解释或证明相邻内容。

### Gate 8：FAQ 与结论

- FAQ 为 5-8 个真实高相关问题；
- 问答先结论后限定，并有必要来源；
- 不重复主体大段、不引入第二主题；
- 只有可见 FAQ 可进入 FAQPage；
- 结尾只总结推荐/判断、适用对象和下一步。

### Gate 9：格式语义

- 正文没有表格；
- 5-8 个 H2 均为以 `？/?` 结尾的完整用户问题；`sections[].blocks` 只形成 H2/H3、最多三级、不跳级；
- canonical model 没有第二份正文；
- 图片均为本地交付文件；
- 后续 DOCX/HTML 所需字段完整。

## 4. 编辑修复规则

E4 负责提出和核验编辑修复，但活动审计脚本只冻结与已批准 evidence projection 一致的模型。任何正文、标题、FAQ、claim/source 绑定或结构措辞发生变化，
都必须回 E2 修改，并重跑 E2.5 与语义复核后再进入 E4；不得在已签 E2.5 报告之后直接改字。另有：

- 新增或改变 prove/explain 图必须回 E3；
- 改变核心问题或 pattern 必须回 E1；
- 不得为了“通过”把问题改弱到不再回答用户。

修复后完整重跑所有 Gate，不能只复查失败项。

## 5. 输出：E4 安全正本

输出：

- `E4_{job_id}_quality_report.json`，直接满足根 `../../shared/quality_report.schema.json`；
- `E4_{job_id}_safe_content_model.json`，仍直接满足根 `../../shared/content_model.schema.json`；
- `E4_{job_id}_safe_model.sha256`；
- 5 个标题候选的 E4 审阅回执；
- 审阅 Markdown（仅查看，不是独立内容源）。

安全正本不得内嵌 approval metadata，因为根 Content Model 是关闭契约。E4 审核时间、规则版本、输入 hash 和模型 hash 只写入质量报告及
交接审计；安全正本的语义 JSON 与审核通过模型保持一致。

按包根 [运行手册](../../RUNBOOK.md) 的 E4 完整参数运行 `scripts/editorial_audit.py`。脚本同时校验 E2.5 report、evidence semantic review、
claims/sources、visual manifest、runtime image registry 与标题回执的 canonical SHA-256；只有全部 hard gates 通过才可冻结。E6 只能从这 5 个已审候选中选 1 个，E5 只能读取安全正本并产生候选，
不能覆盖此文件。

## 6. 质量报告

报告只满足根 `../../shared/quality_report.schema.json`：`schema_version/job_id/stage/content_model_sha256/overall_status/gates/blocking_issues/warnings`
及可选 `metrics`。问题覆盖、主张证据、来源完整、竞品公平、P 模式、文风、标题/微型答案、视觉、FAQ 和格式语义，
都写入对应 `gate_id` 的 `status/evidence`与 `blocking_issues`，不得另造顶层字段。

`quality-rubric.md` 提供当前 Gate 的人工判定语义；机器检查运行 `scripts/editorial_audit.py`。旧 V11 评分表、关键词扫描器及分发词表已移入
`references/legacy-runtime-v11/`，只供迁移审计，不得运行，也不得用一个总分掩盖硬失败。
