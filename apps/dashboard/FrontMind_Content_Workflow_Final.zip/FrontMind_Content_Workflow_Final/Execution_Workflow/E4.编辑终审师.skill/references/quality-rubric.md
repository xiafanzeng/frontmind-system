# E4 单篇内容终审语义准则

本准则只解释根 `quality_report.schema.json` 的 Gate 如何判定。它不建立分数、等级或第二份报告契约；任一 blocking Gate 失败即不得冻结 E4 安全正本，
不得被字数、总分、话语 Token 命中率或其他优点抵消。

## 1. 问题与答案

- `question_answered`：只回答一个已确定主问题；5–8 个必要子问题均有实质答案；所有 H2 是完整问句；5 个标题候选均已逐一审阅。
- `micro_answer_complete`：首句 40–80 字，微型答案 200–300 字且以首句原文开头。首句实质字符不少于 30、微型答案不少于 120，
  实质字符占比不低于 55%，并包含主问题/实体的关键 token。纯标点、空白、重复符号或无意义字符串必须失败。

## 2. 主张、来源与口径

- `claim_evidence_complete`：正文实际使用的全部 material claims 均在 canonical claim registry 中可用，公开主张至少绑定一个有效来源，来源在参考文献可见。
- `statistics_and_price_scoped`：统计数据含时间、样本量、单位、地区/人群和方法；价格含币种、套餐、地区、版本、有效日及附加条件。
- `freshness_and_dates`：时间敏感事实和标题年份与实际截止日一致，不用无法判断的“最新/近期”代替日期。
- `original_information`：按根 P 模式注册表的硬门/条件门执行；需要时必须是正文已用、已授权、带方法/范围/采集时间且可追溯的 `original_evidence`。

## 3. 竞品公平与实体清晰

- `competitor_fairness`：P01/P02 必须通过封闭的同维度矩阵。每个单元明确值/缺失状态、来源、截止日、口径和条件，不得以空对象伪装覆盖。
- `entity_clarity`：重要品牌、机构、产品、型号和版本使用完整名称，不用“某品牌/该产品/业内人士”隐去关键主体。

## 4. P 模式、文风、FAQ

- `pattern_consistency`：只使用当前一个 P01–P15 `pattern_id`，完成其 `structure` 与 `quality_gates` 的功能，不把榜单、对比、教程、案例、新闻或澄清模式写串。
- `voice_and_no_meta_language`：第三方客观报道＋有证据的品牌事实表达；无内部审稿语、Prompt/Agent 痕迹、空开头、贬损和正文表格。
  每个 H2 至少一段实质答案并命中该 H2 的非通用关键词；禁止“该部分/本节将/下面介绍”等占位元叙述。不同节不得用同一句式骨架只替换主题词，
  3 个及以上 FAQ 不得使用相同或高度近似答案；必要的品牌名和专业术语重复不单独构成失败。
- `faq_relevance`：只保留 5–8 个与本题决策最相关的真实问题，每个问题以 `？/?` 结尾，答案不引入第二主题。

## 5. 视觉论证与权限

- `visual_argument_and_rights`：blueprint、Content Model 与 manifest 的 `visual_id/role` 集合一致；`proof→prove`、`cover→navigate`、`process/explanation→explain`。
- explain/prove 必须绑定可用 claim；生成解释图不得声称实体/产品/案例/事件证明角色；生成数据图必须有 `source_ids`。
- 只使用当前 hash 绑定的 canonical image registry；权限必须为 `approved/approved_with_credit`。需署名资产的 `attribution_text` 必须完整出现在 Caption，
  Caption 是正式可见内容，不得禁用或在交付时丢失。

## 6. E6 收口 Gate

E4 中 `html_structure_and_visible_schema`、`docx_html_semantic_parity`、`optimization_fact_integrity` 标记为 `not_applicable`，由 E6 在标题选择、候选回归和同源渲染后收口：

- HTML 唯一 H1、H2 全为完整问句、无表格，JSON-LD 仅包含当前 P 模式允许且页面可见的内容。
- DOCX/HTML 来自同一 approved canonical model，段落、实体、数字、FAQ、来源和图片语义一致。
- E5 候选必须通过事实 token 位置绑定、完整结构比较和逐改写字段语义审查；任一失败整篇回退 E4。

## 7. 报告唯一契约

E4/E6 报告只允许根 Schema 字段：`schema_version`、`job_id`、`stage`、`content_model_sha256`、`overall_status`、`gates`、
`blocking_issues`、`warnings`及可选 `metrics`。上述语义必须落在对应 `gate_id`的 `status/evidence`和 `blocking_issues`，不新增顶层字段。
