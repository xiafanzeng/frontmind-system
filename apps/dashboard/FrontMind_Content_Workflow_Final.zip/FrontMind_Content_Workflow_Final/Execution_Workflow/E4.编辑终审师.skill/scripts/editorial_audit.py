#!/usr/bin/env python3
"""Produce a root quality_report and freeze an unchanged E4 editorial master."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import re
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "shared"))
from schema_validation import validate_root, validate_schema  # noqa: E402
from text_quality import answer_pair_errors, article_specificity_errors, material_claim_binding_errors  # noqa: E402
from content_projections import evidence_projection_sha256, visual_projection_sha256  # noqa: E402
from visual_semantics import visual_claim_relevance_errors, visual_semantic_errors  # noqa: E402
from reference_equivalence import reference_equivalence_errors  # noqa: E402


FORBIDDEN = (
    "资料较完整", "相关资料显示", "以审核为准", "服务边界", "信息边界", "保持克制",
    "用户提交资料", "需要说明", "不构成对", "Execution Layer", "证据单元", "待人工复核",
    "HarnessGEO", "AutoGEO", "optimized_by",
)

ROLE_COMPATIBILITY = {
    "cover": {"cover", "decorative"},
    "proof": {"entity_proof", "product_proof", "case_proof", "event_proof", "data_evidence"},
    "comparison": {"comparison"},
    "process": {"process_explanation"},
    "data": {"data_evidence"},
    "explanation": {"process_explanation", "comparison"},
}
ROLE_ARGUMENT_COMPATIBILITY = {
    "cover": {"navigate"}, "proof": {"prove"}, "comparison": {"explain", "prove"},
    "process": {"explain"}, "data": {"explain", "prove"}, "explanation": {"explain"},
}
PROOF_ASSET_ROLES = {"entity_proof", "product_proof", "case_proof", "event_proof", "data_evidence"}


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain an object")
    return value


def canonical_bytes(value: dict[str, Any]) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def digest(value: dict[str, Any]) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def blocks(model: dict[str, Any]):
    for section in model.get("sections", []):
        if not isinstance(section, dict):
            continue
        for block in section.get("blocks", []):
            if isinstance(block, dict):
                yield block
        for subsection in section.get("subsections", []):
            if isinstance(subsection, dict):
                for block in subsection.get("blocks", []):
                    if isinstance(block, dict):
                        yield block


def text(model: dict[str, Any]) -> str:
    metadata, lead = model.get("metadata", {}), model.get("lead", {})
    chunks = [str(metadata.get(key, "")) for key in ("title", "h1", "meta_description")]
    # Every candidate can become the final H1 at E6, so all five must pass the
    # same publication-language scan before the E4 master is frozen.
    chunks.extend(str(value) for value in metadata.get("title_candidates", []) if isinstance(value, str))
    chunks.extend(str(lead.get(key, "")) for key in ("direct_answer_sentence", "micro_answer"))
    for section in model.get("sections", []):
        if isinstance(section, dict):
            chunks.append(str(section.get("h2_question", "")))
            for subsection in section.get("subsections", []):
                if isinstance(subsection, dict):
                    chunks.append(str(subsection.get("h3", "")))
    for block in blocks(model):
        chunks.append(str(block.get("text", "")))
        chunks.extend(str(item) for item in block.get("items", []) or [])
    for item in model.get("faq", []):
        if isinstance(item, dict):
            chunks.extend((str(item.get("question", "")), str(item.get("answer", ""))))
    conclusion = model.get("conclusion", {})
    if isinstance(conclusion, dict):
        chunks.extend(str(conclusion.get(key, "")) for key in ("summary", "fit", "next_action"))
    return "\n".join(chunks)


def unicode_chars(value: str) -> int:
    return len(value.strip())


def substantive_chars(value: str) -> int:
    return len(re.findall(r"[\u3400-\u9fffA-Za-z0-9]", value))


def used_claims(model: dict[str, Any]) -> set[str]:
    result: set[str] = set()
    lead = model.get("lead", {})
    if isinstance(lead, dict):
        result.update(str(value) for value in lead.get("claim_ids", []))
    for block in blocks(model):
        result.update(str(value) for value in block.get("claim_ids", []))
    for item in model.get("faq", []):
        if isinstance(item, dict):
            result.update(str(value) for value in item.get("claim_ids", []))
    conclusion = model.get("conclusion", {})
    if isinstance(conclusion, dict):
        result.update(str(value) for value in conclusion.get("claim_ids", []))
    return result


def gate(gate_id: str, passed: bool | None, evidence: str) -> dict[str, Any]:
    return {"gate_id": gate_id, "status": "not_applicable" if passed is None else "pass" if passed else "fail", "evidence": evidence}


def _matrix_contract_module():
    """Load the one E2.5 matrix implementation; E4 must not fork its rules."""
    path = Path(__file__).resolve().parents[2] / "E2.5.证据预检师.skill" / "scripts" / "matrix_contract.py"
    spec = importlib.util.spec_from_file_location("frontmind_matrix_contract", path)
    if spec is None or spec.loader is None:
        return None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def validate_matrix_with_single_contract(
    matrix: dict[str, Any], source_ids: set[str], job_id: str, pattern_id: str,
    expected_subjects: set[str] | None = None,
) -> list[dict[str, Any]]:
    module = _matrix_contract_module()
    if module is None:
        return [{"code": "COMPETITOR_MATRIX_VALIDATOR_MISSING"}]
    return module.validate_competitor_matrix(matrix, source_ids, job_id, pattern_id, expected_subjects)


def matrix_requirement_with_single_contract(
    model: dict[str, Any], blueprint: dict[str, Any], claim_registry: dict[str, Any],
) -> tuple[bool, list[str], list[str]]:
    module = _matrix_contract_module()
    if module is None:
        return True, ["matrix_contract_missing"], []
    return module.competitor_matrix_requirement(model, blueprint, claim_registry)


def audit(model: dict[str, Any], evidence: dict[str, Any], visuals: dict[str, Any], blueprint: dict[str, Any],
          claim_registry: dict[str, Any], source_registry: dict[str, Any], pattern_registry: dict[str, Any],
          title_review: dict[str, Any], semantic_review: dict[str, Any], image_registry: dict[str, Any]) -> dict[str, Any]:
    full_text = text(model)
    model_sha256 = digest(model)
    blueprint_sha256 = digest(blueprint)
    handoff_failures: list[str] = []
    for value, schema_name, label in (
        (model, "content_model.schema.json", "E4 content_model"),
        (blueprint, "article_blueprint.schema.json", "E4 article_blueprint"),
        (claim_registry, "registries.schema.json", "E4 claim_registry"),
        (source_registry, "registries.schema.json", "E4 source_registry"),
        (image_registry, "registries.schema.json", "E4 image_registry"),
    ):
        try:
            validate_root(value, schema_name, label)
        except ValueError as exc:
            handoff_failures.append(f"canonical_schema_failure:{exc}")
    for value, path, label in (
        (evidence, Path(__file__).resolve().parents[2] / "E2.5.证据预检师.skill" / "templates" / "evidence_preflight.schema.json", "E4 evidence receipt"),
        (visuals, Path(__file__).resolve().parents[2] / "E3.视觉论证师.skill" / "templates" / "visual_argument_manifest.schema.json", "E4 visual manifest"),
        (title_review, Path(__file__).resolve().parents[1] / "templates" / "title_candidate_review.schema.json", "E4 title review"),
        (semantic_review, Path(__file__).resolve().parents[2] / "E2.5.证据预检师.skill" / "templates" / "evidence_semantic_review.schema.json", "E4 evidence semantic review"),
    ):
        try:
            validate_schema(value, path, label)
        except ValueError as exc:
            handoff_failures.append(f"stage_schema_failure:{exc}")
    if evidence.get("schema_version") != "1.0.0" or evidence.get("job_id") != model.get("job_id"):
        handoff_failures.append("evidence_schema_or_job_mismatch")
    evidence_projection_hash = evidence_projection_sha256(model)
    if evidence.get("evidence_projection_sha256") != evidence_projection_hash:
        handoff_failures.append("evidence_projection_hash_mismatch")
    if evidence.get("article_blueprint_sha256") != blueprint_sha256:
        handoff_failures.append("evidence_blueprint_hash_mismatch")
    if evidence.get("status") != "passed" or evidence.get("blocking_findings"):
        handoff_failures.append("evidence_preflight_not_clean_pass")
    if any(
        not isinstance(item, dict) or item.get("access_verified") is not True
        for item in evidence.get("source_checks", [])
    ):
        handoff_failures.append("evidence_source_access_not_verified")
    claim_registry_sha256 = digest(claim_registry)
    source_registry_sha256 = digest(source_registry)
    pattern_registry_sha256 = digest(pattern_registry)
    evidence_receipt_sha256 = digest(evidence)
    semantic_review_sha256 = digest(semantic_review)
    if (
        evidence.get("semantic_review_status") != "passed"
        or evidence.get("semantic_review_sha256") != semantic_review_sha256
        or semantic_review.get("job_id") != model.get("job_id")
        or semantic_review.get("evidence_projection_sha256") != evidence_projection_hash
        or semantic_review.get("claim_registry_sha256") != claim_registry_sha256
        or semantic_review.get("source_registry_sha256") != source_registry_sha256
        or semantic_review.get("competitor_matrix_sha256") != (
            digest(evidence.get("competitor_dimension_matrix", {}))
            if evidence.get("competitor_dimension_matrix") else None
        )
        or semantic_review.get("overall_status") != "passed"
    ):
        handoff_failures.append("evidence_semantic_review_not_bound_or_passed")
    if evidence.get("claim_registry_sha256") != claim_registry_sha256:
        handoff_failures.append("evidence_claim_registry_hash_mismatch")
    if evidence.get("source_registry_sha256") != source_registry_sha256:
        handoff_failures.append("evidence_source_registry_hash_mismatch")
    if evidence.get("content_pattern_registry_sha256") != pattern_registry_sha256:
        handoff_failures.append("evidence_pattern_registry_hash_mismatch")
    if visuals.get("schema_version") != "1.0.0" or visuals.get("job_id") != model.get("job_id"):
        handoff_failures.append("visual_manifest_schema_or_job_mismatch")
    # E3 records the full model hash it saw for audit, but E4 may make
    # evidence-revalidated copy edits. The visual handoff is therefore enforced
    # by the stable visual projection below, not the stale full-model hash.
    visual_projection_hash = visual_projection_sha256(model)
    if visuals.get("visual_projection_sha256") != visual_projection_hash:
        handoff_failures.append("visual_manifest_projection_hash_mismatch")
    if visuals.get("validation_status") != "passed" or visuals.get("missing_assets"):
        handoff_failures.append("visual_manifest_not_clean_pass")
    image_registry_sha256 = digest(image_registry)
    visual_manifest_sha256 = digest(visuals)
    if image_registry.get("schema_version") != "1.0.0" or image_registry.get("registry_type") != "image_registry":
        handoff_failures.append("image_registry_contract_mismatch")
    if visuals.get("image_registry_sha256") != image_registry_sha256:
        handoff_failures.append("visual_manifest_image_registry_hash_mismatch")
    if blueprint.get("schema_version") != "1.0.0" or blueprint.get("job_id") != model.get("job_id"):
        handoff_failures.append("blueprint_schema_or_job_mismatch")
    for key in ("question_category", "primary_question", "product_scenario_subintent", "pattern_id"):
        if blueprint.get(key) != model.get(key):
            handoff_failures.append(f"blueprint_model_identity_mismatch:{key}")
    if pattern_registry.get("schema_version") != "1.0.0":
        handoff_failures.append("pattern_registry_schema_version_mismatch")

    blueprint_visual_ids = {
        str(item.get("visual_id")) for item in blueprint.get("visual_plan", []) if isinstance(item, dict)
    }
    model_visual_ids = {
        str(item.get("visual_id")) for item in model.get("visual_placements", []) if isinstance(item, dict)
    }
    manifest_visual_ids = {
        str(item.get("visual_id")) for item in visuals.get("visuals", []) if isinstance(item, dict)
    }
    if blueprint_visual_ids != model_visual_ids or model_visual_ids != manifest_visual_ids:
        handoff_failures.append("blueprint_model_manifest_visual_sets_differ")
    image_records = {
        str(item.get("asset_id")): item for item in image_registry.get("images", []) if isinstance(item, dict)
    }
    claims = {str(item.get("claim_id")): item for item in claim_registry.get("claims", []) if isinstance(item, dict)}
    passed_evidence_claim_ids = {
        str(item.get("claim_id")) for item in evidence.get("claim_checks", [])
        if isinstance(item, dict) and item.get("status") == "passed"
    }
    model_visuals = {
        str(item.get("visual_id")): item for item in model.get("visual_placements", []) if isinstance(item, dict)
    }
    blueprint_visuals_by_id = {
        str(item.get("visual_id")): item for item in blueprint.get("visual_plan", []) if isinstance(item, dict)
    }
    for item in visuals.get("visuals", []):
        if not isinstance(item, dict):
            handoff_failures.append("visual_manifest_item_invalid")
            continue
        visual_id, asset_id = str(item.get("visual_id")), str(item.get("asset_id"))
        placement = model_visuals.get(visual_id)
        planned = blueprint_visuals_by_id.get(visual_id)
        if not placement or any(item.get(key) != placement.get(key) for key in ("asset_id", "role", "alt_text", "after_section_id")):
            handoff_failures.append(f"visual_manifest_model_binding_mismatch:{visual_id}")
        if not planned or planned.get("role") != item.get("role"):
            handoff_failures.append(f"visual_blueprint_role_mismatch:{visual_id}")
        role, argument = str(item.get("role")), item.get("argument_function")
        asset = image_records.get(asset_id)
        if not asset:
            handoff_failures.append(f"visual_registry_asset_missing:{visual_id}:{asset_id}")
            continue
        rights = asset.get("rights_status")
        if rights not in {"approved", "approved_with_credit"}:
            handoff_failures.append(f"visual_rights_not_approved:{visual_id}:{rights}")
        if item.get("rights_status") != rights:
            handoff_failures.append(f"visual_rights_receipt_mismatch:{visual_id}")
        handoff_failures.extend(visual_semantic_errors(
            visual_id=visual_id, role=role, argument=argument, asset=asset,
            claim_ids=[str(value) for value in item.get("supports_claim_ids", [])], claims=claims,
            known_source_ids={
                str(value.get("source_id")) for value in source_registry.get("sources", []) if isinstance(value, dict)
            },
        ))
        handoff_failures.extend(visual_claim_relevance_errors(
            visual_id=visual_id, role=role, argument=argument, after_section_id=item.get("after_section_id"),
            claim_ids=[str(value) for value in item.get("supports_claim_ids", [])],
            model=model, passed_claim_ids=passed_evidence_claim_ids,
        ))
        for field in ("attribution_text", "license_name", "license_url"):
            if item.get(field) != asset.get(field):
                handoff_failures.append(f"visual_{field}_receipt_mismatch:{visual_id}")
        if rights == "approved_with_credit":
            attribution = str(asset.get("attribution_text", "")).strip()
            if not attribution or attribution not in str(item.get("caption", "")):
                handoff_failures.append(f"visual_attribution_missing:{visual_id}")
    sources = {str(item.get("source_id")): item for item in source_registry.get("sources", []) if isinstance(item, dict)}
    used = used_claims(model)
    handoff_failures.extend(reference_equivalence_errors(model, claim_registry))
    for index, reference in enumerate(model.get("references", [])):
        if not isinstance(reference, dict):
            continue
        source = sources.get(str(reference.get("source_id")))
        if source and (
            reference.get("display_name") != source.get("title")
            or reference.get("url") != source.get("url")
        ):
            handoff_failures.append(f"visible_reference_metadata_mismatch:{index}:{reference.get('source_id')}")
    lead = model.get("lead", {})
    direct, micro = str(lead.get("direct_answer_sentence", "")), str(lead.get("micro_answer", ""))
    title_candidates = model.get("metadata", {}).get("title_candidates", [])
    reviewed_candidates = title_review.get("candidates", []) if isinstance(title_review.get("candidates"), list) else []
    title_review_hash = digest(title_review)
    title_review_ok = bool(
        title_review.get("schema_version") == "1.0.0"
        and title_review.get("job_id") == model.get("job_id")
        and title_review.get("stage") == "E4_title_candidate_review"
        and title_review.get("overall_status") == "passed"
        and [item.get("title") for item in reviewed_candidates if isinstance(item, dict)] == title_candidates
        and len(reviewed_candidates) == 5
        and all(
            isinstance(item, dict)
            and all(item.get(key) is True for key in (
                "question_alignment_passed", "body_support_passed", "factual_scope_passed", "risk_language_passed"
            ))
            for item in reviewed_candidates
        )
    )
    coverage = evidence.get("question_coverage", [])
    subquestion_coverage = model.get("subquestion_coverage", [])
    h2_questions_ok = all(
        isinstance(section, dict) and re.search(r"[？?]$", str(section.get("h2_question", "")).strip())
        for section in model.get("sections", [])
    )
    faq_questions_ok = all(
        isinstance(item, dict) and re.search(r"[？?]$", str(item.get("question", "")).strip())
        for item in model.get("faq", [])
    )
    question_ok = bool(
        direct and micro and 5 <= len(coverage) <= 8 and all(item.get("covered") for item in coverage)
        and 5 <= len(subquestion_coverage) <= 8 and h2_questions_ok and faq_questions_ok and title_review_ok
        and not any(value.startswith("blueprint_") or value.startswith("evidence_") for value in handoff_failures)
    )
    answer_substance_failures = answer_pair_errors(direct, micro, str(model.get("primary_question", "")))
    question_ok = question_ok and not any(value.startswith("direct_answer") for value in answer_substance_failures)
    micro_ok = (
        40 <= unicode_chars(direct) <= 80 and 200 <= unicode_chars(micro) <= 300
        and micro.startswith(direct) and not answer_substance_failures
    )

    claim_failures = []
    scope_failures = []
    for claim_id in used:
        claim = claims.get(claim_id)
        if not claim or claim.get("verification_status") in {"needs_verification", "disallowed"} or claim.get("allowed_usage") in {"internal_only", "do_not_use"}:
            claim_failures.append(claim_id)
            continue
        if any(str(value) not in sources for value in claim.get("source_ids", [])):
            claim_failures.append(claim_id)
        if claim.get("claim_type") == "statistic":
            context = claim.get("statistical_context") or {}
            if not claim.get("as_of") or any(not context.get(key) for key in ("sample_size", "unit", "region_or_population", "methodology")):
                scope_failures.append(claim_id)
        if claim.get("claim_type") == "price":
            context = claim.get("commercial_context") or {}
            if any(not context.get(key) for key in ("currency", "plan", "region", "version", "valid_until", "conditions")):
                scope_failures.append(claim_id)

    matrix = evidence.get("competitor_dimension_matrix", {})
    fairness_ok = True
    matrix_findings: list[dict[str, Any]] = []
    matrix_required, matrix_reasons, comparison_subjects = matrix_requirement_with_single_contract(
        model, blueprint, claim_registry,
    )
    if matrix_required:
        if not isinstance(matrix, dict) or not matrix:
            fairness_ok = False
            matrix_findings = [{
                "code": "COMPETITOR_DIMENSION_MATRIX_REQUIRED",
                "reasons": matrix_reasons,
                "comparison_subjects": comparison_subjects,
            }]
        else:
            matrix_findings = validate_matrix_with_single_contract(
                matrix, set(sources), str(model.get("job_id")), str(model.get("pattern_id")),
                set(comparison_subjects),
            )
            fairness_ok = not matrix_findings
    elif isinstance(matrix, dict) and matrix:
        matrix_findings = validate_matrix_with_single_contract(
            matrix, set(sources), str(model.get("job_id")), str(model.get("pattern_id")),
            set(comparison_subjects),
        )
        fairness_ok = not matrix_findings

    vague_entities = [value for value in ("某品牌", "某机构", "某产品", "业内人士") if value in full_text]
    fresh_ok = bool(model.get("metadata", {}).get("as_of"))
    patterns = {str(item.get("id")): item for item in pattern_registry.get("patterns", []) if isinstance(item, dict)}
    pattern = patterns.get(str(model.get("pattern_id")), {})
    structured_types = set(str(value) for value in model.get("structured_data_types", []))
    eligible_json_ld = set(str(value) for value in pattern.get("eligible_json_ld", []))
    ineligible_json_ld = sorted(structured_types - eligible_json_ld)
    evidence_readiness = blueprint.get("evidence_readiness", {})
    original_gate = pattern_registry.get("original_information_gate", {})
    hard_original = model.get("pattern_id") in original_gate.get("hard_required_patterns", [])
    preflight_original = next((item for item in evidence.get("special_evidence_checks", [])
                               if isinstance(item, dict) and item.get("check") == "original_information_gate"), {})
    original_required = hard_original or preflight_original.get("required") is True
    authorized_original_claims = []
    review_eligible_original_claims = []
    for claim_id in used:
        original = claims.get(claim_id, {}).get("original_evidence")
        if not isinstance(original, dict) or original.get("authorization_status") not in {"public_approved", "anonymized_approved"}:
            continue
        traceable = bool(original.get("source_ids") or original.get("record_refs"))
        complete = traceable and all(original.get(key) for key in ("type", "methodology", "scope", "collected_at"))
        if complete:
            authorized_original_claims.append(claim_id)
            if original.get("type") in {"independent_test", "actual_usage_test", "customer_case"}:
                review_eligible_original_claims.append(claim_id)
    original_ok = bool(authorized_original_claims) if original_required else evidence_readiness.get("status") != "blocked"
    faq_count = len(model.get("faq", []))
    review_allowed_types = (
        {"customer_case", "actual_usage_test"} if model.get("pattern_id") == "P11"
        else {"independent_test", "actual_usage_test"}
    )
    review_eligible_original_claims = [
        claim_id for claim_id in review_eligible_original_claims
        if claims.get(claim_id, {}).get("original_evidence", {}).get("type") in review_allowed_types
    ]
    review_gate_ok = "Review" not in structured_types or bool(review_eligible_original_claims)
    pattern_ok = (
        model.get("pattern_id") == blueprint.get("pattern_id") and bool(pattern)
        and not ineligible_json_ld and review_gate_ok
    )
    voice_failures = [value for value in FORBIDDEN if value.lower() in full_text.lower()]
    specificity_failures = article_specificity_errors(model)
    unbound_material_failures = material_claim_binding_errors(model, claim_registry, require_content_function=True)
    table_found = bool(re.search(r"(?m)^\s*\|.+\|\s*$", full_text) or "<table" in full_text.lower())
    visual_ok = visuals.get("validation_status") == "passed" and not visuals.get("missing_assets") and not any(
        "visual" in value for value in handoff_failures
    )
    explain_prove = [item for item in visuals.get("visuals", []) if isinstance(item, dict) and item.get("argument_function") in {"explain", "prove"}]
    bound = [item for item in explain_prove if item.get("supports_claim_ids")]
    visual_ratio = len(bound) / len(explain_prove) if explain_prove else 1.0

    gates = [
        gate("question_answered", question_ok, f"direct answer present; planned section coverage={len(coverage)}; h2_questions={h2_questions_ok}; faq_questions={faq_questions_ok}; title_candidates_reviewed={title_review_ok}; title_candidate_review_sha256={title_review_hash}; substantive_failures={answer_substance_failures}"),
        gate("micro_answer_complete", micro_ok, f"direct={unicode_chars(direct)} Unicode chars; micro={unicode_chars(micro)}; substantive_failures={answer_substance_failures}"),
        gate("claim_evidence_complete", not claim_failures and not unbound_material_failures and evidence.get("status") == "passed" and not handoff_failures,
             f"failed claims={claim_failures}; unbound_material_claims={unbound_material_failures}; evidence_projection_sha256={evidence_projection_hash}; "
             f"claim_registry_sha256={claim_registry_sha256}; source_registry_sha256={source_registry_sha256}; "
             f"content_pattern_registry_sha256={pattern_registry_sha256}; evidence_receipt_sha256={evidence_receipt_sha256}; "
             f"semantic_review_sha256={semantic_review_sha256}; "
             f"handoff_failures={handoff_failures}"),
        gate("statistics_and_price_scoped", not scope_failures, f"unscoped claims={scope_failures}"),
        gate("competitor_fairness", fairness_ok, f"competitor dimension matrix findings={matrix_findings}"),
        gate("entity_clarity", not vague_entities, f"vague entities={vague_entities}"),
        gate("freshness_and_dates", fresh_ok, f"as_of={model.get('metadata', {}).get('as_of')}"),
        gate("original_information", original_ok, f"required={original_required}; authorized_used_claims={sorted(authorized_original_claims)}"),
        gate("faq_relevance", 5 <= faq_count <= 8, f"faq_count={faq_count}"),
        gate("pattern_consistency", pattern_ok,
             f"pattern={model.get('pattern_id')}; registry structure={pattern.get('structure', [])}; "
             f"structured_data={sorted(structured_types)}; ineligible={ineligible_json_ld}; "
             f"review_original_claims={sorted(review_eligible_original_claims)}"),
        gate("voice_and_no_meta_language", not voice_failures and not table_found and not specificity_failures,
             f"forbidden={voice_failures}; body_table={table_found}; specificity_failures={specificity_failures}"),
        gate("visual_argument_and_rights", visual_ok and visual_ratio == 1.0,
             f"manifest={visuals.get('validation_status')}; argument_ratio={visual_ratio:.3f}; visual_sets={sorted(model_visual_ids)}; "
             f"image_registry_sha256={image_registry_sha256}; visual_manifest_sha256={visual_manifest_sha256}; "
             f"visual_projection_sha256={visual_projection_hash}; "
             f"handoff_failures={handoff_failures}"),
        gate("html_structure_and_visible_schema", None, "E6 render gate"),
        gate("docx_html_semantic_parity", None, "E6 render gate"),
        gate("optimization_fact_integrity", None, "E5/E6 regression gate"),
    ]
    failures = [item for item in gates if item["status"] == "fail"]
    owners = {
        "question_answered": "E2", "micro_answer_complete": "E2", "claim_evidence_complete": "E2.5",
        "statistics_and_price_scoped": "E2.5", "competitor_fairness": "E2.5", "entity_clarity": "E2",
        "freshness_and_dates": "E2", "original_information": "human_evidence_request", "faq_relevance": "E1",
        "pattern_consistency": "E1", "voice_and_no_meta_language": "E2", "visual_argument_and_rights": "E3",
    }
    issues = [
        {"issue_id": f"issue_{index:03d}", "gate_id": item["gate_id"], "message": item["evidence"], "repair_owner": owners[item["gate_id"]]}
        for index, item in enumerate(failures, 1)
    ]
    return {
        "schema_version": "1.0.0",
        "job_id": model.get("job_id"),
        "stage": "E4_pre_optimization",
        "content_model_sha256": digest(model),
        "overall_status": "fail" if failures else "pass",
        "gates": gates,
        "blocking_issues": issues,
        "warnings": [],
        "metrics": {
            "faq_count": faq_count,
            "unsupported_claim_count": len(claim_failures),
            "unscoped_stat_count": len(scope_failures),
            "visual_argument_ratio": round(visual_ratio, 4),
            "heading_depth": 3 if any(section.get("subsections") for section in model.get("sections", []) if isinstance(section, dict)) else 2,
            "direct_answer_unicode_length": unicode_chars(direct),
            "direct_answer_substantive_length": substantive_chars(direct),
            "micro_answer_unicode_length": unicode_chars(micro),
            "micro_answer_substantive_length": substantive_chars(micro),
            "subquestion_coverage_count": len(subquestion_coverage),
            "authorized_original_evidence_count": len(authorized_original_claims),
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--visuals", type=Path, required=True)
    parser.add_argument("--blueprint", type=Path, required=True)
    parser.add_argument("--claims", type=Path, required=True)
    parser.add_argument("--sources", type=Path, required=True)
    parser.add_argument("--pattern-registry", type=Path, required=True)
    parser.add_argument("--image-registry", type=Path, required=True,
                        help="the same canonical image registry bound by the E3 manifest")
    parser.add_argument("--title-review", type=Path, required=True,
                        help="E4 review receipt covering all five title candidates")
    parser.add_argument("--semantic-review", type=Path, required=True,
                        help="the E2.5 human evidence-support review receipt")
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--safe-output", type=Path, required=True)
    parser.add_argument("--sha-output", type=Path, required=True)
    args = parser.parse_args()
    model = load(args.model)
    result = audit(
        model, load(args.evidence), load(args.visuals), load(args.blueprint),
        load(args.claims), load(args.sources), load(args.pattern_registry), load(args.title_review),
        load(args.semantic_review),
        load(args.image_registry),
    )
    validate_root(result, "quality_report.schema.json", "E4 quality_report")
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    if result["overall_status"] != "pass":
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 1
    # The editorial master is byte-for-byte semantic JSON content; approval lives
    # in the quality report so the root Content Model schema remains closed.
    args.safe_output.parent.mkdir(parents=True, exist_ok=True)
    args.safe_output.write_text(json.dumps(model, ensure_ascii=False, indent=2), encoding="utf-8")
    args.sha_output.write_text(result["content_model_sha256"] + "\n", encoding="utf-8")
    print(json.dumps({"status": "pass", "safe_model_sha256": result["content_model_sha256"]}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
