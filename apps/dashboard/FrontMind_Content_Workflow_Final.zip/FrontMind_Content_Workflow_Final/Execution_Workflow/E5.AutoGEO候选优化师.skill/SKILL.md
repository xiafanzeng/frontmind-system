---
name: frontmind-autogeo-candidate-optimizer
description: >
  E5 AutoGEO 候选优化师。读取 E4 安全 canonical content model，尝试使用 autogeo.rewriters 生成一个独立候选模型和完整字段 diff；
  绝不覆盖 E4、不使用全局词语替换或规则模拟 fallback。AutoGEO 不可用或失败时明确跳过并沿用 E4，由 E6 决定最终正本。
---

# E5 AutoGEO 候选优化师

## 1. 从旧 E5 保留什么

保留“在完成高质量正文后利用算法改善答案前置、结构清晰度、段落可抽取性”的价值，以及变化日志、风险扫描和唯一内容语义的原则。
旧 HarnessGEO/分发技能与脚本分别保存在 `references/legacy-E5-distribution-orchestrator-v11.md`、
`references/legacy-harnessgeo-integration.md` 和 `references/legacy-runtime-v11/harnessgeo_optimizer.py.md`，只供审计，禁止运行。

删除：渠道标题映射、分发计划、平台适配、唯一正本自动覆盖、`harnessgeo` 错误导入、规则替换 fallback、优化器内部 frontmatter。

## 2. 安全地位

E4 是安全正本；E5 只是实验候选。文件关系必须是：

```text
E4_safe_canonical_content_model.json   # 永久保留、只读
E5_autogeo_candidate.json              # 可能不存在
E5_autogeo_report.json                 # 必须存在
E5_field_diff.json                     # 只有候选成功时存在
```

无论 AutoGEO 是否运行，E5 都无权把候选标为 approved、canonical 或 final。

## 3. 输入

- E4 安全正本与 `.sha256`；
- E4 editorial audit，必须 passed；
- 当前 `pattern_id` 和注册表质量门；
- Content Job 的强制 `optimizer_target.dataset`、`optimizer_target.engine_llm` 和可选 `extra_options`，以及 API 环境。

先验证 E4 文件 hash。发现文件已变化时阻断，不对未知版本优化。

## 4. 唯一允许的算法路径

使用官方目标包：

```python
from autogeo.rewriters import rewrite_document
```

具体适配见 `references/autogeo-integration.md`。不得尝试 `harnessgeo.rewriters`，不得用字符串替换、同义词替换、规则模拟、第二个 LLM 或人工随机改写冒充 AutoGEO。

为保持 canonical model，优化器只改写已有文本字段，保持：job ID、主问题、四入口、产品子意图、pattern ID、section/block ID、
`subquestion_coverage`、claim ID、source ID、visual ID、
字段顺序和 FAQ 问题不变。标题、H1、数字事实和来源字段默认锁定；若算法返回结构外内容，本轮失败。

## 5. 允许与禁止

允许候选尝试：

- 让已有结论更前置；
- 拆分过长句或段落；
- 改善实体指代完整性；
- 提高同一事实的清晰度；
- 在不新增内容的前提下改善“结论—证据—建议”顺序。

禁止：

- 新增事实、数字、排名、对象、案例、认证、专家、来源、FAQ 或图片；
- 删除限定条件、负面信息、风险或替代方案；
- 改变比较结论、排序、适用人群、价格/版本/日期；
- 改写标题承诺或主问题；
- 写入 AutoGEO、Prompt、优化策略或内部元数据到正文；
- 用“最佳→较适合”“第一→较早布局”等全局词语替换。

## 6. 三种结果

### `candidate_generated`

AutoGEO 成功返回所有字段，输出候选、逐字段 diff、调用版本与配置摘要。`new_facts_status` 必须为
`unknown_pending_E6_regression`，不能硬编码 false。

### `skipped_autogeo_unavailable`

包、函数、API Key 或运行环境不可用。只输出报告，`fallback_model=E4`，不创建伪候选，不视为错误交付。

### `failed_autogeo_call`

调用中断、返回空文本、改变结构或部分字段失败。删除/不写候选，报告失败原因，`fallback_model=E4`。

三种结果都进入 E6；后两种直接让 E6 复核并交付 E4。

## 7. 输出报告

`E5_autogeo_report.json` 至少包含：

- `e4_safe_model_file`（仅安全文件名，不含本机绝对路径）与 `e4_safe_model_sha256`；
- `status`；
- `autogeo_import_path=autogeo.rewriters`；
- 包版本和运行配置；
- 成功/失败字段；
- 字段级字符 diff；
- 实体、数字、日期、币种、百分比和 source/claim ID 集合差异；
- `new_facts_status=unknown_pending_E6_regression`；候选必须继续满足根 `content_model.schema.json`，否则状态改为 `failed_autogeo_call`；
- `fallback_model=E4`；
- 禁止自动批准声明。

运行 `scripts/autogeo_candidate_optimizer.py`。脚本退出成功只表示已产生明确结果报告，不代表候选通过 E6。

## 8. 边界

E5 不输出 DOCX/HTML，不做分发、渠道、CMS、发布或线上回滚。交付格式只能由 E6 从最终 approved model 生成。
