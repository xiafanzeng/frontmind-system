# AutoGEO 安全接入

目标 API 为 `autogeo.rewriters.rewrite_document`。环境中的具体函数签名可能随官方包版本变化，因此：

1. 运行时记录 `autogeo` 包版本；
2. 适配层只传官方函数明确支持的参数；
3. 不捕获错误后改用规则重写；
4. 每个文本字段保留输入和输出 hash；
5. 任一字段失败则整篇候选失败，不拼接部分优化结果；
6. 不把 API Key、Prompt 或内部配置写进文章。

默认锁定字段：`schema_version/job_id/revision/pattern_id/metadata.title/metadata.h1/metadata.title_candidates/metadata.language/metadata.as_of/references/visual_placements/structured_data_types`。
可优化字段：`metadata.meta_description/lead.direct_answer_sentence/lead.micro_answer/sections[].blocks[].text/sections[].subsections[].blocks[].text/faq[].answer/conclusion.summary|fit|next_action`。

FAQ 问题、H2/H3 标题默认锁定，避免算法改变问题覆盖。若未来允许改标题，必须升级契约版本并新增 E6 标题回归门。
