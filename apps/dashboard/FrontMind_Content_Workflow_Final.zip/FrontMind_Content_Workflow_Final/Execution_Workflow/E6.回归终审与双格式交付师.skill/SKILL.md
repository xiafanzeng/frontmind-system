---
name: frontmind-regression-review-and-dual-format-delivery
description: >
  E6 回归终审与双格式交付师。比较 E5 AutoGEO 候选与 E4 安全正本，执行结构、事实、数字、实体、来源、竞品、文风和视觉全量回归；
  候选只有完全通过才可批准，否则自动沿用 E4。最终从同一个 approved canonical content model 生成 DOCX 和发布级 HTML，不做分发、CMS 或发布回滚。
---

# E6 回归终审与双格式交付师

## 1. 输入

- E4 safe canonical content model、hash、editorial audit；
- 根 P 模式注册表、E2.5 clean-pass evidence receipt、其逐主张 semantic review 与本稿 runtime claim/source registries；
- E5 AutoGEO report；成功时附 candidate 与 field diff；
- E3 visual argument manifest 与图片；
- E4 已审完全部 5 个标题的 `title_candidate_review`，以及符合 `templates/title_selection.schema.json` 的 E6 选 1 回执；
- 只读 Reference Pack 根与 job 根两个解析根、base/runtime image registries 及 runtime seed receipt；Pack 资产从 base root 解析，补充资产从 job root 解析；
- 根 `content_model.schema.json`、`delivery_manifest.schema.json`、`quality_report.schema.json` 和当前 P 模式；
- 发布 profile。

E4 hash 必须重新计算一致。E5 报告不可替代候选文件，候选文件也不可替代 E5 report。

## 2. 最终正本选择

### AutoGEO 未运行或失败

当 E5 状态为 `skipped_autogeo_unavailable` 或 `failed_autogeo_call`：

- 选择 E4；
- 记录 `selection_reason=E5 unavailable/failed; safe fallback`；
- 不把“没有算法候选”视为内容失败；
- 对 E4 再做格式交付前检查。

### 有候选

必须完整回归，不按长度变化阈值抽样。依次检查：

1. job、主问题、四入口/产品子意图、pattern、时间、Title/H1/5 个标题候选、section/block/FAQ/claim/source/visual ID 结构不变；
2. 所有数字、日期、百分比、币种、价格、版本、型号和完整实体集合无异常新增/删除；
3. 外部 claim/source registries、模型 `references`/`visual_placements`/`subquestion_coverage` 和 FAQ 问题保持不变；
4. 每个字段语义未改变事实、比较结论、排序、适用对象、限制、风险和条件；
5. 未新增内部元话语、绝对化表述、竞品贬低、模板腔；
6. 微型答案仍为 200-300 字，第一句仍为 40-80 字并直接回答；
7. 每段仍是结论—证据—建议，FAQ 仍 5-8 个；
8. 视觉 claim 绑定和插入位置没有失效；
9. 根 P 模式质量门全部重跑。

任何一项失败，整篇回退 E4；不得混合“候选的好段落＋E4 的安全段落”形成未经审核的新版本。

运行 `scripts/regression_review.py`。候选的语义审查必须有结构化 `semantic_review.json`；没有人工/模型语义通过记录时，脚本安全回退 E4。

## 3. Approved canonical content model

E6 只产生一个 `approved_content_model.json`，并继续严格满足根 Content Model Schema。以下批准信息不得塞入关闭的模型，必须写入
独立 `E6_regression_audit.json`：

- selected source：E4 或 E5 candidate；
- E4 hash、候选 hash 和 E6 audit；
- 最终批准时间；
- 当前 Schema/registry 版本。

DOCX 和 HTML 都只能读取批准模型，禁止分别编辑；回归审计以 hash 锁定该模型。
E6 只能从 E4 已逐一审过的 5 个候选中选择标题；选题回执必须绑定 E4 标题审阅回执 SHA256 与本轮 approved Content Model SHA256，且该 hash 已写入 E4 质量 Gate。

## 4. HTML 交付

输出发布级 `final.html`：

- 恰好一个 H1；
- `sections[].blocks` 按 H2/H3，最多三级、不跳级；
- 每个 H2 必须为以 `？/?` 结尾的完整用户问题；
- 页面 Title、H1、Meta Description 同主题；
- UTF-8、lang、viewport、canonical 可按 publication profile 配置；
- 图片使用本地相对路径、Alt、Caption、宽高；不使用临时 URL；
- 无正文表格；
- 可见正文、FAQ、步骤、产品/评论信息与 JSON-LD 一致。

结构化数据按 `structured_data_types` 条件生成：

- Article：文章基本信息在模型中存在；
- FAQPage：只包含页面可见的 5-8 个 FAQ；
- HowTo：只有可见步骤同时含输入/动作/结果/检查时；
- Product：只有可见正文提供产品实体及必要字段时；
- Review：只有存在真实、可归因的评测对象与评价方法时。

任何 `structured_data_types` 必须属于当前 P 模式的 `eligible_json_ld`。Product/Review/ItemList 的附加上下文必须满足
`templates/structured_data_context.schema.json`，禁止输入 `@context/@type`、offers、aggregateRating、URL 或其他未授权字段覆盖 renderer；
每个允许值必须出现在可见正文并绑定正文实际使用的公开 claim。Review 还须绑定经授权、带方法与范围的一手测试/实际使用证据；P11 可使用经授权客户案例。
ItemList 名称与顺序必须和 E2.5 竞品矩阵完全一致。不得为了 GEO 同时机械添加全部 Schema。

## 5. DOCX 交付

先从 approved model 生成同源 Markdown，再调用保留并升级的
`../E4.编辑终审师.skill/scripts/md2docx.py --keep-title`：

- 保留唯一文章标题；
- H2/H3 转 Word 样式；
- 图片物理嵌入；
- 无原生 Word 表格；
- 不含 Markdown、HTML、内部元数据和占位符；
- 正文、FAQ、数字、来源名和图片与 HTML 一致。

## 6. 跨格式一致性

渲染后从 DOCX 和 HTML 提取可见文本进行规范化对比。允许标点/空白和 Caption 样式差异，不允许段落、实体、数字、FAQ 或结论差异。

必须检查：

- HTML 只有一个 H1、DOCX 只有一个标题段；
- 两者正文无表格；
- 图片数量与 manifest 一致，所有 explain/prove 图都出现；
- JSON-LD 的问答/步骤不超出可见内容；
- 文件可打开、DOCX 图片内嵌、HTML 无绝对本地路径。

## 7. 输出

```text
approved_content_model.json
approved_source.md
final.docx
final.html
metadata.json
structured_data.json
title_selection_receipt.json
images/*
E6_quality_report.json
render_audit.json
delivery_manifest.json
```

按包根 [运行手册](../../RUNBOOK.md) 的 E6 完整参数先运行 `regression_review.py`，再运行 `render_delivery.py`。后者强制接收 base/runtime image registries、
两类 package roots、runtime receipt、visual manifest、regression/E4 quality、title review/selection、E2.5 evidence/semantic review、claims/sources 与 staged pattern registry。
`--output-dir` 必须是全新或空目录；工具在写 manifest 前核对目录文件集合与本轮 artifacts 完全一致，拒绝遗留旧稿或内部审计文件。
`delivery_manifest.json` 必须逐一登记上述每个实际输出文件（Manifest 自身除外）及图片的相对路径和 SHA256；不得把 render audit
冒充 editorial report。最终交付不包含渠道版本、分发计划、CMS 操作、上线验证或回滚流程。

## 8. 硬失败

- E5 候选在无语义审查时获批；
- 候选改变任何事实或限制仍被部分合并；
- DOCX/HTML 分别从不同源文件制作；
- HTML 多 H1、标题与正文问题不一致或 Heading 跳级；
- JSON-LD 含不可见内容；
- DOCX/HTML 任一正文出现表格或内部元话语；
- 图片热链、缺失、未内嵌或 claim 绑定失效。
