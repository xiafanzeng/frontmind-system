# E5→E6 语义回归契约

候选语义审查必须逐字段记录，至少包括：

- `fact_meaning_unchanged`
- `comparison_conclusion_unchanged`
- `ranking_and_order_unchanged`
- `fit_audience_unchanged`
- `limitations_and_risks_preserved`
- `time_region_version_preserved`
- `source_attribution_preserved`
- `question_answering_improved_or_equal`
- `voice_and_pattern_conformance_passed`

所有字段为 true 且 `status=passed` 才能选择候选。审查说明不能只写“整体无问题”。如果审查无法判断，选择 E4。

`field_reviews` 必须与 E5 diff 中 `before != after` 的字段路径一一对应，不得缺失、增补或重复；每项同时绑定改写前后文本 SHA256并记录具体审查说明。

所有 hash 统一为 **canonical JSON SHA256**：先按 UTF-8、`sort_keys=true`、无多余空格序列化 JSON 对象，再计算 SHA256。
`field_reviews.before_sha256/after_sha256` 是对对应字段的原始 UTF-8 字符串直接计算 SHA256。
