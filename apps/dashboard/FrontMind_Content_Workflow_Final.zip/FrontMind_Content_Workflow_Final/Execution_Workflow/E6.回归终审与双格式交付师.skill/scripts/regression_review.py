#!/usr/bin/env python3
"""Select E4 or E5 candidate after deterministic and semantic regression."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "shared"))
from schema_validation import validate_root, validate_schema  # noqa: E402
from text_quality import answer_pair_errors, article_specificity_errors, material_claim_binding_errors  # noqa: E402


FORBIDDEN = (
    "资料较完整", "相关资料显示", "以审核为准", "服务边界", "信息边界", "保持克制",
    "用户提交资料", "需要说明", "不构成对", "Execution Layer", "证据单元", "待人工复核",
    "HarnessGEO", "AutoGEO", "optimized_by",
)
SEMANTIC_KEYS = (
    "fact_meaning_unchanged", "comparison_conclusion_unchanged", "ranking_and_order_unchanged",
    "fit_audience_unchanged", "limitations_and_risks_preserved", "time_region_version_preserved",
    "source_attribution_preserved", "question_answering_improved_or_equal", "voice_and_pattern_conformance_passed",
)


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain an object")
    return value


def digest(value: dict[str, Any]) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def text_digest(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def text(model: dict[str, Any]) -> str:
    metadata, lead = model.get("metadata", {}), model.get("lead", {})
    chunks = [str(metadata.get("meta_description", "")), str(lead.get("direct_answer_sentence", "")), str(lead.get("micro_answer", ""))]
    for section in model.get("sections", []):
        if not isinstance(section, dict):
            continue
        chunks.append(str(section.get("h2_question", "")))
        for block in section.get("blocks", []):
            if isinstance(block, dict):
                chunks.append(str(block.get("text", "")))
                chunks.extend(str(item) for item in block.get("items", []) or [])
        for subsection in section.get("subsections", []):
            if not isinstance(subsection, dict):
                continue
            chunks.append(str(subsection.get("h3", "")))
            for block in subsection.get("blocks", []):
                if isinstance(block, dict):
                    chunks.append(str(block.get("text", "")))
                    chunks.extend(str(item) for item in block.get("items", []) or [])
    for item in model.get("faq", []):
        if isinstance(item, dict):
            chunks.extend((str(item.get("question", "")), str(item.get("answer", ""))))
    conclusion = model.get("conclusion", {})
    if isinstance(conclusion, dict):
        chunks.extend(str(conclusion.get(key, "")) for key in ("summary", "fit", "next_action"))
    return "\n".join(chunks)


def tokens(value: str) -> dict[str, set[str]]:
    return {
        "numbers": set(re.findall(r"(?<![A-Za-z])\d+(?:\.\d+)?(?:%|％|倍|元|万元|美元)?", value)),
        "dates": set(re.findall(r"\d{4}年(?:\d{1,2}月(?:\d{1,2}日)?)?|\d{4}-\d{1,2}-\d{1,2}", value)),
        "currencies": set(re.findall(r"人民币|美元|港币|欧元|CNY|RMB|USD|HKD|EUR", value, flags=re.I)),
    }


def iter_text_fields(model: dict[str, Any]):
    metadata, lead = model.get("metadata", {}), model.get("lead", {})
    if isinstance(metadata.get("meta_description"), str):
        yield ("metadata", "meta_description"), metadata["meta_description"]
    for key in ("direct_answer_sentence", "micro_answer"):
        if isinstance(lead.get(key), str):
            yield ("lead", key), lead[key]
    for section_index, section in enumerate(model.get("sections", [])):
        if not isinstance(section, dict):
            continue
        for block_index, block in enumerate(section.get("blocks", [])):
            if isinstance(block, dict) and isinstance(block.get("text"), str):
                yield ("sections", section_index, "blocks", block_index, "text"), block["text"]
        for subsection_index, subsection in enumerate(section.get("subsections", [])):
            if not isinstance(subsection, dict):
                continue
            for block_index, block in enumerate(subsection.get("blocks", [])):
                if isinstance(block, dict) and isinstance(block.get("text"), str):
                    yield ("sections", section_index, "subsections", subsection_index, "blocks", block_index, "text"), block["text"]
    for faq_index, item in enumerate(model.get("faq", [])):
        if isinstance(item, dict) and isinstance(item.get("answer"), str):
            yield ("faq", faq_index, "answer"), item["answer"]
    conclusion = model.get("conclusion")
    if isinstance(conclusion, dict):
        for key in ("summary", "fit", "next_action"):
            if isinstance(conclusion.get(key), str):
                yield ("conclusion", key), conclusion[key]


def token_bindings(value: str) -> list[dict[str, str]]:
    """Bind every fact token to its local textual neighborhood.

    Global sets cannot distinguish ``甲1、乙2`` from ``甲2、乙1``.  The local
    binding is deliberately conservative: if a rewrite moves a fact to a new
    subject/context, E6 falls back to E4 unless a new reviewed candidate is made.
    """
    patterns = (
        ("date", r"\d{4}年(?:\d{1,2}月(?:\d{1,2}日)?)?|\d{4}-\d{1,2}-\d{1,2}"),
        ("number", r"(?<![A-Za-z])\d+(?:\.\d+)?(?:%|％|倍|元|万元|美元)?"),
        ("currency", r"人民币|美元|港币|欧元|CNY|RMB|USD|HKD|EUR"),
    )
    candidates: list[tuple[int, int, str, str]] = []
    for token_type, pattern in patterns:
        candidates.extend((match.start(), match.end(), token_type, match.group(0)) for match in re.finditer(pattern, value, flags=re.I))
    # Prefer longer spans at the same start and suppress nested number matches in dates.
    selected: list[tuple[int, int, str, str]] = []
    for item in sorted(candidates, key=lambda part: (part[0], -(part[1] - part[0]), part[2])):
        if any(item[0] < existing[1] and item[1] > existing[0] for existing in selected):
            continue
        selected.append(item)
    compact = re.sub(r"\s+", "", value)
    # Map original offsets to compact offsets without assuming ASCII.
    compact_offsets = []
    count = 0
    for char in value:
        compact_offsets.append(count)
        if not char.isspace():
            count += 1
    compact_offsets.append(count)
    result = []
    for start, end, token_type, token in sorted(selected):
        compact_start, compact_end = compact_offsets[start], compact_offsets[end]
        result.append({
            "type": token_type, "value": token.lower(),
            "left_context": compact[max(0, compact_start - 16):compact_start],
            "right_context": compact[compact_end:compact_end + 16],
        })
    return result


def structural_projection(model: dict[str, Any]) -> dict[str, Any]:
    sections = []
    for section in model.get("sections", []):
        if not isinstance(section, dict):
            continue
        sections.append({
            "section_id": section.get("section_id"),
            "h2_question": section.get("h2_question"),
            "blocks": [
                {key: block.get(key) for key in ("block_id", "type", "content_function", "items", "claim_ids", "step_contract")}
                for block in section.get("blocks", []) if isinstance(block, dict)
            ],
            "subsections": [
                {
                    "h3": subsection.get("h3"),
                    "blocks": [
                        {key: block.get(key) for key in ("block_id", "type", "content_function", "items", "claim_ids", "step_contract")}
                        for block in subsection.get("blocks", []) if isinstance(block, dict)
                    ],
                }
                for subsection in section.get("subsections", []) if isinstance(subsection, dict)
            ],
        })
    return {
        "sections": sections,
        "subquestion_coverage": model.get("subquestion_coverage"),
        "lead_claim_ids": (model.get("lead") or {}).get("claim_ids"),
        "faq": [{"question": item.get("question"), "content_function": item.get("content_function"), "claim_ids": item.get("claim_ids")}
                for item in model.get("faq", []) if isinstance(item, dict)],
        "conclusion_claim_ids": (model.get("conclusion") or {}).get("claim_ids"),
    }


def content_shape_errors(model: dict[str, Any], claim_registry: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if model.get("schema_version") != "1.0.0" or not str(model.get("job_id", "")).startswith("job_"):
        errors.append("invalid_schema_or_job_id")
    category, subintent = model.get("question_category"), model.get("product_scenario_subintent")
    if category not in {"industry_ranking", "competitor_comparison", "reputation", "product_scenario"}:
        errors.append("invalid_question_category")
    valid_subintents = {"offering_definition", "feature_mechanism", "scenario_fit", "delivery_usage", "support_boundary", "price_selection"}
    if category == "product_scenario" and subintent not in valid_subintents:
        errors.append("missing_product_scenario_subintent")
    if category != "product_scenario" and subintent is not None:
        errors.append("unexpected_product_scenario_subintent")
    metadata, lead = model.get("metadata", {}), model.get("lead", {})
    candidates = metadata.get("title_candidates", [])
    if not isinstance(candidates, list) or len(candidates) != 5 or len(set(candidates)) != 5:
        errors.append("invalid_title_candidates")
    elif metadata.get("title") not in candidates or metadata.get("h1") not in candidates:
        errors.append("title_or_h1_not_in_candidates")
    direct, micro = str(lead.get("direct_answer_sentence", "")).strip(), str(lead.get("micro_answer", "")).strip()
    if not 40 <= len(direct) <= 80:
        errors.append("direct_answer_length")
    if not 200 <= len(micro) <= 300 or not micro.startswith(direct):
        errors.append("micro_answer_length_or_prefix")
    errors.extend(answer_pair_errors(direct, micro, str(model.get("primary_question", ""))))
    errors.extend(article_specificity_errors(model))
    errors.extend(material_claim_binding_errors(model, claim_registry, require_content_function=True))
    for key in ("sections", "subquestion_coverage", "faq"):
        value = model.get(key, [])
        if not isinstance(value, list) or not 5 <= len(value) <= 8:
            errors.append(f"{key}_count")
    if not model.get("structured_data_types"):
        errors.append("missing_structured_data_types")
    return errors


def deterministic_failures(
    safe: dict[str, Any], candidate: dict[str, Any], claim_registry: dict[str, Any],
) -> list[dict[str, Any]]:
    failures = []
    immutable_pairs = {
        "schema_version": (safe.get("schema_version"), candidate.get("schema_version")),
        "job_id": (safe.get("job_id"), candidate.get("job_id")),
        "revision": (safe.get("revision"), candidate.get("revision")),
        "question_category": (safe.get("question_category"), candidate.get("question_category")),
        "primary_question": (safe.get("primary_question"), candidate.get("primary_question")),
        "product_scenario_subintent": (safe.get("product_scenario_subintent"), candidate.get("product_scenario_subintent")),
        "pattern_id": (safe.get("pattern_id"), candidate.get("pattern_id")),
        "metadata.title": (safe.get("metadata", {}).get("title"), candidate.get("metadata", {}).get("title")),
        "metadata.h1": (safe.get("metadata", {}).get("h1"), candidate.get("metadata", {}).get("h1")),
        "metadata.title_candidates": (safe.get("metadata", {}).get("title_candidates"), candidate.get("metadata", {}).get("title_candidates")),
        "metadata.language": (safe.get("metadata", {}).get("language"), candidate.get("metadata", {}).get("language")),
        "metadata.as_of": (safe.get("metadata", {}).get("as_of"), candidate.get("metadata", {}).get("as_of")),
        "references": (safe.get("references"), candidate.get("references")),
        "visual_placements": (safe.get("visual_placements"), candidate.get("visual_placements")),
        "structured_data_types": (safe.get("structured_data_types"), candidate.get("structured_data_types")),
    }
    for field, (before, after) in immutable_pairs.items():
        if before != after:
            failures.append({"code": "IMMUTABLE_FIELD_CHANGED", "field": field})
    if structural_projection(safe) != structural_projection(candidate):
        failures.append({"code": "STRUCTURE_OR_CLAIM_BINDING_CHANGED"})
    for error in content_shape_errors(candidate, claim_registry):
        failures.append({"code": "ROOT_CONTENT_MODEL_CONTRACT_FAILURE", "detail": error})
    safe_tokens, candidate_tokens = tokens(text(safe)), tokens(text(candidate))
    for key in safe_tokens:
        if safe_tokens[key] != candidate_tokens[key]:
            failures.append({
                "code": "FACT_TOKEN_SET_CHANGED", "token_type": key,
                "removed": sorted(safe_tokens[key] - candidate_tokens[key]),
                "added": sorted(candidate_tokens[key] - safe_tokens[key]),
            })
    safe_text, candidate_text = text(safe), text(candidate)
    safe_fields = {path: value for path, value in iter_text_fields(safe)}
    candidate_fields = {path: value for path, value in iter_text_fields(candidate)}
    if set(safe_fields) != set(candidate_fields):
        failures.append({"code": "TEXT_FIELD_SET_CHANGED"})
    for path in sorted(set(safe_fields) & set(candidate_fields), key=str):
        before_bindings, after_bindings = token_bindings(safe_fields[path]), token_bindings(candidate_fields[path])
        if before_bindings != after_bindings:
            failures.append({
                "code": "FACT_TOKEN_BINDING_CHANGED", "path": list(path),
                "before": before_bindings, "after": after_bindings,
            })
    for phrase in FORBIDDEN:
        if phrase.lower() in candidate_text.lower() and phrase.lower() not in safe_text.lower():
            failures.append({"code": "FORBIDDEN_PHRASE_ADDED", "value": phrase})
    if re.search(r"(?m)^\s*\|.+\|\s*$", candidate_text) or "<table" in candidate_text.lower():
        failures.append({"code": "BODY_TABLE_ADDED"})
    return failures


def semantic_passed(
    review: dict[str, Any] | None, job_id: str, e4_sha256: str,
    candidate_sha256: str, e5_report_sha256: str, e5_diff_sha256: str,
    changed_diffs: list[dict[str, Any]],
) -> tuple[bool, list[str]]:
    if not review or review.get("schema_version") != "1.0.0" or review.get("job_id") != job_id or review.get("status") != "passed":
        return False, ["missing_or_failed_semantic_review"]
    expected_hashes = {
        "e4_safe_sha256": e4_sha256,
        "candidate_sha256": candidate_sha256,
        "e5_report_sha256": e5_report_sha256,
        "e5_diff_sha256": e5_diff_sha256,
    }
    stale = [key for key, value in expected_hashes.items() if review.get(key) != value]
    if stale:
        return False, [f"semantic_review_hash_mismatch:{key}" for key in stale]
    checks = review.get("checks", {})
    failed = [key for key in SEMANTIC_KEYS if checks.get(key) is not True]
    expected_by_path = {
        tuple(item.get("path", [])): item for item in changed_diffs if isinstance(item, dict)
    }
    reviews = review.get("field_reviews", [])
    review_by_path: dict[tuple[Any, ...], dict[str, Any]] = {}
    for item in reviews if isinstance(reviews, list) else []:
        if not isinstance(item, dict) or not isinstance(item.get("path"), list):
            failed.append("invalid_field_review_item")
            continue
        path = tuple(item["path"])
        if path in review_by_path:
            failed.append(f"duplicate_field_review_path:{list(path)}")
        review_by_path[path] = item
    missing = sorted(set(expected_by_path) - set(review_by_path), key=str)
    extra = sorted(set(review_by_path) - set(expected_by_path), key=str)
    if missing:
        failed.append(f"missing_changed_field_reviews:{[list(path) for path in missing]}")
    if extra:
        failed.append(f"extra_field_reviews:{[list(path) for path in extra]}")
    for path in set(expected_by_path) & set(review_by_path):
        expected, actual = expected_by_path[path], review_by_path[path]
        if actual.get("decision") != "reviewed":
            failed.append(f"field_review_not_approved:{list(path)}")
        if actual.get("before_sha256") != expected.get("before_sha256"):
            failed.append(f"field_review_before_hash_mismatch:{list(path)}")
        if actual.get("after_sha256") != expected.get("after_sha256"):
            failed.append(f"field_review_after_hash_mismatch:{list(path)}")
    return not failed, failed


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--e4-model", type=Path, required=True)
    parser.add_argument("--e4-sha", type=Path, required=True)
    parser.add_argument("--e5-report", type=Path, required=True)
    parser.add_argument("--claims", type=Path, required=True)
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--e5-diff", type=Path,
                        help="required when the E5 report status is candidate_generated")
    parser.add_argument("--candidate", type=Path)
    parser.add_argument("--semantic-review", type=Path)
    parser.add_argument("--approved", type=Path, required=True)
    parser.add_argument("--audit", type=Path, required=True)
    args = parser.parse_args()

    safe = load(args.e4_model)
    validate_root(safe, "content_model.schema.json", "E6 E4 safe content_model")
    claim_registry = load(args.claims)
    validate_root(claim_registry, "registries.schema.json", "E6 claim_registry")
    if claim_registry.get("registry_type") != "claim_registry":
        raise ValueError("--claims must be the canonical claim_registry")
    evidence = load(args.evidence)
    validate_schema(
        evidence,
        Path(__file__).resolve().parents[2] / "E2.5.证据预检师.skill" / "templates" / "evidence_preflight.schema.json",
        "E6 evidence receipt",
    )
    if evidence.get("job_id") != safe.get("job_id") or evidence.get("status") != "passed":
        raise ValueError("E6 regression requires a clean E2.5 receipt for the same job")
    if evidence.get("claim_registry_sha256") != digest(claim_registry):
        raise ValueError("claim_registry differs from the E2.5-approved registry")
    safe_shape_errors = content_shape_errors(safe, claim_registry)
    if safe_shape_errors:
        raise ValueError("E4 safe model violates root content_model contract: " + ", ".join(safe_shape_errors))
    expected, actual = args.e4_sha.read_text(encoding="utf-8").strip(), digest(safe)
    if expected != actual:
        raise ValueError(f"E4 hash mismatch: {expected} != {actual}")
    report = load(args.e5_report)
    validate_schema(
        report,
        Path(__file__).resolve().parents[2] / "E5.AutoGEO候选优化师.skill" / "templates" / "autogeo_report.schema.json",
        "E6 E5 AutoGEO report",
    )
    if report.get("job_id") != safe.get("job_id") or report.get("e4_safe_model_sha256") != actual:
        raise ValueError("E5 report does not bind the supplied E4 safe model/job")
    if report.get("claim_registry_sha256") != digest(claim_registry) or report.get("evidence_receipt_sha256") != digest(evidence):
        raise ValueError("E5 report does not bind the supplied claim registry/evidence receipt")
    e5_report_sha256 = digest(report)
    status = report.get("status")
    selected = "editorial_master"
    failures: list[dict[str, Any]] = []
    semantic_issues: list[str] = []
    approved = copy.deepcopy(safe)
    if status == "candidate_generated":
        if not args.candidate or not args.candidate.is_file():
            failures.append({"code": "CANDIDATE_FILE_MISSING"})
        elif not args.e5_diff or not args.e5_diff.is_file():
            failures.append({"code": "E5_DIFF_FILE_MISSING"})
        else:
            candidate = load(args.candidate)
            try:
                validate_root(candidate, "content_model.schema.json", "E6 AutoGEO candidate")
            except ValueError as exc:
                failures.append({"code": "CANDIDATE_CANONICAL_SCHEMA_FAILURE", "detail": str(exc)})
            candidate_sha256 = digest(candidate)
            if report.get("candidate_sha256") and report.get("candidate_sha256") != candidate_sha256:
                failures.append({"code": "E5_REPORT_CANDIDATE_HASH_MISMATCH"})
            failures.extend(deterministic_failures(safe, candidate, claim_registry))
            diff_report = load(args.e5_diff)
            try:
                validate_schema(
                    diff_report,
                    Path(__file__).resolve().parents[2] / "E5.AutoGEO候选优化师.skill" / "templates" / "autogeo_diff.schema.json",
                    "E6 E5 AutoGEO field diff",
                )
            except ValueError as exc:
                failures.append({"code": "E5_DIFF_SCHEMA_FAILURE", "detail": str(exc)})
            diff_sha256 = digest(diff_report)
            if report.get("diff_sha256") != diff_sha256:
                failures.append({"code": "E5_REPORT_DIFF_HASH_MISMATCH"})
            if (
                diff_report.get("job_id") != safe.get("job_id")
                or diff_report.get("source_sha256") != actual
                or diff_report.get("candidate_sha256") != candidate_sha256
            ):
                failures.append({"code": "E5_DIFF_IDENTITY_MISMATCH"})
            safe_fields = {path: value for path, value in iter_text_fields(safe)}
            candidate_fields = {path: value for path, value in iter_text_fields(candidate)}
            diff_paths: set[tuple[Any, ...]] = set()
            for item in diff_report.get("field_diffs", []):
                if not isinstance(item, dict) or not isinstance(item.get("path"), list):
                    continue
                path = tuple(item["path"])
                if path in diff_paths:
                    failures.append({"code": "E5_DIFF_DUPLICATE_PATH", "path": list(path)})
                diff_paths.add(path)
                before, after = safe_fields.get(path), candidate_fields.get(path)
                if before is None or after is None or item.get("before") != before or item.get("after") != after:
                    failures.append({"code": "E5_DIFF_TEXT_MISMATCH", "path": list(path)})
                elif item.get("before_sha256") != text_digest(before) or item.get("after_sha256") != text_digest(after):
                    failures.append({"code": "E5_DIFF_TEXT_HASH_MISMATCH", "path": list(path)})
            if diff_paths != set(safe_fields) or diff_paths != set(candidate_fields):
                failures.append({"code": "E5_DIFF_FIELD_COVERAGE_MISMATCH"})
            changed_diffs = [
                item for item in diff_report.get("field_diffs", [])
                if isinstance(item, dict) and item.get("before") != item.get("after")
            ]
            semantic = load(args.semantic_review) if args.semantic_review and args.semantic_review.is_file() else None
            semantic_schema_issues: list[str] = []
            if semantic is not None:
                try:
                    validate_schema(
                        semantic, Path(__file__).resolve().parents[1] / "templates" / "semantic_review.schema.json",
                        "E6 semantic_review",
                    )
                except ValueError as exc:
                    semantic_schema_issues.append(f"semantic_review_schema_failure:{exc}")
            semantic_ok, review_issues = semantic_passed(
                semantic, str(safe.get("job_id")), actual, candidate_sha256, e5_report_sha256,
                diff_sha256, changed_diffs,
            )
            semantic_issues = [*semantic_schema_issues, *review_issues]
            semantic_ok = semantic_ok and not semantic_schema_issues
            if not failures and semantic_ok:
                approved = copy.deepcopy(candidate)
                selected = "optimized_candidate"
    elif status not in {"skipped_autogeo_unavailable", "failed_autogeo_call"}:
        failures.append({"code": "UNKNOWN_E5_STATUS", "value": status})

    audit = {
        "schema_version": "1.0.0",
        "job_id": safe.get("job_id"),
        "status": "passed_with_e4_fallback" if selected == "editorial_master" else "passed_with_e5_candidate",
        "selected_revision": selected,
        "e4_safe_sha256": actual,
        "approved_sha256": digest(approved),
        "e5_status": status,
        "e5_report_sha256": e5_report_sha256,
        "deterministic_failures": failures,
        "semantic_review_issues": semantic_issues,
        "fallback_is_safe": selected == "editorial_master",
    }
    args.approved.parent.mkdir(parents=True, exist_ok=True)
    validate_root(approved, "content_model.schema.json", "E6 approved content_model")
    args.approved.write_text(json.dumps(approved, ensure_ascii=False, indent=2), encoding="utf-8")
    args.audit.parent.mkdir(parents=True, exist_ok=True)
    args.audit.write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(audit, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
