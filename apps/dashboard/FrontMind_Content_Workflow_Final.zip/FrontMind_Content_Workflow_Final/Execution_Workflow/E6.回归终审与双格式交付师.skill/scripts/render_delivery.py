#!/usr/bin/env python3
"""Render same-source DOCX/HTML and root delivery/quality contracts."""

from __future__ import annotations

import argparse
import hashlib
import html
from html.parser import HTMLParser
import json
import os
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "shared"))
from schema_validation import validate_root, validate_schema  # noqa: E402
from text_quality import answer_pair_errors, article_specificity_errors, material_claim_binding_errors  # noqa: E402
from content_projections import visual_projection_sha256  # noqa: E402
from visual_semantics import visual_claim_relevance_errors, visual_semantic_errors  # noqa: E402
from reference_equivalence import reference_equivalence_errors  # noqa: E402


ROLE_COMPATIBILITY = {
    "cover": {"cover", "decorative"},
    "proof": {"entity_proof", "product_proof", "case_proof", "event_proof", "data_evidence"},
    "comparison": {"comparison"},
    "process": {"process_explanation"},
    "data": {"data_evidence"},
    "explanation": {"process_explanation", "comparison"},
}
ROLE_ARGUMENT_COMPATIBILITY = {
    "cover": {"navigate"}, "proof": {"prove"}, "comparison": {"explain", "prove"},
    "process": {"explain"}, "data": {"explain", "prove"}, "explanation": {"explain"},
}
PROOF_ASSET_ROLES = {"entity_proof", "product_proof", "case_proof", "event_proof", "data_evidence"}


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain an object")
    return value


def sha_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def model_hash(model: dict[str, Any]) -> str:
    raw = json.dumps(model, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return sha_bytes(raw)


def file_hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def is_safe_public_url(value: Any) -> bool:
    if value is None:
        return True
    if not isinstance(value, str) or not value.strip() or any(char.isspace() for char in value):
        return False
    try:
        parsed = urlsplit(value)
    except ValueError:
        return False
    return parsed.scheme.lower() in {"http", "https"} and bool(parsed.hostname)


def resolve_job_file(root: Path, stored: str) -> Path:
    relative = Path(stored)
    if not stored or relative.is_absolute() or ".." in relative.parts or "\\" in stored:
        raise ValueError(f"unsafe approved evidence path: {stored!r}")
    resolved = (root / relative).resolve()
    try:
        resolved.relative_to(root.resolve())
    except ValueError as exc:
        raise ValueError(f"approved evidence path escapes its root: {stored}") from exc
    return resolved


def validate_source_handoff(
    evidence: dict[str, Any], source_registry: dict[str, Any],
    base_package_root: Path, job_package_root: Path,
) -> None:
    sources = {
        str(item.get("source_id")): item for item in source_registry.get("sources", [])
        if isinstance(item, dict)
    }
    checks = evidence.get("source_checks", [])
    if not isinstance(checks, list) or not checks:
        raise ValueError("E2.5 evidence receipt has no used-source access checks")
    for item in checks:
        if not isinstance(item, dict) or item.get("access_verified") is not True:
            raise ValueError("E2.5 source access check is absent or failed")
        source_id = str(item.get("source_id"))
        source = sources.get(source_id)
        if not source:
            raise ValueError(f"E2.5 source check references missing source: {source_id}")
        mode = item.get("access_mode")
        if mode in {"base_pack_file", "runtime_job_file"}:
            if item.get("file_path") != source.get("file_path") or not item.get("file_sha256"):
                raise ValueError(f"E2.5 source file receipt no longer matches registry: {source_id}")
            root = base_package_root if mode == "base_pack_file" else job_package_root
            path = resolve_job_file(root, str(item["file_path"]))
            if not path.is_file() or file_hash(path) != item.get("file_sha256"):
                raise ValueError(f"approved evidence source missing or changed before delivery: {source_id}")
        elif mode == "url":
            if (
                item.get("url") != source.get("url")
                or item.get("accessed_at") != source.get("accessed_at")
                or not str(source.get("origin") or "").strip()
            ):
                raise ValueError(f"approved URL source receipt no longer matches registry: {source_id}")
        else:
            raise ValueError(f"unknown E2.5 source access mode: {source_id}:{mode}")


def select_title(
    model: dict[str, Any], selection: dict[str, Any], title_review: dict[str, Any], e4_quality: dict[str, Any]
) -> tuple[str, str, str]:
    metadata = model["metadata"]
    candidates = metadata.get("title_candidates", [])
    if len(candidates) != 5 or len(set(candidates)) != 5:
        raise ValueError("metadata.title_candidates must contain five unique same-topic candidates")
    if selection.get("schema_version") != "1.0.0" or selection.get("job_id") != model.get("job_id"):
        raise ValueError("title selection schema_version/job_id mismatch")
    if selection.get("approved_content_model_sha256") != model_hash(model):
        raise ValueError("title selection does not bind the supplied approved content model")
    if title_review.get("schema_version") != "1.0.0" or title_review.get("job_id") != model.get("job_id"):
        raise ValueError("E4 title review schema_version/job_id mismatch")
    if title_review.get("stage") != "E4_title_candidate_review" or title_review.get("overall_status") != "passed":
        raise ValueError("E4 title review is not a passed E4 receipt")
    title_review_hash = model_hash(title_review)
    if selection.get("e4_title_review_sha256") != title_review_hash:
        raise ValueError("title selection does not bind the supplied E4 title review")
    question_gate = next((item for item in e4_quality.get("gates", [])
                          if isinstance(item, dict) and item.get("gate_id") == "question_answered"), {})
    if title_review_hash not in str(question_gate.get("evidence", "")) or question_gate.get("status") != "pass":
        raise ValueError("E4 quality report did not approve the supplied five-title review")
    reviewed = title_review.get("candidates", [])
    if [item.get("title") for item in reviewed if isinstance(item, dict)] != candidates:
        raise ValueError("E4 title review must cover the five model candidates in canonical order")
    if not all(
        isinstance(item, dict) and all(item.get(key) is True for key in (
            "question_alignment_passed", "body_support_passed", "factual_scope_passed", "risk_language_passed"
        )) for item in reviewed
    ):
        raise ValueError("all five title candidates must pass the E4 review")
    selected = selection.get("selected_title")
    if selected not in candidates:
        raise ValueError("selected_title must be one of metadata.title_candidates")
    if selection.get("question_alignment_passed") is not True or selection.get("body_support_passed") is not True:
        raise ValueError("title selection must pass question alignment and body support")
    if not str(selection.get("selection_reason", "")).strip() or not str(selection.get("selected_by", "")).strip():
        raise ValueError("title selection requires selection_reason and selected_by")
    return str(selected), str(selection["selection_reason"]), title_review_hash


def validate_e4_quality_receipt(
    model: dict[str, Any], e4_quality: dict[str, Any], regression: dict[str, Any],
) -> None:
    """Reject forged, stale, failed, or cross-job E4 approvals before gate use."""
    validate_root(e4_quality, "quality_report.schema.json", "E6 E4 quality receipt")
    expected = {
        "schema_version": "1.0.0",
        "job_id": model.get("job_id"),
        "stage": "E4_pre_optimization",
        "overall_status": "pass",
        "content_model_sha256": regression.get("e4_safe_sha256"),
    }
    mismatches = [key for key, value in expected.items() if e4_quality.get(key) != value]
    if mismatches:
        raise ValueError(f"E4 quality receipt does not bind the approved model: {', '.join(mismatches)}")
    approved_hash = model_hash(model)
    if (
        regression.get("schema_version") != "1.0.0"
        or regression.get("job_id") != model.get("job_id")
        or regression.get("approved_sha256") != approved_hash
        or regression.get("selected_revision") not in {"editorial_master", "optimized_candidate"}
    ):
        raise ValueError("E6 regression receipt does not bind the supplied approved model/job")
    if regression.get("selected_revision") == "editorial_master":
        if approved_hash != regression.get("e4_safe_sha256") or regression.get("fallback_is_safe") is not True:
            raise ValueError("editorial_master selection is not the exact E4 safe model")
    elif regression.get("fallback_is_safe") is not False:
        raise ValueError("optimized_candidate selection has an invalid fallback flag")
    if e4_quality.get("blocking_issues"):
        raise ValueError("E4 quality receipt contains blocking issues despite pass status")
    required_gates = {
        "question_answered", "micro_answer_complete", "claim_evidence_complete",
        "statistics_and_price_scoped", "competitor_fairness", "entity_clarity",
        "freshness_and_dates", "original_information", "faq_relevance",
        "pattern_consistency", "voice_and_no_meta_language", "visual_argument_and_rights",
    }
    gate_index = {str(item.get("gate_id")): item for item in e4_quality.get("gates", []) if isinstance(item, dict)}
    not_passed = sorted(gate for gate in required_gates if gate_index.get(gate, {}).get("status") != "pass")
    if not_passed:
        raise ValueError(f"E4 required gates are absent or not pass: {', '.join(not_passed)}")


def validate_delivery_shape(
    model: dict[str, Any], claim_registry: dict[str, Any], source_registry: dict[str, Any],
) -> None:
    errors: list[str] = []
    metadata, lead = model.get("metadata", {}), model.get("lead", {})
    candidates = metadata.get("title_candidates", [])
    if model.get("schema_version") != "1.0.0" or not str(model.get("job_id", "")).startswith("job_"):
        errors.append("invalid schema_version/job_id")
    if not isinstance(candidates, list) or len(candidates) != 5 or len(set(candidates)) != 5:
        errors.append("five unique title candidates required")
    if metadata.get("title") not in candidates or metadata.get("h1") not in candidates:
        errors.append("title and h1 must select a registered title candidate")
    direct, micro = str(lead.get("direct_answer_sentence", "")).strip(), str(lead.get("micro_answer", "")).strip()
    if not 40 <= len(direct) <= 80 or not 200 <= len(micro) <= 300 or not micro.startswith(direct):
        errors.append("direct/micro answer contract failed")
    errors.extend(answer_pair_errors(direct, micro, str(model.get("primary_question", ""))))
    errors.extend(article_specificity_errors(model))
    errors.extend(material_claim_binding_errors(model, claim_registry, require_content_function=True))
    for field in ("sections", "subquestion_coverage", "faq"):
        value = model.get(field, [])
        if not isinstance(value, list) or not 5 <= len(value) <= 8:
            errors.append(f"{field} must contain 5-8 items")
    if not model.get("structured_data_types"):
        errors.append("structured_data_types cannot be empty")
    errors.extend(reference_equivalence_errors(model, claim_registry))
    sources = {str(item.get("source_id")): item for item in source_registry.get("sources", []) if isinstance(item, dict)}
    for index, reference in enumerate(model.get("references", [])):
        if not isinstance(reference, dict):
            continue
        source = sources.get(str(reference.get("source_id")))
        if not source or reference.get("display_name") != source.get("title") or reference.get("url") != source.get("url"):
            errors.append(f"reference does not exactly match source_registry:{index}:{reference.get('source_id')}")
        elif reference.get("url") and not is_safe_public_url(reference.get("url")):
            errors.append(f"reference URL must use http/https:{index}:{reference.get('source_id')}")
    if errors:
        raise ValueError("root content_model delivery contract failed: " + "; ".join(errors))


def image_index(registry: dict[str, Any]) -> dict[str, dict[str, Any]]:
    if registry.get("registry_type") != "image_registry":
        raise ValueError("--image-registry must be a root image_registry")
    return {str(item.get("asset_id")): item for item in registry.get("images", []) if isinstance(item, dict)}


def placement_map(model: dict[str, Any]) -> dict[str, list[dict[str, Any]]]:
    result: dict[str, list[dict[str, Any]]] = {}
    for item in model.get("visual_placements", []):
        if isinstance(item, dict):
            result.setdefault(str(item.get("after_section_id") or "__cover__"), []).append(item)
    return result


def validate_visual_handoff(
    model: dict[str, Any], visual_manifest: dict[str, Any], registry: dict[str, Any],
    base_registry: dict[str, Any], runtime_receipt: dict[str, Any], e4_quality: dict[str, Any],
    claim_registry: dict[str, Any], source_registry: dict[str, Any], evidence: dict[str, Any],
) -> str:
    registry_sha256 = model_hash(registry)
    visual_manifest_sha256 = model_hash(visual_manifest)
    if registry.get("schema_version") != "1.0.0" or registry.get("registry_type") != "image_registry":
        raise ValueError("invalid canonical image_registry at E6")
    if visual_manifest.get("schema_version") != "1.0.0" or visual_manifest.get("job_id") != model.get("job_id"):
        raise ValueError("E3 visual manifest schema/job mismatch")
    if visual_manifest.get("validation_status") != "passed" or visual_manifest.get("missing_assets"):
        raise ValueError("E3 visual manifest is not a clean pass")
    projection_sha256 = visual_projection_sha256(model)
    if visual_manifest.get("visual_projection_sha256") != projection_sha256:
        raise ValueError("E3 visual manifest no longer binds the approved visual topology")
    if visual_manifest.get("image_registry_sha256") != registry_sha256:
        raise ValueError("image_registry changed after E3 validation")
    base_registry_sha256 = model_hash(base_registry)
    receipt_sha256 = model_hash(runtime_receipt)
    if visual_manifest.get("base_image_registry_sha256") != base_registry_sha256:
        raise ValueError("E3 base image_registry fingerprint mismatch")
    if visual_manifest.get("runtime_registry_receipt_sha256") != receipt_sha256:
        raise ValueError("E3 runtime registry receipt fingerprint mismatch")
    if runtime_receipt.get("job_id") != model.get("job_id") or runtime_receipt.get("base_registry_sha256") != base_registry_sha256:
        raise ValueError("runtime registry receipt does not bind this job/base registry")
    base_records = {str(item.get("asset_id")): item for item in base_registry.get("images", []) if isinstance(item, dict)}
    runtime_records = {str(item.get("asset_id")): item for item in registry.get("images", []) if isinstance(item, dict)}
    if any(runtime_records.get(asset_id) != record for asset_id, record in base_records.items()):
        raise ValueError("runtime image_registry modified a signed base asset")
    visual_gate = next((item for item in e4_quality.get("gates", [])
                        if isinstance(item, dict) and item.get("gate_id") == "visual_argument_and_rights"), {})
    gate_evidence = str(visual_gate.get("evidence", ""))
    if (
        visual_gate.get("status") != "pass"
        or f"image_registry_sha256={registry_sha256}" not in gate_evidence
        or f"visual_manifest_sha256={visual_manifest_sha256}" not in gate_evidence
        or f"visual_projection_sha256={projection_sha256}" not in gate_evidence
    ):
        raise ValueError("E4 did not approve this exact image_registry and visual manifest")
    placements = {str(item.get("visual_id")): item for item in model.get("visual_placements", []) if isinstance(item, dict)}
    manifest_items = {str(item.get("visual_id")): item for item in visual_manifest.get("visuals", []) if isinstance(item, dict)}
    if set(placements) != set(manifest_items):
        raise ValueError("Content Model and E3 visual manifest visual sets differ")
    images = image_index(registry)
    claims = {str(item.get("claim_id")): item for item in claim_registry.get("claims", []) if isinstance(item, dict)}
    known_source_ids = {
        str(item.get("source_id")) for item in source_registry.get("sources", []) if isinstance(item, dict)
    }
    passed_claim_ids = {
        str(item.get("claim_id")) for item in evidence.get("claim_checks", [])
        if isinstance(item, dict) and item.get("status") == "passed"
    }
    for visual_id, placement in placements.items():
        item = manifest_items[visual_id]
        for key in ("asset_id", "role", "alt_text", "after_section_id"):
            if item.get(key) != placement.get(key):
                raise ValueError(f"E3 visual manifest/model mismatch: {visual_id}:{key}")
        role, argument = str(placement.get("role")), item.get("argument_function")
        asset = images.get(str(placement.get("asset_id")))
        if not asset:
            raise ValueError(f"E6 image registry missing visual asset: {visual_id}")
        rights = asset.get("rights_status")
        if rights not in {"approved", "approved_with_credit"}:
            raise ValueError(f"visual rights revoked before delivery: {visual_id}:{rights}")
        if item.get("rights_status") != rights:
            raise ValueError(f"visual rights receipt changed before delivery: {visual_id}")
        semantic_errors = visual_semantic_errors(
            visual_id=visual_id, role=role, argument=argument, asset=asset,
            claim_ids=[str(value) for value in item.get("supports_claim_ids", [])], claims=claims,
            known_source_ids=known_source_ids,
        )
        if semantic_errors:
            raise ValueError("visual semantic proof contract failed before delivery: " + "; ".join(semantic_errors))
        relevance_errors = visual_claim_relevance_errors(
            visual_id=visual_id, role=role, argument=argument, after_section_id=item.get("after_section_id"),
            claim_ids=[str(value) for value in item.get("supports_claim_ids", [])],
            model=model, passed_claim_ids=passed_claim_ids,
        )
        if relevance_errors:
            raise ValueError("visual claim relevance failed before delivery: " + "; ".join(relevance_errors))
        for field in ("attribution_text", "license_name", "license_url"):
            if item.get(field) != asset.get(field):
                raise ValueError(f"visual {field} receipt changed before delivery: {visual_id}")
        if rights == "approved_with_credit":
            attribution = str(asset.get("attribution_text", "")).strip()
            if not attribution or attribution not in str(item.get("caption", "")):
                raise ValueError(f"required image attribution is absent from E3 caption: {visual_id}")
    return registry_sha256


def resolve_asset_file(package_root: Path, asset: dict[str, Any]) -> Path:
    stored = str(asset.get("file_path", ""))
    path = Path(stored)
    if not stored or path.is_absolute() or ".." in path.parts or "\\" in stored:
        raise ValueError(f"image_registry.file_path must be package-relative without traversal: {stored!r}")
    resolved = (package_root / path).resolve()
    try:
        resolved.relative_to(package_root.resolve())
    except ValueError as exc:
        raise ValueError(f"image_registry.file_path escapes package root: {stored}") from exc
    return resolved


def copy_visuals(
    model: dict[str, Any], registry: dict[str, Any], visual_manifest: dict[str, Any],
    base_registry: dict[str, Any], base_package_root: Path, job_package_root: Path, output_dir: Path,
) -> dict[str, dict[str, Any]]:
    if registry.get("schema_version") != "1.0.0":
        raise ValueError("image_registry.schema_version must be 1.0.0")
    images = image_index(registry)
    destination = output_dir / "images"
    destination.mkdir(parents=True, exist_ok=True)
    copied: dict[str, dict[str, Any]] = {}
    base_asset_ids = {
        str(item.get("asset_id")) for item in base_registry.get("images", []) if isinstance(item, dict)
    }
    manifest_items = {
        str(item.get("visual_id")): item for item in visual_manifest.get("visuals", []) if isinstance(item, dict)
    }
    for placement in model.get("visual_placements", []):
        visual_id = str(placement.get("visual_id"))
        manifest_item = manifest_items.get(visual_id)
        if not manifest_item:
            raise ValueError(f"E3 visual manifest missing placement: {visual_id}")
        asset_id = str(placement.get("asset_id"))
        asset = images.get(asset_id)
        if not asset:
            raise ValueError(f"visual placement references unknown asset: {asset_id}")
        rights = asset.get("rights_status")
        if rights not in {"approved", "approved_with_credit"}:
            raise ValueError(f"visual rights not approved at final delivery: {asset_id}:{rights}")
        role = str(placement.get("role"))
        if not (set(asset.get("allowed_roles", [])) & ROLE_COMPATIBILITY.get(role, set())):
            raise ValueError(f"visual asset role not allowed at final delivery: {asset_id}:{role}")
        attribution = str(asset.get("attribution_text", "")).strip()
        if rights == "approved_with_credit" and not attribution:
            raise ValueError(f"approved_with_credit image lacks attribution_text: {asset_id}")
        asset_root = base_package_root if asset_id in base_asset_ids else job_package_root
        source = resolve_asset_file(asset_root, asset)
        if not source.is_file() or file_hash(source) != asset.get("sha256"):
            raise ValueError(f"asset file missing or hash mismatch: {asset_id}")
        target = destination / source.name
        if target.exists() and file_hash(target) != asset.get("sha256"):
            raise ValueError(f"two assets collide at delivery filename: {target.name}")
        shutil.copy2(source, target)
        caption_parts = [str(manifest_item.get("caption") or asset.get("caption") or "").strip()]
        if attribution and attribution not in caption_parts[0]:
            caption_parts.append(f"图片署名：{attribution}")
        if asset.get("license_name"):
            caption_parts.append(f"授权：{asset['license_name']}")
        if asset.get("license_url"):
            caption_parts.append(str(asset["license_url"]))
        copied[asset_id] = {
            **asset, "caption": " · ".join(value for value in caption_parts if value),
            "delivery_path": f"images/{target.name}", "absolute_delivery_path": str(target),
        }
    return copied


def block_markdown(block: dict[str, Any]) -> list[str]:
    lines = [str(block.get("text", "")).strip(), ""]
    items = [str(value).strip() for value in block.get("items", []) or [] if str(value).strip()]
    if block.get("type") == "bullet_list":
        lines.extend([f"- {value}" for value in items] + [""])
    elif block.get("type") == "numbered_list":
        lines.extend([f"{index}. {value}" for index, value in enumerate(items, 1)] + [""])
    elif block.get("type") == "step":
        contract = block.get("step_contract") or {}
        lines.extend([
            f"- 输入条件：{contract.get('input', '')}", f"- 具体动作：{contract.get('action', '')}",
            f"- 预期结果：{contract.get('expected_result', '')}", f"- 检查方法：{contract.get('check_method', '')}", "",
        ])
    return lines


def block_html(block: dict[str, Any]) -> list[str]:
    values = [f"<p>{html.escape(str(block.get('text', '')))}</p>"]
    items = [str(value) for value in block.get("items", []) or []]
    if block.get("type") in {"bullet_list", "numbered_list"} and items:
        tag = "ul" if block.get("type") == "bullet_list" else "ol"
        values.append(f"<{tag}>" + "".join(f"<li>{html.escape(item)}</li>" for item in items) + f"</{tag}>")
    elif block.get("type") == "step":
        contract = block.get("step_contract") or {}
        values.append("<ul class=\"step-contract\">" + "".join(
            f"<li><strong>{label}：</strong>{html.escape(str(contract.get(key, '')))}</li>"
            for key, label in (("input", "输入条件"), ("action", "具体动作"), ("expected_result", "预期结果"), ("check_method", "检查方法"))
        ) + "</ul>")
    return values


def visual_markdown(placement: dict[str, Any], copied: dict[str, dict[str, Any]]) -> list[str]:
    asset = copied[str(placement["asset_id"])]
    caption = str(asset.get("caption") or "").strip()
    lines = [f"![{placement['alt_text']}]({asset['delivery_path']})", ""]
    if caption:
        lines.extend((caption, ""))
    return lines


def visual_html(placement: dict[str, Any], copied: dict[str, dict[str, Any]]) -> str:
    asset = copied[str(placement["asset_id"])]
    caption = str(asset.get("caption") or "").strip()
    figcaption = f"<figcaption>{html.escape(caption)}</figcaption>" if caption else ""
    width, height = asset.get("width"), asset.get("height")
    if not isinstance(width, int) or width <= 0 or not isinstance(height, int) or height <= 0:
        raise ValueError(f"visual asset lacks positive intrinsic dimensions: {placement['asset_id']}")
    return '<figure><img src="{src}" alt="{alt}" width="{width}" height="{height}" loading="lazy">{caption}</figure>'.format(
        src=html.escape(asset["delivery_path"], quote=True), alt=html.escape(str(placement["alt_text"]), quote=True),
        width=width, height=height, caption=figcaption,
    )


def render_markdown(model: dict[str, Any], copied: dict[str, dict[str, Any]]) -> str:
    metadata, lead, by_section = model["metadata"], model["lead"], placement_map(model)
    lines = [
        f"# {metadata['h1']}", "", str(lead["micro_answer"]).strip(), "",
        f"资料截止：{metadata['as_of']}",
        f"资料范围：地区={metadata['target_region']}｜人群={metadata['target_audience']}｜时间范围={metadata['time_scope']}", "",
    ]
    for placement in by_section.get("__cover__", []):
        lines.extend(visual_markdown(placement, copied))
    for section in model.get("sections", []):
        lines.extend((f"## {section['h2_question']}", ""))
        for block in section.get("blocks", []):
            lines.extend(block_markdown(block))
        for subsection in section.get("subsections", []):
            lines.extend((f"### {subsection['h3']}", ""))
            for block in subsection.get("blocks", []):
                lines.extend(block_markdown(block))
        for placement in by_section.get(str(section["section_id"]), []):
            lines.extend(visual_markdown(placement, copied))
    lines.extend(("## 关于这个问题，读者还常问什么？", ""))
    for item in model.get("faq", []):
        lines.extend((f"### {item['question']}", "", str(item["answer"]).strip(), ""))
    conclusion = model.get("conclusion", {})
    if conclusion:
        lines.extend(("## 最终应该如何判断和行动？", "", conclusion["summary"], "", conclusion["fit"], "", conclusion["next_action"], ""))
    if model.get("references"):
        lines.extend(("## 本文的事实与判断来自哪些来源？", ""))
        for item in model["references"]:
            suffix = f"：{item['url']}" if item.get("url") else ""
            lines.extend((f"- {item['display_name']}{suffix}", ""))
    return "\n".join(lines).strip() + "\n"


def visible_text(model: dict[str, Any]) -> str:
    chunks = [
        model["metadata"]["h1"], model["lead"]["micro_answer"],
        f"资料截止：{model['metadata']['as_of']}",
        f"资料范围：地区={model['metadata']['target_region']}｜人群={model['metadata']['target_audience']}｜时间范围={model['metadata']['time_scope']}",
    ]
    for section in model.get("sections", []):
        chunks.append(section["h2_question"])
        for block in section.get("blocks", []):
            chunks.extend([block["text"], *(block.get("items", []) or [])])
            if block.get("type") == "step":
                chunks.extend((block.get("step_contract") or {}).values())
        for subsection in section.get("subsections", []):
            chunks.append(subsection["h3"])
            for block in subsection.get("blocks", []):
                chunks.extend([block["text"], *(block.get("items", []) or [])])
                if block.get("type") == "step":
                    chunks.extend((block.get("step_contract") or {}).values())
    for item in model.get("faq", []):
        chunks.extend((item["question"], item["answer"]))
    conclusion = model.get("conclusion") or {}
    chunks.extend(str(conclusion.get(key, "")) for key in ("summary", "fit", "next_action"))
    chunks.extend(str(item["display_name"]) for item in model.get("references", []))
    return "\n".join(str(value) for value in chunks if str(value).strip())


def used_claim_ids(model: dict[str, Any]) -> set[str]:
    result: set[str] = set()
    lead = model.get("lead", {})
    if isinstance(lead, dict):
        result.update(str(value) for value in lead.get("claim_ids", []))
    for section in model.get("sections", []):
        if not isinstance(section, dict):
            continue
        groups = [section.get("blocks", [])] + [
            subsection.get("blocks", []) for subsection in section.get("subsections", []) if isinstance(subsection, dict)
        ]
        for group in groups:
            for block in group:
                if isinstance(block, dict):
                    result.update(str(value) for value in block.get("claim_ids", []))
    for item in model.get("faq", []):
        if isinstance(item, dict):
            result.update(str(value) for value in item.get("claim_ids", []))
    conclusion = model.get("conclusion", {})
    if isinstance(conclusion, dict):
        result.update(str(value) for value in conclusion.get("claim_ids", []))
    return result


def build_json_ld(
    model: dict[str, Any], context: dict[str, Any], pattern_registry: dict[str, Any],
    evidence: dict[str, Any], claim_registry: dict[str, Any],
) -> list[dict[str, Any]]:
    types = set(model.get("structured_data_types", []))
    graph: list[dict[str, Any]] = []
    if pattern_registry.get("schema_version") != "1.0.0":
        raise ValueError("pattern registry schema_version must be 1.0.0")
    pattern = next((item for item in pattern_registry.get("patterns", [])
                    if isinstance(item, dict) and item.get("id") == model.get("pattern_id")), None)
    if not pattern:
        raise ValueError(f"pattern not found in root registry: {model.get('pattern_id')}")
    ineligible = sorted(types - set(pattern.get("eligible_json_ld", [])))
    if ineligible:
        raise ValueError(f"structured data types are ineligible for {model.get('pattern_id')}: {ineligible}")
    if evidence.get("schema_version") != "1.0.0" or evidence.get("job_id") != model.get("job_id") or evidence.get("status") != "passed":
        raise ValueError("E2.5 evidence receipt is not a clean pass for this job")
    claims = {str(item.get("claim_id")): item for item in claim_registry.get("claims", []) if isinstance(item, dict)}
    used = used_claim_ids(model)

    def require_claim_binding(ids: Any, label: str, original_types: set[str] | None = None) -> list[str]:
        bound = [str(value) for value in ids] if isinstance(ids, list) else []
        if not bound or len(bound) != len(set(bound)):
            raise ValueError(f"{label}.claim_ids must be a non-empty unique array")
        if set(bound) - used:
            raise ValueError(f"{label}.claim_ids must all be used in visible content")
        for claim_id in bound:
            claim = claims.get(claim_id)
            if not claim or claim.get("verification_status") in {"needs_verification", "disallowed"} or claim.get("allowed_usage") not in {"public_fact", "public_with_qualification"}:
                raise ValueError(f"{label} references unusable claim: {claim_id}")
        if original_types is not None:
            approved = []
            for claim_id in bound:
                original = claims[claim_id].get("original_evidence")
                if not isinstance(original, dict):
                    continue
                if (original.get("type") in original_types
                        and original.get("authorization_status") in {"public_approved", "anonymized_approved"}
                        and (original.get("source_ids") or original.get("record_refs"))
                        and all(original.get(key) for key in ("methodology", "scope", "collected_at"))):
                    approved.append(claim_id)
            if not approved:
                raise ValueError(f"{label} requires a visible, authorized first-hand claim with method and scope")
        return bound
    if context:
        allowed_context_keys = {"schema_version", "job_id", "Product", "Review", "ItemList"}
        if set(context) - allowed_context_keys:
            raise ValueError(f"structured-data context contains unsupported keys: {sorted(set(context) - allowed_context_keys)}")
        if context.get("schema_version") != "1.0.0" or context.get("job_id") != model.get("job_id"):
            raise ValueError("structured-data context schema_version/job_id mismatch")
    if "Article" in types:
        graph.append({
            "@context": "https://schema.org", "@type": "Article", "headline": model["metadata"]["h1"],
            "description": model["metadata"]["meta_description"], "dateModified": model["metadata"]["as_of"],
            "inLanguage": model["metadata"]["language"],
        })
    if "FAQPage" in types:
        graph.append({
            "@context": "https://schema.org", "@type": "FAQPage",
            "mainEntity": [
                {"@type": "Question", "name": item["question"], "acceptedAnswer": {"@type": "Answer", "text": item["answer"]}}
                for item in model.get("faq", [])
            ],
        })
    if "HowTo" in types:
        steps = []
        for section in model.get("sections", []):
            for block in list(section.get("blocks", [])) + [block for subsection in section.get("subsections", []) for block in subsection.get("blocks", [])]:
                if block.get("type") == "step":
                    contract = block.get("step_contract") or {}
                    text = "；".join(f"{label}：{contract.get(key, '')}" for key, label in (
                        ("input", "输入条件"), ("action", "具体动作"), ("expected_result", "预期结果"), ("check_method", "检查方法")))
                    steps.append({"@type": "HowToStep", "name": block["text"], "text": text})
        if not steps:
            raise ValueError("HowTo requested but no visible step blocks exist")
        graph.append({"@context": "https://schema.org", "@type": "HowTo", "name": model["metadata"]["h1"], "step": steps})
    page_text = normalized(visible_text(model))

    def require_visible(value: Any, label: str) -> None:
        token = normalized(str(value or ""))
        if not token or token not in page_text:
            raise ValueError(f"structured data {label} is not present in visible content")

    for schema_type in ("Product", "Review", "ItemList"):
        if schema_type in types:
            payload = context.get(schema_type)
            if not isinstance(payload, dict):
                raise ValueError(f"{schema_type} requested but --structured-data-context lacks a visible-content-bound payload")
            if schema_type == "Product":
                allowed = {"name", "description", "sku", "brand_name", "claim_ids"}
                if set(payload) - allowed or not {"name", "claim_ids"}.issubset(payload):
                    raise ValueError("Product context only permits name/description/sku/brand_name/claim_ids and requires name+claim_ids")
                require_claim_binding(payload.get("claim_ids"), "Product")
                require_visible(payload.get("name"), "Product.name")
                for key in ("description", "sku", "brand_name"):
                    if payload.get(key):
                        require_visible(payload[key], f"Product.{key}")
                product = {"@context": "https://schema.org", "@type": "Product", "name": payload["name"]}
                if payload.get("description"):
                    product["description"] = payload["description"]
                if payload.get("sku"):
                    product["sku"] = payload["sku"]
                if payload.get("brand_name"):
                    product["brand"] = {"@type": "Brand", "name": payload["brand_name"]}
                graph.append(product)
            elif schema_type == "Review":
                if set(payload) != {"itemReviewed", "reviewBody", "claim_ids"}:
                    raise ValueError("Review context only permits and requires itemReviewed{name}, reviewBody and claim_ids")
                review_types = {"customer_case", "actual_usage_test"} if model.get("pattern_id") == "P11" else {"independent_test", "actual_usage_test"}
                require_claim_binding(payload.get("claim_ids"), "Review", review_types)
                reviewed = payload.get("itemReviewed") or {}
                if not isinstance(reviewed, dict) or set(reviewed) != {"name"}:
                    raise ValueError("Review.itemReviewed must contain only name")
                require_visible(reviewed.get("name") if isinstance(reviewed, dict) else None, "Review.itemReviewed.name")
                require_visible(payload.get("reviewBody"), "Review.reviewBody")
                graph.append({
                    "@context": "https://schema.org", "@type": "Review",
                    "itemReviewed": {"@type": "Thing", "name": reviewed["name"]},
                    "reviewBody": payload["reviewBody"],
                })
            else:
                if set(payload) != {"itemListElement"}:
                    raise ValueError("ItemList context only permits and requires itemListElement")
                elements = payload.get("itemListElement")
                if not isinstance(elements, list) or not elements:
                    raise ValueError("ItemList.itemListElement must be a non-empty visible list")
                safe_elements = []
                element_names = []
                for index, element in enumerate(elements, 1):
                    if not isinstance(element, dict) or set(element) != {"name", "claim_ids"}:
                        raise ValueError(f"ItemList.itemListElement[{index}] must contain only name and claim_ids")
                    name = element["name"]
                    require_claim_binding(element.get("claim_ids"), f"ItemList.itemListElement[{index}]")
                    require_visible(name, f"ItemList.itemListElement[{index}].name")
                    element_names.append(name)
                    safe_elements.append({"@type": "ListItem", "position": index, "name": name})
                matrix_objects = evidence.get("competitor_dimension_matrix", {}).get("objects", [])
                if element_names != matrix_objects:
                    raise ValueError("ItemList order/names must exactly equal the E2.5 competitor matrix objects")
                graph.append({"@context": "https://schema.org", "@type": "ItemList", "itemListElement": safe_elements})
    return graph


def render_html(model: dict[str, Any], copied: dict[str, dict[str, Any]], json_ld: list[dict[str, Any]]) -> str:
    metadata, lead, by_section = model["metadata"], model["lead"], placement_map(model)
    body = [
        f"<h1>{html.escape(metadata['h1'])}</h1>",
        f"<p>{html.escape(lead['micro_answer'])}</p>",
        f"<p class=\"as-of\">资料截止：{html.escape(metadata['as_of'])}</p>",
        f"<p class=\"scope\">资料范围：地区={html.escape(metadata['target_region'])}｜人群={html.escape(metadata['target_audience'])}｜时间范围={html.escape(metadata['time_scope'])}</p>",
    ]
    body.extend(visual_html(item, copied) for item in by_section.get("__cover__", []))
    for section in model.get("sections", []):
        body.append(f"<h2>{html.escape(section['h2_question'])}</h2>")
        for block in section.get("blocks", []):
            body.extend(block_html(block))
        for subsection in section.get("subsections", []):
            body.append(f"<h3>{html.escape(subsection['h3'])}</h3>")
            for block in subsection.get("blocks", []):
                body.extend(block_html(block))
        body.extend(visual_html(item, copied) for item in by_section.get(str(section["section_id"]), []))
    body.append("<h2>关于这个问题，读者还常问什么？</h2>")
    for item in model.get("faq", []):
        body.extend((f"<h3>{html.escape(item['question'])}</h3>", f"<p>{html.escape(item['answer'])}</p>"))
    conclusion = model.get("conclusion") or {}
    if conclusion:
        body.extend(("<h2>最终应该如何判断和行动？</h2>", f"<p>{html.escape(conclusion['summary'])}</p>",
                     f"<p>{html.escape(conclusion['fit'])}</p>", f"<p>{html.escape(conclusion['next_action'])}</p>"))
    if model.get("references"):
        body.append("<h2>本文的事实与判断来自哪些来源？</h2><ul>")
        for item in model["references"]:
            label = html.escape(item["display_name"])
            body.append(f'<li><a href="{html.escape(item["url"], quote=True)}">{label}</a></li>' if item.get("url") else f"<li>{label}</li>")
        body.append("</ul>")
    # JSON must remain valid JSON. Only neutralize a literal closing-script sequence.
    scripts = "\n".join(
        '<script type="application/ld+json">' + json.dumps(item, ensure_ascii=False).replace("</", "<\\/") + "</script>"
        for item in json_ld
    )
    return """<!doctype html>
<html lang="{lang}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title><meta name="description" content="{description}">{scripts}</head>
<body><article>{body}</article></body></html>
""".format(lang=html.escape(metadata["language"], quote=True), title=html.escape(metadata["title"]),
           description=html.escape(metadata["meta_description"], quote=True), scripts=scripts, body="\n".join(body))


class TextCollector(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.values: list[str] = []
        self.in_script = False

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag == "script":
            self.in_script = True

    def handle_endtag(self, tag: str) -> None:
        if tag == "script":
            self.in_script = False

    def handle_data(self, data: str) -> None:
        if not self.in_script and data.strip():
            self.values.append(data.strip())


def normalized(value: str) -> str:
    return re.sub(r"\s+", "", value)


def validate_outputs(
    model: dict[str, Any], html_document: str, docx_path: Path,
    expected_images: int, json_ld: list[dict[str, Any]], copied: dict[str, dict[str, Any]],
) -> list[str]:
    errors = []
    if len(re.findall(r"<h1(?:\s|>)", html_document, flags=re.I)) != 1:
        errors.append("HTML must contain exactly one H1")
    if re.search(r"<table(?:\s|>)", html_document, flags=re.I):
        errors.append("HTML body tables are forbidden")
    levels = [int(value) for value in re.findall(r"<h([1-6])(?:\s|>)", html_document, flags=re.I)]
    if any(current > previous + 1 for previous, current in zip(levels, levels[1:])):
        errors.append("HTML heading level jump")
    if len(re.findall(r"<img(?:\s|>)", html_document, flags=re.I)) != expected_images:
        errors.append("HTML image count differs from visual placements")
    for asset in copied.values():
        expected_dimension_tokens = (f'width="{asset.get("width")}"', f'height="{asset.get("height")}"')
        source = html.escape(str(asset.get("delivery_path") or ""), quote=True)
        image_tag = next(
            (tag for tag in re.findall(r"<img\b[^>]*>", html_document, flags=re.I) if f'src="{source}"' in tag),
            "",
        )
        if not image_tag or any(token not in image_tag for token in expected_dimension_tokens):
            errors.append(f"HTML image dimensions differ from registry: {asset.get('asset_id')}")
    if "&quot;@context&quot;" in html_document:
        errors.append("JSON-LD was HTML-escaped and is invalid JSON")
    for raw in re.findall(r'<script type="application/ld\+json">(.*?)</script>', html_document, flags=re.I | re.S):
        try:
            json.loads(raw.replace("<\\/", "</"))
        except json.JSONDecodeError as exc:
            errors.append(f"invalid JSON-LD: {exc}")
    faq_schema = [item for item in json_ld if item.get("@type") == "FAQPage"]
    if faq_schema and len(faq_schema[0].get("mainEntity", [])) != len(model.get("faq", [])):
        errors.append("FAQPage differs from visible FAQ")
    article_schema = [item for item in json_ld if item.get("@type") == "Article"]
    if article_schema:
        article = article_schema[0]
        expected_article = {
            "headline": model["metadata"]["h1"],
            "description": model["metadata"]["meta_description"],
            "dateModified": model["metadata"]["as_of"],
            "inLanguage": model["metadata"]["language"],
        }
        mismatches = [key for key, value in expected_article.items() if article.get(key) != value]
        if mismatches:
            errors.append("Article JSON-LD differs from visible page metadata: " + ",".join(mismatches))
        if f"资料截止：{model['metadata']['as_of']}" not in html_document:
            errors.append("Article dateModified is not visible as the article cutoff date")
        if not re.search(
            rf"<html\s+lang=[\"']?{re.escape(model['metadata']['language'])}[\"']?",
            html_document, flags=re.I,
        ):
            errors.append("Article inLanguage differs from HTML lang")
        if not re.search(rf"<h1>{re.escape(html.escape(model['metadata']['h1']))}</h1>", html_document):
            errors.append("Article headline differs from visible H1")
        description = html.escape(model["metadata"]["meta_description"], quote=True)
        if f'<meta name="description" content="{description}">' not in html_document:
            errors.append("Article description differs from page meta description")
    try:
        from docx import Document  # type: ignore
        document = Document(docx_path)
    except Exception as exc:
        return errors + [f"DOCX cannot be opened: {exc}"]
    if document.tables:
        errors.append("DOCX contains native tables")
    # inline_shapes counts visible insertions. Relationship counts can undercount
    # repeated images or overcount non-visible package relationships.
    if len(document.inline_shapes) != expected_images:
        errors.append("DOCX inline image count differs from visual placements")
    styled_paragraphs = [paragraph for paragraph in document.paragraphs if paragraph.text.strip()]
    title_count = sum(1 for paragraph in styled_paragraphs if paragraph.style.style_id == "Title")
    expected_h2 = len(model.get("sections", [])) + 1 + (1 if model.get("conclusion") else 0) + (1 if model.get("references") else 0)
    expected_h3 = sum(len(section.get("subsections", [])) for section in model.get("sections", [])) + len(model.get("faq", []))
    heading1_count = sum(1 for paragraph in styled_paragraphs if paragraph.style.style_id == "Heading1")
    heading2_count = sum(1 for paragraph in styled_paragraphs if paragraph.style.style_id == "Heading2")
    if title_count != 1:
        errors.append("DOCX must contain exactly one semantic Title paragraph")
    if heading1_count != expected_h2:
        errors.append("DOCX Heading 1 count differs from canonical H2 structure")
    if heading2_count != expected_h3:
        errors.append("DOCX Heading 2 count differs from canonical H3 structure")
    canonical_chunks = [chunk for chunk in visible_text(model).splitlines() if chunk.strip()]
    collector = TextCollector(); collector.feed(html_document)
    html_text = normalized("\n".join(collector.values))
    docx_text = normalized("\n".join(paragraph.text for paragraph in document.paragraphs))
    for chunk in canonical_chunks:
        token = normalized(chunk)
        if token and token not in html_text:
            errors.append(f"HTML missing canonical text: {chunk[:40]}")
        if token and token not in docx_text:
            errors.append(f"DOCX missing canonical text: {chunk[:40]}")
    return errors


def build_final_quality(
    model: dict[str, Any], e4: dict[str, Any], regression: dict[str, Any], render_ok: bool,
    evidence: str, title_evidence: str,
) -> dict[str, Any]:
    by_id = {item["gate_id"]: dict(item) for item in e4.get("gates", [])}
    for gate_id in ("html_structure_and_visible_schema", "docx_html_semantic_parity"):
        by_id[gate_id] = {"gate_id": gate_id, "status": "pass" if render_ok else "fail", "evidence": evidence}
    if "question_answered" in by_id:
        by_id["question_answered"]["evidence"] = f"{by_id['question_answered']['evidence']}; {title_evidence}"
    selected_candidate = regression.get("selected_revision") == "optimized_candidate"
    optimization_ok = not regression.get("deterministic_failures") and not regression.get("semantic_review_issues")
    by_id["optimization_fact_integrity"] = {
        "gate_id": "optimization_fact_integrity",
        "status": "pass" if selected_candidate and optimization_ok else "not_applicable",
        "evidence": f"selected_revision={regression.get('selected_revision')}; candidate regression failures={len(regression.get('deterministic_failures', []))}",
    }
    gates = list(by_id.values())
    failures = [item for item in gates if item["status"] == "fail"]
    issues = [{
        "issue_id": f"issue_e6_{index:03d}", "gate_id": item["gate_id"], "message": item["evidence"],
        "repair_owner": "E5" if item["gate_id"] == "optimization_fact_integrity" else "E6",
    } for index, item in enumerate(failures, 1)]
    return {
        "schema_version": "1.0.0", "job_id": model["job_id"], "stage": "E6_final",
        "content_model_sha256": model_hash(model), "overall_status": "fail" if failures else "pass",
        "gates": gates, "blocking_issues": issues, "warnings": [], "metrics": e4.get("metrics", {}),
    }


def artifact(role: str, path: Path, media_type: str, output_dir: Path) -> dict[str, str]:
    try:
        stored_path = path.resolve().relative_to(output_dir.resolve()).as_posix()
    except ValueError as exc:
        raise ValueError(f"delivery artifact escapes output directory: {path}") from exc
    return {"role": role, "path": stored_path, "sha256": file_hash(path), "media_type": media_type}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--image-registry", type=Path, required=True)
    parser.add_argument("--base-image-registry", type=Path, required=True)
    parser.add_argument("--runtime-registry-receipt", type=Path, required=True)
    parser.add_argument("--visuals", type=Path, required=True,
                        help="the E3 passed visual manifest bound to the same image registry")
    parser.add_argument("--base-package-root", type=Path, required=True,
                        help="read-only staged Reference Pack root for signed base images")
    parser.add_argument("--job-package-root", type=Path, required=True,
                        help="job-local root for supplemental/generated images")
    parser.add_argument("--regression-audit", type=Path, required=True)
    parser.add_argument("--e4-quality", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--title-selection", type=Path, required=True)
    parser.add_argument("--title-review", type=Path, required=True,
                        help="the E4 receipt that reviewed all five title candidates")
    parser.add_argument("--structured-data-context", type=Path)
    parser.add_argument("--pattern-registry", type=Path, required=True)
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--evidence-semantic-review", type=Path, required=True)
    parser.add_argument("--claims", type=Path, required=True)
    parser.add_argument("--sources", type=Path, required=True)
    args = parser.parse_args()
    model = load(args.model)
    validate_root(model, "content_model.schema.json", "E6 approved input content_model")
    regression, e4_quality = load(args.regression_audit), load(args.e4_quality)
    validate_e4_quality_receipt(model, e4_quality, regression)
    if regression.get("schema_version") != "1.0.0" or regression.get("job_id") != model.get("job_id"):
        raise ValueError("E6 regression audit schema/job mismatch")
    if model_hash(model) != regression.get("approved_sha256"):
        raise ValueError("approved model hash does not match regression audit")
    image_registry, base_image_registry = load(args.image_registry), load(args.base_image_registry)
    runtime_registry_receipt, visual_manifest = load(args.runtime_registry_receipt), load(args.visuals)
    validate_root(image_registry, "registries.schema.json", "E6 image_registry")
    validate_root(base_image_registry, "registries.schema.json", "E6 base image_registry")
    validate_schema(
        visual_manifest,
        Path(__file__).resolve().parents[2] / "E3.视觉论证师.skill" / "templates" / "visual_argument_manifest.schema.json",
        "E6 E3 visual manifest",
    )
    evidence, claim_registry, source_registry = load(args.evidence), load(args.claims), load(args.sources)
    semantic_review = load(args.evidence_semantic_review)
    validate_schema(
        evidence,
        Path(__file__).resolve().parents[2] / "E2.5.证据预检师.skill" / "templates" / "evidence_preflight.schema.json",
        "E6 E2.5 evidence receipt",
    )
    validate_root(claim_registry, "registries.schema.json", "E6 claim_registry")
    validate_root(source_registry, "registries.schema.json", "E6 source_registry")
    validate_schema(
        semantic_review,
        Path(__file__).resolve().parents[2] / "E2.5.证据预检师.skill" / "templates" / "evidence_semantic_review.schema.json",
        "E6 E2.5 evidence semantic review",
    )
    if claim_registry.get("registry_type") != "claim_registry":
        raise ValueError("--claims must be the canonical claim_registry")
    if source_registry.get("registry_type") != "source_registry":
        raise ValueError("--sources must be the canonical source_registry")
    if evidence.get("claim_registry_sha256") != model_hash(claim_registry) or evidence.get("source_registry_sha256") != model_hash(source_registry):
        raise ValueError("E2.5 evidence receipt does not bind supplied claim/source registries")
    semantic_review_sha256 = model_hash(semantic_review)
    if (
        evidence.get("semantic_review_status") != "passed"
        or evidence.get("semantic_review_sha256") != semantic_review_sha256
        or semantic_review.get("job_id") != model.get("job_id")
        or semantic_review.get("evidence_projection_sha256") != evidence.get("evidence_projection_sha256")
        or semantic_review.get("claim_registry_sha256") != evidence.get("claim_registry_sha256")
        or semantic_review.get("source_registry_sha256") != evidence.get("source_registry_sha256")
        or semantic_review.get("competitor_matrix_sha256") != (
            model_hash(evidence.get("competitor_dimension_matrix", {}))
            if evidence.get("competitor_dimension_matrix") else None
        )
        or semantic_review.get("overall_status") != "passed"
    ):
        raise ValueError("E2.5 semantic evidence review is not bound or passed")
    image_registry_sha256 = validate_visual_handoff(
        model, visual_manifest, image_registry, base_image_registry, runtime_registry_receipt,
        e4_quality, claim_registry, source_registry, evidence,
    )
    claim_gate = next((item for item in e4_quality.get("gates", [])
                       if isinstance(item, dict) and item.get("gate_id") == "claim_evidence_complete"), {})
    if (
        claim_gate.get("status") != "pass"
        or evidence.get("status") != "passed"
        or evidence.get("job_id") != model.get("job_id")
        or evidence.get("evidence_projection_sha256") not in str(claim_gate.get("evidence", ""))
        or model_hash(evidence) not in str(claim_gate.get("evidence", ""))
        or semantic_review_sha256 not in str(claim_gate.get("evidence", ""))
    ):
        raise ValueError("E4 did not approve this exact E2.5 evidence projection")
    final_model = json.loads(json.dumps(model, ensure_ascii=False))
    base_package_root, job_package_root = args.base_package_root.resolve(), args.job_package_root.resolve()
    if not base_package_root.is_dir() or not job_package_root.is_dir():
        raise FileNotFoundError("--base-package-root and --job-package-root must both exist")
    validate_source_handoff(evidence, source_registry, base_package_root, job_package_root)
    title_selection, title_review = load(args.title_selection), load(args.title_review)
    validate_schema(
        title_selection, Path(__file__).resolve().parents[1] / "templates" / "title_selection.schema.json",
        "E6 title selection",
    )
    validate_schema(
        title_review,
        Path(__file__).resolve().parents[2] / "E4.编辑终审师.skill" / "templates" / "title_candidate_review.schema.json",
        "E6 E4 title review",
    )
    selected_title, title_reason, title_review_hash = select_title(final_model, title_selection, title_review, e4_quality)
    final_model["metadata"]["title"] = selected_title
    final_model["metadata"]["h1"] = selected_title
    validate_delivery_shape(final_model, claim_registry, source_registry)
    # Delivery is a trust boundary, not a scratch directory.  Reusing a
    # non-empty directory could leak stale internal reviews, previous drafts or
    # images that are not represented by this run's manifest.
    if args.output_dir.is_symlink():
        raise ValueError("--output-dir must not be a symlink")
    if args.output_dir.exists():
        if not args.output_dir.is_dir():
            raise ValueError("--output-dir must be a directory")
        if any(args.output_dir.iterdir()):
            raise FileExistsError("--output-dir must be new or empty; refusing stale delivery files")
    else:
        args.output_dir.mkdir(parents=True, exist_ok=False)
    copied = copy_visuals(
        final_model, image_registry, visual_manifest, base_image_registry,
        base_package_root, job_package_root, args.output_dir,
    )
    source_model = args.output_dir / "approved_content_model.json"
    source_model.write_text(json.dumps(final_model, ensure_ascii=False, indent=2), encoding="utf-8")
    markdown = render_markdown(final_model, copied)
    md_path = args.output_dir / "approved_source.md"; md_path.write_text(markdown, encoding="utf-8")
    context = load(args.structured_data_context) if args.structured_data_context else {}
    if args.structured_data_context:
        validate_schema(
            context, Path(__file__).resolve().parents[1] / "templates" / "structured_data_context.schema.json",
            "E6 structured_data_context",
        )
    json_ld = build_json_ld(
        final_model, context, load(args.pattern_registry), evidence, claim_registry,
    )
    structured_path = args.output_dir / "structured_data.json"
    structured_path.write_text(json.dumps(json_ld, ensure_ascii=False, indent=2), encoding="utf-8")
    html_document = render_html(final_model, copied, json_ld)
    html_path = args.output_dir / "final.html"; html_path.write_text(html_document, encoding="utf-8")
    metadata_path = args.output_dir / "metadata.json"
    metadata_path.write_text(json.dumps({
        "schema_version": "1.0.0", "job_id": final_model["job_id"],
        "article_metadata": final_model["metadata"], "title_selection_reason": title_reason,
        "e4_title_review_sha256": title_review_hash, "image_registry_sha256": image_registry_sha256,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    title_receipt_path = args.output_dir / "title_selection_receipt.json"
    title_receipt_path.write_text(json.dumps(title_selection, ensure_ascii=False, indent=2), encoding="utf-8")

    converter = Path(__file__).resolve().parents[2] / "E4.编辑终审师.skill" / "scripts" / "md2docx.py"
    docx_path = args.output_dir / "final.docx"
    process = subprocess.run([
        sys.executable, "-B", str(converter), "--input", str(md_path), "--images-dir", str(args.output_dir / "images"),
        "--output", str(docx_path), "--keep-title",
    ], text=True, capture_output=True, env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
    if process.returncode != 0:
        raise RuntimeError(f"DOCX rendering failed: {process.stderr or process.stdout}")
    output_errors = validate_outputs(
        final_model, html_document, docx_path, len(final_model.get("visual_placements", [])), json_ld, copied,
    )
    final_quality_report = build_final_quality(
        final_model, e4_quality, regression, not output_errors,
        "; ".join(output_errors) or "same-source HTML/DOCX checks passed",
        f"selected_title={selected_title}; e4_title_review_sha256={title_review_hash}",
    )
    quality_path = args.output_dir / "E6_quality_report.json"
    validate_root(final_quality_report, "quality_report.schema.json", "E6 quality_report")
    quality_path.write_text(json.dumps(final_quality_report, ensure_ascii=False, indent=2), encoding="utf-8")
    if output_errors or final_quality_report["overall_status"] != "pass":
        raise ValueError("; ".join(output_errors) or "E6 final quality report failed")
    render_audit = {
        "schema_version": "1.0.0", "job_id": final_model["job_id"],
        "status": "passed", "content_model_sha256": model_hash(final_model), "selected_revision": regression["selected_revision"],
        "selected_title": selected_title, "e4_title_review_sha256": title_review_hash,
        "image_registry_sha256": image_registry_sha256,
        "visible_attribution_count": sum(1 for item in copied.values() if item.get("attribution_text")),
        "html_h1_count": 1, "body_tables": 0, "image_count": len(copied),
        "json_ld_types": [item.get("@type") for item in json_ld],
        "docx_renderer": {"id": "E4.md2docx", "sha256": file_hash(converter)},
    }
    render_audit_path = args.output_dir / "render_audit.json"
    render_audit_path.write_text(json.dumps(render_audit, ensure_ascii=False, indent=2), encoding="utf-8")

    artifacts = [
        artifact("content_model", source_model, "application/json", args.output_dir),
        artifact("docx", docx_path, "application/vnd.openxmlformats-officedocument.wordprocessingml.document", args.output_dir),
        artifact("html", html_path, "text/html", args.output_dir),
        artifact("structured_data", structured_path, "application/ld+json", args.output_dir),
        artifact("quality_report", quality_path, "application/json", args.output_dir),
        artifact("metadata", metadata_path, "application/json", args.output_dir),
        artifact("source_markdown", md_path, "text/markdown", args.output_dir),
        artifact("render_audit", render_audit_path, "application/json", args.output_dir),
        artifact("title_selection_receipt", title_receipt_path, "application/json", args.output_dir),
    ]
    artifacts.extend(artifact("visual", Path(item["absolute_delivery_path"]), item["mime_type"], args.output_dir) for item in copied.values())
    e5_status = regression.get("e5_status")
    candidate_generated = e5_status == "candidate_generated"
    delivery = {
        "schema_version": "1.0.0", "job_id": final_model["job_id"],
        "created_at": datetime.now(timezone.utc).isoformat(),
        "selected_revision": regression["selected_revision"],
        "source_equivalence": {
            "content_model_sha256": model_hash(final_model), "docx_rendered_from_same_model": True, "html_rendered_from_same_model": True,
        },
        "artifacts": artifacts, "quality_report_path": quality_path.relative_to(args.output_dir).as_posix(),
        "optimization": {
            "attempted": e5_status not in {"skipped_autogeo_unavailable"},
            "candidate_selected": regression["selected_revision"] == "optimized_candidate",
            "fact_diff_status": "pass" if regression["selected_revision"] == "optimized_candidate" else "fail" if candidate_generated else "not_run",
        },
    }
    validate_root(delivery, "delivery_manifest.schema.json", "E6 delivery_manifest")
    manifested_paths = {item["path"] for item in artifacts}
    actual_paths = {
        path.relative_to(args.output_dir).as_posix()
        for path in args.output_dir.rglob("*")
        if path.is_file() and not path.is_symlink()
    }
    if actual_paths != manifested_paths:
        raise ValueError(
            f"delivery directory differs from manifest before manifest write: "
            f"missing={sorted(manifested_paths - actual_paths)}, extra={sorted(actual_paths - manifested_paths)}"
        )
    if any(path.is_symlink() for path in args.output_dir.rglob("*")):
        raise ValueError("delivery directory must not contain symlinks")
    manifest_path = args.output_dir / "delivery_manifest.json"
    manifest_path.write_text(json.dumps(delivery, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"status": "passed", "delivery_manifest": manifest_path.name, "content_model_sha256": model_hash(final_model)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
