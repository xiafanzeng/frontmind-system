# FrontMind 单篇内容制作执行层

本执行层只做一件事：基于企业 References、图片库、一个已确定问题以及该问题的答案表/信源表，生产一篇专业文章的 DOCX 和 HTML。

固定链路（E0 是双相门）：

`E0-A 安全落地/任务建档 → E0.5 Micro Tracking → E0-B 全契约 intake/runtime 图片表 → E1 蓝图与后台 P 路由 → E2 正文 → E2.5 证据预检 → E3 视觉论证 → E4 安全正本 → E5 AutoGEO 候选 → E6 回归与双格式交付`

用户只看到四个正式问题入口。P01-P15 是根 `shared/content-pattern-registry.json` 中的后台模式，E1 每轮自动选择恰好一个。

从 S0 ZIP 到 E6 双格式交付的唯一完整命令序列见包根 [运行手册](../RUNBOOK.md)。本页只保留执行层边界与最先三个交接门，避免复制第二套易漂移参数。

## 强制输入

1. 一个正式问题和四入口类别；
2. 企业 Reference Pack/知识库；Pack 内的 canonical `image_registry` 就是默认图片库，不要求再上传第二份 Manifest；
3. 该问题的 AI 答案表；
4. 该问题的信源表；
5. 非空的时间范围、地区和受众；输出语言按根契约为 `zh-CN`。单篇补充图片只能进入 job-local runtime Registry，签名 Pack 永远只读。

答案表或信源表缺失时不启动。执行层不发现新问题，不生成 24 类菜单、日历、渠道、分发、CMS 或回滚任务。

## S0 ZIP 到 E0 的安全交接

S0 只交付 ZIP。不手工解压，不使用 `unzip -o`：

```bash
python3 E0.单篇执行编排师.skill/scripts/stage_reference_pack.py \
  --zip /path/to/S0_brand_label_reference_pack_v1.zip \
  --output-dir /path/to/job/reference \
  --manifest-output /path/to/job/00_input/reference_pack_staging.json \
  --job-package-root /path/to/job
```

工具完成 ZIP 安全预检、解压前/后两次 canonical Pack 校验和原子落地。输出的 `reference/` 是后续 E0-E6 共用的持久 Pack 根。

先用 `normalize_content_job.py` 将 Dashboard/API 导入 JSON 正规化为 `00_input/content_job.json`；`industry` 只在此处转换为 `industry_ranking`。
确认原始双表存在，再由 E0.5 生成 `E0.5_{job_id}_monitoring_input.json`；随后运行 E0-B：

```bash
python3 E0.单篇执行编排师.skill/scripts/intake_validator.py \
  --content-job /path/to/job/00_input/content_job.json \
  --reference-pack /path/to/job/reference/reference_pack.json \
  --monitoring-input /path/to/job/01_monitoring/E0.5_job_xxx_monitoring_input.json \
  --staging-receipt /path/to/job/00_input/reference_pack_staging.json \
  --source-zip /path/to/S0_brand_label_reference_pack_v1.zip \
  --package-root /path/to/job \
  --report /path/to/job/00_input/E0_intake_report.json
```

E0-B 通过后，先按根 `runtime_evidence_extension.schema.json` 建立 job-local evidence extension，再运行
`build_runtime_evidence_bundle.py` 生成 runtime claim/source registries 与回执。新增 URL 来源也必须有 job-local 快照/摘录文件、SHA-256 与可公开/匿名授权；
无新增来源时仍提交空 extension。随后建立 runtime 图片表：

```bash
python3 E0.单篇执行编排师.skill/scripts/seed_runtime_image_registry.py \
  --job-id job_xxx \
  --base-registry /path/to/job/reference/registries/image_registry.json \
  --runtime-registry /path/to/job/02_runtime_images/image_registry.json \
  --receipt /path/to/job/02_runtime_images/seed_receipt.json
```

E2-E6 消费 runtime claim/source registries；E3/E4/E6 消费 runtime image registry，同时以 staged Pack 为只读 base root。需要长期复用的新 Logo/案例/事实图必须回 R0/S7/S10 生成新版签名 Pack。

## 环境依赖

- Python 3.10 或更高版本；
- `openpyxl`（XLSX 双表）、`Pillow`（图片）、`python-docx`（DOCX）是基础必装；正文禁止表格，因此旧 DOCX 工具中的 `matplotlib` 表格降级路径不属于活动依赖；
- 任务使用 SVG Logo 时再安装 `requirements-optional.txt` 中的 `CairoSVG`；
- `autogeo` 是可选依赖，缺失时 E5 明确跳过并沿用 E4；
- 系统 Python 缺包会清晰报错。先切到 Workflow 根目录，再安装与预检（本文其他 E 阶段命令则从 `Execution_Workflow/` 运行）：

```bash
cd /path/to/FrontMind_Content_Workflow_Final
python3 -m pip install -r requirements.txt
python3 -B scripts/check_runtime_dependencies.py
```

也可使用已配置且预检通过的 bundled runtime。

## 安全正本

E4 是编辑审核后的安全正本。E5 只用 `autogeo.rewriters` 生成候选；不可用时沿用 E4，没有词语替换 fallback。
E6 只有在完整 diff 与语义回归通过时才采用候选，否则交付 E4。

## 最终输出

DOCX 和 HTML 必须从同一个 approved canonical content model 生成。正文无表格；HTML 恰好一个 H1；结构化数据与可见正文一致。
E0.5-E6 的阶段 JSON 留在 job 内部审计目录；客户 delivery manifest 只登记 E6 实际交付文件，不复制原始双表或客户知识库。
