# Execution shared

本目录只保留执行层共享政策与兼容说明。跨层契约、四类问题与 P01-P15 只读取根 [global shared](../../shared/README.md)。

旧 PDF/Markdown 渲染脚本与 v11 政策已转为 `references/legacy-*` 只读文本，不能执行或作为运行输入；active Skill 只可点名它们说明迁移审计或禁用原因。DOCX/HTML 只由 E6 的同源渲染器生成。

- `content_job`：`../../shared/content_job.schema.json`
- 单问题监控：`../../shared/monitoring_input.schema.json`
- Article Blueprint：`../../shared/article_blueprint.schema.json`
- Content Model：`../../shared/content_model.schema.json`
- Quality Report：`../../shared/quality_report.schema.json`
- Delivery Manifest：`../../shared/delivery_manifest.schema.json`
- 内容结构：`../../shared/content-pattern-registry.json`

`references/legacy-*` 文件仅为迁移审计，不得被加载为 Prompt、Schema、模板、脚本或活动政策。
