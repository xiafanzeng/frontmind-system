# 根级唯一契约路径

执行层不复制以下定义，运行时从工作流根目录 `shared/` 读取：

- `../../shared/content-pattern-registry.json`
- `../../shared/content-pattern-guide.md`
- `../../shared/content_model.schema.json`
- `../../shared/reference_pack.schema.json`
- `../../shared/content_job.schema.json`
- `../../shared/monitoring_input.schema.json`
- `../../shared/registries.schema.json`
- `../../shared/article_blueprint.schema.json`
- `../../shared/quality_report.schema.json`
- `../../shared/delivery_manifest.schema.json`
- `../../shared/runtime_evidence_extension.schema.json`

从 skill 目录解析时为 `../../shared/...`；从 `skill/scripts/` 解析时为 `../../../shared/...`。
版本不兼容时阻断，不允许在执行层创建第二份 P01-P15 或事实/图片 Schema。
