# 执行层输出与同源渲染标准

## 1. 唯一正本

`content_model.json` 是正文唯一正本，必须符合 [Content Model Schema](../../shared/content_model.schema.json)。E6 从同一 SHA-256 版本渲染：

- `final.docx`：客户/媒体可编辑稿；
- `final.html`：网页稿；
- `structured_data.json`：仅表达可见正文已有内容。

不得分别写 DOCX 与 HTML，不得在渲染后只修改其中一份。最终标题写入 Content Model；DOCX 以标题段呈现，HTML 使用唯一 H1。

## 2. 阶段产物

| 阶段 | 必需产物 |
|---|---|
| E0-A/B | `reference_pack_staging.json`、`content_job.json`、`E0_intake_report.json`、runtime evidence/image registries 与回执 |
| E0.5 | `E0.5_{job_id}_monitoring_input.json`、`raw_metadata.json` |
| E1 | `E1_{job_id}_article_blueprint.json` |
| E2 | `E2_{job_id}_content_model.draft.json` |
| E2.5 | `E2.5_{job_id}_semantic_review.json`、`E2.5_{job_id}_evidence_preflight.json` |
| E3 | `E3_{brand_label}_{job_id}_visual_argument_manifest.json`、视觉版 Content Model 与审核通过的视觉文件 |
| E4 | `E4_{job_id}_safe_content_model.json`、`E4_{job_id}_safe_model.sha256`、`E4_{job_id}_quality_report.json`、标题审阅回执 |
| E5 | `E5_autogeo_candidate.json`、`E5_field_diff.json`、`E5_autogeo_report.json`；工具不可用时报告明确 skip |
| E6 | `approved_content_model.json`、`approved_source.md`、`final.docx`、`final.html`、`structured_data.json`、`E6_quality_report.json`、`render_audit.json`、`delivery_manifest.json`；E5 候选不通过事实回归时沿用 E4 安全正本 |

## 3. DOCX

- 标题、正文、H2/H3、列表、FAQ、引用与图片顺序严格来自 Content Model。
- 企业实图、案例图、产品图与事件图必须来自 canonical image registry，物理嵌入文件。
- 不使用表格；比较内容使用平行段落。
- 不含内部 ID、工作流、编辑批注、占位符、证据缺口、生成说明或算法分数。

## 4. HTML

执行 [HTML 与结构化数据政策](../../shared/html-structured-data-policy.md)。必须只有一个 H1，层级不跳跃，最多 H3；Title/H1/Meta 同题；JSON-LD 与可见正文逐项一致。

## 5. 交付

所有文件进入 [Delivery Manifest](../../shared/delivery_manifest.schema.json)，记录路径、媒体类型与 SHA-256。Manifest 必须证明 DOCX/HTML 来自同一个 `content_model_sha256`。PDF、发布文件、渠道计划和效果报表不属于必需产物。
