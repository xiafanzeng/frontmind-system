#!/usr/bin/env python3
"""Shared answer-first substantive-text quality gates for E1/E2/E4/E6."""

from __future__ import annotations

import re
from difflib import SequenceMatcher
from typing import Any


SUBSTANTIVE_RE = re.compile(r"[\u3400-\u9fffA-Za-z0-9]")
LATIN_TOKEN_RE = re.compile(r"[A-Za-z][A-Za-z0-9._+-]{1,}")
HAN_RUN_RE = re.compile(r"[\u3400-\u9fff]{2,}")
GENERIC_NGRAMS = {
    "什么", "哪些", "如何", "是否", "为什", "么样", "怎么", "为什么",
    "推荐", "对比", "评价", "适合", "需要", "哪个", "最好", "问题",
}
PLACEHOLDER_PATTERNS = (
    re.compile(r"该部分|本节将|下文将|下面(?:介绍|说明|分析)|接下来(?:介绍|说明|分析)|本文将"),
    re.compile(r"首先(?:介绍|说明|分析|讨论).{0,100}其次(?:介绍|说明|分析|讨论)"),
)

MATERIAL_SIGNAL_PATTERNS = (
    ("number_or_date", re.compile(
        r"(?:\d{4}年|\d{1,4}(?:\.\d+)?\s*(?:%|％|元|万元|亿元|美元|USD|CNY|RMB|倍|个|项|家|天|小时|分钟))",
        flags=re.I,
    )),
    ("price_or_version", re.compile(r"(?:价格|报价|套餐|版本|型号|规格|参数|费率|成本)")),
    ("ranking_or_research", re.compile(
        r"(?:第一|领先|最佳|最优|权威|排名|排行榜|研究(?:表明|发现|显示)|调查(?:表明|发现|显示)|数据显示|样本量)",
        flags=re.I,
    )),
    ("attributed_fact", re.compile(
        r"(?:发布|宣布|成立于|总部位于|获得(?:认证|奖项|融资)|通过(?:认证|审核)|官方(?:表示|公布|提供))",
        flags=re.I,
    )),
)

CAPABILITY_VERBS = re.compile(
    r"(?:是(?:一项|一种|一个|国内|全球|面向)|提供|支持|具备|拥有|覆盖|达到|实现|主要用于|适用于|可用于|能够|"
    r"解决|接入|部署|推出|发布|采用|包括)",
    flags=re.I,
)

STRICT_FACT_TOKEN_RE = re.compile(
    r"(?:\d+(?:\.\d+)?\s*(?:%|％|元|万元|亿元|美元|USD|CNY|RMB|倍|家|项|款|秒|分钟|小时)|"
    r"(?:v(?:ersion)?\s*)?\d+(?:\.\d+){1,3})",
    flags=re.I,
)
DATE_FACT_RE = re.compile(
    r"(?P<year>\d{4})(?:年|[-/])(?P<month>\d{1,2})(?:(?:月|[-/])(?P<day>\d{1,2})(?:日)?)?(?:月)?"
)

NON_ENTITY_TERMS = {
    "团队", "用户", "企业", "机构", "品牌", "产品", "服务", "方案", "平台", "系统", "项目",
    "模型", "接口", "内容", "数据", "行业", "场景", "当前", "目标", "结果", "条件",
}


def substantive_chars(value: str) -> list[str]:
    return SUBSTANTIVE_RE.findall(value.strip())


def question_key_tokens(question: str) -> set[str]:
    tokens = {match.group(0).lower() for match in LATIN_TOKEN_RE.finditer(question)}
    for run in HAN_RUN_RE.findall(question):
        for size in (4, 3, 2):
            for index in range(0, len(run) - size + 1):
                token = run[index:index + size]
                if token not in GENERIC_NGRAMS and not any(generic in token for generic in GENERIC_NGRAMS):
                    tokens.add(token)
    return tokens


def substantive_text_errors(
    value: str, *, label: str, minimum: int, ratio: float, minimum_unique: int,
) -> list[str]:
    stripped = value.strip()
    substantive = substantive_chars(stripped)
    errors: list[str] = []
    if len(substantive) < minimum:
        errors.append(f"{label}_substantive_chars:{len(substantive)}:minimum_{minimum}")
    actual_ratio = len(substantive) / len(stripped) if stripped else 0.0
    if actual_ratio < ratio:
        errors.append(f"{label}_substantive_ratio:{actual_ratio:.3f}:minimum_{ratio:.2f}")
    if len(set(char.lower() for char in substantive)) < minimum_unique:
        errors.append(f"{label}_substantive_variety:minimum_{minimum_unique}")
    return errors


def answer_pair_errors(direct: str, micro: str, primary_question: str) -> list[str]:
    errors = substantive_text_errors(
        direct, label="direct_answer", minimum=30, ratio=0.55, minimum_unique=8,
    )
    errors.extend(substantive_text_errors(
        micro, label="micro_answer", minimum=120, ratio=0.55, minimum_unique=20,
    ))
    if not micro.startswith(direct):
        errors.append("micro_answer_must_start_with_direct_answer")
    tokens = question_key_tokens(primary_question)
    direct_lower, micro_lower = direct.lower(), micro.lower()
    if not tokens or not any(token in direct_lower for token in tokens):
        errors.append("direct_answer_missing_primary_question_key_token")
    if not tokens or not any(token in micro_lower for token in tokens):
        errors.append("micro_answer_missing_primary_question_key_token")
    return errors


def _visible_block_text(section: dict[str, Any]) -> str:
    chunks: list[str] = []
    groups = [section.get("blocks", [])]
    groups.extend(item.get("blocks", []) for item in section.get("subsections", []) if isinstance(item, dict))
    for group in groups:
        for block in group if isinstance(group, list) else []:
            if not isinstance(block, dict):
                continue
            chunks.append(str(block.get("text", "")))
            chunks.extend(str(value) for value in block.get("items", []) or [])
    return "\n".join(value.strip() for value in chunks if value.strip())


def _normalized_similarity_text(value: str) -> str:
    return re.sub(r"[^\u3400-\u9fffA-Za-z0-9]", "", value).lower()


def article_specificity_errors(model: dict[str, Any]) -> list[str]:
    """Reject placeholder prose and mechanical repetition without penalizing terms."""
    errors: list[str] = []
    primary_tokens = question_key_tokens(str(model.get("primary_question", "")))
    section_texts: list[tuple[str, str]] = []
    for section in model.get("sections", []):
        if not isinstance(section, dict):
            continue
        section_id = str(section.get("section_id", "unknown"))
        answer = _visible_block_text(section)
        section_texts.append((section_id, answer))
        substantive = substantive_chars(answer)
        if len(substantive) < 20:
            errors.append(f"section_without_substantive_answer:{section_id}")
        h2_tokens = question_key_tokens(str(section.get("h2_question", "")))
        specific_tokens = h2_tokens - primary_tokens
        if not specific_tokens:
            specific_tokens = h2_tokens
        answer_lower = answer.lower()
        if not specific_tokens or not any(token in answer_lower for token in specific_tokens):
            errors.append(f"section_answer_missing_h2_specific_token:{section_id}")
        for pattern in PLACEHOLDER_PATTERNS:
            if pattern.search(answer):
                errors.append(f"section_placeholder_meta_narration:{section_id}:{pattern.pattern}")

    for index, (left_id, left) in enumerate(section_texts):
        left_normalized = _normalized_similarity_text(left)
        if len(left_normalized) < 50:
            continue
        for right_id, right in section_texts[index + 1:]:
            right_normalized = _normalized_similarity_text(right)
            if len(right_normalized) < 50:
                continue
            ratio = SequenceMatcher(None, left_normalized, right_normalized, autojunk=False).ratio()
            if ratio >= 0.88:
                errors.append(f"section_near_duplicate:{left_id}:{right_id}:{ratio:.3f}")

    faq_answers = [
        (index, _normalized_similarity_text(str(item.get("answer", ""))))
        for index, item in enumerate(model.get("faq", []), 1) if isinstance(item, dict)
    ]
    adjacency: dict[int, set[int]] = {index: set() for index, _ in faq_answers}
    for offset, (left_index, left) in enumerate(faq_answers):
        if len(left) < 20:
            errors.append(f"faq_without_substantive_answer:{left_index}")
        for right_index, right in faq_answers[offset + 1:]:
            if min(len(left), len(right)) < 20:
                continue
            ratio = SequenceMatcher(None, left, right, autojunk=False).ratio()
            if ratio >= 0.90:
                adjacency[left_index].add(right_index)
                adjacency[right_index].add(left_index)
    visited: set[int] = set()
    for start in adjacency:
        if start in visited:
            continue
        stack, component = [start], set()
        while stack:
            current = stack.pop()
            if current in component:
                continue
            component.add(current)
            stack.extend(adjacency[current] - component)
        visited.update(component)
        if len(component) >= 3:
            errors.append(f"faq_answer_near_duplicate_group:{sorted(component)}")
    return errors


def _visible_value(block: dict[str, Any]) -> str:
    chunks = [str(block.get("text", ""))]
    chunks.extend(str(item) for item in block.get("items", []) or [])
    return "\n".join(item.strip() for item in chunks if item.strip())


def _material_signals(text: str, entities: set[str]) -> list[str]:
    signals = [name for name, pattern in MATERIAL_SIGNAL_PATTERNS if pattern.search(text)]
    normalized = text.lower()
    mentioned = sorted(
        entity for entity in entities
        if len(entity.strip()) >= 2 and entity.strip().lower() in normalized and entity.strip() not in NON_ENTITY_TERMS
    )
    if mentioned and CAPABILITY_VERBS.search(text):
        signals.append("entity_capability:" + ",".join(mentioned[:3]))
    return signals


def _claim_supports_text(text: str, claim: dict[str, Any]) -> bool:
    """Require semantic anchors between a field and its own bound claim."""
    if claim.get("verification_status") not in {"verified", "verified_with_limits"}:
        return False
    if claim.get("allowed_usage") not in {"public_fact", "public_with_qualification"}:
        return False
    claim_text = "\n".join(
        str(value or "") for value in (
            claim.get("claim_text"), claim.get("evidence_excerpt"), claim.get("scope"), claim.get("as_of"),
        )
    )
    field_lower, claim_lower = text.lower(), claim_text.lower()
    # A semantic overlap must never launder a changed number, price, date,
    # percentage or version. Every strict fact token asserted by the field must
    # occur in the bound claim/evidence text verbatim after whitespace folding.
    def date_tokens(value: str) -> set[str]:
        result = set()
        for match in DATE_FACT_RE.finditer(value):
            token = f"{int(match.group('year')):04d}-{int(match.group('month')):02d}"
            if match.group("day"):
                token += f"-{int(match.group('day')):02d}"
            result.add(token)
        return result

    field_dates, claim_dates = date_tokens(text), date_tokens(claim_text)
    if any(not any(left == right or left.startswith(right + "-") or right.startswith(left + "-")
                   for right in claim_dates) for left in field_dates):
        return False
    field_without_dates = DATE_FACT_RE.sub("", text)
    claim_without_dates = DATE_FACT_RE.sub("", claim_text)
    field_facts = {
        re.sub(r"\s+", "", match.group(0)).lower()
        for match in STRICT_FACT_TOKEN_RE.finditer(field_without_dates)
    }
    claim_facts = {
        re.sub(r"\s+", "", match.group(0)).lower()
        for match in STRICT_FACT_TOKEN_RE.finditer(claim_without_dates)
    }
    if field_facts - claim_facts:
        return False
    entities = {
        str(value).strip().lower() for value in claim.get("about_entities", [])
        if len(str(value).strip()) >= 2
    }
    shared_entity = bool(entities) and any(entity in field_lower and entity in claim_lower for entity in entities)
    field_tokens = question_key_tokens(text)
    claim_tokens = question_key_tokens(claim_text)
    shared = {
        token for token in field_tokens & claim_tokens
        if len(token) >= 3 and token not in entities and token not in NON_ENTITY_TERMS
    }
    if shared_entity:
        return len(shared) >= 2
    # Legacy, already-built R0 packs may omit about_entities. New root packs
    # require it, but a conservative content-anchor fallback keeps those signed
    # historical packs usable. Three distinct non-generic four-character
    # anchors are enough for a natural Chinese paraphrase, while the strict fact
    # token equality above prevents a nearby claim from laundering new figures.
    long_anchors = {token for token in shared if len(token) >= 4}
    return len(long_anchors) >= 3


def material_claim_binding_errors(
    model: dict[str, Any], claim_registry: dict[str, Any], *, require_content_function: bool = False,
) -> list[str]:
    """Find objective/material prose that has no field-local evidence binding.

    Advice, transitions and procedural instructions may be unbound only while
    they contain no factual signals. Factual/analysis fields always require a
    claim aligned to that exact field; an unrelated valid claim cannot launder
    a material assertion. Lead and conclusion use only their own local IDs.
    """
    errors: list[str] = []
    claims = {
        str(item.get("claim_id")): item
        for item in claim_registry.get("claims", []) if isinstance(item, dict)
    }
    used_ids: set[str] = set()
    for section in model.get("sections", []):
        if not isinstance(section, dict):
            continue
        groups = [(f"sections.{section.get('section_id')}.blocks", section.get("blocks", []))]
        groups.extend(
            (f"sections.{section.get('section_id')}.subsections.{index}.blocks", item.get("blocks", []))
            for index, item in enumerate(section.get("subsections", [])) if isinstance(item, dict)
        )
        for prefix, group in groups:
            for index, block in enumerate(group if isinstance(group, list) else []):
                if not isinstance(block, dict):
                    continue
                used_ids.update(str(value) for value in block.get("claim_ids", []))
    lead = model.get("lead", {}) if isinstance(model.get("lead"), dict) else {}
    used_ids.update(str(value) for value in lead.get("claim_ids", []))
    for item in model.get("faq", []):
        if isinstance(item, dict):
            used_ids.update(str(value) for value in item.get("claim_ids", []))
    conclusion = model.get("conclusion", {}) if isinstance(model.get("conclusion"), dict) else {}
    used_ids.update(str(value) for value in conclusion.get("claim_ids", []))

    entities = {
        str(value).strip() for claim in claims.values() for value in claim.get("about_entities", [])
        if len(str(value).strip()) >= 2
    }
    # Latin/camel-case names in the primary question remain useful even when a
    # malformed registry omits about_entities; common generic Chinese terms do not.
    entities.update(
        token for token in LATIN_TOKEN_RE.findall(str(model.get("primary_question", "")))
        if len(token) >= 3
    )

    def check_local(path: str, value: str, local_ids: Any, content_function: Any) -> None:
        ids = [str(item) for item in local_ids] if isinstance(local_ids, list) else []
        signals = _material_signals(value, entities)
        function = str(content_function or "").strip()
        if require_content_function and not function:
            errors.append(f"missing_content_function:{path}")
        if function in {"factual_claim", "analysis", "factual_answer"} and not ids:
            errors.append(f"unbound_material_claim:{path}:content_function={function}")
        elif not ids and signals:
            errors.append(f"unbound_material_claim:{path}:signals={','.join(signals)}")
        if ids and (function in {"factual_claim", "analysis", "factual_answer"} or signals):
            aligned = [claim_id for claim_id in ids if _claim_supports_text(value, claims.get(claim_id, {}))]
            if not aligned:
                errors.append(f"misaligned_claim_binding:{path}:{ids}")

    for section in model.get("sections", []):
        if not isinstance(section, dict):
            continue
        section_id = str(section.get("section_id", "unknown"))
        groups = [(f"sections.{section_id}.blocks", section.get("blocks", []))]
        groups.extend(
            (f"sections.{section_id}.subsections.{index}.blocks", item.get("blocks", []))
            for index, item in enumerate(section.get("subsections", [])) if isinstance(item, dict)
        )
        for prefix, group in groups:
            for index, block in enumerate(group if isinstance(group, list) else []):
                if isinstance(block, dict):
                    check_local(
                        f"{prefix}[{index}]", _visible_value(block), block.get("claim_ids", []),
                        block.get("content_function"),
                    )
    for index, item in enumerate(model.get("faq", [])):
        if isinstance(item, dict):
            check_local(
                f"faq[{index}].answer", str(item.get("answer", "")), item.get("claim_ids", []),
                item.get("content_function"),
            )

    for field in ("direct_answer_sentence", "micro_answer"):
        value = str(lead.get(field, ""))
        signals = _material_signals(value, entities)
        local_ids = [str(item) for item in lead.get("claim_ids", [])]
        aligned = [claim_id for claim_id in local_ids if _claim_supports_text(value, claims.get(claim_id, {}))]
        if not local_ids:
            errors.append(f"unbound_material_claim:lead.{field}:signals={','.join(signals) or 'answer_claim'}")
        elif not aligned:
            errors.append(f"misaligned_claim_binding:lead.{field}:{local_ids}")

    conclusion_ids = conclusion.get("claim_ids")
    for field in ("summary", "fit", "next_action"):
        value = str(conclusion.get(field, ""))
        signals = _material_signals(value, entities)
        local_ids = [str(item) for item in conclusion_ids] if isinstance(conclusion_ids, list) else []
        aligned = [claim_id for claim_id in local_ids if _claim_supports_text(value, claims.get(claim_id, {}))]
        requires_alignment = field in {"summary", "fit"} or bool(signals)
        if requires_alignment and not local_ids:
            errors.append(f"unbound_material_claim:conclusion.{field}:signals={','.join(signals) or 'decision_claim'}")
        elif requires_alignment and not aligned:
            errors.append(f"misaligned_claim_binding:conclusion.{field}:{local_ids}")
    return errors
