# FrontMind GEO 内容制作全局总控与契约规范

> SSOT 版本：`1.0.0`
> 适用范围：Reference Pack 构建与单问题文章制作。

## 1. 目标和边界

本工作流的目标是把“企业可核验资料”转成“围绕一个确定问题、可直接编辑和上线的高质量文章”。它分为可复用资料统筹层与逐问题制作层。

包含：企业资料读取、Reference Pack、问题监控输入分析、标杆结构拆解、文章结构选择、写作、视觉、编辑质量控制、算法候选优化、DOCX/HTML 双格式交付。

不包含：广域问题发现、关键词策略、内容优先级、客户策略报告、发布/CMS 操作、渠道排期、监测复测、Analytics/CRM/收入归因、权限与商业产品架构。

## 2. 继承与冲突决策

| 原工作流能力 | 决策 | 新规则 |
|---|---|---|
| 企业事实与知识库 | 保留 | 作为输入读取，不重新发明事实；统一进入 Reference Pack 与 claim/source registry |
| 趋势材料 | 保留为可选引用 | 只输出可写观点、时间范围与来源；不决定是否生产文章 |
| 品牌定位与话语 | 保留并工程化 | 形成写作可消费的定位、RTB、首选词、禁用词和句式约束 |
| 企业图片库与视觉规则 | 保留并工程化 | 统一 image registry；真实图片、生成视觉和数据图分源登记 |
| 问答树 | 缩减 | 形成 30-50 条可追溯 FAQ 候选池；每篇选择最相关的 5-8 条 |
| 旧策略报告、资产打分与行动建议 | 删除依赖 | 不进入 Reference Pack，也不参与文章路由 |
| 固定全量文章矩阵 | 替换 | 四类问题入口 + E1 后台自动选择一个 P01-P15 |
| 旧版算法直接重写正本 | 替换 | E5 只生成候选；保留原稿、事实 diff 和 E6 人工/编辑质量门 |
| 单一 DOCX 交付 | 扩展 | 一个 Content Model 同源生成 DOCX 与 HTML |
| PDF 报告链路 | 移出必需契约 | 可另行生成，但不能阻塞 Reference Pack 或文章交付 |
| 渠道与发布动作 | 移出范围 | 工作流在可发布文件包完成后结束 |

详细旧类型迁移见 [迁移映射](../shared/workflow-migration-map.md)。

## 3. 唯一状态流

### 3.1 资料统筹层

```text
散乱原始企业资料 -> 可选 S1 整理 -> 既有 KB Builder -> canonical KB v4
canonical KB v4 + 图片库 -> R0 -> 读取并验证既有事实、来源与图片权利
  -> 提取可写趋势、定位、RTB、话语、视觉与 FAQ 候选
  -> 建立 knowledge/source/claim/image registries
  -> 生成 reference_pack.json
  -> 校验文件存在性、哈希与 schema
  -> Reference Pack ZIP
```

该层可以为同一企业多次内容任务复用。知识、来源或视觉资产变化时生成新版本，不覆盖旧版本。

canonical KB v4 是资料统筹层的必需输入。S1 原样保留为可选上游资料整理工具，但 S1 输出本身不是合法 R0 输入；它必须先经既有 KB Builder 生成 manifest、source index 与 knowledge tree。不得声称存在 S1-only 直达 R0 的归一化路径。

### 3.2 单问题制作层

| 阶段 | 职责 | 核心输入 | 核心输出 |
|---|---|---|---|
| E0-A | 安全校验并原子落地 Reference Pack ZIP；创建 canonical Content Job；确认原始双表物理存在 | Reference Pack ZIP、任务输入 | `reference_pack_staging.json`、`content_job.json` |
| E0.5 | 正规化已上传的 AI 回答与信源；抽取竞品；访问相似引用页；拆解标杆结构 | Content Job、答案表、信源表 | `E0.5_{job_id}_monitoring_input.json` |
| E0-B | 复验 staged Pack、Job、monitoring/原表哈希、题面、范围与标杆访问证据；建立只读 Pack 与 job-local 证据/图片追加层 | E0-A、E0.5 | `E0_intake_report.json`、runtime evidence/image registries 与回执 |
| E1 | 深挖一个问题；确定必须回答内容；融合预置与标杆结构；自动选择一个 P 模式 | Pack、Job、E0.5 | `E1_{job_id}_article_blueprint.json` |
| E2 | 写作并形成语义正本；生成标题候选、证据绑定、FAQ 与视觉槽位 | Blueprint、registries | `E2_{job_id}_content_model.draft.json` |
| E2.5 | 证据预检：逐主张语义复核并校验主张绑定、统计口径、价格六要素、比较输入与原创信息门 | E2 初稿、registries | `E2.5_{job_id}_semantic_review.json`、`E2.5_{job_id}_evidence_preflight.json` |
| E3 | 选择企业实图、生成解释性视觉、绑定正文位置与来源 | E2 初稿、E2.5 预检、image registry | `E3_{brand_label}_{job_id}_visual_argument_manifest.json`、视觉文件、视觉版 Content Model |
| E4 | 编辑终审：修订回答完整性、公平性、文风、类型与多模态质量，并冻结安全正本 | E3 视觉版模型、E2.5 预检、visuals | `E4_{job_id}_safe_content_model.json`、`E4_{job_id}_safe_model.sha256`、`E4_{job_id}_quality_report.json`、标题审阅回执 |
| E5 | 运行算法优化并输出候选；计算事实、结构和措辞 diff | E4 冻结的安全正本 | `E5_autogeo_candidate.json`（可选）、`E5_autogeo_report.json`、`E5_field_diff.json`（可选） |
| E6 | 对候选执行事实回归，选定最终模型，同源渲染并校验交付 | E4 安全正本、E5 候选 | DOCX、HTML、JSON-LD、quality report、delivery manifest |

E0 是双相门，顺序固定为 `E0-A → E0.5 → E0-B`；E0-B 未通过不得进入 E1。E4 未通过不得进入 E5。E5 跳过、失败或事实回归不通过时，E6 必须沿用 E4 冻结的安全正本；不得用无审查的全局替换作为降级优化。

## 4. 四类问题入口

持久化只能使用：

| canonical id | 中文 | 决策含义 | 导入别名 |
|---|---|---|---|
| `industry_ranking` | 行业排名 | 开放推荐、榜单、候选名单与品类发现 | `industry` |
| `competitor_comparison` | 竞品对比 | 当前企业与明确命名替代项的共同维度取舍 | 无 |
| `reputation` | 美誉舆情 | 可信、口碑、交付、安全、服务与争议判断 | 无 |
| `product_scenario` | 产品场景 | 具体 offering 的定义、机制、适用、交付与限制 | 无 |

别名只能在 E0 导入边界转换，后续文件不得保存 `industry`。四类的机器定义、P01-P15 和路由都以 [content-pattern-registry.json](../shared/content-pattern-registry.json) 为唯一来源。

### 4.1 Content Job 输入

- 人工入口只提交主问题与四类 `question_category`；七类 intent tag 由 E1 自动标注并写入 Article Blueprint，不成为第二个人工菜单。
- `product_scenario_subintent` 可由工程师提供为提示，但 E1 必须按问题自动复核；缺失时由 E1 判定。
- `monitoring_input_path` 必填，并指向由答案表、信源表正规化得到的 canonical Monitoring Input。
- `optimizer_target.dataset` 与 `optimizer_target.engine_llm` 必填。运行时工具不可用时 E5 可以明确跳过并沿用 E4，但 Job 根本未声明目标时 E0 必须阻断。

## 5. P01-P15 的选择原则

- P 编号是后台内容结构，不是用户入口、服务套餐或先验选题。
- E1 先建立 `question_contract`，再按问题动作、证据可用性、期望判断和标杆结构选择 exactly one pattern。
- 辅助模式不得混写成第二种文章。FAQ、微型答案、条件说明、风险提示和结构化数据属于横向模块。
- required evidence 不满足时，E1 必须改选合格模式或返回补证清单；不能降低事实标准。
- 每种结构骨架和门槛见 [content-pattern-guide.md](../shared/content-pattern-guide.md)。

## 6. Reference Pack 契约

ZIP 根目录必须有且只能有一个入口文件：`reference_pack.json`。Schema 为 [reference_pack.schema.json](../shared/reference_pack.schema.json)。

Reference Pack 必须包含：

- `profile=frontmind-content-reference-pack-v1`、原知识包 profile 与 SHA-256；
- 状态为 `approved` 的确认回执；
- 企业 canonical identity 与知识库版本；
- 品牌事实文件；
- knowledge、source、claim、image registries；
- 定位/RTB、话语 token、视觉约束；
- 可选趋势观点与 FAQ 候选池；
- 所有文件的 ZIP 相对路径、媒体类型、用途和 SHA-256。

PDF 不在 required 字段中。ZIP 可以附带 PDF，但缺少 PDF 不能导致 schema 或 validator 失败。

## 7. 内容与渲染契约

`content_model.json` 是正文唯一语义正本，Schema 为 [content_model.schema.json](../shared/content_model.schema.json)。

- 最终标题、Meta Description、开头微型答案、H2/H3、正文块、FAQ、引用与视觉位置全部来自该文件。
- DOCX 与 HTML 由同一个 `content_model_sha256` 渲染；任何渲染后文字修改必须回写 Content Model 并重新生成两份文件。
- 正文不使用表格。比较内容使用同维度、同顺序的平行段落。
- HTML 只有一个 H1；正文按 H2/H3 组织，最多三级且不跳级。
- H2 写成用户可理解的完整子问题，H3 只拆价格、功能、案例、限制等判断维度。
- JSON-LD 必须与可见正文一致，不能用结构化数据添加正文没有的主张或 FAQ。

## 8. 事实与来源优先级

| tier | 来源 | 可支持内容 |
|---|---|---|
| 1 | 法规、政府、监管文件、标准、同行评审研究、原始数据 | 定义、规则、统计、合规与行业事实 |
| 2 | 企业官方文件、合同/产品资料、官方定价、经确认的项目记录 | 企业事实、规格、价格、服务、案例过程 |
| 3 | 有编辑责任的权威媒体、专业机构数据库、明确身份专家 | 第三方观察、口碑背景、行业解释 |
| 4 | 论坛、评论、聚合页与无明确责任主体内容 | 只发现问题或风险线索，不单独支持关键结论 |

重要事实优先追溯原始来源。每项统计必须记录日期、样本量、单位、地区/人群和口径；价格与规格记录币种、套餐、地区、版本、有效日期和附加条件。来源不足时缩小主张，不得用“据悉”“业内人士”或模型常识补齐。

文末可见 `references` 必须与正文实际使用主张的 `source_ids` 精确相等：不能漏掉支撑来源，也不能加入未被文章主张使用的“垫权威”来源。公开或匿名公开的原创证据来源必须同时登记为对应 claim 的来源并显示；只有内部记录路径、没有可公开来源身份时，不能宣称已向读者注明原始来源。

## 9. 图片与视觉契约

- 企业 Logo、产品、团队、场地、证书、客户现场、事件与案例图只能来自企业提交且权利明确的图片库。
- 生成图片不能冒充真实人物、真实场景、客户案例、认证或产品外观。
- 数据图、流程图、架构图必须绑定来源或正文事实，并承担解释、比较、证明或操作指引功能。
- 所有图片统一登记在 `images[]`，哈希字段统一为 `sha256`；不得并存第二套 `entries/file_hash` registry。
- 图片的用途不能靠下游猜测：每项必须有 `asset_kind`。Logo 同时满足 `asset_kind=logo`、`allowed_roles` 含 `entity_proof` 和可发布权利；普通品牌图不得冒充 Logo。
- `approved_with_credit` 图片必须保留并在成品中显示 `attribution_text`；缺少署名文本时不得使用。
- 缺少必需真实素材时输出 `asset_gap`，不能偷偷以网图或生成图替代。

## 10. 写作与质量门

全局写作规则见 [writing-policy.md](../shared/writing-policy.md)，HTML 与 JSON-LD 规则见 [html-structured-data-policy.md](../shared/html-structured-data-policy.md)。

E4/E6 至少阻断以下问题：

1. 标题问题未被直接回答；
2. 核心主张无证据，或统计/价格缺口径；
3. 竞品没有采用相同维度、来源或篇幅严重失衡；
4. 类型写串、模板痕迹或内部审稿语言进入正文；
5. 视觉仅装饰，或事实性图片来源/权利不清；
6. 微型答案、5-8 个相关 FAQ 或必要子问题缺失；
7. HTML 层级、Title/H1/Meta 一致性或 JSON-LD 可见性不合格；
8. DOCX 与 HTML 语义不一致；
9. 算法候选改变实体、数字、日期、价格、比较结论或引用关系。

质量报告必须符合 [quality_report.schema.json](../shared/quality_report.schema.json)。

## 11. 文件命名

```text
S0_{brand_label}_reference_pack_v{N}.zip
reference_pack.json
content_job.json
E0.5_{job_id}_monitoring_input.json
E1_{job_id}_article_blueprint.json
E2_{job_id}_content_model.draft.json
E2.5_{job_id}_evidence_preflight.json
E3_{brand_label}_{job_id}_visual_argument_manifest.json
E4_{job_id}_safe_content_model.json
E4_{job_id}_quality_report.json
E5_autogeo_candidate.json
E5_autogeo_report.json
E5_field_diff.json
final.docx
final.html
structured_data.json
delivery_manifest.json
```

`brand_label` 只用于安全文件名，可以是品牌正式名的无路径分隔符版本或稳定 slug；品牌身份与别名以 Pack 内 canonical identity 为准，不从 ZIP 文件名反推。

文件名不包含渠道、发布或效果归因含义。FrontMind canonical artifact 与阶段回执 JSON 都必须带 `schema_version`；标准 JSON-LD 数组不虚构该字段。delivery manifest 登记除自身以外的全部交付物并记录 SHA-256，避免自引用哈希。

## 12. 错误与降级

- Reference Pack 缺 required 文件、路径逃逸、哈希不匹配或 registry 不兼容：E0 阻断。
- 答案表或信源表缺失、为空、无法解析或与当前问题不匹配：E0/E0.5 阻断并返回补件清单；不得使用预置骨架绕过监控。
- 原创信息缺失：严格按 registry 的 `original_information_gate` 执行。P01、P02、P03、P09、P11，以及执行多对象价格/套餐/总成本比较的 P06 必须阻断；其余模式可说明理由后豁免，但不得声称独立测试、最佳、领先、权威排名或原创数据结论。P12 不因“事件”标签自动成为原创硬门。
- 视觉缺失：可在不需要事实性图片的模式中降级为来源明确的解释图；真实案例/事件模式不得降级。
- E5 工具不可用、失败或候选回归不通过：跳过候选，沿用 E4 冻结的安全正本；不得运行全局字符串替换。
- 任一质量门连续两次修订仍失败：停止并输出具体差异和所需资料，不自动改变问题。
