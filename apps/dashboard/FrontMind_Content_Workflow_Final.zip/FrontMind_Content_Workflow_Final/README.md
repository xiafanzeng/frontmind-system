# FrontMind GEO 内容制作工作流

> 版本：`1.0.0-content-production`
> 定位：面向服务商内部使用的企业内容资料统筹与单问题内容制作工作流。

本工作流只解决两件事：

1. 把企业知识库、证据文件和图片库整理为可重复使用的 `Reference Pack`；
2. 接收一个已在工作流外确认的 GEO 问题，完成问题监控、标杆拆解、文章规划、写作、视觉、编辑审查、算法候选优化与 DOCX/HTML 双格式交付。

它不发现“应该优化什么问题”，不制作客户策略报告，不生成内容日历，不负责发布、渠道运营、CMS、Analytics、CRM 或收入归因。

## 唯一入口

读取 [内容制作总控](00.FrontMind内容制作总控.skill/SKILL.md)，再读取 [全局 SSOT](Master_Control/FrontMind_Content_Workflow_Master.md)。

工程落地时按 [完整运行手册](RUNBOOK.md) 执行。手册区分内容工程师/负责人必须完成的产物与脚本校验步骤，并给出从 canonical KB ZIP 到 DOCX/HTML 的完整参数链。

本版本的测试范围、真实 KB 适配结果、对抗门和环境说明见 [验证报告](VALIDATION_REPORT.md)。

总控支持三种启动状态：

- 只有 canonical KB v4/图片库：先构建或刷新 `Reference Pack`；
- 已有 `Reference Pack`，并有一个确定问题：直接进入内容制作；
- 两者同时提供：先统筹资料，再连续制作该问题的文章。

## 固定流程

```text
散乱原始企业资料 -> 可选 S1 整理 -> 既有 KB Builder -> canonical KB v4
canonical KB v4 + 企业图片库 -> R0 -> 事实/趋势/定位/话语/视觉/FAQ 资产整理
  -> Reference Pack ZIP（根目录固定 reference_pack.json）

Reference Pack ZIP + 一个已确认问题 + 该问题的答案/信源监控输入
  -> E0-A 安全落地 Pack、建立任务并确认原始双表
  -> E0.5 问题监控、竞品提取、引用信源与标杆结构拆解
  -> E0-B 全契约校验与 job-local 证据/图片交接（签名 Pack 只读）
  -> E1 问题深挖、后台选择一个 P01-P15 内容结构、生成 Article Blueprint
  -> E2 同源 Content Model 初稿
  -> E2.5 证据、主张、统计、价格与输入完整性预检
  -> E3 视觉选择/制作并绑定论证位置
  -> E4 编辑终审、多模态质量审查并冻结安全正本
  -> E5 算法优化候选 + 事实差异报告（不直接覆盖正本）
  -> E6 复审、选择最终版本、同源渲染 DOCX + HTML、打包交付
```

## 用户可见的四类问题

- `industry_ranking`：行业排名与开放推荐；兼容导入别名 `industry`。
- `competitor_comparison`：明确品牌/产品之间的竞品对比。
- `reputation`：口碑、可信度、交付、安全与风险判断。
- `product_scenario`：具体产品、服务、功能、使用、实施与适用场景。

P01-P15 是 E1 后台自动选择的文章结构，不作为用户菜单。唯一注册表为 [content-pattern-registry.json](shared/content-pattern-registry.json)。

## 核心契约

- Reference Pack ZIP 命名固定为 `S0_{brand_label}_reference_pack_v{N}.zip`；`brand_label` 是不含路径分隔符的安全文件标签，正式品牌身份仍以 Pack 内 canonical identity 为准。ZIP 根目录入口固定为 `reference_pack.json`；其他入口文件名不构成有效入口。
- 每次内容任务都必须上传与当前问题匹配的答案表和信源表；缺任一表、无法解析或问题不匹配时，E0/E0.5 阻断。
- PDF 不是机器执行契约的必需项；如客户另行需要，可在主流程之外从现有源文件生成。
- `content_model.json` 是正文唯一正本；DOCX 与 HTML 必须由同一版本渲染，不允许分别改写。
- 企业知识单元、来源、主张和图片分别登记到唯一 canonical registries：`knowledge_units[]`、`sources[]`、`claims[]`、`images[]`；图片哈希统一为 `sha256`。
- Reference Pack 必须带 `frontmind-content-reference-pack-v1` profile、原知识包 profile/SHA-256 与状态为 `approved` 的确认回执。
- E5 只生成实验候选版本；E6 必须执行事实 diff、编辑复核和质量门后才可选为终稿。

## 目录

```text
00.FrontMind内容制作总控.skill/  唯一入口
Master_Control/                  全局契约与迁移决策
shared/                          canonical schemas、P01-P15 注册表、政策与验证器
Strategy_Workflow/               可复用 Reference Pack 构建层
Execution_Workflow/              单问题内容制作层
scripts/validate_workflow.py     全工作流静态完整性检查
```

## 验证

先在 Workflow 根目录准备 Python 3.10+ 环境：

```bash
python3 -m pip install -r requirements.txt
python3 -B scripts/check_runtime_dependencies.py
```

SVG Logo 覆盖及原样保留的可选 S1 抓取能力见 `requirements-optional.txt`；AutoGEO 是经单独审核的选装组件，缺失时 E5 明确跳过并沿用 E4 安全正本。

```bash
python3 -B scripts/validate_workflow.py
python3 -B shared/scripts/check_cross_references.py .
python3 -B shared/scripts/validate_package.py shared/fixtures/minimal_reference_pack
```

验证必须同时通过：Skill frontmatter、相对引用、JSON/JSON Schema 解析、Python 编译、canonical registry 完整性、Reference Pack 文件/哈希校验和旧逻辑残留扫描。
