# FrontMind GEO 内容制作运行手册

> 本手册面向实际执行人员。它区分“由负责人/内容工程师产出内容”的步骤与“由脚本执行确定性校验”的步骤；validator 通过不等于内容已经自动生成。

## 1. 运行原则

1. 正式资料入口只能是通过验证的 canonical KB v4 **原始 ZIP**。目录输入只用于 R0 本地诊断，不能直接打成正式 Reference Pack。
2. Reference Pack 经 S10 批准后只读。单篇任务新增的网页证据、访谈记录、价格采样和图片都进入 job-local runtime 层，不原位修改 Pack。
3. 一个任务只处理一个主问题。用户只选择四类入口之一；P01–P15 由 E1 后台选择且每篇恰好一个。
4. 先产出 JSON，再运行对应 validator。任何硬门失败都回到责任阶段修源文件，不修改报告来伪造通过。
5. E4 是安全正本；E5 只产生候选。E6 回归未通过时必须使用 E4。
6. DOCX 与 HTML 必须从同一个 approved Content Model 生成。

## 2. 环境与变量

在 Workflow 根目录安装基础依赖并预检：

```bash
cd /path/to/FrontMind_Content_Workflow_Final
python3 -m pip install -r requirements.txt
python3 -B scripts/check_runtime_dependencies.py
```

建议为每次运行声明明确的绝对路径，以下命令均从 Workflow 根目录执行：

```bash
WF=/absolute/path/to/FrontMind_Content_Workflow_Final
PROJECT=/absolute/path/to/client-reference-project
JOB=/absolute/path/to/article-job
KB=/absolute/path/to/canonical-knowledge-base-v4.zip
BRAND='品牌正式名称'
BRAND_LABEL='brand_stable_file_label'
PACK="/absolute/path/to/S0_${BRAND_LABEL}_reference_pack_v1.zip"
JOB_ID='job_brand_question_001'
PATTERNS="$WF/shared/content-pattern-registry.json"
```

路径不得使用 `~`、未解析变量、父目录逃逸或符号链接替代真实文件。

## 3. A 段：构建可复用 Reference Pack

### A0. 检查输入

- canonical KB v4 原始 ZIP；
- 可选的、权利状态明确的企业图库；
- 可选 S1 事实/视觉补充。S1 保持原样，只能作为补充，不能替代 canonical KB。

若只有散乱资料，先在本工作流之外用原样 S1 整理，再经既有 KB Builder 生成 canonical KB v4。

### A1. R0 归一化资料与四类 Registry

确定性执行：

```bash
mkdir -p "$PROJECT/R0"
python3 -B "$WF/Strategy_Workflow/R0.资料标准化适配器.skill/scripts/kb_v4_adapter.py" \
  --brand "$BRAND" \
  --kb "$KB" \
  --output-dir "$PROJECT/R0" \
  --legacy-policy reject
```

如确有补充资料，可另外使用 `--s1-facts`、`--s1-visual-manifest`、`--s1-assets-root` 或 `--gallery`。R0 必须输出且通过：

- `R0_{brand_label}_adapter_report.json`；
- `R0_{brand_label}_knowledge_registry.json`；
- `R0_{brand_label}_source_registry.json`；
- `R0_{brand_label}_claim_registry.json`；
- `R0_{brand_label}_image_registry.json`。

`BRAND` 是文章中使用的正式品牌名称；`BRAND_LABEL` 是不含空格、标点和路径分隔符的稳定文件标签。它必须与 R0 实际输出文件名中的标签一致，只用于路径与文件名，不得替代正文品牌名。首次运行 R0 后先核对该标签，再继续 A2；不得手工改名绕过。

`adapter_report.fatal_errors` 和 `warnings` 必须为空；正式打包时 S0 会再次核对原 KB ZIP 字节哈希。

### A2. S3 可选趋势参考

只有近期变化会实质影响文章时才做。内容工程师先收集有来源的信号并生成符合 S3 schema 的 JSON；随后校验：

```bash
python3 -B "$WF/Strategy_Workflow/S3.内容趋势参考.skill/scripts/signal_aggregator.py" \
  --validate "$PROJECT/S3/S3_${BRAND_LABEL}_trend_reference.json" \
  --source-registry "$PROJECT/R0/R0_${BRAND_LABEL}_source_registry.json" \
  --knowledge-registry "$PROJECT/R0/R0_${BRAND_LABEL}_knowledge_registry.json" \
  --pattern-registry "$PATTERNS"
```

没有可靠信号时可以不运行；不得为了填充段落制造趋势。

### A3. S4 信息与证据架构

内容工程师完整读取 R0 registries，并按 [S4 Skill](Strategy_Workflow/S4.信息与证据架构师.skill/SKILL.md) 产出：

- `S4_{brand_label}_information_evidence.json`；
- `S4_{brand_label}_brand_facts.json`。

确定性校验：

```bash
python3 -B "$WF/Strategy_Workflow/S4.信息与证据架构师.skill/scripts/information_evidence_validator.py" \
  "$PROJECT/S4/S4_${BRAND_LABEL}_information_evidence.json" \
  --brand-facts "$PROJECT/S4/S4_${BRAND_LABEL}_brand_facts.json" \
  --knowledge-registry "$PROJECT/R0/R0_${BRAND_LABEL}_knowledge_registry.json" \
  --claim-registry "$PROJECT/R0/R0_${BRAND_LABEL}_claim_registry.json" \
  --source-registry "$PROJECT/R0/R0_${BRAND_LABEL}_source_registry.json" \
  --pattern-registry "$PATTERNS"
```

### A4. S6 文章话语契约

内容工程师按 [S6 Skill](Strategy_Workflow/S6.文章话语契约.skill/SKILL.md) 产出 `S6_{brand_label}_voice_contract.json`，把品牌语言变成可检查的首选词、禁用词、证据状态措辞和句式规则。

```bash
python3 -B "$WF/Strategy_Workflow/S6.文章话语契约.skill/scripts/article_voice_contract_validator.py" \
  "$PROJECT/S6/S6_${BRAND_LABEL}_voice_contract.json" \
  --architecture "$PROJECT/S4/S4_${BRAND_LABEL}_information_evidence.json" \
  --pattern-registry "$PATTERNS"
```

### A5. S7 视觉参考体系

内容工程师按 [S7 Skill](Strategy_Workflow/S7.视觉参考体系.skill/SKILL.md) 产出 `S7_{brand_label}_visual_reference.json`。真实 Logo 只能登记为 `asset_kind=logo` 并以原件 overlay；禁止生成、重绘或猜测 Logo。

```bash
python3 -B "$WF/Strategy_Workflow/S7.视觉参考体系.skill/scripts/visual_reference_validator.py" \
  "$PROJECT/S7/S7_${BRAND_LABEL}_visual_reference.json" \
  --image-registry "$PROJECT/R0/R0_${BRAND_LABEL}_image_registry.json" \
  --pattern-registry "$PATTERNS"
```

### A6. S8 问题与 FAQ 参考库

内容工程师按 [S8 Skill](Strategy_Workflow/S8.问题与FAQ参考库.skill/SKILL.md) 建立 30–50 个问题资产，覆盖四入口与七类 intent tag；只写问题、来源和回答边界，不提前生成标准答案。

```bash
python3 -B "$WF/Strategy_Workflow/S8.问题与FAQ参考库.skill/scripts/question_library_validator.py" \
  "$PROJECT/S8/S8_${BRAND_LABEL}_question_library.json" \
  --pattern-registry "$PATTERNS" \
  --knowledge-registry "$PROJECT/R0/R0_${BRAND_LABEL}_knowledge_registry.json" \
  --source-registry "$PROJECT/R0/R0_${BRAND_LABEL}_source_registry.json" \
  --claim-registry "$PROJECT/R0/R0_${BRAND_LABEL}_claim_registry.json" \
  --architecture "$PROJECT/S4/S4_${BRAND_LABEL}_information_evidence.json"
```

### A7. S10 人工确认

S10 是资料层唯一暂停点。先生成确认工作簿：

```bash
mkdir -p "$PROJECT/S10"
python3 -B "$WF/Strategy_Workflow/S10.ReferencePack确认师.skill/scripts/reference_pack_confirmation_generator.py" \
  --brand "$BRAND" \
  --work-dir "$PROJECT" \
  --pattern-registry "$PATTERNS" \
  --out "$PROJECT/S10/S10_${BRAND_LABEL}_ReferencePack确认表.xlsx"
```

负责人逐对象选择 `keep/change/block`，完成六项确认并保存。不得由脚本替负责人勾选。解析确认结果：

```bash
python3 -B "$WF/Strategy_Workflow/S10.ReferencePack确认师.skill/scripts/reference_pack_approval_parser.py" \
  --confirmed "$PROJECT/S10/S10_${BRAND_LABEL}_ReferencePack确认表.xlsx" \
  --brand "$BRAND" \
  --out "$PROJECT/S10/S10_${BRAND_LABEL}_approval.json"
```

只有无修改、无条件、无风险的 `approved` 才能继续；`changes_requested` 返回对应责任阶段并重新确认。

### A8. S0 打包

```bash
mkdir -p "$PROJECT/ReferencePack"
python3 -B "$WF/Strategy_Workflow/S0.策略编排师.skill/scripts/pack_builder.py" \
  --brand "$BRAND" \
  --work-dir "$PROJECT" \
  --kb "$KB" \
  --pattern-registry "$PATTERNS" \
  --output "$PROJECT/ReferencePack/S0_${BRAND_LABEL}_reference_pack_v1.zip"
```

S0 同时校验目录与 ZIP；正式 Pack 的根入口固定为 `reference_pack.json`。

## 4. B 段：围绕一个确定问题制作文章

### B0. 创建只追加的任务目录

```bash
mkdir -p "$JOB/00_input" "$JOB/raw" "$JOB/01_monitoring" \
  "$JOB/02_runtime_evidence" "$JOB/02_runtime_images" "$JOB/03_blueprint" \
  "$JOB/04_draft" "$JOB/05_evidence" "$JOB/06_visual" \
  "$JOB/07_editorial" "$JOB/08_optimization" "$JOB/09_delivery"
```

同一 `JOB_ID` 不复用旧回执；需要重做时建立新的 job 目录。

### B1. E0-A 安全落地 Reference Pack

严禁手工解压或 `unzip -o`：

```bash
python3 -B "$WF/Execution_Workflow/E0.单篇执行编排师.skill/scripts/stage_reference_pack.py" \
  --zip "$PACK" \
  --output-dir "$JOB/reference" \
  --manifest-output "$JOB/00_input/reference_pack_staging.json" \
  --job-package-root "$JOB"
```

输出目录必须原先不存在。工具会在解压前后各验证一次 Pack，并阻断重复项、路径逃逸、符号链接、压缩炸弹与哈希不匹配。

### B2. 建立 Content Job 与原始双表

工程师参照 [Content Job Schema](shared/content_job.schema.json) 的字段结构先生成导入文件 `$JOB/00_input/content_job.raw.json`；它在正规化后才必须完整满足该 Schema。必须包含：

- `job_id` 与一个主问题；
- `question.category` 为四个 canonical 类别之一，或导入边界唯一支持的旧别名 `industry`；
- `target_region`、`target_audience`、`time_scope`；
- canonical monitoring 输出路径；原始答案表与信源表另行放入 `$JOB/raw/`，并由 Monitoring Input 记录；
- `optimizer_target.dataset` 与 `optimizer_target.engine_llm`。

运行导入正规化器。即使输入已是 canonical，也通过这一门生成可审计回执：

```bash
python3 -B "$WF/Execution_Workflow/E0.单篇执行编排师.skill/scripts/normalize_content_job.py" \
  --input "$JOB/00_input/content_job.raw.json" \
  --output "$JOB/00_input/content_job.json" \
  --receipt "$JOB/00_input/content_job_normalization.json"
```

若收到别名 `industry`，工具只在这一处转换为 `industry_ranking`；持久化 canonical Content Job 不得保留别名。

把当前问题对应的两份原始文件放入 `$JOB/raw/`。两表缺失、为空或题面不匹配时不得继续。

### B3. E0.5 Micro Tracking

E0.5 不是广域选题。它只围绕当前主问题完成：答案格局、竞品提取、引用页访问、1–5 篇同形态标杆拆解、可采用/拒绝结构判断及补充原始来源。

工程师先按 [E0.5 Skill](Execution_Workflow/E0.5.单问题监控与标杆拆解师.skill/SKILL.md) 形成 `$JOB/raw/derived.json`；每个标杆 `retrieved` 都必须有实际访问时间、正文摘录、引用上下文、被引主张、来源类型、原始来源判断和新鲜度风险。再执行：

```bash
python3 -B "$WF/Execution_Workflow/E0.5.单问题监控与标杆拆解师.skill/scripts/micro_tracking_builder.py" \
  --job-id "$JOB_ID" \
  --question '这里填写本篇唯一主问题' \
  --answers "$JOB/raw/answers.xlsx" \
  --citations "$JOB/raw/sources.xlsx" \
  --derived-analysis "$JOB/raw/derived.json" \
  --output "$JOB/01_monitoring/E0.5_${JOB_ID}_monitoring_input.json" \
  --raw-metadata-output "$JOB/01_monitoring/raw_metadata.json" \
  --package-root "$JOB"
```

CSV、JSON 或 XLSX 以脚本实际支持格式为准。`content_job.monitoring_input_path` 必须指向上面的正式输出。

### B4. E0-B 全量 Intake

```bash
python3 -B "$WF/Execution_Workflow/E0.单篇执行编排师.skill/scripts/intake_validator.py" \
  --content-job "$JOB/00_input/content_job.json" \
  --reference-pack "$JOB/reference/reference_pack.json" \
  --monitoring-input "$JOB/01_monitoring/E0.5_${JOB_ID}_monitoring_input.json" \
  --staging-receipt "$JOB/00_input/reference_pack_staging.json" \
  --source-zip "$PACK" \
  --package-root "$JOB" \
  --report "$JOB/00_input/E0_intake_report.json"
```

该报告将冻结本 job 使用的 Pack、Job、monitoring 与基础 registries 指纹。

### B5. 建立 job-local 证据与图片层

#### B5.1 运行时证据

工程师按 [Runtime Evidence Extension Schema](shared/runtime_evidence_extension.schema.json) 生成 `$JOB/02_runtime_evidence/extension.json`。即使当前问题不需新增来源，也要提交空的 `sources[]/claims[]/evidence_files[]`，以显式证明沿用 Pack 基线。

新增来源必须有可复核的 job-local 证据文件及 SHA-256；网页 URL 只能作为定位信息，不能靠自行填写 `verified/public_fact` 获得事实资格。价格采样、访谈、测试与项目记录还须带授权状态和方法/范围。

```bash
python3 -B "$WF/Execution_Workflow/E0.单篇执行编排师.skill/scripts/build_runtime_evidence_bundle.py" \
  --job-id "$JOB_ID" \
  --base-claims "$JOB/reference/registries/claim_registry.json" \
  --base-sources "$JOB/reference/registries/source_registry.json" \
  --extension "$JOB/02_runtime_evidence/extension.json" \
  --job-package-root "$JOB" \
  --runtime-claims "$JOB/02_runtime_evidence/claim_registry.json" \
  --runtime-sources "$JOB/02_runtime_evidence/source_registry.json" \
  --receipt "$JOB/02_runtime_evidence/receipt.json"
```

#### B5.2 运行时图片

```bash
python3 -B "$WF/Execution_Workflow/E0.单篇执行编排师.skill/scripts/seed_runtime_image_registry.py" \
  --job-id "$JOB_ID" \
  --base-registry "$JOB/reference/registries/image_registry.json" \
  --runtime-registry "$JOB/02_runtime_images/image_registry.json" \
  --receipt "$JOB/02_runtime_images/seed_receipt.json"
```

基础图片仍从只读 `$JOB/reference` 解析；新增或生成图片从 `$JOB` 解析。新增图片必须经 E3 去重、权利和角色登记，不写回 Pack。

### B6. E1 问题深挖与 Article Blueprint

工程师按 [E1 Skill](Execution_Workflow/E1.文章蓝图师.skill/SKILL.md) 生成 `$JOB/03_blueprint/E1_${JOB_ID}_article_blueprint.json`。它必须明确：

- 一个主问题、5–8 个必要子问题、决策顾虑、误解、反对意见与替代方案；
- 当前任务范围与时间；
- 每个标杆观察采用或拒绝的理由；
- 恰好一个 P01–P15 模式；
- direct answer、200–300 字微型答案、H2 问题句、5–8 个 FAQ 与结尾计划；
- 所需事实、主张、原创信息和视觉槽位。

```bash
python3 -B "$WF/Execution_Workflow/E1.文章蓝图师.skill/scripts/pattern_router.py" validate \
  --registry "$JOB/reference/shared/content-pattern-registry.json" \
  --blueprint "$JOB/03_blueprint/E1_${JOB_ID}_article_blueprint.json" \
  --monitoring-input "$JOB/01_monitoring/E0.5_${JOB_ID}_monitoring_input.json" \
  --content-job "$JOB/00_input/content_job.json" \
  --report "$JOB/03_blueprint/E1_validation.json"
```

### B7. E2 同源 Content Model 初稿

工程师按 [E2 Skill](Execution_Workflow/E2.正文制作师.skill/SKILL.md) 与根 Content Model Schema 生成 `$JOB/04_draft/E2_${JOB_ID}_content_model.draft.json`。正文每段只表达一个主要观点，章节按“结论—证据—建议”；不能用表格，也不能把内部审稿语言写进正文。

```bash
python3 -B "$WF/Execution_Workflow/E2.正文制作师.skill/scripts/content_model_validator.py" \
  "$JOB/04_draft/E2_${JOB_ID}_content_model.draft.json" \
  --claims "$JOB/02_runtime_evidence/claim_registry.json" \
  --sources "$JOB/02_runtime_evidence/source_registry.json" \
  --content-job "$JOB/00_input/content_job.json" \
  --blueprint "$JOB/03_blueprint/E1_${JOB_ID}_article_blueprint.json" \
  --intake-report "$JOB/00_input/E0_intake_report.json" \
  --runtime-evidence-receipt "$JOB/02_runtime_evidence/receipt.json" \
  --report "$JOB/04_draft/E2_validation.json"
```

### B8. E2.5 证据预检

当问题为 `competitor_comparison`，或正文实际比较两个以上对象时，先按相同维度建立 competitor matrix。

机器检查之前，证据编辑还要按 [语义复核 Schema](Execution_Workflow/E2.5.证据预检师.skill/templates/evidence_semantic_review.schema.json) 生成 `$JOB/05_evidence/E2.5_${JOB_ID}_semantic_review.json`。逐一核对正文实际使用的 claim，记录 `supported/not_supported` 和理由，并绑定：

- Content Model 的 evidence projection SHA-256；
- 本轮 runtime claim/source Registry 的 canonical SHA-256；
- competitor matrix 的 canonical SHA-256（不适用为 `null`）。

所有布尔门和 `overall_status` 只能由真实复核结论决定；不能复制旧 job 回执或先写 `passed` 再补审。随后执行：

```bash
python3 -B "$WF/Execution_Workflow/E2.5.证据预检师.skill/scripts/evidence_preflight.py" \
  --model "$JOB/04_draft/E2_${JOB_ID}_content_model.draft.json" \
  --blueprint "$JOB/03_blueprint/E1_${JOB_ID}_article_blueprint.json" \
  --claims "$JOB/02_runtime_evidence/claim_registry.json" \
  --sources "$JOB/02_runtime_evidence/source_registry.json" \
  --pattern-registry "$JOB/reference/shared/content-pattern-registry.json" \
  --content-job "$JOB/00_input/content_job.json" \
  --intake-report "$JOB/00_input/E0_intake_report.json" \
  --runtime-evidence-receipt "$JOB/02_runtime_evidence/receipt.json" \
  --semantic-review "$JOB/05_evidence/E2.5_${JOB_ID}_semantic_review.json" \
  --base-package-root "$JOB/reference" \
  --job-package-root "$JOB" \
  --output "$JOB/05_evidence/E2.5_${JOB_ID}_evidence_preflight.json"
```

有 competitor matrix 时增加：

```text
--competitor-matrix "$JOB/05_evidence/competitor_dimension_matrix.json"
```

脚本会把这份语义回执的 canonical SHA-256 写入预检报告；任何 claim 未覆盖、证据不支持或指纹不匹配都会阻断。

### B9. E3 视觉论证

E3 读取蓝图的视觉需求，先选择可用实图，再生成解释型视觉。封面用于导航；流程/机制图用于解释；数据图或事实图只有在证据和来源完全绑定时才能证明。Logo 不能当作能力、案例或数据主张的证明。

新增图片先运行去重与登记：

```bash
python3 -B "$WF/Execution_Workflow/E3.视觉论证师.skill/scripts/image_dedup_checker.py" \
  --image "$JOB/02_runtime_images/assets/new-image.png" \
  --registry "$JOB/02_runtime_images/image_registry.json" \
  --base-registry "$JOB/reference/registries/image_registry.json" \
  --base-package-root "$JOB/reference" \
  --job-package-root "$JOB" \
  --job-id "$JOB_ID" \
  --register \
  --asset-record "$JOB/02_runtime_images/new-image-record.json" \
  --output "$JOB/02_runtime_images/new-image-dedup.json"
```

工程师完成视觉版 Content Model 与 manifest 后校验：

```bash
python3 -B "$WF/Execution_Workflow/E3.视觉论证师.skill/scripts/visual_claim_validator.py" \
  --model "$JOB/06_visual/E3_${JOB_ID}_content_model.json" \
  --blueprint "$JOB/03_blueprint/E1_${JOB_ID}_article_blueprint.json" \
  --manifest "$JOB/06_visual/E3_${BRAND_LABEL}_${JOB_ID}_visual_argument_manifest.draft.json" \
  --claims "$JOB/02_runtime_evidence/claim_registry.json" \
  --sources "$JOB/02_runtime_evidence/source_registry.json" \
  --evidence "$JOB/05_evidence/E2.5_${JOB_ID}_evidence_preflight.json" \
  --images "$JOB/02_runtime_images/image_registry.json" \
  --base-images "$JOB/reference/registries/image_registry.json" \
  --runtime-registry-receipt "$JOB/02_runtime_images/seed_receipt.json" \
  --base-package-root "$JOB/reference" \
  --job-package-root "$JOB" \
  --report "$JOB/06_visual/E3_validation.json" \
  --validated-manifest "$JOB/06_visual/E3_${BRAND_LABEL}_${JOB_ID}_visual_argument_manifest.json"
```

### B10. E4 编辑终审并冻结安全正本

编辑先逐项审阅五个标题候选，形成符合 title review schema 的回执；再运行：

```bash
python3 -B "$WF/Execution_Workflow/E4.编辑终审师.skill/scripts/editorial_audit.py" \
  --model "$JOB/06_visual/E3_${JOB_ID}_content_model.json" \
  --evidence "$JOB/05_evidence/E2.5_${JOB_ID}_evidence_preflight.json" \
  --visuals "$JOB/06_visual/E3_${BRAND_LABEL}_${JOB_ID}_visual_argument_manifest.json" \
  --blueprint "$JOB/03_blueprint/E1_${JOB_ID}_article_blueprint.json" \
  --claims "$JOB/02_runtime_evidence/claim_registry.json" \
  --sources "$JOB/02_runtime_evidence/source_registry.json" \
  --pattern-registry "$JOB/reference/shared/content-pattern-registry.json" \
  --image-registry "$JOB/02_runtime_images/image_registry.json" \
  --title-review "$JOB/07_editorial/E4_${JOB_ID}_title_review.json" \
  --semantic-review "$JOB/05_evidence/E2.5_${JOB_ID}_semantic_review.json" \
  --report "$JOB/07_editorial/E4_${JOB_ID}_quality_report.json" \
  --safe-output "$JOB/07_editorial/E4_${JOB_ID}_safe_content_model.json" \
  --sha-output "$JOB/07_editorial/E4_${JOB_ID}_safe_model.sha256"
```

E4 必须回答：问题是否真正回答、主张是否被相关证据支持、竞品是否公平、文章是否模板化、视觉是否参与解释/证明、P 模式是否写串。

### B11. E5 AutoGEO 候选

```bash
python3 -B "$WF/Execution_Workflow/E5.AutoGEO候选优化师.skill/scripts/autogeo_candidate_optimizer.py" \
  --e4-model "$JOB/07_editorial/E4_${JOB_ID}_safe_content_model.json" \
  --e4-sha "$JOB/07_editorial/E4_${JOB_ID}_safe_model.sha256" \
  --content-job "$JOB/00_input/content_job.json" \
  --claims "$JOB/02_runtime_evidence/claim_registry.json" \
  --evidence "$JOB/05_evidence/E2.5_${JOB_ID}_evidence_preflight.json" \
  --output-dir "$JOB/08_optimization" \
  --candidate "$JOB/08_optimization/E5_autogeo_candidate.json" \
  --diff "$JOB/08_optimization/E5_field_diff.json" \
  --report "$JOB/08_optimization/E5_autogeo_report.json"
```

AutoGEO 缺失时该阶段明确记录 skip，不运行词语替换 fallback，也不阻塞 E6 沿用 E4。

### B12. E6 回归、标题选择与双格式交付

先回归并选定 approved model：

```bash
python3 -B "$WF/Execution_Workflow/E6.回归终审与双格式交付师.skill/scripts/regression_review.py" \
  --e4-model "$JOB/07_editorial/E4_${JOB_ID}_safe_content_model.json" \
  --e4-sha "$JOB/07_editorial/E4_${JOB_ID}_safe_model.sha256" \
  --e5-report "$JOB/08_optimization/E5_autogeo_report.json" \
  --claims "$JOB/02_runtime_evidence/claim_registry.json" \
  --evidence "$JOB/05_evidence/E2.5_${JOB_ID}_evidence_preflight.json" \
  --approved "$JOB/09_delivery/E6_${JOB_ID}_approved_content_model.json" \
  --audit "$JOB/09_delivery/E6_${JOB_ID}_regression_audit.json"
```

若 E5 生成了候选，还必须增加 `--candidate`、`--e5-diff` 与绑定本次三项哈希的 `--semantic-review`；不允许复用旧回执。

编辑基于五个已审标题和最终正文形成 title selection receipt，且绑定本次 approved model。随后渲染：

```bash
python3 -B "$WF/Execution_Workflow/E6.回归终审与双格式交付师.skill/scripts/render_delivery.py" \
  --model "$JOB/09_delivery/E6_${JOB_ID}_approved_content_model.json" \
  --image-registry "$JOB/02_runtime_images/image_registry.json" \
  --base-image-registry "$JOB/reference/registries/image_registry.json" \
  --runtime-registry-receipt "$JOB/02_runtime_images/seed_receipt.json" \
  --visuals "$JOB/06_visual/E3_${BRAND_LABEL}_${JOB_ID}_visual_argument_manifest.json" \
  --base-package-root "$JOB/reference" \
  --job-package-root "$JOB" \
  --regression-audit "$JOB/09_delivery/E6_${JOB_ID}_regression_audit.json" \
  --e4-quality "$JOB/07_editorial/E4_${JOB_ID}_quality_report.json" \
  --output-dir "$JOB/09_delivery/delivery" \
  --title-selection "$JOB/09_delivery/E6_${JOB_ID}_title_selection.json" \
  --title-review "$JOB/07_editorial/E4_${JOB_ID}_title_review.json" \
  --pattern-registry "$JOB/reference/shared/content-pattern-registry.json" \
  --evidence "$JOB/05_evidence/E2.5_${JOB_ID}_evidence_preflight.json" \
  --evidence-semantic-review "$JOB/05_evidence/E2.5_${JOB_ID}_semantic_review.json" \
  --claims "$JOB/02_runtime_evidence/claim_registry.json" \
  --sources "$JOB/02_runtime_evidence/source_registry.json"
```

最终客户交付目录至少包含 `final.docx`、`final.html`、`structured_data.json` 与 `delivery_manifest.json`。阶段回执、原始双表、Reference Pack 和内部证据文件留在 job 审计目录，不放入客户公开交付目录。

## 5. 重跑与版本规则

| 变化 | 必须回到 | 不得做 |
|---|---|---|
| 企业事实、正式来源、Logo/长期图库变化 | R0，并重新 S4/S6/S7/S8/S10/S0 | 改写已批准 Pack |
| 当前问题增加临时网页、访谈、测试或价格记录 | B5 runtime evidence | 向签名 claim/source registry 追加 |
| 当前文章补充或生成图片 | B5 runtime image + E3 | 向签名 image registry 追加 |
| 题面、地区、受众或时间范围变化 | 新建 Content Job，从 E0.5 重跑 | 沿用旧 monitoring/blueprint 回执 |
| 正文改动 | E2 起重跑相关证据、视觉、编辑门 | 只改 DOCX 或 HTML |
| E5 候选改变事实关系 | 回退 E4 | 手工放宽回归报告 |

## 6. 发布前自检

```bash
cd "$WF"
python3 -B scripts/validate_workflow.py
python3 -B shared/scripts/check_cross_references.py .
python3 -B shared/scripts/validate_package.py shared/fixtures/minimal_reference_pack
```

此外应确认：无 `__pycache__`/`.pyc`/`.DS_Store`、无本机绝对路径或客户测试数据、S1 与原始版本一致、最终 ZIP 解包后仍能通过同一组验证。
