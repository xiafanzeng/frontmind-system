---
name: frontmind-reference-material-adapter
description: 将必需的 canonical knowledge base v4 与可选 S1 补充、客户图库统一成可追溯的 knowledge/source/claim/image registries。用于任何内容策略分析前；保留上游 evidenceStatus、contentStatus 与 evidence_precision，并隔离低证据或权利不明材料。
---

# R0 资料标准化适配器

## 作用

R0 是所有后续内容阶段的唯一资料入口。它不改写 S1、不“增强”事实，也不把品牌自述升级为客观结论；只负责格式兼容、稳定 ID、去重、状态保留、证据精度与图片权利边界。

正式输入始终是通过验证的 canonical KB v4。S1 不被修改，也不是 R0 的必经阶段：它只是包外的可选上游资料整理工具。若项目只有散乱企业资料，必须先运行 S1，再通过既有知识库构建器生成并验证包含 manifest、source index 与 knowledge tree 的 canonical KB，之后才能进入 R0。R0 不接受 S1-only 输入，也不伪造 canonical KB。

## 输入

正式构包输入必须是 canonical knowledge base v4 ZIP，标准为 `schemaVersion=4`、`profile=dashboard-enterprise-v1`。R0 仍允许已解压目录用于本地诊断，但目录模式不能直接进入 S0：正式构包必须用与 R0 `input_fingerprints.kb` 完全一致的原始 ZIP 重跑 R0，才能形成可审批、可复验的字节级链路。

建议：

- S1 品牌事实图谱、视觉资产清单与 `visual_assets/`（仅作补充资料）；
- 客户另行上传的品牌图库。

documents、assets 与 evidence documents 的数量不是固定门槛，必须逐包以 manifest 为准。旧 flat/legacy 包只能降级隔离，不能假装兼容 v4。

## 执行

先读 `references/registry-contract.md`，再运行：

```bash
python3 scripts/kb_v4_adapter.py \
  --brand "品牌名" \
  --kb "/path/to/canonical-kb-v4.zip" \
  --s1-facts "/path/to/S1_品牌事实图谱.json" \
  --s1-visual-manifest "/path/to/S1_视觉资产清单.json" \
  --s1-assets-root "/path/to/visual_assets" \
  --gallery "/path/to/client-gallery" \
  --output-dir "/path/to/project/R0"
```

参数 `--s1-facts`、`--s1-visual-manifest` 与 `--gallery` 都是可选补充。canonical KB 通过时，不得因缺少 S1 而阻断。默认 `--legacy-policy quarantine`：没有正确 v4 manifest 的文档会进入隔离 knowledge items，所有相关 claims 标记 `do_not_use`。

## 输出

- `R0_{brand_label}_knowledge_registry.json`
- `R0_{brand_label}_source_registry.json`
- `R0_{brand_label}_claim_registry.json`
- `R0_{brand_label}_image_registry.json`
- `R0_{brand_label}_adapter_report.json`
- `assets/`：经哈希核验并复制的可携带图片；不复制仅有 URL 的资产。

`brand_label` 由脚本对正式品牌名执行稳定文件名正规化后生成，只用于路径；正文与事实对象仍保存正式品牌名。正式链路应在后续阶段持续复用 R0 实际输出文件名中的同一标签。

## 强制规则

1. v4 manifest 的 `evidenceStatus`、`contentStatus` 以 snake_case 原值保存在 claim；不得因 `verified_first_party` 自动变成可客观断言。
2. 每个 claim 必须使用根契约的 `evidence_precision`：`exact/claim/branch/document/source/none/unknown` 之一；上游 `section` 降级映射为 `document`。
3. `contentStatus=limited_evidence` 默认 `verification_status=verified_with_limits`、`allowed_usage=public_with_qualification`；只有 exact/claim 级支持才可 `public_fact`。
4. S1 `ai_inference`、低置信度或无证据事实不得公开断言。
5. 图片只使用根契约 `rights_status=approved/approved_with_credit/restricted_not_allowed/unknown`；客户明确提供且文件哈希通过可为 `approved`，网页抓取或权利未知默认 `unknown`，禁止私自升级。`approved_with_credit` 必须保留 `attribution_text`，不得在下游丢失署名条件。
6. 图片必须写入显式 `asset_kind`。只有上游元数据明确为 Logo/品牌识别且 `allowed_roles` 含 `entity_proof` 的记录才可标为 `logo`；不得因为图片已授权或被 S7 引用就反推它是 Logo。
7. 同一二进制图片按 SHA-256 去重并保留 aliases，不能仅按文件名去重。
8. S1 supplemental 中被引用的事实文件必须以哈希化安全名称复制到 `sources/s1/`，Source Registry 不得留下悬空本机路径；绝对路径只能用于本轮读取，不能写入 alias、locator、warning 或 Reference Pack。
9. 任何不兼容、哈希不符、路径越界或缺失文件都写入 adapter report；严重问题返回非零退出码。

## 交接门

正式进入 S3/S4 前确认：

- 四个 registry 均符合包根 `shared/registries.schema.json`，ID 使用 `kn_/src_/clm_/img_`；
- canonical manifest 与所有资产哈希通过；
- claims 中不存在“无来源却 approved”的对象；
- images 中不存在“权利未知却 approved”的对象；
- adapter report 的 `fatal_errors` 为空。

后续阶段只引用 registry ID。需要看原文时，通过 `package_path`/`file_path` 回到材料，不复制一套失去来源的文本。
