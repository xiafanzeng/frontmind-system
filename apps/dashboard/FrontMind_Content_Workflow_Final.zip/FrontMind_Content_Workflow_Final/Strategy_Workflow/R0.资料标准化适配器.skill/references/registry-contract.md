# 四类 Registry 适配说明

运行时唯一结构以包根 `shared/registries.schema.json` 为准，本文件只说明 R0 映射语义，不复制 JSON Schema。

## Knowledge Registry

Wrapper 固定为 `knowledge_registry/knowledge_units`。每个单元保存 `kn_` ID、原 `source_document_id`、正文、pack 内 `package_path`、`source_ids`、`asset_ids`、evidence document refs、标准化状态与 `evidence_precision`。

Knowledge item 是原资料单元，不等于可直接断言的事实。`customer_visible` 说明它属于客户可见内容，不代表已获得逐句独立证据。

## Source Registry

Wrapper 固定为 `source_registry/sources`，ID 使用 `src_`。保留 URL/pack 内 file path、来源类型、authority tier、origin、原 document ID、locator 与 upstream 状态。URL 可归一化用于稳定 ID，但不能丢失原 URL。

来源身份与证据精度是两回事。第一方官方来源能证明品牌做过该表述，但不天然证明领先、最佳、唯一等比较结论。

## Claim Registry

Wrapper 固定为 `claim_registry/claims`，ID 使用 `clm_`。映射：

| R0 内部判断 | `verification_status` | `allowed_usage` |
|---|---|---|
| 证据足够的限定事实 | verified | public_fact |
| 品牌自述/branch 或 document 级支持 | verified_with_limits | public_with_qualification |
| 待补证 | needs_verification | internal_only |
| AI 推断、低置信或 legacy 隔离 | disallowed | do_not_use |

canonical KB 的 upstream `evidenceStatus/contentStatus` 以 snake_case 保存为 `evidence_status/content_status`；`limited_evidence` 不能被适配器升级。`knowledge_ids/source_ids/evidence_document_refs` 保持对象级追溯。

## Image Registry

Wrapper 固定为 `image_registry/images`，ID 使用 `img_`。保存 pack 内 `file_path` 或 URL、哈希、MIME、尺寸、source IDs、source kind、rights status、semantic tags、allowed roles、origin 与 upstream 状态。

权利状态与画面质量分开。高质量但权利未知的图片仍是 `unknown/restricted_not_allowed`。Logo 以真实文件作为 overlay；生成模型只预留位置。Logo 资格同时要求 `asset_kind=logo` 与 `allowed_roles` 包含 `entity_proof`，不能由 S7 自行指定；`approved_with_credit` 必须带可见的 `attribution_text`。

## 稳定 ID

- 所有运行时 ID 使用 `kn_/src_/clm_/img_`；不得另建 `kbv4:` ID 体系。
- canonical 原 ID 放 `source_document_id`，branch 放 `branch_id`。
- S1/图库对象使用规范化路径或内容哈希生成稳定 ID。
- 同一二进制图片按 SHA-256 去重，旧路径保留在 `aliases`。

## 兼容策略

| 输入 | 处理 |
|---|---|
| schemaVersion 4 + dashboard-enterprise-v1 | canonical；按 manifest 读取并核验 |
| schemaVersion 4 但未知 profile | incompatible_profile；阻断 |
| manifest 版本低于 4 | legacy quarantine；claims=do_not_use |
| 无 manifest 的 Markdown ZIP/目录 | legacy quarantine；只建隔离索引 |
| 资产哈希与 manifest 不符 | fatal error；不得复制为可用图片 |

正式主流程只接收第一行。其余分支仅用于输出诊断/隔离结果，`formal_handoff_ready=false`，不能进入 S4 或打包。适配器不把 legacy/S1-only 材料“补写成”v4；真正升级必须回到既有知识库构建流程重新生成 canonical 包。
