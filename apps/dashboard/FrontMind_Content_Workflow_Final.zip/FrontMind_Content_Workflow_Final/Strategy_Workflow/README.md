# FrontMind 内容策略工作流

这套策略层只为已确定问题的专业文章生产准备可复用的 `Reference Pack`。它不承担选题发现、AI 可见度监测、CMS 发布、业务行动规划、完整文章写作或运维。

从 canonical KB ZIP 到 S10 审批与 S0 打包的完整可复制命令，以包根 [运行手册](../RUNBOOK.md) 为准；本页解释职责边界，不另建第二套参数契约。

## 唯一主流程

`S0 → R0 → S3（可选）→ S4 → S6 → S7 → S8 → S10`

| 阶段 | 作用 | 进入 Reference Pack 的主要对象 |
|---|---|---|
| S0 | 编排、断点续作、打包 | 运行状态、文件清单、版本与哈希 |
| R0 | 统一 canonical KB、可选 S1 补充与图库 | knowledge/source/claim/image registries |
| S3 | 补充有来源的新鲜趋势；可跳过 | trend references；跳过原因 |
| S4 | 把事实、受众决策与证据组织成文章可用架构 | message architecture、proof bundles、claim policy |
| S6 | 把品牌话语变成逐句可执行约束 | voice contract、evidence phrase rules |
| S7 | 把真实资产与图库变成文章视觉规则 | asset usage policy、visual patterns |
| S8 | 建立 30–50 个有来源的问题与 FAQ 参考 | question library、answer boundaries |
| S10 | 由负责人确认边界并批准 Reference Pack | approval receipt、修改项、未决风险 |

S2、S5、S5.5、S9 不再是活跃节点。原 S2 中真正服务文章的用户决策方法并入 S4，问题发现方法并入 S8；原 S5/S5.5 的证据边界与语义完整性原则并入 R0/S4/S8；原 S9 的完整性、可追溯性与风险门槛并入 S0/S10。

## 公共契约

- 内容模式与四个入口的唯一注册表：包根 `shared/content-pattern-registry.json`
- 使用说明：包根 `shared/content-pattern-guide.md`
- 策略层只能引用 `pattern_id` 与入口 ID，不得在本层复制 P01–P15 或四入口枚举。
- 合法 canonical KB v4 是正式主流程的必需输入，不得再强制用户提供 S1。只有散乱原始资料时，可在主流程外先运行原样 S1，再经既有知识库构建器生成/验证 canonical KB；S1 产物只作为只读补充源，不能直接替代 KB。
- `S3` 是唯一可选节点；缺失趋势不能阻断文章生产。
- `S10` 未批准前，执行层不得消费 Reference Pack。

## 标准交付目录

```text
{brand_label}/
  S1/                 # 可选 supplemental；不属于正式运行序列
  R0/
  S3/                  # 可缺失
  S4/
  S6/
  S7/
  S8/
  S10/
  ReferencePack/
```

Reference Pack 是可追溯引用包，不是把所有阶段报告拼成一份长文。执行层应按 ID 读取注册表对象，并在文章 brief、正文、FAQ 与视觉说明中回写被消费的 `source_id`、`claim_id`、`asset_id`、`question_id` 与 `pattern_id`。
