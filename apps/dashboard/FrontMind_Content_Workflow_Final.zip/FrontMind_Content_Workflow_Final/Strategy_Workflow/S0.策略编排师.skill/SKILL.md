---
name: frontmind-content-strategy-orchestrator
description: 编排 FrontMind 内部 GEO 内容策略层，将必需的 canonical KB v4、可选 S1 补充与图库转成经审批的自包含 Reference Pack ZIP。用于开始、续作、检查或打包已确定问题的内容生产资料；运行 S0→R0→S3（可选）→S4→S6→S7→S8→S10，不处理选题、监测、发布或运维。
---

# S0 内容策略编排师

## 唯一目标

让执行层针对已确定问题得到一份能直接提升文章质量、可追溯且已审批的 Reference Pack。阶段报告不是终点；未被后续文章引用的分析不应生产。

## 开始前

1. 读取本文件与 `references/strategy-orchestration-rules.md`。
2. 确认项目目录、品牌名、通过验证的 canonical KB v4 **原始 ZIP** 与可选图库；目录模式只用于 R0 本地诊断，不是正式 S0 输入。
3. 读取包根 `shared/content-pattern-registry.json` 和 `shared/content-pattern-guide.md`。只传递 `pattern_id`/入口 ID，不复制其中枚举。
4. 运行 `scripts/state_detector.py --work-dir <项目目录> --kb <canonical KB>`，先复用已通过的阶段。

## 固定顺序

```text
R0 → S3? → S4 → S6 → S7 → S8 → S10 → Reference Pack ZIP
```

- S1：不在正式运行序列内，也绝不修改。只有散乱原始资料时可先用 S1 整理，随后必须经既有知识库构建器生成/验证 canonical KB，再启动本流程；其输出只可作 supplemental。
- R0：先标准化所有资料并建立四类 registry，后续阶段只通过稳定 ID 引用。
- S3：可选。只有“新鲜趋势会实质改变当前文章的论证、段落或刷新时间”时运行；无可靠信号或用户跳过均不阻断。
- S4：建立文章可用的信息、受众决策与证据架构，并输出根 schema 兼容的 canonical brand facts。
- S6：建立可注入写作任务的话语契约。
- S7：建立文章视觉参考、资产权利与用法规则。
- S8：建立 30–50 个有来源的问题与 FAQ 回答边界，不写完整答案。
- S10：由负责人确认事实、证据、话语、问题与视觉边界，输出审批记录。

S2/S5/S5.5/S9 不得路由或要求输出。AI 监测表、信源排名、语义资产评分、业务行动菜单、CMS、发布与回滚均不属于本工作流。

## 阶段交接门

每次交接必须检查：

1. **输入真实消费**：输出对象必须列出上游 registry ID；仅写“参考了知识库/S1”不算消费。
2. **证据边界**：未经支持的品牌自述只能标为 `public_with_qualification`；禁止变成无条件客观事实。
3. **资产边界**：无权利状态或来源的图片只能 `reference_only`，不得直接用于成品。
4. **模式唯一源**：问题与文章模式只能引用包根共享 registry。
5. **未决项显式化**：不得用空字符串掩盖缺口，使用根契约的 `needs_verification/internal_only/unknown`，required brand facts 缺失则阻断。

完整阶段契约见 `references/strategy-orchestration-rules.md`。

## S3 运行判定

满足任一条件才运行：

- 内容涉及近 12 个月发生变化的政策、技术、数据或用户行为；
- 需要用近期第三方事实证明“为什么现在”；
- 当前文章是否采用某个观点、放在哪一段或何时刷新，依赖外部变化。

若运行后没有通过来源门槛的信号，在 S3 标准产物中写 `status=skipped_no_reliable_signal`；若从未运行，Reference Pack 以 `trend_viewpoints_path=null` 明确记录。两者均继续 S4，不得为了凑数制造趋势。

## S10 暂停点

只在 S10 暂停一次，请负责人确认：

- 哪些声明可公开、需归因、待补证或禁用；
- 核心受众与决策标准；
- 文章话语和竞品比较边界；
- 问题覆盖是否正确；
- 哪些视觉资产可直接使用以及权利限制；
- 未决风险能否接受。

审批状态只能是 `approved` 或 `changes_requested`。只有逐项无修改、无附带条件、六项确认全部通过的 `approved` 才可打包。

## 打包

```bash
python3 -B scripts/pack_builder.py \
  --brand "品牌名" \
  --work-dir "/path/to/project" \
  --kb "/path/to/canonical-kb-v4.zip" \
  --pattern-registry "/path/to/package/shared/content-pattern-registry.json" \
  --output "/path/to/project/ReferencePack/S0_brand_label_reference_pack_v1.zip"
```

质量门：

- canonical KB v4、R0 四 registry、S4 architecture + canonical brand facts、S6、S7、S8、S10 审批记录全部存在；S1 仅为可选 supplemental；
- S3 可缺失，缺失时 `trend_viewpoints_path=null`；
- R0/S4/S6/S7/S8 先通过各自的 JSON Schema 与语义 validator；空壳 JSON 不得因文件存在而进入 Pack；
- S10 必须为无附带条件、无未决风险、六项确认全部为真且对象审核全为 `keep` 的 `approved`；
- S10 `input_files` 的角色、文件名、字节数与 SHA-256 必须与本次实际打包输入逐项一致，原确认工作簿也必须存在且哈希一致；
- 每个文件都有 SHA-256，清单不是“每阶段第一个文件”的抽样；
- pack 在 staging 根生成唯一 `reference_pack.json`，安全解包 canonical KB、复制原 KB ZIP/全部必要资产并写逐文件哈希；
- `--kb` 字节哈希必须与 R0 adapter report 的 `input_fingerprints.kb` 完全一致；S1 supplemental 的本地证据文件按 Source Registry 路径一并携带，不能产生悬空来源；
- staging 与 ZIP 都通过包根 `shared/scripts/validate_package.py`。

## 最终输出

- `S0_{brand_label}_reference_pack_v{version}.zip`（`brand_label` 为安全文件标签；根入口唯一为 `reference_pack.json`）
- 一行交接摘要：版本、审批状态、ZIP 哈希、文件数、四类 registry 数量、S3 状态。

不要生成全景报告或合并 PDF；Reference Pack 的价值是机器可读、逐对象可追溯与可复用。
