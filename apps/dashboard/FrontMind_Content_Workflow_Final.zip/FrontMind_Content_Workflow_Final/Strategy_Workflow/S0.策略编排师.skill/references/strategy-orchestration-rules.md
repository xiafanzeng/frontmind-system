# Reference Pack 编排契约

运行时结构只以包根 `shared/reference_pack.schema.json`、`shared/registries.schema.json`、`shared/brand_facts.schema.json` 与 `shared/scripts/validate_package.py` 为准。

## 1. 输入路由

```text
合法 canonical KB v4 → R0
散乱企业原始资料 → 原样 S1（包外可选工具）→ 既有 KB builder → 验证 canonical KB v4 → R0
```

canonical KB v4 是主流程的硬输入。S1 不属于正式运行序列，也不能单独进入 R0；若提供，只作为 supplemental，不能覆盖 KB manifest 的状态。

## 2. 输入输出矩阵

| 阶段 | 必须读取 | 可以读取 | 必须输出 | 失败时 |
|---|---|---|---|---|
| R0 | canonical KB v4 | S1、客户图库 | root-schema knowledge/source/claim/image registries + adapter report | 阻断 |
| S3 | knowledge/source registries + 已定问题 | 时效性外部来源 | trend references 或 skip status | 非阻断 |
| S4 | 四 registry，S3 若有 | S1 supplemental | architecture + root-schema canonical brand facts | 阻断 |
| S6 | S4、claim/source registries | 原品牌语言 | article voice contract | 阻断 |
| S7 | image registry、S4、S6 | 图库 | visual reference system | 阻断 |
| S8 | S4/S6/S7、四 registry | S3、共享 pattern registry | 30–50 questions + FAQ boundaries | 阻断 |
| S10 | R0、S4/S6/S7/S8 | S3、S1 supplemental | strict approval receipt | 暂停或回退 |

## 3. 对象级消费

下游通过根 ID 证明消费：`kn_/src_/clm_/img_`、S4 proof/context IDs、S8 question IDs 与共享 pattern IDs。文件名或“综合多个阶段”不算引用。

## 4. 证据状态

- `public_fact`：在 scope/as_of 内可客观陈述；
- `public_with_qualification`：必须保留归因与限定；
- `internal_only`：只进入缺口/待核验，不进入成品；
- `do_not_use`：任何文章字段都不得使用。

`verified_first_party` 只说明来源身份；`contentStatus=limited_evidence` 默认映射为 `verified_with_limits + public_with_qualification`。证据精度使用根 registry 枚举。

## 5. 图片状态

只有 image registry 中 `rights_status=approved/approved_with_credit` 且本地文件哈希通过的图片可进入成品；`unknown/restricted_not_allowed` 不得直接使用。Logo 只使用真实文件 overlay。

## 6. S10 与回退

最终状态仅 `approved/changes_requested`。任何 change/block、附带条件、未决事实或权利风险都必须 changes_requested：事实→S1/R0/S4；表达→S6；视觉→S7；问题→S8。

## 7. 自包含打包

S0 staging 至少包括：

```text
reference_pack.json
sources/original_kb.zip
sources/knowledge_base/...
brand/brand_facts.json
registries/{knowledge,source,claim,image}_registry.json
writing/{information_evidence,voice_contract,visual_reference,question_library}.json
approval/approval.json
approval/confirmation_workbook.xlsx
assets/...
shared/content-pattern-registry.json
```

打包前逐个执行 R0/S4/S6/S7/S8 的结构与语义门，再校验 S10 六项确认、零附带条件、零未决风险、全对象 `keep` 以及审批时输入指纹与当前文件完全一致。所有路径为 pack-relative；禁止绝对路径、`..`、反斜杠、ZIP duplicate path、zip-slip 与哈希不符。`files[]` 记录 staging 中除自引用入口外的每个文件。先验证目录，再打 ZIP，再验证 ZIP；任一步失败不交付。
