#!/usr/bin/env python3
"""Detect resumable state for the canonical-KB strategy workflow."""

from __future__ import annotations

import argparse
import json
import zipfile
from pathlib import Path
from pathlib import PurePosixPath


ROLE_PATTERNS = {
    "s1_facts": ("**/S1_*品牌事实图谱.json", "**/S1_*brand_facts*.json"),
    "r0_report": ("**/R0_*adapter_report.json",),
    "r0_knowledge": ("**/R0_*knowledge_registry.json",),
    "r0_source": ("**/R0_*source_registry.json",),
    "r0_claim": ("**/R0_*claim_registry.json",),
    "r0_image": ("**/R0_*image_registry.json",),
    "s3": ("**/S3_*trend_reference*.json", "**/S3_status.json", "**/S3_*status.json"),
    "s4_architecture": ("**/S4_*information_evidence*.json", "**/S4_*信息与证据架构*.json"),
    "s4_brand_facts": ("**/S4_*brand_facts.json", "**/S4_*canonical_brand_facts*.json"),
    "s6": ("**/S6_*voice_contract*.json", "**/S6_*文章话语契约*.json"),
    "s7": ("**/S7_*visual_reference*.json", "**/S7_*视觉参考体系*.json"),
    "s8": ("**/S8_*question_library*.json", "**/S8_*问题与FAQ参考库*.json"),
    "s10": ("**/S10_*approval.json", "**/S10_*审批记录*.json"),
}

STAGES = [
    ("R0", ["r0_report", "r0_knowledge", "r0_source", "r0_claim", "r0_image"]),
    ("S3", ["s3"]),
    ("S4", ["s4_architecture", "s4_brand_facts"]),
    ("S6", ["s6"]),
    ("S7", ["s7"]),
    ("S8", ["s8"]),
    ("S10", ["s10"]),
]


def kb_manifest(path: Path) -> dict:
    if path.is_file() and zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as archive:
            names = [name for name in archive.namelist() if not name.endswith("/")]
            if len(names) != len(set(names)):
                raise ValueError("canonical KB ZIP contains duplicate paths")
            for name in names:
                pure = PurePosixPath(name)
                if pure.is_absolute() or ".." in pure.parts:
                    raise ValueError(f"unsafe canonical KB ZIP path: {name}")
            manifests = [name for name in names if name == "00_package_manifest.json" or name.endswith("/00_package_manifest.json")]
            if len(manifests) != 1:
                raise ValueError("canonical KB ZIP must contain exactly one 00_package_manifest.json")
            return json.loads(archive.read(manifests[0]))
    if path.is_dir():
        candidate = path / "00_package_manifest.json"
        if not candidate.is_file():
            raise ValueError("canonical KB directory lacks 00_package_manifest.json")
        return json.loads(candidate.read_text(encoding="utf-8"))
    raise ValueError("canonical KB must be a ZIP or directory")


def discover(root: Path, patterns: tuple[str, ...]) -> list[str]:
    files: set[Path] = set()
    for pattern in patterns:
        files.update(path.resolve() for path in root.glob(pattern) if path.is_file())
    return [str(path) for path in sorted(files)]


def main() -> None:
    parser = argparse.ArgumentParser(description="Detect FrontMind Reference Pack workflow state")
    parser.add_argument("--work-dir", required=True)
    parser.add_argument("--kb", required=True, help="Canonical KB v4 ZIP or directory")
    parser.add_argument("--json", action="store_true", dest="as_json")
    args = parser.parse_args()
    root = Path(args.work_dir).expanduser().resolve()
    if not root.is_dir():
        parser.error(f"work directory does not exist: {root}")
    kb_path = Path(args.kb).expanduser().resolve()
    try:
        manifest = kb_manifest(kb_path)
    except (OSError, ValueError, json.JSONDecodeError, zipfile.BadZipFile) as exc:
        parser.error(str(exc))
    if manifest.get("schemaVersion") != 4 or manifest.get("profile") != "dashboard-enterprise-v1":
        parser.error("input is not canonical KB v4 profile dashboard-enterprise-v1")

    role_files = {role: discover(root, patterns) for role, patterns in ROLE_PATTERNS.items()}
    rows = []
    next_stage = None
    for stage, roles in STAGES:
        required = stage != "S3"
        missing_roles = [role for role in roles if not role_files[role]]
        if not missing_roles:
            status = "complete"
        elif required:
            status = "missing"
        else:
            status = "optional_not_run"
        rows.append({"stage": stage, "required": required, "status": status, "missing_roles": missing_roles, "files": {role: role_files[role] for role in roles}})
        if required and missing_roles and next_stage is None:
            next_stage = stage
    payload = {
        "work_dir": str(root),
        "canonical_kb": str(kb_path),
        "canonical_kb_profile": manifest.get("profile"),
        "s1_supplemental_present": bool(role_files["s1_facts"]),
        "active_sequence": ["R0", "S3_optional", "S4", "S6", "S7", "S8", "S10"],
        "next_required_stage": next_stage,
        "ready_for_execution": next_stage is None,
        "stages": rows,
    }
    if args.as_json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        for row in rows:
            mark = "✓" if row["status"] == "complete" else ("○" if not row["required"] else "✗")
            print(f"{mark} {row['stage']}: {row['status']}")
            if row["missing_roles"]:
                print("  missing:", ", ".join(row["missing_roles"]))
        print("next:", next_stage or "execution layer")


if __name__ == "__main__":
    main()
