---
name: frontmind-reference-pack-approver
description: 对内容策略层的四类 registry、S4 信息证据架构、S6 话语、S7 视觉与 S8 问题库进行一次集中人审，并输出可机器读取的 Reference Pack 审批记录。用于执行层写文章前的唯一暂停点；不生成全景报告、业务行动计划或发布任务。
---

# S10 Reference Pack 确认师

## 目标

让品牌/项目负责人明确批准“文章可以用什么、怎样说、为谁写、回答哪些问题、可以用哪些图片”。S10 不把上游报告重新总结一遍；它检查对象级引用、显示高风险项、记录修改归属并形成审批凭证。

## 输入

- R0 adapter report 与四类 registry；
- S4 information/evidence architecture；
- S6 article voice contract；
- S7 visual reference system；
- S8 question library；
- S3 trend reference 或 skip status；
- S4 canonical brand facts；S1 原始事实底稿若存在仅作只读补充；
- 包根 `shared/content-pattern-registry.json`。

## 硬门槛

生成确认表前必须检查：

- R0 `fatal_errors=[]`；
- S4 每个核心 message 有 proof；
- S6 有四种证据状态的措辞规则；
- S7 直接使用资产都有可用权利状态，Logo 为真实文件 overlay；
- S8 有 30–50 问题，覆盖共享 registry 的七意图和四入口，每题有 provenance；
- 所有 `*_refs` 指向存在对象；
- S3 若存在，状态必须是 `completed/skipped_not_needed/skipped_no_reliable_signal`；未运行本身合法且不阻断。

任何硬门槛失败都回到责任阶段，不以“批准但稍后补”绕过。

## 生成确认工作簿

读 `references/confirmation_sheet_spec.md`，运行：

```bash
python3 scripts/reference_pack_confirmation_generator.py \
  --brand "品牌名" \
  --work-dir "/path/to/project" \
  --pattern-registry "/path/to/package/shared/content-pattern-registry.json" \
  --out "/path/to/project/S10/S10_品牌_ReferencePack确认表.xlsx"
```

工作簿只展示需要决定的内容：声明与证据、受众/话语、问题覆盖、视觉资产、未决风险和最终审批。每个对象保留 ID 与来源状态，避免修改后失去追溯。

## 负责人确认

负责人逐项选择 `keep/change/block`，填写修改要求，并在“审批决议”页确认：

1. 事实与声明边界；
2. 目标受众与决策标准；
3. 话语与竞品比较边界；
4. 七意图/四入口问题覆盖；
5. 图片权利与 Logo 规则；
6. 未决风险和附带条件。

最终状态：

- `approved`：无修改项、无附带条件、无未决阻断；
- `changes_requested`：任何 change/block、附带条件或未决项都必须回到责任阶段修改。

## 解析审批记录

```bash
python3 scripts/reference_pack_approval_parser.py \
  --confirmed S10_品牌_ReferencePack确认表.xlsx \
  --brand "品牌名" \
  --out S10_品牌_approval.json
```

解析器会拒绝“声称 approved 但仍有 change/block、必选确认项未勾选、来源指纹丢失”的工作簿。

## 输出与回退

- `S10_{brand_label}_ReferencePack确认表.xlsx`
- `S10_{brand_label}_approval.json`

回退归属：canonical KB/事实错误→R0/S4（若源头是散乱材料，可在包外回 S1 后重新构建 canonical KB）；证据或信息结构→S4；表达→S6；图片→S7；问题→S8。回退后重新生成确认表并保留上一版审批记录，不在 S10 直接改写上游源文件。

只有严格 `approved` 才交给 S0 打包。S10 不生成文章标题、正文、FAQ 答案、制作排期、PDF、CMS 任务或监测方案。
