---
name: frontmind-content-trend-reference
description: 可选地研究会实质改变当前文章论证、段落位置或刷新时间的品类趋势，并输出有来源的 trend references。用于涉及近期政策、技术、需求或文化变化的已确定问题；无可靠信号时明确跳过，不阻断 S4 或文章生产。
---

# S3 内容趋势参考

## 目标

只补充“当前文章为什么现在要采用某个观点、哪些事实刚发生变化”。不做宏大趋势报告，不发现新选题，不凑固定数量，不把热搜或单一媒体转述当事实。

## 输入

- R0 knowledge/source/claim registries；
- S1 品牌事实图谱（用于相关性判断，不用于反向证明趋势）；
- 包根 `shared/content-pattern-registry.json`；
- 明确的品类、地域与观察时间窗。

S4 尚未完成，因此这里不能替 S4 决定品牌定位。S3 只为已经确定的文章问题与论证提供外部时效参考。

## 是否运行

满足任一条件才运行：近期政策/标准变化、技术或产品能力发生可验证变化、用户需求/语言显著变化、文章必须回答“为什么现在”。否则输出：

```json
{"schema_version":"1.0.0","status":"skipped_not_needed","reason":"...","trends":[]}
```

无可靠来源时用 `skipped_no_reliable_signal`，继续 S4。

## 研究方法

1. 读 `references/trend-frameworks.md` 确定信号类型，读 `references/signal-source-list.md` 选择原始或权威来源。
2. 先写可证伪的候选句，再找来源；不要先搜“证明我们观点”的材料。
3. 记录发生时间、发布时间、观察地域与来源定位。
4. 一般趋势至少两个相互独立来源；法规、标准、论文原文等权威原始来源可单源，但必须标 `primary_authoritative`。
5. 把通过门槛的趋势连接到 `knowledge_ids`、已有问题资产中的 `related_question_refs`、共享 `pattern_refs`/入口 ID。只引用 ID，不复制共享枚举。
6. 说明当前文章是否采用、放在哪一段，以及何时必须刷新；也可影响标题时效性、论证背景或风险提醒，但不得借此扩展新选题。

## 输出

- `S3_{brand_label}_trend_reference.json`
- `S3_{brand_label}_内容趋势参考.md`（仅供人审，可由 JSON 渲染）

每个趋势至少包含：`trend_id`、statement、what_changed、observed_at、region、source_ids、evidence_precision、confidence、knowledge_ids、content_impact、freshness_rule、pattern_refs。`source_ids/knowledge_ids` 必须来自 R0，`pattern_refs` 必须来自包根共享 registry。

## 校验

```bash
python3 scripts/signal_aggregator.py \
  --validate S3_brand_label_trend_reference.json \
  --knowledge-registry R0_brand_label_knowledge_registry.json \
  --source-registry R0_brand_label_source_registry.json \
  --pattern-registry /path/to/package/shared/content-pattern-registry.json
```

不通过条件：来源不存在、普通趋势仅有一个转述来源、无日期/地域、没有说明内容影响、把相关性写成因果、引用未知 `pattern_id`。

S3 不能输出文章正文、完整 FAQ、固定 3/6/12 月日历或内容发布计划。
