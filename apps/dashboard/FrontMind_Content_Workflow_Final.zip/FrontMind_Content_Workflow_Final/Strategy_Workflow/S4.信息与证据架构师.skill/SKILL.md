---
name: frontmind-information-evidence-architect
description: 将品牌事实、知识单元、受众决策情境与可用证据组织成文章可直接消费的信息与证据架构。用于 R0 完成后、写作话语和问题库之前；输出定位锚点、信息支柱、proof bundles、声明/比较边界、四入口决策口吻与可选文体指引。
---

# S4 信息与证据架构师

## 目标

回答四件事：写给谁、在什么决策时刻写、可以明确说什么、每句话拿什么证明。S4 不做抽象品牌战略报告；每个输出对象都必须能进入文章 brief、正文论证或事实检查。

## 输入

必需：

- R0 knowledge/source/claim registries；
- S1 品牌事实图谱（可选 supplemental；正式输入仍以 canonical KB/R0 为准）；
- 包根 `shared/content-pattern-registry.json`。

可选：

- S3 trend references；缺失不阻断；
- 客户对目标市场、决策角色与禁区的明确说明。

先读：

- `references/audience-decision-context-method.md`：承接原 S2 的用户—场景—意图与决策标准；
- `references/positioning-frameworks.md`：保留四要素定位与价值证明方法；
- `references/competitive-analysis-method.md`：只保留文章真正需要的比较边界；
- `references/evidence-boundaries.md`：承接原 S5/S5.5 的证据与语义完整性原则。

## 工作步骤

### 1. 构建受众决策情境

以 `角色 × 触发事件 × 任务 × 约束 × 决策标准` 建立 3–8 个高价值 context。必须区分使用者、影响者、技术/合规把关者和最终决策者；不能只写人口画像。

每个 context 连接 `knowledge_ids/source_ids`，并说明哪些只是研究假设。问题句留给 S8，这里只定义决策信息需求。

### 2. 建立定位锚点

输出：目标受众、品类/使用情境、差异化价值、reasons to believe。每一项连接 claim/proof refs。若差异化没有比较证据，只能写为品牌选择或能力描述，不能写“领先/唯一/最佳”。

### 3. 建立信息架构

为文章准备 3–6 个 message pillars。每个 pillar 包含：

- 一句核心信息；
- 服务的 decision context；
- 可用 claim refs 与 proof bundle refs；
- 需要解释的实体/机制/属性；
- 适配的共享 `pattern_refs`；
- 禁止越界的表述。

模式只引用包根 registry 的 ID，不复制 P01–P15 或四入口枚举。

### 4. 组装 Proof Bundles

proof bundle 是写作者可直接调用的最小证据包：`claim_ids → source_ids/locator → evidence_precision → verification_status/allowed_usage → allowed wording → caveat`。第一方来源可证明“官方如此表述”，不能自动证明比较优越性；`limited_evidence` 内容默认 `public_with_qualification`。

### 5. 定义比较与声明边界

明确：可客观陈述、必须归因、待补证、禁止使用；竞品可比较维度、可用来源、时间截点和不得推断事项。不要输出 AI 可见度、引用排名或竞争占位评分。

### 6. 给执行层入口口吻与文体指引

对共享 registry 的四个 canonical category 分别写 `decision_tone`、`must_consume`、`proof_minimum`、`avoid` 与候选 `pattern_refs`。可另给 `publication_form_guidance`（如 objective article/news/technical）作为文体字段，但不能成为第三层运行时分类。这里不替 E1 选择最终模式；E1 按共享 registry 的 selection contract 每篇只选一个 `pattern_id`。

### 7. 同步生成 Canonical Brand Facts

无论 canonical KB 是否附带 S1 supplemental，S4 都必须同时生成 `S4_{brand_label}_brand_facts.json`，严格符合包根 `shared/brand_facts.schema.json`。它是 Reference Pack 的统一事实入口，不是对 S1 的修改。

- `brand_identity/positioning/offerings/capabilities/proof_points/limitations` 只能来自 R0 `src_/clm_` 对象；
- 每个 required `source_ids` 必须真实存在；proof point 的 `claim_ids` 必须真实存在；
- 没有材料时不能写“待确认/TBD”冒充事实；应先补充可靠资料或缩窄定位，再通过 S4；
- canonical KB 的 `limited_evidence` 内容只能作为带限定/归因的信息，不得在 brand facts 中升级为独立验证事实；
- S1 若存在只提供 supplemental 输入，冲突时保留两条来源和差异，不能覆盖 canonical KB。

## 输出

- `S4_{brand_label}_information_evidence.json`
- `S4_{brand_label}_brand_facts.json`（根 schema 的唯一兼容版本）
- `S4_{brand_label}_信息与证据架构.md`

JSON 结构见 `templates/information_evidence_architecture_schema.json`，人审格式见 `templates/information_evidence_architecture_template.md`。

## 校验

```bash
python3 scripts/information_evidence_validator.py \
  S4_brand_label_information_evidence.json \
  --brand-facts S4_brand_label_brand_facts.json \
  --knowledge-registry R0_brand_label_knowledge_registry.json \
  --claim-registry R0_brand_label_claim_registry.json \
  --source-registry R0_brand_label_source_registry.json \
  --pattern-registry /path/to/package/shared/content-pattern-registry.json
```

阻断条件：核心信息无 proof bundle；引用不存在的 claim/source/pattern；把 `public_with_qualification` 改为无条件客观事实；canonical brand facts 缺 required 字段或使用未知 src_/clm_；用户情境没有决策标准；比较结论无时点/来源；输出只是一句定位口号而无法进入文章。
