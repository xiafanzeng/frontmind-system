#!/usr/bin/env python3
"""Validate S4 object references, root evidence states, and brand facts."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any


PUBLIC_USAGES = {"public_fact", "public_with_qualification"}
ALLOWED_USAGES = PUBLIC_USAGES | {"internal_only", "do_not_use"}
VERIFICATION = {"verified", "verified_with_limits", "needs_verification", "disallowed"}
PRECISIONS = {"exact", "claim", "branch", "document", "source", "none", "unknown"}
LEGACY_KEYS = {"publishability", "claim_refs", "source_refs", "knowledge_refs"}
RETIRED_KEYS = {"visibility_score", "citation_share", "bsas_score", "business_action_plan"}
PLACEHOLDER = re.compile(r"^(?:tbd|todo|unknown|待确认|待补充|未知)(?:\b|[：:])", re.IGNORECASE)


def load(path: str) -> Any:
    with Path(path).expanduser().open("r", encoding="utf-8") as handle:
        return json.load(handle)


def scalar_ids(payload: Any, key_names: set[str]) -> set[str]:
    result: set[str] = set()
    if isinstance(payload, dict):
        for key, value in payload.items():
            if key in key_names and isinstance(value, str):
                result.add(value)
            result.update(scalar_ids(value, key_names))
    elif isinstance(payload, list):
        for value in payload:
            result.update(scalar_ids(value, key_names))
    return result


def list_values(payload: Any, key_name: str) -> set[str]:
    result: set[str] = set()
    if isinstance(payload, dict):
        for key, value in payload.items():
            if key == key_name and isinstance(value, list):
                result.update(str(item) for item in value if isinstance(item, str))
            result.update(list_values(value, key_name))
    elif isinstance(payload, list):
        for value in payload:
            result.update(list_values(value, key_name))
    return result


def find_keys(payload: Any, targets: set[str], path: str = "") -> list[str]:
    hits: list[str] = []
    if isinstance(payload, dict):
        for key, value in payload.items():
            child = f"{path}.{key}" if path else key
            if key in targets:
                hits.append(child)
            hits.extend(find_keys(value, targets, child))
    elif isinstance(payload, list):
        for index, value in enumerate(payload):
            hits.extend(find_keys(value, targets, f"{path}[{index}]"))
    return hits


def registry_ids(payload: Any, array_key: str, id_key: str) -> set[str]:
    if not isinstance(payload, dict) or not isinstance(payload.get(array_key), list):
        return set()
    return {
        str(item[id_key])
        for item in payload[array_key]
        if isinstance(item, dict) and isinstance(item.get(id_key), str)
    }


def pattern_contract(payload: Any) -> tuple[set[str], set[str]]:
    if not isinstance(payload, dict):
        return set(), set()
    patterns = {
        str(item["id"])
        for item in payload.get("patterns", [])
        if isinstance(item, dict) and isinstance(item.get("id"), str)
    }
    categories = {
        str(item["id"])
        for item in payload.get("canonical_question_categories", [])
        if isinstance(item, dict) and isinstance(item.get("id"), str)
    }
    return patterns, categories


def validate_architecture(
    payload: Any,
    known_claims: set[str] | None,
    known_sources: set[str] | None,
    known_knowledge: set[str] | None,
    known_patterns: set[str] | None,
    known_categories: set[str] | None,
) -> list[str]:
    errors: list[str] = []
    if not isinstance(payload, dict):
        return ["root must be an object"]
    required = [
        "positioning_anchor", "audience_decision_contexts", "message_pillars",
        "proof_bundles", "claim_policy", "comparison_boundary",
        "category_tone_guidance", "research_gaps",
    ]
    for key in required:
        if key not in payload:
            errors.append(f"missing top-level field: {key}")
    if payload.get("schema_version") != "1.0.0":
        errors.append("schema_version must be 1.0.0")

    legacy = find_keys(payload, LEGACY_KEYS)
    if legacy:
        errors.append(f"legacy reference/evidence fields are forbidden: {legacy}")
    retired = find_keys(payload, RETIRED_KEYS)
    if retired:
        errors.append(f"retired monitoring/scoring fields are forbidden: {retired}")

    anchor = payload.get("positioning_anchor") or {}
    for field in ("target_audience", "category_context", "differentiated_value", "reasons_to_believe"):
        if not anchor.get(field):
            errors.append(f"positioning_anchor.{field} is required")

    contexts = payload.get("audience_decision_contexts") or []
    if not contexts:
        errors.append("at least one audience decision context is required")
    context_ids: set[str] = set()
    for index, context in enumerate(contexts):
        label = f"audience_decision_contexts[{index}]"
        if not isinstance(context, dict):
            errors.append(f"{label} must be an object")
            continue
        context_id = str(context.get("context_id") or "")
        if not context_id or context_id in context_ids:
            errors.append(f"{label}.context_id must be non-empty and unique")
        context_ids.add(context_id)
        for field in ("role", "trigger", "job", "provenance_status"):
            if not context.get(field):
                errors.append(f"{label}.{field} is required")
        if len(context.get("decision_criteria") or []) < 2:
            errors.append(f"{label} needs at least two decision criteria")
        if context.get("provenance_status") not in {"validated", "client_asserted", "hypothesis"}:
            errors.append(f"{label}.provenance_status is invalid")
        if not (context.get("knowledge_ids") or context.get("source_ids")):
            errors.append(f"{label} must bind at least one knowledge_id or source_id")

    bundles = payload.get("proof_bundles") or []
    bundle_by_id: dict[str, dict[str, Any]] = {}
    for index, bundle in enumerate(bundles):
        label = f"proof_bundles[{index}]"
        if not isinstance(bundle, dict):
            errors.append(f"{label} must be an object")
            continue
        bundle_id = str(bundle.get("proof_id") or "")
        if not bundle_id or bundle_id in bundle_by_id:
            errors.append(f"{label}.proof_id must be non-empty and unique")
        bundle_by_id[bundle_id] = bundle
        claim_ids = bundle.get("claim_ids") or []
        source_ids = bundle.get("source_ids") or []
        verification = bundle.get("verification_status")
        usage = bundle.get("allowed_usage")
        precision = bundle.get("evidence_precision")
        if not claim_ids:
            errors.append(f"{label}.claim_ids must not be empty")
        if not source_ids:
            errors.append(f"{label}.source_ids must not be empty")
        if verification not in VERIFICATION:
            errors.append(f"{label}.verification_status is invalid")
        if usage not in ALLOWED_USAGES:
            errors.append(f"{label}.allowed_usage is invalid")
        if precision not in PRECISIONS:
            errors.append(f"{label}.evidence_precision is invalid")
        if usage == "public_fact" and (verification != "verified" or precision not in {"exact", "claim"}):
            errors.append(f"{label} public_fact requires verified exact/claim evidence")
        if usage == "public_with_qualification" and verification not in {"verified", "verified_with_limits"}:
            errors.append(f"{label} qualified public use requires verified evidence status")
        wording = str(bundle.get("allowed_wording") or "").strip()
        if usage in PUBLIC_USAGES and not wording:
            errors.append(f"{label}.allowed_wording is required for public use")
        if usage not in PUBLIC_USAGES and wording:
            errors.append(f"{label}.allowed_wording must be blank for non-public evidence")
        if usage == "public_with_qualification" and not str(bundle.get("caveat") or "").strip():
            errors.append(f"{label}.caveat is required for public_with_qualification")

    for index, pillar in enumerate(payload.get("message_pillars") or []):
        label = f"message_pillars[{index}]"
        if not isinstance(pillar, dict):
            errors.append(f"{label} must be an object")
            continue
        if not pillar.get("message"):
            errors.append(f"{label}.message is required")
        proof_refs = set(pillar.get("proof_refs") or [])
        if not proof_refs:
            errors.append(f"{label} must consume at least one proof bundle")
        unknown = proof_refs - set(bundle_by_id)
        if unknown:
            errors.append(f"{label} has unknown proof refs: {sorted(unknown)}")
        non_public = sorted(
            ref for ref in proof_refs
            if ref in bundle_by_id and bundle_by_id[ref].get("allowed_usage") not in PUBLIC_USAGES
        )
        if non_public:
            errors.append(f"{label} references non-public proof bundles: {non_public}")
        unknown_contexts = set(pillar.get("audience_context_refs") or []) - context_ids
        if unknown_contexts:
            errors.append(f"{label} has unknown audience context refs: {sorted(unknown_contexts)}")

    if known_claims is not None:
        unknown = list_values(payload, "claim_ids") - known_claims
        if unknown:
            errors.append(f"unknown claim IDs: {sorted(unknown)}")
    if known_sources is not None:
        unknown = list_values(payload, "source_ids") - known_sources
        if unknown:
            errors.append(f"unknown source IDs: {sorted(unknown)}")
    if known_knowledge is not None:
        unknown = list_values(payload, "knowledge_ids") - known_knowledge
        if unknown:
            errors.append(f"unknown knowledge IDs: {sorted(unknown)}")
    if known_patterns is not None:
        unknown = list_values(payload, "pattern_refs") - known_patterns
        if unknown:
            errors.append(f"unknown pattern refs: {sorted(unknown)}")
    guidance = payload.get("category_tone_guidance") or []
    used_categories = {
        str(item.get("canonical_category_ref"))
        for item in guidance if isinstance(item, dict) and item.get("canonical_category_ref")
    }
    if known_categories is not None and used_categories != known_categories:
        errors.append(
            "category_tone_guidance must cover each shared canonical category exactly once; "
            f"missing={sorted(known_categories - used_categories)}, unknown={sorted(used_categories - known_categories)}"
        )
    if len(used_categories) != len(guidance):
        errors.append("category_tone_guidance contains duplicate/blank canonical_category_ref")
    return errors


def validate_brand_facts(
    payload: Any,
    known_claims: set[str] | None,
    known_sources: set[str] | None,
) -> list[str]:
    errors: list[str] = []
    if not isinstance(payload, dict):
        return ["brand facts root must be an object"]
    required = {"brand_identity", "positioning", "offerings", "capabilities", "proof_points", "limitations"}
    missing = required - set(payload)
    if missing:
        errors.append(f"brand facts missing fields: {sorted(missing)}")
    if payload.get("schema_version") != "1.0.0":
        errors.append("brand facts schema_version must be 1.0.0")
    identity = payload.get("brand_identity") or {}
    positioning = payload.get("positioning") or {}
    if not identity.get("canonical_name") or not identity.get("source_ids"):
        errors.append("brand_identity needs canonical_name and source_ids")
    if not isinstance(identity.get("aliases"), list):
        errors.append("brand_identity.aliases must be an array")
    for field in ("category", "target_audiences", "value_proposition", "reasons_to_believe", "source_ids"):
        if not positioning.get(field):
            errors.append(f"positioning.{field} is required and cannot be a placeholder")

    arrays = {
        "offerings": ("offering_id", "off_", ("name", "offering_type", "definition", "fit", "limitations", "source_ids")),
        "capabilities": ("capability_id", "cap_", ("name", "description", "verification", "source_ids")),
        "proof_points": ("proof_id", "proof_", ("proof_type", "statement", "claim_ids", "source_ids")),
        "limitations": ("limitation_id", "lim_", ("statement", "applies_to", "source_ids")),
    }
    for array_name, (id_key, prefix, fields) in arrays.items():
        items = payload.get(array_name)
        if not isinstance(items, list):
            errors.append(f"brand facts {array_name} must be an array")
            continue
        seen: set[str] = set()
        for index, item in enumerate(items):
            label = f"brand facts {array_name}[{index}]"
            if not isinstance(item, dict):
                errors.append(f"{label} must be an object")
                continue
            identifier = str(item.get(id_key) or "")
            if not identifier.startswith(prefix) or identifier in seen:
                errors.append(f"{label}.{id_key} must be unique and start with {prefix}")
            seen.add(identifier)
            for field in fields:
                value = item.get(field)
                if field not in item or value is None or value == "":
                    errors.append(f"{label}.{field} is required")
            if not item.get("source_ids"):
                errors.append(f"{label}.source_ids must not be empty")
            if array_name == "proof_points" and not item.get("claim_ids"):
                errors.append(f"{label}.claim_ids must not be empty")

    for value in scalar_ids(payload, {"canonical_name", "category", "value_proposition", "name", "definition", "description", "statement"}):
        if PLACEHOLDER.search(value.strip()):
            errors.append(f"brand facts contains placeholder value: {value}")
    if known_sources is not None:
        unknown = list_values(payload, "source_ids") - known_sources
        if unknown:
            errors.append(f"brand facts has unknown source IDs: {sorted(unknown)}")
    if known_claims is not None:
        unknown = list_values(payload, "claim_ids") - known_claims
        if unknown:
            errors.append(f"brand facts has unknown claim IDs: {sorted(unknown)}")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate S4 information/evidence architecture and canonical brand facts")
    parser.add_argument("architecture_json")
    parser.add_argument("--brand-facts", required=True)
    parser.add_argument("--knowledge-registry")
    parser.add_argument("--claim-registry")
    parser.add_argument("--source-registry")
    parser.add_argument("--pattern-registry")
    args = parser.parse_args()

    known_claims = registry_ids(load(args.claim_registry), "claims", "claim_id") if args.claim_registry else None
    known_sources = registry_ids(load(args.source_registry), "sources", "source_id") if args.source_registry else None
    known_knowledge = registry_ids(load(args.knowledge_registry), "knowledge_units", "knowledge_id") if args.knowledge_registry else None
    known_patterns: set[str] | None = None
    known_categories: set[str] | None = None
    if args.pattern_registry:
        known_patterns, known_categories = pattern_contract(load(args.pattern_registry))

    errors = validate_architecture(
        load(args.architecture_json), known_claims, known_sources, known_knowledge,
        known_patterns, known_categories,
    )
    errors.extend(validate_brand_facts(load(args.brand_facts), known_claims, known_sources))
    print(json.dumps({"valid": not errors, "errors": errors}, ensure_ascii=False, indent=2))
    return 0 if not errors else 1


if __name__ == "__main__":
    sys.exit(main())
