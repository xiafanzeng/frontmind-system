# Canonical Brand Facts 映射清单

结构只以包根 `shared/brand_facts.schema.json` 为准。本清单帮助从 R0/S4 映射，不能替代根 schema。

| 根字段 | 主要来源 | 最低门槛 |
|---|---|---|
| brand_identity | R0 identity knowledge/claims | canonical name + 至少一个 src_ |
| positioning | S4 positioning anchor + R0 claims | category、受众、价值主张均有 src_ |
| offerings | R0 product knowledge/claims | 定义、适用、限制、src_ |
| capabilities | R0 capability claims | verification 说明 + src_ |
| proof_points | S4 proof bundles | proof_/clm_/src_ 均存在 |
| limitations | S4 claim/comparison boundary + R0 | 明确 applies_to + src_ |

不得使用 `TBD/待确认/unknown` 填满 schema。若 required 内容缺证据，S4 必须阻断并报告具体需要的资料。
