# {{brand}} 信息与证据架构

## 1. 使用边界

- 版本与日期：
- 主要输入哈希：
- S3 状态：已使用 / 未运行 / 无可靠信号
- 仍需客户确认：

## 2. 定位锚点

| 要素 | 内容 | Claim/Proof refs | 表达边界 |
|---|---|---|---|
| 目标受众 |  |  |  |
| 品类/使用情境 |  |  |  |
| 差异化价值 |  |  |  |
| Reasons to believe |  |  |  |

## 3. 受众决策情境

每个情境写：角色、触发、任务、约束、决策标准、资料来源与假设状态。

## 4. 信息支柱

每个支柱写：核心信息、服务情境、需要解释的实体/机制、proof bundle、共享 pattern refs、禁止越界表述。

## 5. Proof Bundles

| ID | Claim | 来源定位 | 证据精度 | 可用措辞 | 限制/时点 |
|---|---|---|---|---|---|

## 6. 比较边界

- 可比较维度：
- 必须使用的来源与时点：
- 禁止推断：

## 7. 四入口决策口吻

| Canonical category ref | Decision tone | Must consume | Proof minimum | Candidate pattern refs | Avoid |
|---|---|---|---|---|---|

可选补充 publication form（objective article/news/technical 等）的文体规则，但不建立新的运行时分类。

## 8. 缺口与未决项

只记录会影响文章正确性、可信度或决策价值的缺口。
