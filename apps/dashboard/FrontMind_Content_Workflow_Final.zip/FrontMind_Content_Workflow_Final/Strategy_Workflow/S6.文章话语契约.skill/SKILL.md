---
name: frontmind-article-voice-contract
description: 把品牌原始语言与 S4 信息证据架构转成可注入文章写作任务的话语契约。用于正文生产前统一术语、语气、句式、证据措辞、竞品比较、四入口决策口吻与可选文体差异；不凭空创造品牌口号或无证据卖点。
---

# S6 文章话语契约

## 目标

把“品牌调性”从形容词清单变成逐句可检查的写作规则：哪些词怎么用、何时必须归因、怎样讲复杂机制、怎样比较、什么绝不能说。最终输出应能直接注入 E2 的 system/task context。

## 输入

- S4 information/evidence architecture；
- R0 claim/source registries；
- R0 knowledge registry 中的原始品牌用语、官网文案、术语与口号；S1 若存在仅作补充；
- 包根 `shared/content-pattern-registry.json`（只引用 pattern ID）。

阅读 `references/verbal-identity-method.md`，保留其中语言考古、Tone of Voice、Messaging House 与证据砖方法，但必须按本契约的证据状态重新约束。

## 工作步骤

1. **语言考古**：从 knowledge registry 与可选 S1 补充中抽取品牌真实使用的术语、句式和语气；记录 `knowledge_id/source_id`。不要让模型自创一套“像该行业”的品牌话语。
2. **建立默认语气**：用可观察维度写规则，例如句长、主动/被动、专业解释密度、直接程度、情绪强度、第一/二人称。
3. **建立术语表**：首选词、允许变体、首次解释、禁用词与理由。禁用词按风险而非数量决定。
4. **把 S4 信息支柱变成 Messaging House**：每个 message 必须带 `proof_refs` 和允许措辞；不得把 `internal_only` 包装成卖点。
5. **建立证据措辞规则**：对 `public_fact`、`public_with_qualification`、`internal_only`、`do_not_use` 分别定义句型和禁止转换。
6. **建立比较规则**：允许点名竞品，但必须来自 S4 comparison boundary、同维度同时间且有来源；没有支持时只解释选择标准，不判胜负。
7. **建立四入口口吻覆盖**：按共享 canonical category 覆盖决策语气、解释深度、CTA 强度与 proof minimum；可选 publication form 只调节文体。共享 pattern 的结构仍以包根 registry 为准。

## 输出

- `S6_{brand_label}_voice_contract.json`
- `S6_{brand_label}_文章话语契约.md`

结构见 `templates/article_voice_contract_schema.json` 与 `templates/article_voice_contract_template.md`。

## 写作注入顺序

```text
事实与证据边界（S4/R0）
→ 默认 voice contract
→ canonical category tone override
→ optional publication form override
→ 单篇选中的 pattern_id 结构要求
→ 单篇 brief 的受众/问题/视觉约束
```

后层可以更具体，但不得放宽前层的证据和禁止声明。`system_prompt_fragment` 只汇总规则与 ID，不嵌入一批未经核验的新事实。

## 校验

```bash
python3 scripts/article_voice_contract_validator.py \
  S6_brand_label_voice_contract.json \
  --architecture S4_brand_label_information_evidence.json \
  --pattern-registry /path/to/package/shared/content-pattern-registry.json
```

阻断条件：核心话语无 proof ref；无归因规则；禁用词没有理由；竞品规则一律禁止点名或无条件允许点名；入口口吻规则复制/改写共享模式枚举；publication form 变成第三层运行时分类；契约只写“专业、可信、有温度”而不可执行。
