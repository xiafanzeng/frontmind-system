---
name: frontmind-article-visual-reference-system
description: 将 S1/R0 的真实品牌资产、客户图库与 S4/S6 的信息约束工程化为文章可消费的视觉参考体系。用于封面、正文解释图、数据图、案例图与品牌覆盖层规划；输出资产权利、稳定 ID、视觉槽位、prompt scaffold 和验证规则，不直接生成文章图片。
---

# S7 视觉参考体系

## “保留并工程化”是什么意思

保留是继续使用原流程中有价值的真实 Logo/配色/字体/企业实拍、三层视觉符号方法和各图像工具 prompt 语法。工程化是把它们从描述性报告变成可被每篇文章调用的结构化对象：稳定 `asset_id`、权利状态、允许用途、画面槽位、尺寸、构图规则、prompt 变量、负面约束与验收门。

## 输入

- R0 image registry（唯一 `img_` ID、文件哈希与权利状态源）；
- S1 视觉资产清单及物理文件（若有，仅作 R0 supplemental）；
- 客户图库（应已由 R0 纳入 image registry）；
- S4 message pillars/proof bundles；
- S6 article voice contract；
- 包根 `shared/content-pattern-registry.json`。

先读 `references/visual-symbol-system-method.md` 与 `references/ai-image-tool-prompt-syntax.md`。前者保留符号层次、颜色与构图方法，后者只作为工具语法参考；不得为了适配工具而牺牲品牌事实或图片权利。

## 工作步骤

### 1. 资产分诊

对每个候选资产写 `usage_mode`：

- `direct_use`：仅限 `rights_status=approved/approved_with_credit`；
- `overlay_only`：Logo、徽标、认证标识等真实文件；其中 Logo 必须在 R0 同时标记 `asset_kind=logo` 与 `allowed_roles` 含 `entity_proof`，不能由 S7 把普通已授权图片改称 Logo；
- `reference_only`：只提取构图/色彩/场景原则，不复制画面；
- `blocked`：不使用。

权利状态来自 R0，不在 S7 私自升级。分辨率或画质不足是另一项质量状态。
若状态为 `approved_with_credit`，S7 必须把 `attribution_text` 带入图注规则；无法显示署名时改为 `blocked`。

### 2. 建立品牌约束

记录主/辅色、字体回退、Logo 安全区、允许背景、摄影/插画倾向、人物和产品真实性、禁用风格。颜色应连接资产来源；没有 VI 时标 `inferred_reference`，不能称官方色。

### 3. 建立视觉语法

保留三层思想：

- 核心识别层：真实 Logo、色彩、品牌形状；
- 叙事符号层：反复出现的构图、隐喻和信息层次；
- 应用层：封面、解释图、流程图、比较图、案例图与图注。

符号数量由内容需要决定；每个 motif 必须说明承载的信息，不能只为装饰。

### 4. 建立文章视觉 Pattern

每个 `visual_pattern` 包含：适用 message/problem、关联共享 `pattern_refs`、封面与正文槽位、直接使用资产、可生成部分、prompt scaffold、negative constraints、alt/caption 规则和验收标准。

只引用共享 pattern ID；S7 自有的 `visual_pattern_id` 只用于视觉方案，不是另一套内容模式。

### 5. Logo 与真实照片

- 生成模型不得重绘 Logo、认证标识或产品界面文字；prompt 只预留干净位置，最后叠加真实资产。
- `logo_policy.generation_rule` 固定保存机器令牌 `never_generate_or_redraw_logo`，不接受可被反向解释的自然语言；`mode` 固定为 `overlay_real_asset`。
- `brand_constraints.logo_asset_refs` 只接受 R0 明确分类为 Logo 的真实资产；不得用客户上传的装饰图、案例图或一般品牌图片冒充。
- 客户图库可直接用时优先真实照片；需要 AI 延展必须记录具体授权与变更范围。
- `rights_status=unknown/restricted_not_allowed` 的资产不能进入成品像素；S7 只能把它标为 `reference_only/blocked`，且抽象参考不得复刻原画面。

## 输出

- `S7_{brand_label}_visual_reference.json`
- `S7_{brand_label}_视觉参考体系.md`

结构见 `templates/visual_reference_schema.json`。保留并改造的 `scripts/visual_consistency_helper.py` 只用于可选的色彩/一致性辅助检查，不能替代人工品牌、信息正确性或权利审核。

## 校验

```bash
python3 scripts/visual_reference_validator.py \
  S7_brand_label_visual_reference.json \
  --image-registry R0_brand_label_image_registry.json \
  --pattern-registry /path/to/package/shared/content-pattern-registry.json
```

阻断条件：直接使用权利不明资产；带署名资产缺少署名文本；资产 ID 不存在；Logo 不是 `asset_kind=logo + entity_proof`；Logo 进入生成 prompt 而非 overlay；视觉只讲风格不对应信息支柱；没有 alt/caption 规则；复制共享 pattern 枚举。
