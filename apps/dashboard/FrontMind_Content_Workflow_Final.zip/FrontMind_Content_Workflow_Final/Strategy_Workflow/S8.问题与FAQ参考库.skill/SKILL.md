---
name: frontmind-question-faq-reference-library
description: 基于 S4 决策情境、R0 证据、S6 话语和 S7 视觉参考建立 30–50 个有 provenance 的问题与 FAQ 参考。每题标共享七意图标签、四入口 category 和候选 pattern_id，只写回答边界与证据需求，不写完整答案、页面方案或制作排期。
---

# S8 问题与 FAQ 参考库

## 目标

把上游事实、受众决策标准、证据缺口与内容模式连接到用户真正会问的问题。产物只供已确定问题的 brief、正文问答块与 FAQ 规划复用；不是选题发现工具，也不是一批生成好的答案。

## 输入

- S4 audience decision contexts、decision criteria、message pillars、proof bundles；
- R0 knowledge/source/claim registries；
- S6 article voice contract；
- S7 visual reference system；
- S3 trend references（若有）；
- 包根 `shared/content-pattern-registry.json` 与 `shared/content-pattern-guide.md`。

共享 registry 是以下项目的唯一源：

- 七个 `question_intent_tags`；
- 四个 `canonical_question_categories`（内容入口）；
- `product_scenario_subintents`；
- P01–P15 与 routing。

S8 只保存 ID，不复制这些枚举或重写路由。

## FAQ 问题资产整理方法

先读 `references/faq-question-asset-method.md`、`references/question-path-framework.md` 与 `references/faq-answer-boundary-method.md`。这里的“整理”只围绕已确定的企业决策问题补齐可复用 FAQ 资产，不承担广域需求发现或文章选题。

1. 从每个 S4 decision context 的触发、任务、约束与决策标准生成问题种子。
2. 从 knowledge/source 中提取用户原话、客户访谈、站内搜索、搜索建议、社区讨论等可定位问题。
3. 从 proof bundles 反推“证据能回答什么”；从 research gaps 反推“目前不能可靠回答什么”。
4. 合并同一核心决策的同义问题；不要用品牌名替换、语序变化或地区词凑到 30 条。
5. 对每题标：一个 `primary_intent_tag`、可选 `secondary_intent_tags`、一个 `canonical_category_ref`、必要时 `product_scenario_subintent_ref`、候选 `pattern_refs`。
6. 每题标 provenance；研究者推导的问题必须写 `research_hypothesis`，不能假装真实搜索数据。

## 数量与覆盖

- 问题总数 30–50。
- 七个 intent tag 全覆盖；覆盖量按项目实际决策价值分配，不要求平均。
- 四个 canonical category 全覆盖；若某入口确实不适用，必须在 `coverage_exceptions` 给出客户确认的理由，S10 明确批准。
- 每个与当前企业决策问题直接相关的 S4 context 至少有问题；每个核心 proof bundle 至少被一个可回答问题消费或写明不使用原因。

每题使用 `faq_relevance=core/supporting/edge` 和 `relevance_reason` 表示它与已确定企业决策问题的关联度。它不是选题、排期或生产顺序，不能据此生成批量制作计划。

## FAQ 回答边界

对适合 FAQ 的问题只写：

- `answer_thesis`：一句短结论方向，不是完整答案；
- `must_cover`：必须解释的实体、步骤、条件或比较维度；
- `proof_refs`：必须使用的 proof bundles；
- `must_not_claim`：不能说什么；
- `freshness_rule`：何时必须重新核验；
- `visual_pattern_refs`：若解释需要图示。

禁止写标准答案段落、完整 FAQ 文案、FAQPage JSON-LD、页面蓝图或 3/6/12 月制作排期。这些属于后续单篇生产。

## 输出

- `S8_{brand_label}_question_library.json`
- `S8_{brand_label}_问题与FAQ参考库.md`

结构见 `templates/question_library_schema.json`。

## 校验

```bash
python3 scripts/question_library_validator.py \
  S8_brand_label_question_library.json \
  --pattern-registry /path/to/package/shared/content-pattern-registry.json \
  --knowledge-registry R0_brand_label_knowledge_registry.json \
  --source-registry R0_brand_label_source_registry.json \
  --claim-registry R0_brand_label_claim_registry.json \
  --architecture S4_brand_label_information_evidence.json
```

阻断条件：不足 30 或超过 50；七意图/四入口无说明缺失；provenance 为空；引用未知 source/claim/pattern；`answer_thesis` 写成长答案；出现日历/落地页/完整答案字段；问题与 S4 决策情境无连接。
