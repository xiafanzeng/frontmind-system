# FrontMind GEO 内容制作工作流验证报告

> 版本：`1.0.0-content-production`  
> 验证日期：2026-08-10  
> 结论：通过，可作为服务商内部“企业资料统筹 + 单问题文章制作”工作流使用。

## 1. 验证边界

本次验证覆盖从 canonical KB v4 ZIP、企业图片资产、Reference Pack 审批与打包，到单问题 Micro Tracking、Article Blueprint、同源正文、证据语义复核、视觉论证、编辑终审、AutoGEO 候选回归、DOCX/HTML 双格式交付的完整契约。

不把发布、CMS、渠道运营、效果监测、Analytics/CRM、收入归因或商业 SaaS 架构计入完成条件。

## 2. 确定性验证结果

| 验证项 | 结果 | 说明 |
|---|---|---|
| 全工作流静态检查 | PASS | 19 个活动 Skill、10 个 canonical contract；0 error、0 warning |
| 根 JSON Schema runtime | 7/7 PASS | 正反例、条件分支、格式、相对 `$ref`、循环与路径逃逸均覆盖 |
| Reference Pack 对抗测试 | 7/7 PASS | 空阶段、伪审批、装饰图冒充 Logo、生成图冒充证明、KB 换包、原创记录伪引用均被阻断 |
| 内容文本质量单测 | 3/3 PASS | 实质字符、主张绑定与日期表达回归 |
| 可见信源精确集合单测 | 4/4 PASS | 漏列、额外垫权威、隐藏原创来源、仅内部记录路径均被阻断 |
| 图片尺寸单测 | 4/4 PASS | PNG、显式 SVG 尺寸、SVG `viewBox` 回退、缺尺寸负例 |
| 相对引用检查 | PASS | 126 个活动文件，0 issue |
| 严格匿名 Reference Pack | PASS | 21 个文件，Schema、语义、审批对象、路径与 SHA-256 全部一致 |

复现命令见 [RUNBOOK.md](RUNBOOK.md) 第 6 节。

## 3. 本轮真实 canonical KB 适配验证

使用用户提供的 canonical KB v4 ZIP 进行了只读 R0 smoke test，结果为：

- 67 个 knowledge unit；
- 8 个 source；
- 52 个 claim；
- 2 个真实图片资产；
- 0 fatal error、0 warning；
- 52/52 claim 均具有实体锚点；
- Logo 与装饰图被区分登记，尺寸、文件 SHA-256、权利状态与允许角色有效。

该 smoke test 只验证输入兼容性和 Registry 归一化，没有伪造客户的 S10 审批、策略判断或公开授权。

## 4. 文章生产正向链验证

匿名夹具已完成 E0-A → E0.5 → E0-B → E1 → E2 → E2.5 → E3 → E4 → E5 → E6 正向回归，并覆盖两条终局路径：

1. AutoGEO 不可用时明确 skip，E6 选择 E4 `editorial_master`；
2. AutoGEO 候选确实修改正文时，语义回执和事实 diff 绑定本轮哈希，E6 仅在回归通过后选择 `optimized_candidate`。

两条路径均满足：

- DOCX 与 HTML 来自同一 approved Content Model；
- HTML 仅一个 H1、无正文表格、本地图片含 alt/width/height；
- DOCX 无表格、图片实际嵌入，标题使用 Title/Heading 1/Heading 2 语义样式；
- 中文字符完整保存在 OOXML，正文 run 带东亚字体槽与 `zh-CN`；
- JSON-LD 只输出可在可见正文定位的字段；
- delivery manifest 登记除自身外全部交付文件，文件集合与 SHA-256 完全一致；
- 非空旧交付目录、符号链接、绝对本机路径和未登记文件均被阻断。

SVG 输入采用确定性策略：安装可选 CairoSVG 时转为 PNG 后嵌入 DOCX；未安装时明确失败并给出补依赖/提供批准 PNG 衍生物的操作提示，不生成“看似成功但缺图”的 DOCX。

## 5. 关键对抗门

- Reference Pack ZIP 在提取前后双重验证，拒绝重复成员、路径逃逸、符号链接、压缩炸弹与哈希漂移。
- 已审批 Pack 全程只读；当前问题新增的网页、访谈、测试、价格记录和图片只进入 job-local append-only 层。
- 运行时网页证据必须有本地快照或记录文件及 SHA-256；URL 和自行声明的 `verified` 不能单独获得公开事实资格。
- 正文每个实质主张必须绑定语义相关 claim；无关 claim ID 不能为夸大主张“洗白”。
- 文末可见 references 必须与正文实际使用 claim 的 source 集合精确相等。
- 排名、对比、研究、案例及多对象价格等模式按契约执行原创信息与同维度公平门。
- Logo 只能使用已登记真实原件 overlay，不能生成、重绘，也不能充当能力、案例、数据或产品证明。
- E5 不允许覆盖 E4 正本，不运行全局词语替换 fallback；候选、diff、回执与最终模型均绑定哈希。

## 6. 保留项与环境说明

- 原工作流 S1 按用户要求逐字节保留；源目录与新工作流内 S1 的文件内容哈希集合均为 `bbdcec21fb7896cff4b621b0ac32e7d98588da06d6e4b5ebb952574f132ef16b`。S1 仅是可选上游整理工具，不是正式 Reference Pack 的直接输入。
- 因 S1 必须原样保留，其中历史 Schema 文档仍含原作者的示例企业名称；这不是本轮客户数据，也不进入正式运行链。若未来要求发行包全文零示例名称，需要另行授权修改 S1。
- 当前自动化 LibreOffice 预览环境无法访问系统中文字体；因此本报告不把该预览截图作为中文视觉通过证据。已验证 DOCX 的 OOXML 中文文本、东亚字体槽、语言、标题层级和图片关系完整；正式交付仍应在团队实际使用的 Word/Office 环境做一次视觉抽检。
- AutoGEO 是经单独审核的选装依赖；未安装不会伪装为已优化，而是走已验证的 E4 安全正本路径。

## 7. 发布结论

该版本已从“策略报告型旧流程”收敛为内容生产工作流：四类入口供工程师接单，P01–P15 只作为 E1 后台结构库；Reference Pack 负责长期资料统筹，job-local 层负责当前问题补证；Content Model 负责同源 DOCX/HTML；证据、视觉和编辑门负责最终质量。

最终 ZIP 的包外 SHA-256 在交付消息中提供，避免把 ZIP 自身哈希写入包内造成自引用。
