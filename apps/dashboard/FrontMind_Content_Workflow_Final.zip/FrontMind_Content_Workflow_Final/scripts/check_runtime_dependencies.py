#!/usr/bin/env python3
"""Fail-fast dependency preflight for the active content-production path."""

from __future__ import annotations

import argparse
import importlib
import json
import sys


CORE = {
    "openpyxl": "openpyxl",
    "Pillow": "PIL",
    "python-docx": "docx",
}
OPTIONAL = {
    "CairoSVG (SVG Logo overlay)": "cairosvg",
    "AutoGEO candidate optimization": "autogeo.rewriters",
}


def probe(module: str) -> dict[str, object]:
    try:
        importlib.import_module(module)
    except Exception as exc:  # import-time binary/configuration failures also mean unusable
        return {"available": False, "error": f"{type(exc).__name__}: {str(exc)[:240]}"}
    return {"available": True, "error": None}


def main() -> int:
    parser = argparse.ArgumentParser(description="Check FrontMind active runtime dependencies")
    parser.add_argument("--require-svg", action="store_true", help="Treat CairoSVG as required for this job")
    parser.add_argument("--require-autogeo", action="store_true", help="Treat AutoGEO as required instead of skippable")
    args = parser.parse_args()

    result = {
        "python": sys.version.split()[0],
        "python_supported": sys.version_info >= (3, 10),
        "core": {name: probe(module) for name, module in CORE.items()},
        "optional": {name: probe(module) for name, module in OPTIONAL.items()},
    }
    required_missing = [name for name, item in result["core"].items() if not item["available"]]
    if args.require_svg and not result["optional"]["CairoSVG (SVG Logo overlay)"]["available"]:
        required_missing.append("CairoSVG (SVG Logo overlay)")
    if args.require_autogeo and not result["optional"]["AutoGEO candidate optimization"]["available"]:
        required_missing.append("AutoGEO candidate optimization")
    if not result["python_supported"]:
        required_missing.append("Python>=3.10")
    result["status"] = "pass" if not required_missing else "fail"
    result["required_missing"] = required_missing
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if not required_missing else 1


if __name__ == "__main__":
    raise SystemExit(main())
