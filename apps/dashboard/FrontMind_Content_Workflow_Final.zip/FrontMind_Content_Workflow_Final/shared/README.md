# Global shared SSOT

本目录是策略层与执行层唯一共享事实源。两层 `shared/` 只保留渲染工具和兼容说明，不复制四类问题、P01-P15 或 JSON Schema。

## Canonical schemas

- `reference_pack.schema.json`：企业可复用写作资料包。
- `content_job.schema.json`：一个已确认问题的制作任务。
- `monitoring_input.schema.json`：该问题的 AI 回答与信源监控输入/分析。
- `registries.schema.json`：唯一 knowledge/source/claim/image registries，固定 wrappers 为 `knowledge_units`、`sources`、`claims`、`images`；图片显式记录 `asset_kind`，带署名许可时保留 `attribution_text`；生成解释图不得冒充实体/产品/案例/事件证据，生成数据图必须绑定 `source_ids`。
- `brand_facts.schema.json`：策略层与执行层共用的品牌事实结构。
- `article_blueprint.schema.json`：E1 单篇规划。
- `content_model.schema.json`：DOCX/HTML 共同语义正本。
- `quality_report.schema.json`：E4/E6 质量门。
- `delivery_manifest.schema.json`：最终交付物与同源证明。
- `runtime_evidence_extension.schema.json`：单篇任务在不改写签名 Pack 的前提下，追加当前问题专属 source/claim 与哈希证据文件。

## Canonical policies and registries

- `content-pattern-registry.json`：四类问题与 P01-P15 唯一机器注册表。
- `content-pattern-guide.md`：十五种结构的详细骨架与证据门槛。
- `writing-policy.md`：统一文风、证据、微型答案、FAQ 与编辑规则。
- `html-structured-data-policy.md`：HTML 与 JSON-LD 规则。
- `workflow-migration-map.md`：旧文件保留/替换和类型迁移，仅用于迁移审计。

## Validators and fixture

- `scripts/validate_json_instance.py`：仅使用 Python 标准库的 JSON Schema 运行时；支持本工作流实际使用的 Draft 2020-12 子集，并输出 JSON Pointer、可读 JSONPath 与 Schema 定位。
- `scripts/validate_package.py`：校验 Reference Pack 入口、profile、正式路径契约、原始 KB ZIP/R0 指纹、确认工作簿、完整对象审阅、全部活动 Schema/语义门、路径、哈希与 registries；同一规则同时用于目录、ZIP 和 E0，不信任仅由打包器生成的输入。
- `scripts/validate_content_model.py`：校验四入口持久化、微型答案字符数、5-8 节覆盖、FAQ 与标题候选，并报告忽略空白/标点后的有效字符数。
- `scripts/validate_workflow.py`：递归校验 active 工作流完整性。
- `scripts/test_validate_json_instance.py`：覆盖十个根 Schema 的典型正反例、全部可匹配 fixture、格式解析、组合关键字及安全 `$ref` 的回归测试。
- `scripts/test_validate_package.py`：覆盖严格目录/ZIP 正例、空阶段伪审批、审阅缩减、KB 拼接、装饰图伪 Logo、生成图 proof-role 与原创记录伪引用攻击。
- `fixtures/minimal_reference_pack/`：通过包校验器的严格匿名最小样例，包含 artifact-tool 生成并逐表渲染核验的 S10 工作簿，不含生产证据。

正式 Pack 必须显式声明 `knowledge_base.original_package_path`、`diagnostics.adapter_report_path`、`approval_evidence_path` 与 `content_pattern_registry_path`；校验器同时要求固定 canonical path、正确 `files[].role` 和 SHA-256，避免仅靠目录约定猜测关键资产。

Markdown 链接与 JSON Schema `$ref` 按其所在文件目录解析。机器产物中的 `file_path`/`*_path` 则严格按字段契约指定的根解析：签名 Pack 资产相对 Reference Pack 根，job-local 证据/图片相对 job 根；不得按 Registry 文件所在目录自行拼接。

### JSON Schema runtime 用法

命令行校验：

```bash
python3 -B scripts/validate_json_instance.py reference_pack.schema.json fixtures/minimal_reference_pack/reference_pack.json --report validation_report.json
```

退出码固定为：`0` 表示实例通过，`1` 表示实例不符合 Schema，`2` 表示 JSON、Schema、`$ref` 或报告写入发生运行错误。报告同时写到标准输出；每条错误包含 `instance_path`、`json_path`、`schema_path` 和 `schema_uri`。

读取 ZIP 内 JSON 时无需落临时实例文件，可直接导入：

```python
from validate_json_instance import load_json, validate_instance

schema_path = shared_dir / "reference_pack.schema.json"
schema = load_json(schema_path)
errors = validate_instance(instance_from_zip, schema, schema_path)
```

运行时只解析入口 Schema 所在目录内的本地相对 `$ref` 和 JSON Pointer；网络引用、绝对路径、目录越界与无限循环会被阻止。回归测试命令：

```bash
python3 -B scripts/test_validate_json_instance.py
python3 -B scripts/test_validate_package.py
python3 -B scripts/validate_package.py fixtures/minimal_reference_pack
```
