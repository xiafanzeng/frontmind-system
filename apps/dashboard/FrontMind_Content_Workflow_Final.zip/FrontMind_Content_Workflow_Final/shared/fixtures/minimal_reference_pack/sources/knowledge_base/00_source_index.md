# 来源索引

- source-fixture-official：匿名示例企业内部批准的测试资料，仅用于工作流自测。
