# HTML 与结构化数据政策

## 1. 同源渲染

HTML 和 DOCX 必须由同一个 `content_model.json` 渲染。渲染器只能改变呈现，不能改写正文、FAQ、引用、图片含义或结论。E6 在 delivery manifest 记录同一个 `content_model_sha256`。

## 2. HTML 结构

- 页面只设置一个 H1，且来自 `metadata.h1`。
- `title`、H1 和 Meta Description 表达同一个核心问题与结论范围。
- 正文最多三级：H1 -> H2 -> H3，不跳级。
- 每个 H2 是一个完整、自然的用户子问题；H3 只拆价格、功能、案例、限制等判断维度。
- 可见正文不使用表格。竞品、价格和规格使用平行小节或列表。
- 图片必须有与正文一致的 `alt`，事实性图片保留来源/权利记录；不把内部 asset_id 当可见替代文本。
- 参考来源名称与链接在正文或文末可见，不能只藏在 JSON-LD。

## 3. JSON-LD 选择

| 类型 | 使用条件 |
|---|---|
| `Article` | 所有完整文章；当前契约只输出可从页面逐项定位的 `headline`、`description`、`dateModified`、`inLanguage`。资料截止日期必须在正文可见；当前 Content Model 没有作者/发布者字段，因此不得臆造这两项 |
| `FAQPage` | 页面可见 5-8 个 FAQ，JSON-LD 问答逐字对应可见内容 |
| `ItemList` | P01 的可见正文存在完整候选列表，名称、顺序和项目数量逐项一致 |
| `HowTo` | P07 或具有真实连续步骤的 P10；每个步骤在页面可见并含动作 |
| `Product` | 正文围绕一个明确产品，名称、品牌、型号、版本等字段在正文可见 |
| `Review` | 存在真实第一手评测/体验、明确评价主体、方法与可复核结论；不能把公开资料汇编、案例叙事或企业宣传稿伪装为评测 |

不得为了覆盖更多 Schema 类型而添加正文没有的价格、评分、库存、评价、步骤、FAQ、作者资质或发布日期。

## 4. 一致性验证

E6 必须检查：

1. `title`、H1、Meta 与主问题一致；
2. H1 数量为 1，heading depth 不超过 3，层级不跳跃；
3. FAQ、HowTo、Product、Review 的结构化字段均能在可见正文逐项定位；
4. JSON-LD 中的实体名称、日期、价格、版本和结论绑定相同 claim/source；
5. HTML 文本与 DOCX 的语义块顺序、FAQ、引用和视觉位置一致。

任一不一致都必须回到 Content Model 修复并重新渲染，不允许只手工修改 HTML。
