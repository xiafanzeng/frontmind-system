#!/usr/bin/env python3
"""Regression tests for the stdlib-only JSON Schema runtime."""

from __future__ import annotations

import copy
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from validate_json_instance import (
    JsonSchemaValidator,
    ReferenceResolutionError,
    load_json,
    validate_instance,
)


SHARED = Path(__file__).resolve().parents[1]
FIXTURE = SHARED / "fixtures" / "minimal_reference_pack"
HASH = "a" * 64
STAMP = "2026-08-10T00:00:00+08:00"


def valid_content_job() -> dict:
    return {
        "schema_version": "1.0.0",
        "job_id": "job_schema_runtime_001",
        "pack_id": "rp_schema_runtime_001",
        "created_at": STAMP,
        "question": {
            "text": "示例企业是否适合目标用户？",
            "category": "reputation",
            "confirmed_outside_workflow": True,
            "target_region": "中国大陆",
            "target_audience": "正在评估示例服务的企业决策者",
            "time_scope": "截至2026-08-10",
        },
        "monitoring_input_path": "monitoring/micro_tracking.json",
        "optimizer_target": {"dataset": "fixture", "engine_llm": "fixture-model"},
        "deliverables": {"docx": True, "html": True},
        "editorial_profile": "third_party_objective_with_evidence_based_brand_promotion",
    }


def valid_monitoring() -> dict:
    return {
        "schema_version": "1.0.0",
        "job_id": "job_schema_runtime_001",
        "question": "示例企业是否适合目标用户？",
        "captured_at": STAMP,
        "analysis_status": "available",
        "input_files": {
            "answers_table_path": "inputs/answers.csv",
            "sources_table_path": "inputs/sources.csv",
            "answers_table_sha256": HASH,
            "sources_table_sha256": HASH,
        },
        "answers": [
            {
                "answer_id": "answer_1",
                "platform": "example-ai",
                "sampled_at": STAMP,
                "answer_text": "这是用于运行时测试的回答。",
                "citations": [{"citation_id": "citation_1", "url": "https://example.com/a"}],
            }
        ],
        "source_observations": [
            {
                "observation_id": "observation_1",
                "url": "https://example.com/a",
                "retrieval_status": "retrieved",
                "question_similarity": 0.9,
            }
        ],
        "derived": {
            "competitors": [],
            "excluded_observations": [],
            "answer_landscape": [
                {
                    "platform": "example-ai",
                    "answer_id": "answer_1",
                    "direct_answer": "测试回答直接回应了问题。",
                    "entities": ["示例企业"],
                    "stance": "neutral",
                    "dimensions": ["适合对象"],
                    "unanswered_subquestions": [],
                }
            ],
            "benchmark_observation_ids": ["observation_1"],
            "benchmark_pages": [
                {
                    "observation_id": "observation_1",
                    "similarity": 0.9,
                    "content_form": "分析文章",
                    "opening_answer_function": "直接回答",
                    "section_sequence": ["结论", "证据", "建议"],
                    "covered_subquestions": ["适合对象"],
                    "comparison_dimensions": [],
                    "evidence_placement": ["结论之后"],
                    "conditional_recommendation": "在满足条件时采用。",
                    "limitations_and_alternatives": ["不适合缺少数据的场景"],
                    "faq_topics": ["适合谁"],
                    "visual_argument_roles": ["explanation"],
                    "strengths": ["直接回答"],
                    "gaps": ["样本有限"],
                    "borrowable_abstract_patterns": ["先结论后证据"],
                    "non_borrowable_elements": ["原文措辞"],
                }
            ],
            "supplementary_primary_sources": [],
            "recurring_subquestions": ["适合谁"],
            "structure_findings": ["采用问题式小标题"],
            "warnings": [],
        },
    }


def valid_blueprint() -> dict:
    sections = []
    for index in range(1, 6):
        sections.append(
            {
                "section_id": f"sec_part_{index}",
                "h2_question": f"第{index}个必要判断是什么？",
                "answer_goal": "回答该子问题并形成可执行判断。",
                "section_conclusion": "本节先给出清晰且有限定条件的结论。",
                "evidence_strategy": "使用已登记来源与明确口径支持结论。",
                "reader_advice": "按自身条件核对。",
                "claim_ids": [],
                "suggested_length": 300,
            }
        )
    faqs = []
    for index in range(1, 6):
        faqs.append(
            {
                "question": f"第{index}个常见问题是什么？",
                "answer_plan": "直接回答问题，再说明证据、适用条件、限制和下一步核对方法。" + "答" * 20,
                "claim_ids": [],
                "intent_tag": "evaluation",
                "provenance": {"kind": "derived_from_primary_question", "reference_ids": []},
            }
        )
    return {
        "schema_version": "1.0.0",
        "job_id": "job_schema_runtime_001",
        "question_category": "reputation",
        "primary_question": "示例企业是否适合目标用户？",
        "scope": {
            "target_region": "中国大陆",
            "target_audience": "正在评估示例方案的企业决策者",
            "time_scope": "截至2026年8月",
        },
        "pattern_id": "P04",
        "routing_reason": "该问题要求解释定义、适用条件与判断边界，因此采用机制解释结构。",
        "question_contract": {
            "primary_question": "示例企业是否适合目标用户？",
            "primary_intent_tag": "evaluation",
            "secondary_intent_tags": ["risk"],
            "direct_decision": "读者需要判断该企业是否适合自己的具体使用条件。",
            "necessary_subquestions": [f"必要子问题{i}" for i in range(1, 6)],
            "misconceptions": [],
            "decision_concerns": ["证据是否适用于当前场景"],
            "objections": [],
            "alternatives": [],
            "evidence_needed": ["官方说明与适用边界"],
            "brand_intervention": {
                "entry_section_ids": ["sec_part_3"],
                "rationale": "只在证据能够支撑的判断位置引入品牌。",
                "supported_claim_ids": [],
                "non_promotional_boundary": "不得把未验证信息改写成确定性宣传结论。",
            },
        },
        "benchmark_fusion": {
            "status": "available",
            "monitoring_input_sha256": HASH,
            "benchmark_decisions": [
                {
                    "observation_id": "obs_1",
                    "disposition": "adopted",
                    "adopted_elements": ["先结论后证据"],
                    "rationale": "该抽象结构能缩短读者获得判断所需的路径。",
                }
            ],
            "structure_finding_indexes": [0],
            "retained_template_elements": ["问题式小标题"],
            "benchmark_elements_adopted": ["先结论后证据"],
            "elements_rejected": ["无来源断言"],
            "final_structure_rationale": "结构同时覆盖核心问题与五个必要子问题。",
        },
        "title_plan": {
            "title_formula": "年份＋对象＋决策问题",
            "title_candidates": [f"2026年示例企业适用性判断指南{i}" for i in range(1, 6)],
        },
        "lead_plan": {
            "direct_answer_sentence": "结" * 40,
            "micro_answer_plan": "先直接回答，再说明判断标准、证据、适合对象、时间范围和必要限制。" + "答" * 20,
            "claim_ids": ["clm_fixture_scope"],
            "required_elements": [
                "explicit_conclusion",
                "judgment_criteria",
                "fit_audience",
                "time_scope",
                "necessary_qualification",
            ],
        },
        "section_plan": sections,
        "claim_plan": [],
        "visual_plan": [],
        "faq_plan": faqs,
        "conclusion_plan": {
            "summary_decision": "总结已展开的适用性判断与限制条件。",
            "fit_audience": "符合前述条件的目标读者。",
            "next_action": "核对来源与条件。",
            "forbid_new_points": True,
            "claim_ids": ["clm_fixture_scope"],
        },
        "evidence_readiness": {
            "status": "ready_with_narrowed_claims",
            "missing_evidence": [],
            "original_information_status": "exempted",
            "original_information_claim_ids": [],
            "exemption_reason": "本篇只解释已登记事实，不声称原创测试或独家结论。",
        },
    }


def valid_content_model() -> dict:
    sections = []
    coverage = []
    for index in range(1, 6):
        section_id = f"sec_part_{index}"
        sections.append(
            {
                "section_id": section_id,
                "h2_question": f"第{index}个必要判断是什么？",
                "blocks": [
                    {
                        "block_id": f"blk_part_{index}",
                        "type": "paragraph",
                        "content_function": "advice",
                        "text": "先给结论，再给证据，最后给出适用建议。",
                        "claim_ids": [],
                    }
                ],
            }
        )
        coverage.append({"subquestion": f"必要子问题{index}", "section_ids": [section_id]})
    faq = [
        {
            "question": f"第{index}个常见问题是什么？",
            "answer": "这是一条包含判断条件、适用边界和核对方法的完整回答。",
            "content_function": "decision_advice",
            "claim_ids": [],
        }
        for index in range(1, 6)
    ]
    return {
        "schema_version": "1.0.0",
        "job_id": "job_schema_runtime_001",
        "revision": 1,
        "question_category": "reputation",
        "primary_question": "示例企业是否适合目标用户？",
        "pattern_id": "P04",
        "metadata": {
            "title": "2026年示例企业适用性判断指南",
            "h1": "2026年示例企业适用性判断指南",
            "meta_description": "描" * 40,
            "title_candidates": [f"2026年示例企业适用性判断指南{i}" for i in range(1, 6)],
            "language": "zh-CN",
            "as_of": "2026-08-10",
            "target_region": "中国大陆",
            "target_audience": "正在评估示例方案的企业决策者",
            "time_scope": "截至2026年8月",
        },
        "lead": {
            "direct_answer_sentence": "答" * 40,
            "micro_answer": "微" * 200,
            "claim_ids": ["clm_fixture_scope"],
        },
        "sections": sections,
        "subquestion_coverage": coverage,
        "faq": faq,
        "conclusion": {
            "summary": "总结前文已经展开的判断、证据、适用条件与限制范围。",
            "fit": "适合能够满足前述条件并核对来源的目标读者。",
            "next_action": "核对实际条件后行动。",
            "claim_ids": ["clm_fixture_scope"],
        },
        "references": [],
        "visual_placements": [],
        "structured_data_types": ["Article", "FAQPage"],
    }


def valid_quality_report() -> dict:
    gate_ids = [
        "question_answered",
        "micro_answer_complete",
        "claim_evidence_complete",
        "statistics_and_price_scoped",
        "competitor_fairness",
        "entity_clarity",
        "freshness_and_dates",
        "original_information",
        "faq_relevance",
        "pattern_consistency",
        "voice_and_no_meta_language",
        "visual_argument_and_rights",
    ]
    return {
        "schema_version": "1.0.0",
        "job_id": "job_schema_runtime_001",
        "stage": "E4_pre_optimization",
        "content_model_sha256": HASH,
        "overall_status": "pass",
        "gates": [{"gate_id": gate_id, "status": "pass", "evidence": "测试通过。"} for gate_id in gate_ids],
        "blocking_issues": [],
        "warnings": [],
    }


def valid_delivery_manifest() -> dict:
    roles = ["content_model", "docx", "html", "quality_report", "metadata"]
    return {
        "schema_version": "1.0.0",
        "job_id": "job_schema_runtime_001",
        "created_at": STAMP,
        "selected_revision": "editorial_master",
        "source_equivalence": {
            "content_model_sha256": HASH,
            "docx_rendered_from_same_model": True,
            "html_rendered_from_same_model": True,
        },
        "artifacts": [
            {"role": role, "path": f"delivery/{role}", "sha256": HASH, "media_type": "application/json"}
            for role in roles
        ],
        "quality_report_path": "delivery/quality_report.json",
        "optimization": {"attempted": False, "candidate_selected": False, "fact_diff_status": "not_run"},
    }


def valid_runtime_evidence_extension() -> dict:
    return {
        "schema_version": "1.0.0",
        "job_id": "job_schema_runtime_001",
        "sources": [],
        "claims": [],
        "evidence_files": [],
    }


class RuntimeKeywordTests(unittest.TestCase):
    def test_supported_keyword_subset_and_error_paths(self) -> None:
        schema = {
            "type": "object",
            "required": ["name", "count", "tags", "when", "where"],
            "additionalProperties": {"type": "boolean"},
            "properties": {
                "name": {"type": "string", "minLength": 2, "maxLength": 5, "pattern": "^[a-z]+$"},
                "count": {"type": "integer", "minimum": 1, "maximum": 3},
                "tags": {"type": "array", "items": {"enum": ["a", "b"]}, "minItems": 1, "maxItems": 2, "uniqueItems": True},
                "when": {"type": "string", "format": "date-time"},
                "where": {"type": "string", "format": "uri"},
            },
            "allOf": [{"properties": {"name": {"const": "alpha"}}}],
            "if": {"properties": {"count": {"const": 3}}, "required": ["count"]},
            "then": {"required": ["approved"]},
            "else": {"properties": {"approved": {"const": False}}},
        }
        instance = {
            "name": "alpha",
            "count": 3,
            "tags": ["a", "b"],
            "when": STAMP,
            "where": "https://example.com/a",
            "approved": True,
        }
        with tempfile.TemporaryDirectory() as temp:
            schema_path = Path(temp) / "schema.json"
            errors = validate_instance(instance, schema, schema_path)
            self.assertEqual(errors, [])
            invalid = copy.deepcopy(instance)
            invalid["tags"] = ["a", "a"]
            invalid["where"] = "not a uri"
            errors = validate_instance(invalid, schema, schema_path)
        self.assertEqual({error.keyword for error in errors}, {"uniqueItems", "format"})
        self.assertIn("$.tags[1]", {error.json_path for error in errors})
        self.assertIn("$.where", {error.json_path for error in errors})
        self.assertTrue(all(error.schema_path for error in errors))

    def test_one_of_any_of_and_integer_rejects_boolean(self) -> None:
        schema = {
            "type": "object",
            "required": ["value", "choice"],
            "properties": {
                "value": {"type": "integer"},
                "choice": {"oneOf": [{"const": "a"}, {"const": "b"}]},
                "nullable": {"anyOf": [{"type": "string"}, {"type": "null"}]},
            },
        }
        with tempfile.TemporaryDirectory() as temp:
            schema_path = Path(temp) / "schema.json"
            self.assertEqual(validate_instance({"value": 1.0, "choice": "a", "nullable": None}, schema, schema_path), [])
            errors = validate_instance({"value": True, "choice": "c", "nullable": 1}, schema, schema_path)
        self.assertEqual({error.keyword for error in errors}, {"type", "oneOf", "anyOf"})

    def test_formats_use_real_parsing(self) -> None:
        schema = {
            "type": "object",
            "properties": {
                "day": {"type": "string", "format": "date"},
                "instant": {"type": "string", "format": "date-time"},
                "url": {"type": "string", "format": "uri"},
            },
        }
        bad = {"day": "2026-02-30", "instant": "2026-08-10T12:00:00", "url": "https://exa mple.com"}
        with tempfile.TemporaryDirectory() as temp:
            errors = validate_instance(bad, schema, Path(temp) / "schema.json")
        self.assertEqual(len(errors), 3)
        self.assertTrue(all(error.keyword == "format" for error in errors))

    def test_relative_ref_cycle_and_escape_control(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            defs = root / "defs.json"
            defs.write_text(
                json.dumps({"$defs": {"identifier": {"type": "string", "pattern": "^id_"}}}),
                encoding="utf-8",
            )
            schema = {"$ref": "defs.json#/$defs/identifier"}
            validator = JsonSchemaValidator(root / "entry.json", schema=schema)
            self.assertEqual(validator.validate("id_ok"), [])
            self.assertEqual(validator.validate("bad")[0].keyword, "pattern")

            cyclic = JsonSchemaValidator(root / "cycle.json", schema={"$ref": "#"})
            self.assertEqual(cyclic.validate({"finite": True}), [])

            unsafe = JsonSchemaValidator(root / "unsafe.json", schema={"$ref": "../outside.json"})
            with self.assertRaises(ReferenceResolutionError):
                unsafe.validate({})

    def test_cli_exit_codes_and_report(self) -> None:
        runtime = Path(__file__).with_name("validate_json_instance.py")
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            schema = root / "schema.json"
            valid = root / "valid.json"
            invalid = root / "invalid.json"
            report = root / "report.json"
            schema.write_text('{"type":"integer"}', encoding="utf-8")
            valid.write_text("1", encoding="utf-8")
            invalid.write_text("true", encoding="utf-8")

            passed = subprocess.run(
                [sys.executable, str(runtime), str(schema), str(valid), "--report", str(report)],
                check=False,
                capture_output=True,
                text=True,
            )
            failed = subprocess.run(
                [sys.executable, str(runtime), str(schema), str(invalid)],
                check=False,
                capture_output=True,
                text=True,
            )
            runtime_error = subprocess.run(
                [sys.executable, str(runtime), str(root / "missing.json"), str(valid)],
                check=False,
                capture_output=True,
                text=True,
            )
            self.assertEqual(passed.returncode, 0, passed.stderr)
            self.assertTrue(json.loads(report.read_text(encoding="utf-8"))["valid"])
            self.assertEqual(failed.returncode, 1, failed.stderr)
            self.assertEqual(runtime_error.returncode, 2, runtime_error.stderr)


class ProjectSchemaTests(unittest.TestCase):
    @classmethod
    def valid_root_instances(cls) -> dict[str, dict]:
        return {
            "reference_pack.schema.json": load_json(FIXTURE / "reference_pack.json"),
            "brand_facts.schema.json": load_json(FIXTURE / "brand" / "brand_facts.json"),
            "registries.schema.json": load_json(FIXTURE / "registries" / "knowledge_registry.json"),
            "content_job.schema.json": valid_content_job(),
            "monitoring_input.schema.json": valid_monitoring(),
            "article_blueprint.schema.json": valid_blueprint(),
            "content_model.schema.json": valid_content_model(),
            "quality_report.schema.json": valid_quality_report(),
            "delivery_manifest.schema.json": valid_delivery_manifest(),
            "runtime_evidence_extension.schema.json": valid_runtime_evidence_extension(),
        }

    def test_every_root_schema_accepts_typical_valid_and_rejects_negative(self) -> None:
        discovered = {path.name for path in SHARED.glob("*.schema.json")}
        instances = self.valid_root_instances()
        self.assertEqual(discovered, set(instances), "add an explicit positive example for every root schema")
        for name, instance in instances.items():
            with self.subTest(schema=name, case="positive"):
                schema_path = SHARED / name
                errors = JsonSchemaValidator(schema_path).validate(instance)
                self.assertEqual(errors, [], [error.to_dict() for error in errors])
            with self.subTest(schema=name, case="negative"):
                invalid = copy.deepcopy(instance)
                invalid["schema_version"] = "9.9.9"
                errors = JsonSchemaValidator(SHARED / name).validate(invalid)
                self.assertTrue(errors)
                expected_keywords = {"oneOf"} if name == "registries.schema.json" else {"const"}
                self.assertTrue(expected_keywords & {error.keyword for error in errors})

    def test_all_fixture_instances_with_canonical_schema_are_valid(self) -> None:
        cases = [
            ("reference_pack.schema.json", FIXTURE / "reference_pack.json"),
            ("brand_facts.schema.json", FIXTURE / "brand" / "brand_facts.json"),
            ("registries.schema.json", FIXTURE / "registries" / "knowledge_registry.json"),
            ("registries.schema.json", FIXTURE / "registries" / "source_registry.json"),
            ("registries.schema.json", FIXTURE / "registries" / "claim_registry.json"),
            ("registries.schema.json", FIXTURE / "registries" / "image_registry.json"),
        ]
        for schema_name, instance_path in cases:
            with self.subTest(instance=str(instance_path.relative_to(FIXTURE))):
                errors = JsonSchemaValidator(SHARED / schema_name).validate_path(instance_path)
                self.assertEqual(errors, [], [error.to_dict() for error in errors])


if __name__ == "__main__":
    unittest.main(verbosity=2)
