#!/usr/bin/env python3
"""Validate high-risk invariants of a canonical FrontMind Content Model."""

from __future__ import annotations

import argparse
import json
import unicodedata
from pathlib import Path
from typing import Any


CATEGORIES = {"industry_ranking", "competitor_comparison", "reputation", "product_scenario"}
SUBINTENTS = {
    "offering_definition",
    "feature_mechanism",
    "scenario_fit",
    "delivery_usage",
    "support_boundary",
    "price_selection",
}


def substantive_length(value: str) -> int:
    """Count Unicode code points after excluding whitespace and punctuation."""
    return sum(1 for char in value if not char.isspace() and not unicodedata.category(char).startswith("P"))


def add(errors: list[str], condition: bool, message: str) -> None:
    if not condition:
        errors.append(message)


def validate(model: dict[str, Any]) -> dict[str, Any]:
    errors: list[str] = []
    category = model.get("question_category")
    add(errors, category in CATEGORIES, "question_category must be one of the four canonical values")
    add(errors, isinstance(model.get("primary_question"), str) and len(model["primary_question"]) >= 4, "primary_question is required")
    subintent = model.get("product_scenario_subintent")
    if category == "product_scenario":
        add(errors, subintent in SUBINTENTS, "product_scenario requires a canonical product_scenario_subintent")
    elif "product_scenario_subintent" in model:
        add(errors, subintent is None, "non-product question must not persist a product_scenario_subintent")

    lead = model.get("lead") if isinstance(model.get("lead"), dict) else {}
    direct = lead.get("direct_answer_sentence", "")
    micro = lead.get("micro_answer", "")
    add(errors, isinstance(direct, str) and 40 <= len(direct) <= 80, "direct_answer_sentence must contain 40-80 Unicode code points")
    add(errors, isinstance(micro, str) and 200 <= len(micro) <= 300, "micro_answer must contain 200-300 Unicode code points")

    sections = model.get("sections")
    coverage = model.get("subquestion_coverage")
    faq = model.get("faq")
    add(errors, isinstance(sections, list) and 5 <= len(sections) <= 8, "sections must contain 5-8 items")
    add(errors, isinstance(coverage, list) and 5 <= len(coverage) <= 8, "subquestion_coverage must contain 5-8 items")
    add(errors, isinstance(faq, list) and 5 <= len(faq) <= 8, "faq must contain 5-8 items")

    section_ids = {
        section.get("section_id")
        for section in sections or []
        if isinstance(section, dict) and isinstance(section.get("section_id"), str)
    }
    for index, section in enumerate(sections or []):
        if not isinstance(section, dict) or not isinstance(section.get("h2_question"), str) or not section["h2_question"].endswith(("？", "?")):
            errors.append(f"sections[{index}].h2_question must end with ？ or ?")
    for index, item in enumerate(coverage or []):
        if not isinstance(item, dict):
            errors.append(f"subquestion_coverage[{index}] must be an object")
            continue
        refs = item.get("section_ids")
        if not isinstance(refs, list) or not refs:
            errors.append(f"subquestion_coverage[{index}].section_ids must not be empty")
            continue
        unknown = sorted(set(refs) - section_ids)
        if unknown:
            errors.append(f"subquestion_coverage[{index}] references unknown sections: {', '.join(unknown)}")

    metadata = model.get("metadata") if isinstance(model.get("metadata"), dict) else {}
    candidates = metadata.get("title_candidates")
    add(errors, isinstance(candidates, list) and len(candidates) == 5 and len(set(candidates)) == 5, "metadata.title_candidates must contain five unique candidates")
    for index, item in enumerate(faq or []):
        if not isinstance(item, dict) or not isinstance(item.get("question"), str) or not item["question"].endswith(("？", "?")):
            errors.append(f"faq[{index}].question must end with ？ or ?")
    add(errors, isinstance(model.get("conclusion"), dict), "conclusion is required")

    metrics = {
        "direct_answer_unicode_length": len(direct) if isinstance(direct, str) else None,
        "direct_answer_substantive_length": substantive_length(direct) if isinstance(direct, str) else None,
        "micro_answer_unicode_length": len(micro) if isinstance(micro, str) else None,
        "micro_answer_substantive_length": substantive_length(micro) if isinstance(micro, str) else None,
        "section_count": len(sections) if isinstance(sections, list) else None,
        "coverage_count": len(coverage) if isinstance(coverage, list) else None,
        "faq_count": len(faq) if isinstance(faq, list) else None,
    }
    return {"status": "pass" if not errors else "fail", "metrics": metrics, "errors": errors}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("content_model", type=Path)
    args = parser.parse_args()
    try:
        value = json.loads(args.content_model.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("JSON root must be an object")
        report = validate(value)
    except (OSError, UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
        report = {"status": "fail", "metrics": {}, "errors": [str(exc)]}
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
