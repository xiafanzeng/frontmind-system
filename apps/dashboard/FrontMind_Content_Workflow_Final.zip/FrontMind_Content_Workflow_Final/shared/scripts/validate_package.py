#!/usr/bin/env python3
"""Validate a FrontMind Reference Pack directory or ZIP using only stdlib."""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import posixpath
import re
import runpy
import sys
import zipfile
from xml.etree import ElementTree
from pathlib import Path, PurePosixPath
from typing import Any

from validate_json_instance import (
    ValidationRuntimeError,
    load_json as load_schema_json,
    validate_instance,
)


# Stage validators are loaded from source.  A validator must never dirty the
# deliverable tree merely by being run from a normal (non-``-B``) command.
sys.dont_write_bytecode = True


SHA256 = re.compile(r"^[a-f0-9]{64}$")
ZIP_NAME = re.compile(r"^S0_(?P<brand>[^/]+)_reference_pack_v(?P<version>[1-9][0-9]*)\.zip$")
REQUIRED_TOP = {
    "schema_version",
    "profile",
    "pack_id",
    "version",
    "created_at",
    "brand",
    "knowledge_base",
    "diagnostics",
    "approval_receipt_path",
    "approval_evidence_path",
    "content_pattern_registry_path",
    "brand_facts_path",
    "registries",
    "writing_assets",
    "files",
}
CANONICAL_CATEGORIES = ["industry_ranking", "competitor_comparison", "reputation", "product_scenario"]
CANONICAL_INTENTS = ["recommendation", "price", "comparison", "tutorial", "evaluation", "risk", "alternative"]
CANONICAL_PATTERNS = [f"P{index:02d}" for index in range(1, 16)]
CANONICAL_CONFIRMATIONS = [
    "事实与声明边界已确认",
    "目标受众与决策标准已确认",
    "话语与竞品比较边界已确认",
    "七意图与四入口问题覆盖已确认",
    "图片权利与Logo规则已确认",
    "未决风险与附带条件已确认",
]
REVIEW_SHEETS = ["声明与证据", "受众与话语", "问题覆盖", "视觉资产"]
REQUIRED_WORKBOOK_SHEETS = ["说明与总览", *REVIEW_SHEETS, "审批决议", "_meta"]
FINGERPRINT_PATHS = {
    "adapter_report": "diagnostics/adapter_report.json",
    "knowledge_registry": "registries/knowledge_registry.json",
    "source_registry": "registries/source_registry.json",
    "claim_registry": "registries/claim_registry.json",
    "image_registry": "registries/image_registry.json",
    "brand_facts": "brand/brand_facts.json",
    "information_evidence": "writing/information_evidence.json",
    "voice_contract": "writing/voice_contract.json",
    "visual_reference": "writing/visual_reference.json",
    "question_library": "writing/question_library.json",
    "pattern_registry": "shared/content-pattern-registry.json",
    "trend_reference": "writing/trend_reference.json",
}
APPROVAL_WORKBOOK_PATH = "approval/confirmation_workbook.xlsx"
MAX_XLSX_UNCOMPRESSED_BYTES = 64 * 1024 * 1024
XLSX_MAIN_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
XLSX_REL_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PACKAGE_ROOT = Path(__file__).resolve().parents[2]
STRATEGY_ROOT = PACKAGE_ROOT / "Strategy_Workflow"
SCHEMA_PATHS = {
    "reference_pack": PACKAGE_ROOT / "shared/reference_pack.schema.json",
    "brand_facts": PACKAGE_ROOT / "shared/brand_facts.schema.json",
    "registry": PACKAGE_ROOT / "shared/registries.schema.json",
    "information_evidence": STRATEGY_ROOT / "S4.信息与证据架构师.skill/templates/information_evidence_architecture_schema.json",
    "voice_contract": STRATEGY_ROOT / "S6.文章话语契约.skill/templates/article_voice_contract_schema.json",
    "visual_reference": STRATEGY_ROOT / "S7.视觉参考体系.skill/templates/visual_reference_schema.json",
    "question_library": STRATEGY_ROOT / "S8.问题与FAQ参考库.skill/templates/question_library_schema.json",
    "approval": STRATEGY_ROOT / "S10.ReferencePack确认师.skill/templates/reference_pack_approval_schema.json",
}


def safe_relative(value: str) -> bool:
    path = PurePosixPath(value)
    return bool(value) and not path.is_absolute() and ".." not in path.parts and "\\" not in value


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def reject_duplicate_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    value: dict[str, Any] = {}
    for key, child in pairs:
        if key in value:
            raise ValueError(f"duplicate object key: {key!r}")
        value[key] = child
    return value


def reject_nonstandard_number(value: str) -> None:
    raise ValueError(f"non-standard JSON number is forbidden: {value}")


def decode_json(data: bytes, label: str) -> Any:
    try:
        return json.loads(
            data.decode("utf-8"),
            object_pairs_hook=reject_duplicate_object,
            parse_constant=reject_nonstandard_number,
        )
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
        raise ValueError(f"invalid JSON {label}: {exc}") from exc


class PackageView:
    def names(self) -> list[str]:
        raise NotImplementedError

    def read(self, name: str) -> bytes:
        raise NotImplementedError


class DirectoryView(PackageView):
    def __init__(self, root: Path):
        self.root = root
        for path in root.rglob("*"):
            if path.is_symlink():
                raise ValueError(f"directory package contains symlink: {path.relative_to(root)}")

    def names(self) -> list[str]:
        return sorted(path.relative_to(self.root).as_posix() for path in self.root.rglob("*") if path.is_file())

    def read(self, name: str) -> bytes:
        return (self.root / name).read_bytes()


class ZipView(PackageView):
    def __init__(self, path: Path):
        self.archive = zipfile.ZipFile(path)
        names = self.archive.namelist()
        if len(names) != len(set(names)):
            raise ValueError("ZIP contains duplicate paths")
        for name in names:
            if name.endswith("/"):
                continue
            if not safe_relative(name):
                raise ValueError(f"unsafe ZIP path: {name}")

    def names(self) -> list[str]:
        return sorted(name for name in self.archive.namelist() if not name.endswith("/"))

    def read(self, name: str) -> bytes:
        return self.archive.read(name)


def load_json(view: PackageView, name: str, errors: list[str]) -> dict[str, Any] | None:
    try:
        value = decode_json(view.read(name), name)
    except KeyError:
        errors.append(f"missing file: {name}")
        return None
    except ValueError as exc:
        errors.append(str(exc))
        return None
    if not isinstance(value, dict):
        errors.append(f"JSON root must be object: {name}")
        return None
    return value


def validate_with_schema(value: Any, schema_key: str, instance_name: str, errors: list[str]) -> None:
    """Apply the canonical stdlib runtime to an in-memory package instance."""

    schema_path = SCHEMA_PATHS[schema_key]
    try:
        schema = load_schema_json(schema_path)
        failures = validate_instance(value, schema, schema_path)
    except ValidationRuntimeError as exc:
        errors.append(f"{instance_name}: schema runtime error: {exc}")
        return
    for failure in failures:
        errors.append(
            f"{instance_name}: schema {failure.keyword} at {failure.json_path} "
            f"({failure.schema_path}): {failure.message}"
        )


def load_required_json(view: PackageView, name: Any, label: str, names: set[str], errors: list[str]) -> dict[str, Any] | None:
    if not isinstance(name, str) or not safe_relative(name):
        errors.append(f"{label}: required package path is missing or unsafe: {name!r}")
        return None
    if name not in names:
        errors.append(f"{label}: referenced package file is absent: {name}")
        return None
    return load_json(view, name, errors)


def validate_registry(view: PackageView, path: str, registry_type: str, array_key: str, errors: list[str]) -> dict[str, Any] | None:
    if not isinstance(path, str) or not path:
        errors.append(f"missing {registry_type} path")
        return None
    value = load_json(view, path, errors)
    if value is None:
        return None
    validate_with_schema(value, "registry", path, errors)
    if value.get("schema_version") != "1.0.0":
        errors.append(f"{path}: unsupported schema_version")
    if value.get("registry_type") != registry_type:
        errors.append(f"{path}: registry_type must be {registry_type}")
    if not isinstance(value.get(array_key), list):
        errors.append(f"{path}: {array_key} must be an array")
    if registry_type == "image_registry":
        for index, image in enumerate(value.get("images", [])):
            if not isinstance(image, dict):
                errors.append(f"{path}: images[{index}] must be object")
                continue
            for key in ("asset_id", "file_path", "sha256", "source_kind", "rights_status"):
                if key not in image:
                    errors.append(f"{path}: images[{index}] missing {key}")
            if "file_hash" in image:
                errors.append(f"{path}: legacy file_hash is forbidden; use sha256")
    return value


def unique_ids(
    value: dict[str, Any] | None,
    array_key: str,
    id_key: str,
    path: str,
    prefix: str,
    errors: list[str],
) -> set[str]:
    result: set[str] = set()
    if value is None:
        return result
    for index, item in enumerate(value.get(array_key, [])):
        if not isinstance(item, dict):
            continue
        identifier = item.get(id_key)
        if not isinstance(identifier, str) or not identifier:
            errors.append(f"{path}: {array_key}[{index}] missing {id_key}")
        elif not identifier.startswith(prefix):
            errors.append(f"{path}: {id_key} must start with {prefix}: {identifier}")
        elif identifier in result:
            errors.append(f"{path}: duplicate {id_key}: {identifier}")
        else:
            result.add(identifier)
    return result


def referenced_ids(value: Any, key: str) -> set[str]:
    result: set[str] = set()
    if isinstance(value, dict):
        for name, child in value.items():
            if name == key and isinstance(child, list):
                result.update(item for item in child if isinstance(item, str))
            else:
                result.update(referenced_ids(child, key))
    elif isinstance(value, list):
        for child in value:
            result.update(referenced_ids(child, key))
    return result


def xlsx_column_number(reference: str) -> int:
    match = re.match(r"^([A-Z]+)", reference.upper())
    if not match:
        raise ValueError(f"invalid XLSX cell reference: {reference!r}")
    result = 0
    for character in match.group(1):
        result = result * 26 + ord(character) - 64
    return result


def xlsx_text(element: ElementTree.Element) -> str:
    return "".join(node.text or "" for node in element.iter(f"{{{XLSX_MAIN_NS}}}t"))


def normalize_xlsx_target(target: str) -> str:
    if not target or "\\" in target:
        raise ValueError(f"invalid XLSX relationship target: {target!r}")
    if target.startswith("/"):
        value = target.lstrip("/")
    else:
        value = posixpath.normpath(posixpath.join("xl", target))
    if not safe_relative(value) or not value.startswith("xl/"):
        raise ValueError(f"unsafe XLSX relationship target: {target!r}")
    return value


def parse_approval_workbook(data: bytes, label: str, errors: list[str]) -> dict[str, dict[str, str]] | None:
    """Read the S10 XLSX evidence with stdlib OpenXML, without trusting formulas."""

    try:
        archive = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile as exc:
        errors.append(f"{label}: invalid XLSX ZIP: {exc}")
        return None
    with archive:
        infos = archive.infolist()
        names = [item.filename for item in infos if not item.is_dir()]
        if len(names) != len(set(names)):
            errors.append(f"{label}: XLSX contains duplicate members")
            return None
        for info in infos:
            if info.is_dir():
                continue
            if not safe_relative(info.filename):
                errors.append(f"{label}: unsafe XLSX member: {info.filename}")
                return None
            if info.flag_bits & 0x1:
                errors.append(f"{label}: encrypted XLSX members are forbidden")
                return None
        if sum(info.file_size for info in infos) > MAX_XLSX_UNCOMPRESSED_BYTES:
            errors.append(f"{label}: XLSX expands beyond {MAX_XLSX_UNCOMPRESSED_BYTES} bytes")
            return None
        if any(name.endswith("vbaProject.bin") or name.startswith("xl/externalLinks/") for name in names):
            errors.append(f"{label}: macros and external workbook links are forbidden")
            return None
        required = {"xl/workbook.xml", "xl/_rels/workbook.xml.rels"}
        missing = required - set(names)
        if missing:
            errors.append(f"{label}: XLSX lacks {sorted(missing)}")
            return None
        try:
            workbook_root = ElementTree.fromstring(archive.read("xl/workbook.xml"))
            relation_root = ElementTree.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
        except ElementTree.ParseError as exc:
            errors.append(f"{label}: invalid workbook XML: {exc}")
            return None

        relations: dict[str, str] = {}
        for relation in relation_root.findall("{*}Relationship"):
            relation_id = relation.attrib.get("Id")
            target = relation.attrib.get("Target")
            mode = relation.attrib.get("TargetMode")
            if relation_id and target and mode != "External":
                try:
                    relations[relation_id] = normalize_xlsx_target(target)
                except ValueError as exc:
                    errors.append(f"{label}: {exc}")
        shared_strings: list[str] = []
        if "xl/sharedStrings.xml" in names:
            try:
                shared_root = ElementTree.fromstring(archive.read("xl/sharedStrings.xml"))
                shared_strings = [xlsx_text(item) for item in shared_root.findall(f"{{{XLSX_MAIN_NS}}}si")]
            except ElementTree.ParseError as exc:
                errors.append(f"{label}: invalid sharedStrings XML: {exc}")
                return None

        sheets: dict[str, dict[str, str]] = {}
        for sheet in workbook_root.findall(f".//{{{XLSX_MAIN_NS}}}sheet"):
            sheet_name = sheet.attrib.get("name")
            relation_id = sheet.attrib.get(f"{{{XLSX_REL_NS}}}id")
            target = relations.get(relation_id or "")
            if not sheet_name or not target:
                errors.append(f"{label}: workbook sheet has no resolvable name/relationship")
                continue
            if sheet_name in sheets:
                errors.append(f"{label}: duplicate sheet name: {sheet_name}")
                continue
            if target not in names:
                errors.append(f"{label}: worksheet member is absent: {target}")
                continue
            try:
                sheet_root = ElementTree.fromstring(archive.read(target))
            except ElementTree.ParseError as exc:
                errors.append(f"{label}: invalid worksheet XML {sheet_name}: {exc}")
                continue
            cells: dict[str, str] = {}
            for cell in sheet_root.findall(f".//{{{XLSX_MAIN_NS}}}c"):
                reference = cell.attrib.get("r")
                if not reference:
                    continue
                cell_type = cell.attrib.get("t")
                if cell_type == "inlineStr":
                    value = xlsx_text(cell)
                else:
                    raw = cell.find(f"{{{XLSX_MAIN_NS}}}v")
                    value = raw.text if raw is not None and raw.text is not None else ""
                    if cell_type == "s" and value:
                        try:
                            value = shared_strings[int(value)]
                        except (ValueError, IndexError):
                            errors.append(f"{label}: invalid shared string index at {sheet_name}!{reference}")
                            value = ""
                    elif cell_type == "b":
                        value = "TRUE" if value == "1" else "FALSE"
                cells[reference.upper()] = str(value).strip()
            sheets[sheet_name] = cells
    return sheets


def validate_original_knowledge_package(
    view: PackageView,
    names: set[str],
    knowledge_base: dict[str, Any],
    errors: list[str],
) -> dict[str, Any] | None:
    """Bind the normalized KB tree to the immutable source ZIP and its digest."""

    path = knowledge_base.get("original_package_path")
    if not isinstance(path, str) or path not in names:
        return None
    data = view.read(path)
    if digest(data) != knowledge_base.get("package_sha256"):
        errors.append("knowledge_base.package_sha256 does not match the packaged original KB ZIP")
    try:
        archive = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile as exc:
        errors.append(f"{path}: invalid original knowledge ZIP: {exc}")
        return None
    with archive:
        members = [item.filename for item in archive.infolist() if not item.is_dir()]
        if len(members) != len(set(members)):
            errors.append(f"{path}: original knowledge ZIP contains duplicate paths")
            return None
        if any(not safe_relative(name) for name in members):
            errors.append(f"{path}: original knowledge ZIP contains unsafe paths")
            return None
        manifests = [
            name for name in members
            if name == "00_package_manifest.json" or name.endswith("/00_package_manifest.json")
        ]
        if len(manifests) != 1:
            errors.append(f"{path}: original knowledge ZIP must contain exactly one 00_package_manifest.json")
            return None
        prefix = str(PurePosixPath(manifests[0]).parent)
        prefix = "" if prefix == "." else prefix + "/"
        normalized: dict[str, bytes] = {}
        for member in members:
            if prefix and not member.startswith(prefix):
                errors.append(f"{path}: original knowledge ZIP mixes files outside its package root: {member}")
                continue
            relative = member[len(prefix):] if prefix else member
            if not safe_relative(relative) or relative in normalized:
                errors.append(f"{path}: unsafe or duplicate normalized knowledge path: {relative}")
                continue
            normalized[relative] = archive.read(member)
        packaged = {
            name.removeprefix("sources/knowledge_base/"): name
            for name in names if name.startswith("sources/knowledge_base/")
        }
        if set(packaged) != set(normalized):
            errors.append(
                f"{path}: normalized KB file set differs from original ZIP: "
                f"missing={sorted(set(normalized) - set(packaged))}, "
                f"extra={sorted(set(packaged) - set(normalized))}"
            )
        for relative in set(packaged) & set(normalized):
            if view.read(packaged[relative]) != normalized[relative]:
                errors.append(f"{path}: normalized KB file differs from original ZIP: {relative}")
        try:
            manifest = decode_json(normalized["00_package_manifest.json"], f"{path}!00_package_manifest.json")
        except (KeyError, ValueError) as exc:
            errors.append(str(exc))
            return None
        if not isinstance(manifest, dict):
            errors.append(f"{path}: knowledge manifest must be an object")
            return None
        return manifest


def workbook_field_map(cells: dict[str, str], label: str, errors: list[str]) -> dict[str, str]:
    values: dict[str, str] = {}
    rows = sorted(
        {int(match.group(1)) for reference in cells for match in [re.search(r"(\d+)$", reference)] if match}
    )
    for row in rows:
        key = cells.get(f"A{row}", "").strip()
        if not key:
            continue
        if key in values:
            errors.append(f"{label}: duplicate field label {key!r}")
        values[key] = cells.get(f"B{row}", "").strip()
    return values


def workbook_review_rows(sheet_name: str, cells: dict[str, str], errors: list[str]) -> list[dict[str, str]]:
    header_row: int | None = None
    columns: dict[str, int] = {}
    for row in range(1, 13):
        current = {
            value: xlsx_column_number(reference)
            for reference, value in cells.items()
            if (match := re.search(r"(\d+)$", reference)) and int(match.group(1)) == row and value
        }
        if "对象ID" in current and "审核决定" in current:
            header_row, columns = row, current
            break
    if header_row is None:
        errors.append(f"workbook:{sheet_name}: review headers not found")
        return []

    def value_at(row: int, header: str) -> str:
        column = columns.get(header)
        if column is None:
            return ""
        letters = ""
        current = column
        while current:
            current, remainder = divmod(current - 1, 26)
            letters = chr(65 + remainder) + letters
        return cells.get(f"{letters}{row}", "").strip()

    maximum_row = max(
        (int(match.group(1)) for reference in cells for match in [re.search(r"(\d+)$", reference)] if match),
        default=header_row,
    )
    result: list[dict[str, str]] = []
    seen: set[str] = set()
    for row in range(header_row + 1, maximum_row + 1):
        object_id = value_at(row, "对象ID")
        if not object_id:
            continue
        if object_id in seen:
            errors.append(f"workbook:{sheet_name}: duplicate reviewed object_id {object_id!r}")
        seen.add(object_id)
        result.append(
            {
                "sheet": sheet_name,
                "object_id": object_id,
                "decision": value_at(row, "审核决定").lower(),
                "requested_change": value_at(row, "修改要求"),
                "notes": value_at(row, "备注"),
            }
        )
    return result


def split_workbook_lines(value: str) -> list[str]:
    return [line.strip(" -•\t") for line in value.splitlines() if line.strip(" -•\t")]


def validate_workbook_evidence(
    workbook_bytes: bytes,
    receipt: dict[str, Any],
    pack_brand: str | None,
    errors: list[str],
) -> None:
    sheets = parse_approval_workbook(workbook_bytes, APPROVAL_WORKBOOK_PATH, errors)
    if sheets is None:
        return
    missing = set(REQUIRED_WORKBOOK_SHEETS) - set(sheets)
    if missing:
        errors.append(f"{APPROVAL_WORKBOOK_PATH}: missing required sheets: {sorted(missing)}")
        return
    meta = workbook_field_map(sheets["_meta"], "workbook:_meta", errors)
    approval_sheet = workbook_field_map(sheets["审批决议"], "workbook:审批决议", errors)
    if meta.get("schema_version") != "1.0.0":
        errors.append("workbook:_meta schema_version must be 1.0.0")
    if meta.get("brand") != pack_brand or approval_sheet.get("品牌") != pack_brand:
        errors.append("workbook brand must match reference_pack.json brand.canonical_name")
    try:
        workbook_inputs = json.loads(meta.get("input_files", ""))
    except json.JSONDecodeError:
        workbook_inputs = None
        errors.append("workbook:_meta input_files is not valid JSON")
    if workbook_inputs != receipt.get("input_files"):
        errors.append("workbook:_meta input_files must exactly match approval receipt fingerprints")
    if meta.get("pattern_registry_sha256") != receipt.get("pattern_registry_sha256"):
        errors.append("workbook:_meta pattern_registry_sha256 must match approval receipt")

    approval = receipt.get("approval") if isinstance(receipt.get("approval"), dict) else {}
    approval_pairs = {
        "审批状态": approval.get("status"),
        "负责人": approval.get("reviewer"),
        "负责人角色": approval.get("reviewer_role"),
        "审批日期": approval.get("approved_at"),
        "总备注": approval.get("notes", ""),
    }
    for label, expected in approval_pairs.items():
        if approval_sheet.get(label, "") != str(expected or ""):
            errors.append(f"workbook:审批决议 {label} does not match approval receipt")
    if split_workbook_lines(approval_sheet.get("附带条件（每行一项）", "")) != approval.get("conditions", []):
        errors.append("workbook:审批决议 conditions do not match approval receipt")
    if split_workbook_lines(approval_sheet.get("未决风险（每行一项）", "")) != approval.get("unresolved_risks", []):
        errors.append("workbook:审批决议 unresolved risks do not match approval receipt")
    confirmations = receipt.get("confirmations") if isinstance(receipt.get("confirmations"), dict) else {}
    for label in CANONICAL_CONFIRMATIONS:
        workbook_value = approval_sheet.get(label, "").upper()
        if workbook_value != "YES" or confirmations.get(label) is not True:
            errors.append(f"workbook:审批决议 confirmation is not YES/true: {label}")

    workbook_reviews: list[dict[str, str]] = []
    for sheet_name in REVIEW_SHEETS:
        workbook_reviews.extend(workbook_review_rows(sheet_name, sheets[sheet_name], errors))
    if workbook_reviews != receipt.get("review_decisions"):
        errors.append("workbook review rows must exactly match approval receipt review_decisions")


def registry_id_set(registry: dict[str, Any] | None, array_key: str, id_key: str) -> set[str]:
    if not isinstance(registry, dict):
        return set()
    return {
        str(item[id_key])
        for item in registry.get(array_key, [])
        if isinstance(item, dict) and isinstance(item.get(id_key), str)
    }


def nested_list_values(payload: Any, key_name: str) -> set[str]:
    result: set[str] = set()
    if isinstance(payload, dict):
        for key, value in payload.items():
            if key == key_name and isinstance(value, list):
                result.update(item for item in value if isinstance(item, str))
            result.update(nested_list_values(value, key_name))
    elif isinstance(payload, list):
        for value in payload:
            result.update(nested_list_values(value, key_name))
    return result


def load_semantic_validator(relative: str, errors: list[str]) -> dict[str, Any] | None:
    path = STRATEGY_ROOT / relative
    if not path.is_file():
        errors.append(f"semantic validator is missing: {path.relative_to(PACKAGE_ROOT)}")
        return None
    try:
        return runpy.run_path(str(path), run_name=f"frontmind_semantic_{path.stem}")
    except Exception as exc:  # defensive: a broken validator is a release blocker
        errors.append(f"semantic validator could not load {path.relative_to(PACKAGE_ROOT)}: {exc}")
        return None


def append_semantic_errors(stage: str, failures: Any, errors: list[str]) -> None:
    if not isinstance(failures, list):
        errors.append(f"{stage} semantic validator returned a non-list result")
        return
    errors.extend(f"{stage} semantic gate: {failure}" for failure in failures)


def run_semantic_gate(stage: str, validator: Any, errors: list[str], *args: Any) -> None:
    """Run a stage validator without allowing malformed input to crash the trust gate."""

    try:
        failures = validator(*args)
    except Exception as exc:
        errors.append(f"{stage} semantic validator rejected malformed input: {type(exc).__name__}: {exc}")
        return
    append_semantic_errors(stage, failures, errors)


def validate_pattern_registry(pattern: dict[str, Any] | None, errors: list[str]) -> tuple[set[str], set[str]]:
    if not isinstance(pattern, dict):
        errors.append("shared/content-pattern-registry.json must be an object")
        return set(), set()
    categories = [item.get("id") for item in pattern.get("canonical_question_categories", []) if isinstance(item, dict)]
    intents = [item.get("id") for item in pattern.get("question_intent_tags", []) if isinstance(item, dict)]
    patterns = [item.get("id") for item in pattern.get("patterns", []) if isinstance(item, dict)]
    if pattern.get("schema_version") != "1.0.0":
        errors.append("content pattern registry schema_version must be 1.0.0")
    if categories != CANONICAL_CATEGORIES:
        errors.append(f"content pattern registry categories must be {CANONICAL_CATEGORIES}")
    if intents != CANONICAL_INTENTS:
        errors.append(f"content pattern registry intents must be {CANONICAL_INTENTS}")
    if patterns != CANONICAL_PATTERNS:
        errors.append("content pattern registry must contain P01-P15 once and in order")
    aliases = {
        item.get("id"): item.get("aliases")
        for item in pattern.get("canonical_question_categories", [])
        if isinstance(item, dict)
    }
    if aliases.get("industry_ranking") != ["industry"] or any(
        aliases.get(category) not in ([], None) for category in CANONICAL_CATEGORIES[1:]
    ):
        errors.append("content pattern registry may expose only industry as the industry_ranking import alias")
    selection = pattern.get("selection_contract") if isinstance(pattern.get("selection_contract"), dict) else {}
    if selection.get("exactly_one_pattern") is not True or selection.get("selection_owner") != "E1":
        errors.append("content pattern registry selection contract must assign exactly one pattern in E1")
    original_gate = pattern.get("original_information_gate")
    if not isinstance(original_gate, dict) or not original_gate.get("hard_required_patterns"):
        errors.append("content pattern registry original_information_gate is incomplete")
    return set(patterns), set(categories)


def validate_logo_references(
    visual: dict[str, Any] | None,
    image_registry: dict[str, Any] | None,
    errors: list[str],
) -> None:
    if not isinstance(visual, dict) or not isinstance(image_registry, dict):
        return
    image_by_id = {
        item.get("asset_id"): item
        for item in image_registry.get("images", [])
        if isinstance(item, dict) and isinstance(item.get("asset_id"), str)
    }
    constraints = visual.get("brand_constraints")
    logo_refs = constraints.get("logo_asset_refs") or [] if isinstance(constraints, dict) else []
    for asset_id in logo_refs:
        item = image_by_id.get(asset_id)
        if not isinstance(item, dict):
            errors.append(f"S7 logo_asset_refs references unknown image: {asset_id}")
            continue
        roles = set(item.get("allowed_roles") or [])
        if "entity_proof" not in roles:
            errors.append(f"S7 logo asset {asset_id} must allow the entity_proof role")
        if item.get("asset_kind") != "logo":
            errors.append(f"S7 logo asset {asset_id} must carry canonical asset_kind='logo'")
        if item.get("rights_status") not in {"approved", "approved_with_credit"}:
            errors.append(f"S7 logo asset {asset_id} lacks publishable rights")
        if item.get("source_kind") not in {"client_submitted", "first_party_download", "first_party_reference"}:
            errors.append(f"S7 logo asset {asset_id} is not a client/first-party identity asset")


def validate_stage_semantics(
    payloads: dict[str, dict[str, Any] | None],
    pack_brand: str | None,
    errors: list[str],
) -> None:
    pattern = payloads.get("pattern_registry")
    pattern_ids, category_ids = validate_pattern_registry(pattern, errors)
    knowledge_ids = registry_id_set(payloads.get("knowledge_registry"), "knowledge_units", "knowledge_id")
    source_ids = registry_id_set(payloads.get("source_registry"), "sources", "source_id")
    claim_ids = registry_id_set(payloads.get("claim_registry"), "claims", "claim_id")

    report = payloads.get("adapter_report")
    if not isinstance(report, dict):
        errors.append("diagnostics/adapter_report.json must be an object")
    else:
        if report.get("schema_version") != "1.0.0":
            errors.append("R0 adapter report schema_version must be 1.0.0")
        if report.get("mode") != "canonical_v4" or report.get("canonical") is not True:
            errors.append("R0 adapter report must record a canonical_v4 input")
        if report.get("formal_handoff_ready") is not True or report.get("fatal_errors"):
            errors.append("R0 adapter report is not a clean formal handoff")
        if report.get("brand") != pack_brand:
            errors.append("R0 adapter report brand does not match the Reference Pack")
        kb_contract = payloads.get("knowledge_base_contract") or {}
        fingerprints = report.get("input_fingerprints") if isinstance(report.get("input_fingerprints"), dict) else {}
        if set(fingerprints) != {"kb"}:
            errors.append("R0 adapter report input_fingerprints must contain exactly the source KB fingerprint")
        if fingerprints.get("kb") != kb_contract.get("package_sha256"):
            errors.append("R0 adapter report KB fingerprint does not match the packaged original KB ZIP")
        manifest = payloads.get("kb_manifest") or {}
        report_manifest = report.get("manifest") if isinstance(report.get("manifest"), dict) else {}
        expected_manifest = {
            "schemaVersion": manifest.get("schemaVersion"),
            "profile": manifest.get("profile"),
            "buildRevision": manifest.get("buildRevision"),
            "documents": len(manifest.get("documents") or []) if isinstance(manifest.get("documents"), list) else None,
            "assets": len(manifest.get("assets") or []) if isinstance(manifest.get("assets"), list) else None,
        }
        if report_manifest != expected_manifest:
            errors.append(
                f"R0 adapter report manifest summary does not match packaged KB manifest: "
                f"expected {expected_manifest}, found {report_manifest}"
            )
        counts = report.get("counts") if isinstance(report.get("counts"), dict) else {}
        expected_counts = {
            "knowledge": len(knowledge_ids),
            "sources": len(source_ids),
            "claims": len(claim_ids),
            "images": len((payloads.get("image_registry") or {}).get("images", [])),
        }
        if counts != expected_counts:
            errors.append(f"R0 adapter report counts do not match packaged registries: expected {expected_counts}, found {counts}")
        if isinstance(manifest.get("documents"), list) and len(manifest["documents"]) != expected_counts["knowledge"]:
            errors.append("packaged KB manifest document count does not match the knowledge registry")
        if isinstance(manifest.get("assets"), list) and len(manifest["assets"]) != expected_counts["images"]:
            errors.append("packaged KB manifest asset count does not match the image registry")
        report_registries = report.get("registries") if isinstance(report.get("registries"), dict) else {}
        if set(report_registries) != {"knowledge", "source", "claim", "image"}:
            errors.append("R0 adapter report registries must contain exactly knowledge/source/claim/image filenames")
        approval = payloads.get("approval_receipt") or {}
        approval_inputs = approval.get("input_files") if isinstance(approval.get("input_files"), list) else []
        source_names = {
            item.get("role"): item.get("file_name") for item in approval_inputs
            if isinstance(item, dict) and isinstance(item.get("role"), str)
        }
        for report_role, input_role in (
            ("knowledge", "knowledge_registry"),
            ("source", "source_registry"),
            ("claim", "claim_registry"),
            ("image", "image_registry"),
        ):
            if report_registries.get(report_role) != source_names.get(input_role):
                errors.append(
                    f"R0 adapter report registry filename {report_role!r} is not bound to "
                    f"the approved {input_role} input"
                )

    s4 = load_semantic_validator(
        "S4.信息与证据架构师.skill/scripts/information_evidence_validator.py", errors
    )
    architecture = payloads.get("information_evidence")
    brand_facts = payloads.get("brand_facts")
    branded_payloads = {
        "S4 information/evidence": architecture,
        "S6 voice contract": payloads.get("voice_contract"),
        "S7 visual reference": payloads.get("visual_reference"),
        "S8 question library": payloads.get("question_library"),
    }
    for label, value in branded_payloads.items():
        if isinstance(value, dict) and value.get("brand") != pack_brand:
            errors.append(f"{label} brand does not match the Reference Pack")
    identity = (brand_facts or {}).get("brand_identity") if isinstance(brand_facts, dict) else {}
    if not isinstance(identity, dict) or identity.get("canonical_name") != pack_brand:
        errors.append("S4 brand facts canonical_name does not match the Reference Pack")
    if s4:
        run_semantic_gate(
            "S4 information/evidence",
            s4["validate_architecture"],
            errors,
            architecture, claim_ids, source_ids, knowledge_ids, pattern_ids, category_ids,
        )
        run_semantic_gate(
            "S4 brand facts", s4["validate_brand_facts"], errors, brand_facts, claim_ids, source_ids
        )

    proof_ids = {
        str(item.get("proof_id"))
        for item in (architecture or {}).get("proof_bundles", [])
        if isinstance(item, dict) and item.get("proof_id")
    }
    s6 = load_semantic_validator(
        "S6.文章话语契约.skill/scripts/article_voice_contract_validator.py", errors
    )
    if s6:
        run_semantic_gate(
            "S6 voice contract", s6["validate"], errors,
            payloads.get("voice_contract"), proof_ids, pattern_ids, category_ids,
        )

    image_registry = payloads.get("image_registry")
    image_by_id = {
        str(item.get("asset_id")): item
        for item in (image_registry or {}).get("images", [])
        if isinstance(item, dict) and item.get("asset_id")
    }
    s7 = load_semantic_validator(
        "S7.视觉参考体系.skill/scripts/visual_reference_validator.py", errors
    )
    if s7:
        run_semantic_gate(
            "S7 visual reference", s7["validate"], errors,
            payloads.get("visual_reference"), image_by_id, pattern_ids,
        )
    validate_logo_references(payloads.get("visual_reference"), image_registry, errors)

    context_ids = {
        str(item.get("context_id"))
        for item in (architecture or {}).get("audience_decision_contexts", [])
        if isinstance(item, dict) and item.get("context_id")
    }
    s8 = load_semantic_validator(
        "S8.问题与FAQ参考库.skill/scripts/question_library_validator.py", errors
    )
    if s8:
        run_semantic_gate(
            "S8 question library", s8["validate"], errors,
            payloads.get("question_library"), pattern, knowledge_ids, source_ids,
            claim_ids, context_ids, proof_ids,
        )

    trend = payloads.get("trend_reference")
    if isinstance(trend, dict):
        if trend.get("status") not in {"completed", "skipped_not_needed", "skipped_no_reliable_signal"}:
            errors.append("S3 trend reference status is invalid")
        for key, known, label in (
            ("source_ids", source_ids, "source"),
            ("knowledge_ids", knowledge_ids, "knowledge"),
            ("pattern_refs", pattern_ids, "pattern"),
        ):
            unknown = nested_list_values(trend, key) - known
            if unknown:
                errors.append(f"S3 trend reference has unknown {label} IDs: {sorted(unknown)}")


def validate_approval_binding(
    view: PackageView,
    names: set[str],
    receipt: dict[str, Any] | None,
    pack_brand: str | None,
    file_records: dict[str, dict[str, Any]],
    trend_present: bool,
    payloads: dict[str, dict[str, Any] | None],
    errors: list[str],
) -> None:
    if not isinstance(receipt, dict):
        return
    approval = receipt.get("approval") if isinstance(receipt.get("approval"), dict) else {}
    if receipt.get("brand") != pack_brand:
        errors.append("approval receipt brand must match reference_pack.json brand.canonical_name")
    if approval.get("status") != "approved":
        errors.append("approval receipt status must be exactly approved")
    if not all(isinstance(approval.get(key), str) and approval[key].strip() for key in ("reviewer", "reviewer_role", "approved_at")):
        errors.append("approved receipt requires reviewer, reviewer_role, and approved_at")
    if approval.get("conditions") or approval.get("unresolved_risks"):
        errors.append("approved receipt cannot contain conditions or unresolved risks")
    confirmations = receipt.get("confirmations") if isinstance(receipt.get("confirmations"), dict) else {}
    if set(confirmations) != set(CANONICAL_CONFIRMATIONS) or not all(
        confirmations.get(label) is True for label in CANONICAL_CONFIRMATIONS
    ):
        errors.append("approval receipt must contain exactly six canonical true confirmations")

    reviews = receipt.get("review_decisions")
    if not isinstance(reviews, list) or not reviews:
        errors.append("approval receipt review_decisions must be non-empty")
        reviews = []
    seen_reviews: set[tuple[str, str]] = set()
    reviewed_sheets: set[str] = set()
    for index, review in enumerate(reviews):
        if not isinstance(review, dict):
            errors.append(f"approval review_decisions[{index}] must be an object")
            continue
        sheet, object_id = review.get("sheet"), review.get("object_id")
        key = (str(sheet), str(object_id))
        if sheet not in REVIEW_SHEETS or not isinstance(object_id, str) or not object_id.strip():
            errors.append(f"approval review_decisions[{index}] has invalid sheet/object_id")
        elif key in seen_reviews:
            errors.append(f"approval receipt duplicates reviewed object: {key}")
        seen_reviews.add(key)
        reviewed_sheets.add(str(sheet))
        if review.get("decision") != "keep":
            errors.append(f"approved receipt may contain only keep decisions: {key}")
        if review.get("requested_change"):
            errors.append(f"keep decision cannot retain a requested_change: {key}")
    if reviewed_sheets != set(REVIEW_SHEETS):
        errors.append(f"approval receipt must contain review evidence from all four sheets: {REVIEW_SHEETS}")

    expected_reviews: dict[str, set[str]] = {sheet: set() for sheet in REVIEW_SHEETS}
    claims = payloads.get("claim_registry") or {}
    expected_reviews["声明与证据"].update(
        str(item.get("claim_id")) for item in claims.get("claims", [])
        if isinstance(item, dict) and item.get("claim_id")
    )
    architecture = payloads.get("information_evidence") or {}
    expected_reviews["声明与证据"].update(
        str(item.get("proof_id")) for item in architecture.get("proof_bundles", [])
        if isinstance(item, dict) and item.get("proof_id")
    )
    facts = payloads.get("brand_facts") or {}
    expected_reviews["声明与证据"].update({"brand:identity", "brand:positioning"})
    for section, id_key in (
        ("offerings", "offering_id"),
        ("capabilities", "capability_id"),
        ("proof_points", "proof_id"),
        ("limitations", "limitation_id"),
    ):
        expected_reviews["声明与证据"].update(
            str(item.get(id_key)) for item in facts.get(section, [])
            if isinstance(item, dict) and item.get(id_key)
        )
    expected_reviews["受众与话语"].update(
        str(item.get("context_id")) for item in architecture.get("audience_decision_contexts", [])
        if isinstance(item, dict) and item.get("context_id")
    )
    expected_reviews["受众与话语"].update(
        str(item.get("message_id") or item.get("pillar_id"))
        for item in architecture.get("message_pillars", [])
        if isinstance(item, dict) and (item.get("message_id") or item.get("pillar_id"))
    )
    expected_reviews["受众与话语"].update({"voice:default", "voice:terminology", "voice:comparison"})
    library = payloads.get("question_library") or {}
    expected_reviews["问题覆盖"].update(
        str(item.get("question_id")) for item in library.get("questions", [])
        if isinstance(item, dict) and item.get("question_id")
    )
    images = payloads.get("image_registry") or {}
    expected_reviews["视觉资产"].update(
        str(item.get("asset_id")) for item in images.get("images", [])
        if isinstance(item, dict) and item.get("asset_id")
    )
    expected_reviews["视觉资产"].add("visual:logo-policy")
    actual_reviews: dict[str, set[str]] = {sheet: set() for sheet in REVIEW_SHEETS}
    for review in reviews:
        if isinstance(review, dict) and review.get("sheet") in actual_reviews and isinstance(review.get("object_id"), str):
            actual_reviews[review["sheet"]].add(review["object_id"])
    for sheet, expected in expected_reviews.items():
        missing = expected - actual_reviews[sheet]
        unexpected = actual_reviews[sheet] - expected
        if missing:
            errors.append(f"approval receipt omits reviewable {sheet} objects: {sorted(missing)}")
        if unexpected:
            errors.append(f"approval receipt contains unknown {sheet} objects: {sorted(unexpected)}")

    expected_paths = dict(FINGERPRINT_PATHS)
    if not trend_present:
        expected_paths.pop("trend_reference")
    fingerprints = receipt.get("input_files")
    by_role: dict[str, dict[str, Any]] = {}
    if not isinstance(fingerprints, list):
        errors.append("approval receipt input_files must be an array")
        fingerprints = []
    for index, item in enumerate(fingerprints):
        if not isinstance(item, dict) or not isinstance(item.get("role"), str):
            errors.append(f"approval input_files[{index}] must be an object with role")
            continue
        role = item["role"]
        if role in by_role:
            errors.append(f"approval receipt contains duplicate input fingerprint role: {role}")
        by_role[role] = item
    if set(by_role) != set(expected_paths):
        errors.append(
            "approval input fingerprint roles differ from packaged reviewed inputs: "
            f"expected={sorted(expected_paths)}, actual={sorted(by_role)}"
        )
    for role, package_path in expected_paths.items():
        item = by_role.get(role)
        if item is None or package_path not in names:
            continue
        source_name = item.get("file_name")
        if not isinstance(source_name, str) or not source_name or PurePosixPath(source_name).name != source_name:
            errors.append(f"approval fingerprint {role}.file_name must be a basename")
        payload = view.read(package_path)
        actual_hash = digest(payload)
        if item.get("sha256") != actual_hash or item.get("bytes") != len(payload):
            errors.append(f"approval fingerprint mismatch for {role} -> {package_path}")
        record = file_records.get(package_path)
        if not isinstance(record, dict) or record.get("sha256") != actual_hash:
            errors.append(f"approval fingerprint {role} is not bound by files[]: {package_path}")
    pattern_path = FINGERPRINT_PATHS["pattern_registry"]
    if pattern_path in names and receipt.get("pattern_registry_sha256") != digest(view.read(pattern_path)):
        errors.append("approval pattern_registry_sha256 does not match packaged pattern registry")

    workbook = receipt.get("workbook") if isinstance(receipt.get("workbook"), dict) else {}
    source_workbook_name = workbook.get("file_name")
    if (
        not isinstance(source_workbook_name, str)
        or PurePosixPath(source_workbook_name).name != source_workbook_name
        or not source_workbook_name.lower().endswith(".xlsx")
    ):
        errors.append("approval workbook.file_name must be an XLSX basename")
    if APPROVAL_WORKBOOK_PATH not in names:
        errors.append(f"approved package lacks workbook evidence: {APPROVAL_WORKBOOK_PATH}")
        return
    workbook_bytes = view.read(APPROVAL_WORKBOOK_PATH)
    workbook_hash = digest(workbook_bytes)
    if workbook.get("sha256") != workbook_hash:
        errors.append("approval workbook SHA-256 does not match packaged workbook evidence")
    workbook_record = file_records.get(APPROVAL_WORKBOOK_PATH)
    if not isinstance(workbook_record, dict) or workbook_record.get("sha256") != workbook_hash:
        errors.append("approval workbook evidence is not hash-bound in reference_pack.json files[]")
    elif workbook_record.get("role") != "approval_evidence":
        errors.append("approval workbook files[] role must be approval_evidence")
    validate_workbook_evidence(workbook_bytes, receipt, pack_brand, errors)


def validate(view: PackageView) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    names = set(view.names())
    if "reference_pack.json" not in names:
        errors.append("ZIP/directory root must contain reference_pack.json")
        return {"status": "fail", "errors": errors, "warnings": warnings}
    if any(name != "reference_pack.json" and name.endswith("/reference_pack.json") for name in names):
        errors.append("nested reference_pack.json is not a valid entrypoint")

    pack = load_json(view, "reference_pack.json", errors)
    if pack is None:
        return {"status": "fail", "errors": errors, "warnings": warnings}
    validate_with_schema(pack, "reference_pack", "reference_pack.json", errors)
    missing = sorted(REQUIRED_TOP - set(pack))
    if missing:
        errors.append(f"reference_pack.json missing keys: {', '.join(missing)}")
    if pack.get("schema_version") != "1.0.0":
        errors.append("reference_pack.json schema_version must be 1.0.0")
    if pack.get("profile") != "frontmind-content-reference-pack-v1":
        errors.append("reference_pack.json profile must be frontmind-content-reference-pack-v1")
    if not isinstance(pack.get("pack_id"), str) or not re.fullmatch(r"rp_[a-z0-9][a-z0-9_-]{5,80}", pack["pack_id"]):
        errors.append("reference_pack.json pack_id is invalid")
    if not isinstance(pack.get("version"), int) or isinstance(pack.get("version"), bool) or pack["version"] < 1:
        errors.append("reference_pack.json version must be a positive integer")
    brand = pack.get("brand")
    if not isinstance(brand, dict) or not isinstance(brand.get("canonical_name"), str) or not brand.get("canonical_name").strip():
        errors.append("reference_pack.json brand.canonical_name is required")
    if not isinstance(brand, dict) or not isinstance(brand.get("aliases"), list):
        errors.append("reference_pack.json brand.aliases must be an array")

    knowledge_base = pack.get("knowledge_base", {})
    if not isinstance(knowledge_base, dict):
        errors.append("knowledge_base must be an object")
        knowledge_base = {}
    package_sha256 = knowledge_base.get("package_sha256")
    if not isinstance(package_sha256, str) or not SHA256.fullmatch(package_sha256):
        errors.append("knowledge_base.package_sha256 must be a lowercase SHA-256")
    if not isinstance(knowledge_base.get("profile"), str) or not knowledge_base.get("profile"):
        errors.append("knowledge_base.profile is required")

    registry_paths = pack.get("registries") if isinstance(pack.get("registries"), dict) else {}
    writing_assets = pack.get("writing_assets") if isinstance(pack.get("writing_assets"), dict) else {}
    diagnostics = pack.get("diagnostics") if isinstance(pack.get("diagnostics"), dict) else {}
    path_fields = [
        pack.get("approval_receipt_path"),
        pack.get("approval_evidence_path"),
        pack.get("content_pattern_registry_path"),
        pack.get("brand_facts_path"),
        diagnostics.get("adapter_report_path"),
        *(knowledge_base.get(key) for key in ("original_package_path", "package_manifest_path", "source_index_path", "knowledge_tree_path")),
        *(registry_paths.get(key) for key in ("knowledge_registry_path", "source_registry_path", "claim_registry_path", "image_registry_path")),
        *(writing_assets.get(key) for key in ("positioning_path", "voice_token_path", "visual_rules_path", "faq_library_path")),
    ]
    for value in path_fields:
        if not isinstance(value, str) or not safe_relative(value):
            errors.append(f"invalid required relative path: {value!r}")
        elif value not in names:
            errors.append(f"referenced file absent: {value}")
    trend_path = writing_assets.get("trend_viewpoints_path")
    if trend_path is not None:
        if not isinstance(trend_path, str) or not safe_relative(trend_path):
            errors.append(f"invalid optional trend_viewpoints_path: {trend_path!r}")
        elif trend_path not in names:
            errors.append(f"referenced trend file absent: {trend_path}")

    original_manifest = validate_original_knowledge_package(view, names, knowledge_base, errors)
    manifest: dict[str, Any] | None = None
    manifest_path = knowledge_base.get("package_manifest_path")
    if isinstance(manifest_path, str) and manifest_path in names:
        manifest = load_json(view, manifest_path, errors)
        if manifest is not None:
            if str(manifest.get("schemaVersion")) != str(knowledge_base.get("schema_version")):
                errors.append(f"{manifest_path}: schemaVersion does not match knowledge_base.schema_version")
            if manifest.get("profile") != knowledge_base.get("profile"):
                errors.append(f"{manifest_path}: profile does not match knowledge_base.profile")
            if manifest.get("schemaVersion") != 4 or manifest.get("profile") != "dashboard-enterprise-v1":
                errors.append(f"{manifest_path}: formal KB must be schemaVersion=4/profile=dashboard-enterprise-v1")
            for collection in ("documents", "assets"):
                if not isinstance(manifest.get(collection), list):
                    errors.append(f"{manifest_path}: {collection} must be an array")
            if original_manifest is not None and manifest != original_manifest:
                errors.append(f"{manifest_path}: manifest differs from the original KB ZIP manifest")

    seen_paths: set[str] = set()
    records_by_path: dict[str, dict[str, Any]] = {}
    file_records = pack.get("files", [])
    if not isinstance(file_records, list) or len(file_records) < 12:
        errors.append("reference_pack.json files must contain at least 12 canonical records")
        file_records = file_records if isinstance(file_records, list) else []
    for index, record in enumerate(file_records):
        if not isinstance(record, dict):
            errors.append(f"files[{index}] must be object")
            continue
        path = record.get("path")
        expected = record.get("sha256")
        if not isinstance(path, str) or not safe_relative(path):
            errors.append(f"files[{index}] has unsafe path")
            continue
        if path in seen_paths:
            errors.append(f"duplicate files[] path: {path}")
        seen_paths.add(path)
        records_by_path[path] = record
        if path not in names:
            errors.append(f"files[] path absent: {path}")
            continue
        if not isinstance(expected, str) or not SHA256.fullmatch(expected):
            errors.append(f"files[{index}] invalid sha256: {path}")
        elif digest(view.read(path)) != expected:
            errors.append(f"sha256 mismatch: {path}")
    unregistered_required = [value for value in path_fields if isinstance(value, str) and value not in seen_paths]
    if unregistered_required:
        errors.append(f"required paths absent from files[]: {', '.join(unregistered_required)}")
    unregistered_files = sorted((names - {"reference_pack.json"}) - seen_paths)
    if unregistered_files:
        errors.append(f"package files absent from files[]: {', '.join(unregistered_files)}")
    phantom_records = sorted(seen_paths - (names - {"reference_pack.json"}))
    if phantom_records:
        errors.append(f"files[] entries have no package file: {', '.join(phantom_records)}")

    expected_file_roles = {
        pack.get("approval_receipt_path"): "approval_receipt",
        pack.get("approval_evidence_path"): "approval_evidence",
        pack.get("content_pattern_registry_path"): "content_pattern_registry",
        pack.get("brand_facts_path"): "brand_facts",
        diagnostics.get("adapter_report_path"): "adapter_report",
        knowledge_base.get("original_package_path"): "knowledge_source_package",
        knowledge_base.get("package_manifest_path"): "knowledge_manifest",
        knowledge_base.get("source_index_path"): "knowledge_index",
        knowledge_base.get("knowledge_tree_path"): "knowledge_tree",
        registry_paths.get("knowledge_registry_path"): "knowledge_registry",
        registry_paths.get("source_registry_path"): "source_registry",
        registry_paths.get("claim_registry_path"): "claim_registry",
        registry_paths.get("image_registry_path"): "image_registry",
        writing_assets.get("positioning_path"): "positioning",
        writing_assets.get("voice_token_path"): "voice_tokens",
        writing_assets.get("visual_rules_path"): "visual_rules",
        writing_assets.get("faq_library_path"): "faq_library",
    }
    if trend_path is not None:
        expected_file_roles[trend_path] = "trend_viewpoints"
    for path, expected_role in expected_file_roles.items():
        if not isinstance(path, str):
            continue
        record = records_by_path.get(path)
        if isinstance(record, dict) and record.get("role") != expected_role:
            errors.append(f"files[] role for {path} must be {expected_role}")

    knowledge_registry: dict[str, Any] | None = None
    source_registry: dict[str, Any] | None = None
    claim_registry: dict[str, Any] | None = None
    image_registry: dict[str, Any] | None = None
    brand_facts: dict[str, Any] | None = None
    registries = registry_paths
    if isinstance(registries, dict):
        knowledge_path = registries.get("knowledge_registry_path", "")
        source_path = registries.get("source_registry_path", "")
        claim_path = registries.get("claim_registry_path", "")
        image_path = registries.get("image_registry_path", "")
        knowledge_registry = validate_registry(view, knowledge_path, "knowledge_registry", "knowledge_units", errors)
        source_registry = validate_registry(view, source_path, "source_registry", "sources", errors)
        claim_registry = validate_registry(view, claim_path, "claim_registry", "claims", errors)
        image_registry = validate_registry(view, image_path, "image_registry", "images", errors)

        knowledge_ids = unique_ids(knowledge_registry, "knowledge_units", "knowledge_id", knowledge_path, "kn_", errors)
        source_ids = unique_ids(source_registry, "sources", "source_id", source_path, "src_", errors)
        claim_ids = unique_ids(claim_registry, "claims", "claim_id", claim_path, "clm_", errors)
        image_ids = unique_ids(image_registry, "images", "asset_id", image_path, "img_", errors)

        for label, value in (("knowledge registry", knowledge_registry), ("claim registry", claim_registry), ("image registry", image_registry)):
            missing_sources = sorted(referenced_ids(value, "source_ids") - source_ids)
            if missing_sources:
                errors.append(f"{label} references unknown source_ids: {', '.join(missing_sources)}")
        missing_knowledge = sorted(referenced_ids(claim_registry, "knowledge_ids") - knowledge_ids)
        if missing_knowledge:
            errors.append(f"claim registry references unknown knowledge_ids: {', '.join(missing_knowledge)}")
        missing_assets = sorted(referenced_ids(knowledge_registry, "asset_ids") - image_ids)
        if missing_assets:
            errors.append(f"knowledge registry references unknown asset_ids: {', '.join(missing_assets)}")

        for index, claim in enumerate((claim_registry or {}).get("claims", [])):
            if not isinstance(claim, dict):
                continue
            original = claim.get("original_evidence")
            if not isinstance(original, dict):
                continue
            for record_ref in original.get("record_refs") or []:
                if not isinstance(record_ref, str) or not safe_relative(record_ref):
                    errors.append(f"{claim_path}: claims[{index}] has unsafe original_evidence record_ref: {record_ref!r}")
                elif record_ref not in names or record_ref not in records_by_path:
                    errors.append(
                        f"{claim_path}: claims[{index}] original_evidence record_ref is not a hash-bound Pack file: {record_ref}"
                    )

        for index, unit in enumerate((knowledge_registry or {}).get("knowledge_units", [])):
            if not isinstance(unit, dict):
                continue
            content = unit.get("content")
            content_hash = unit.get("content_sha256")
            if not isinstance(content, str) or not isinstance(content_hash, str) or digest(content.encode("utf-8")) != content_hash:
                errors.append(f"{knowledge_path}: knowledge_units[{index}] content_sha256 mismatch")

        for index, source in enumerate((source_registry or {}).get("sources", [])):
            if not isinstance(source, dict):
                continue
            file_path = source.get("file_path")
            url = source.get("url")
            if not isinstance(file_path, str) and not isinstance(url, str):
                errors.append(f"{source_path}: sources[{index}] requires a non-null url or file_path")
            if isinstance(file_path, str) and (not safe_relative(file_path) or file_path not in names):
                errors.append(f"{source_path}: sources[{index}] local file is missing or unsafe: {file_path}")

        for index, image in enumerate((image_registry or {}).get("images", [])):
            if not isinstance(image, dict):
                continue
            source_kind = image.get("source_kind")
            allowed_roles = set(image.get("allowed_roles") or [])
            proof_roles = {"entity_proof", "product_proof", "case_proof", "event_proof"}
            if source_kind == "generated_explanatory" and allowed_roles & proof_roles:
                errors.append(
                    f"{image_path}: images[{index}] generated_explanatory asset cannot carry proof roles: "
                    f"{sorted(allowed_roles & proof_roles)}"
                )
            if source_kind == "generated_data_chart" and not image.get("source_ids"):
                errors.append(f"{image_path}: images[{index}] generated_data_chart requires source_ids")
            file_path = image.get("file_path")
            image_hash = image.get("sha256")
            if isinstance(file_path, str):
                if not safe_relative(file_path) or file_path not in names:
                    errors.append(f"{image_path}: images[{index}] local file is missing or unsafe: {file_path}")
                elif isinstance(image_hash, str) and digest(view.read(file_path)) != image_hash:
                    errors.append(f"{image_path}: images[{index}] sha256 mismatch: {file_path}")

        brand_facts_path = pack.get("brand_facts_path")
        if isinstance(brand_facts_path, str) and brand_facts_path in names:
            brand_facts = load_json(view, brand_facts_path, errors)
            if brand_facts is not None:
                validate_with_schema(brand_facts, "brand_facts", brand_facts_path, errors)
                missing_fact_sources = sorted(referenced_ids(brand_facts, "source_ids") - source_ids)
                missing_fact_claims = sorted(referenced_ids(brand_facts, "claim_ids") - claim_ids)
                if missing_fact_sources:
                    errors.append(f"brand facts reference unknown source_ids: {', '.join(missing_fact_sources)}")
                if missing_fact_claims:
                    errors.append(f"brand facts reference unknown claim_ids: {', '.join(missing_fact_claims)}")

    canonical_pointers = {
        "approval_receipt_path": (pack.get("approval_receipt_path"), "approval/approval.json"),
        "approval_evidence_path": (pack.get("approval_evidence_path"), APPROVAL_WORKBOOK_PATH),
        "content_pattern_registry_path": (
            pack.get("content_pattern_registry_path"), FINGERPRINT_PATHS["pattern_registry"]
        ),
        "adapter_report_path": (diagnostics.get("adapter_report_path"), FINGERPRINT_PATHS["adapter_report"]),
        "original_package_path": (knowledge_base.get("original_package_path"), "sources/original_kb.zip"),
        "brand_facts_path": (pack.get("brand_facts_path"), FINGERPRINT_PATHS["brand_facts"]),
        "knowledge_registry_path": (registry_paths.get("knowledge_registry_path"), FINGERPRINT_PATHS["knowledge_registry"]),
        "source_registry_path": (registry_paths.get("source_registry_path"), FINGERPRINT_PATHS["source_registry"]),
        "claim_registry_path": (registry_paths.get("claim_registry_path"), FINGERPRINT_PATHS["claim_registry"]),
        "image_registry_path": (registry_paths.get("image_registry_path"), FINGERPRINT_PATHS["image_registry"]),
        "positioning_path": (writing_assets.get("positioning_path"), FINGERPRINT_PATHS["information_evidence"]),
        "voice_token_path": (writing_assets.get("voice_token_path"), FINGERPRINT_PATHS["voice_contract"]),
        "visual_rules_path": (writing_assets.get("visual_rules_path"), FINGERPRINT_PATHS["visual_reference"]),
        "faq_library_path": (writing_assets.get("faq_library_path"), FINGERPRINT_PATHS["question_library"]),
    }
    for field, (actual, expected) in canonical_pointers.items():
        if actual != expected:
            errors.append(f"Reference Pack {field} must use canonical path {expected}, found {actual!r}")
    if trend_path is not None and trend_path != FINGERPRINT_PATHS["trend_reference"]:
        errors.append(f"Reference Pack trend_viewpoints_path must use {FINGERPRINT_PATHS['trend_reference']}")

    stage_paths = {
        "adapter_report": diagnostics.get("adapter_report_path"),
        "pattern_registry": pack.get("content_pattern_registry_path"),
        "information_evidence": writing_assets.get("positioning_path"),
        "voice_contract": writing_assets.get("voice_token_path"),
        "visual_reference": writing_assets.get("visual_rules_path"),
        "question_library": writing_assets.get("faq_library_path"),
    }
    payloads: dict[str, dict[str, Any] | None] = {
        "knowledge_registry": knowledge_registry,
        "source_registry": source_registry,
        "claim_registry": claim_registry,
        "image_registry": image_registry,
        "brand_facts": brand_facts,
        "kb_manifest": manifest,
        "knowledge_base_contract": knowledge_base,
    }
    for role, path in stage_paths.items():
        payloads[role] = load_required_json(view, path, role, names, errors)
    payloads["trend_reference"] = (
        load_required_json(view, trend_path, "trend_reference", names, errors)
        if trend_path is not None else None
    )
    for role, schema_key in (
        ("information_evidence", "information_evidence"),
        ("voice_contract", "voice_contract"),
        ("visual_reference", "visual_reference"),
        ("question_library", "question_library"),
    ):
        value = payloads.get(role)
        path = stage_paths[role]
        if isinstance(value, dict) and isinstance(path, str):
            validate_with_schema(value, schema_key, path, errors)

    approval_path = pack.get("approval_receipt_path")
    receipt = load_required_json(view, approval_path, "approval receipt", names, errors)
    if receipt is not None and isinstance(approval_path, str):
        validate_with_schema(receipt, "approval", approval_path, errors)
    payloads["approval_receipt"] = receipt
    pack_brand = brand.get("canonical_name") if isinstance(brand, dict) else None
    validate_stage_semantics(payloads, pack_brand, errors)
    validate_approval_binding(
        view,
        names,
        receipt,
        pack_brand,
        records_by_path,
        trend_path is not None,
        payloads,
        errors,
    )

    return {
        "status": "pass" if not errors else "fail",
        "entrypoint": "reference_pack.json",
        "pack_version": pack.get("version"),
        "checked_files": len(names),
        "errors": errors,
        "warnings": warnings,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("package", type=Path)
    args = parser.parse_args()
    path = args.package.resolve()
    try:
        view: PackageView = DirectoryView(path) if path.is_dir() else ZipView(path)
        report = validate(view)
        if not path.is_dir():
            match = ZIP_NAME.fullmatch(path.name)
            if match is None:
                report["errors"].append("ZIP name must be S0_{brand_label}_reference_pack_v{N}.zip")
                report["status"] = "fail"
            elif report.get("pack_version") != int(match.group("version")):
                report["errors"].append("ZIP filename version does not match reference_pack.json version")
                report["status"] = "fail"
    except (OSError, ValueError, zipfile.BadZipFile) as exc:
        report = {"status": "fail", "errors": [str(exc)], "warnings": []}
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
