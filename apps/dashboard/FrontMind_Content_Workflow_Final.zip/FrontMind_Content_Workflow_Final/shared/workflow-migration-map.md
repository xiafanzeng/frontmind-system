# 旧工作流迁移与继承表

> 本文件只用于迁移审计，不是运行时规则。运行时唯一契约见 `Master_Control/FrontMind_Content_Workflow_Master.md` 与根 `shared/`。

## 1. 节点迁移

| 旧能力/节点 | 新位置 | 处理 |
|---|---|---|
| S1 企业知识与事实整理 | Reference Pack 输入适配与 `brand_facts` | 保留既有知识库，不加入问题发现 |
| S2 营销图谱 | 工作流外 | 删除依赖；不再生成问题或内容策略 |
| S3 趋势扫描 | Reference Pack `trend_viewpoints` | 只保留有来源、可写入正文的可选观点 |
| S4 品牌定位 | Reference Pack `positioning` | 保留定位、目标人群、价值主张和 RTB |
| S5 问题监控 | E0.5 单问题监控 | 从企业级诊断改为对当前已确认问题的答案/信源输入分析 |
| S5.5 语义资产评分 | 无 | 删除；评分不进入文章规划或正文 |
| S6 话语体系 | Reference Pack `voice_tokens` | 保留为机器可执行写作约束 |
| S7 视觉体系 | Reference Pack `visual_rules` + image registry | 保留真实视觉资产、提示词和权利边界 |
| S8 问答架构 | Reference Pack FAQ 候选池 + E1 单篇问题蓝图 | 删除日历和预写长答案；保留问题/证据线索 |
| S9 行动建议 | 无 | 删除；当前问题的内容规划集中在 E1 |
| S10 报告/确认交付 | Reference Pack Builder/Validator | 不生成策略报告；只组装并验证资料包 |
| E0 | E0 | 改为 Pack/Job/图片/registry 契约校验 |
| 新增单问题监控 | E0.5 | 接收 AI 答案和信源，抽竞品并拆标杆结构 |
| E1 | E1 | 从全量选题矩阵改为问题深挖与后台选一个 P 模式 |
| E2 | E2 | 生成 canonical Content Model 初稿 |
| 新增证据预检 | E2.5 | 在视觉与终审前阻断主张、统计、价格、比较输入和原创信息缺口，不改写正文 |
| E3 | E3 | 继承图片库规则，视觉继续承担解释和证明 |
| E4 | E4 | 完成编辑修订与多模态终审，冻结可供 E5/E6 回退的安全正本 |
| E5 分发编排师 / HarnessGEO 正本覆盖 | E5 算法候选优化 | 取消分发；候选不覆盖编辑正本，必须事实 diff |
| 新增终审交付 | E6 | 对候选执行事实回归；不通过则沿用 E4 安全正本，并同源输出 DOCX/HTML/JSON-LD |

## 2. 旧文章类型迁移

| 旧编号 | 新归属 |
|---|---|
| A1 推荐/榜单 | P01 |
| A2 测评解析 | 明确对象对比归 P02；可信度评估归 P03 |
| A3 场景方案 | P05 |
| A4 技术科普 | P04 |
| A5 品牌故事 | 不再作为独立模式；有事实的深度报道归 P13 |
| A6 选型指南 | P06 |
| A7 避坑指南 | P08 |
| A8 用户案例 | 不再作为宽泛文章；满足案例五要素时归 P11 |
| A9 趋势洞察 | 有论点和证据时归 P14；否则只作为趋势支持段 |
| A10 FAQ | 变为所有模式的 5-8 条横向模块 |
| A11 教程 | P07 |
| A12 数据报告 | 有研究方法和数据时归 P09；否则不生产 |
| B1 白皮书 | P09 |
| B2 技术文档 | P10 |
| B3 案例研究 | P11 |
| B4 用例分析 | 场景回答归 P05；技术实施归 P10 |
| C1a 事件新闻 | P12 |
| C1b 品牌深度稿 | P13 |
| C2 第三方报道 | 可信评估归 P03；品牌特写归 P13 |
| C3 行业评论 | P14 |
| C4 风险回应 | P15 |
| D1-D3 实体/平台资料修正 | 不属于内容制作模式；回到企业知识库维护 |

## 3. 共享文件保留与替换

| 文件 | 处理 |
|---|---|
| 旧 `geo_pdf_generator.py` | 从 active shared 移出，只保留不可执行审计文本；主流程不生成 PDF |
| 旧 shared `md2docx.py` / `html_renderer.py` | 从 active shared 移出，只保留不可执行审计文本；E6 是 DOCX/HTML 唯一同源渲染入口 |
| `enterprise-image-library-policy.md` | 保留真实图片来源、权利、asset_id 和缺图阻断，统一到 image registry |
| `brand-voice-token-schema.md` | 保留首选词、禁用词、语气与句式，但不能覆盖事实规则 |
| `output-format-standard.md` | 重写为 Reference Pack 与 DOCX/HTML 同源交付 |
| 旧类型风险、标题、语义优势政策 | 提炼到 P01-P15、`writing-policy.md` 与质量门，不再维护旧编号分支 |

## 4. 契约修复

- ZIP 入口统一为 `reference_pack.json`，不再出现带节点/品牌前缀的替代文件名。
- PDF 从 required contract 移除。
- knowledge、source、claim、image registries 使用唯一 schema；固定 ID 前缀 `kn_`/`src_`/`clm_`/`img_`，图片固定 `images[] + sha256`。
- Reference Pack 必须记录原知识包 profile/SHA-256，并包含状态为 `approved` 的确认回执。
- 两层品牌事实结构统一为根 `shared/brand_facts.schema.json`。
- 所有 Skill、模板、脚本与 Markdown 相对引用必须通过全局 validator。
