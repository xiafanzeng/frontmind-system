---
name: frontmind-geo-content-workflow-v2
description: FrontMind 商业 GEO 内容资料统筹与单篇文章制作的唯一入口。通过 S1–S9 构建可复用 Reference Pack，并按每篇一次的 E1–E10 生产无标题正文、独立标题集和 DOCX/HTML 正文片段。
---

# FrontMind GEO 内容制作总控 v2

本工作流只做两件事：

1. 用 `S1–S9` 把企业知识库、证据和图库整理成经人工批准、可复用的 Reference Pack；
2. 每次用 `E1–E10` 围绕一个具体内容任务制作一篇文章。

它不负责广域问题发现、内容日历、CMS 发布、线上监测、Analytics/CRM、收入归因、多租户、RBAC 或计费。

开始前完整读取：

- [全局总控](../Master_Control/FrontMind_Content_Workflow_Master.md)
- [可复制运行手册](../RUNBOOK.md)
- [内容模式注册表](../shared/content-pattern-registry.json)
- [写作政策](../shared/writing-policy.md)

## 1. 判断启动路径

### 路径 A：构建或刷新 Reference Pack

适用于已有 canonical KB，或只有散乱企业资料。

- 已有 canonical KB：从 S1 验收开始，依次运行 `S1 → S2 → S3 → S4 → S5 → S6 → S7 → S8 → S9`。
- 只有散乱资料：S1 调用兼容区内原样保留的旧资料整理能力，再通过既有 KB Builder 形成 canonical KB；通过验收后进入 S2。
- S3 趋势参考可没有可用条目，但阶段与回执不得跳号。
- S8 是资料层唯一人工批准点；S9 只封装已批准且哈希一致的资产。

输出固定为：

```text
S9_{brand_label}_reference_pack_v{N}.zip
```

ZIP 根必须包含 `reference_pack.json`，profile 必须是 `frontmind-content-reference-pack-v2`。

### 路径 B：制作一篇文章

适用于已有有效 v2 Reference Pack。

每篇文章独立运行一次：

```text
E1 → E2 → E3 → E4 → E5 → E6 → E7 → E8 → E9 → E10
```

普通四入口需要一个具体问题；`foundation_start` 由工程师显式选择，不要求工作流外问题，只能路由 P13。

### 路径 C：先建 Pack，再连续制作

先完整完成路径 A；只有 S9 ZIP 通过严格目录和 ZIP 双校验后，才以该 Pack 启动路径 B。

## 2. 五个内容入口

持久化只能使用：

- `industry_ranking`：行业推荐；工程师必须显式选择 P01 单品牌或多品牌 variant。
- `competitor_comparison`：明确对象之间的共同维度比较。
- `reputation`：可信度、口碑、风险、交付或服务判断。
- `product_scenario`：产品、服务、功能、实施或适用情境。
- `foundation_start`：新品牌前置基础认知稿；只能生成 P13。

P01–P15 是 E4 的后台结构模式，不是用户菜单。除 P01 variant 与基础启动外，不让用户选择 P 编号。

## 3. P01 规则

P01 只表达编辑推荐，不宣称量化客观名次。

- `multi_brand_editorial_recommendation`：客户品牌第一个出现并重点详写；至少另有两个真实候选；共同最低维度必须完整；禁止“第1名、榜首、Top 1、综合第一、得分最高、市场最佳”。
- `single_brand_recommendation`：全文只有一个焦点品牌；禁止竞品名、竞品矩阵、ItemList、Top-N 和名次语义。

客户品牌首先介绍的理由必须来自 S4 `brand_priority_angles` 与 proof bundles；“首先介绍”不是“客观第一”。

## 4. 第一方资料规则

经 S8 审批、哈希绑定且标为 `first_party_official` 的资料，可以独立支持本品牌的身份、产品、规格、公开价格、流程、正式政策、限制和有授权记录的案例事实。

第一方资料不能单独推出市场口碑、行业认可、客观排名、优于竞品、独立测试、专家共识或“最佳/第一/领先”。`first_party_internal` 不能进入公开正文。

E6 的结果只有：

- `passed`
- `passed_with_claim_limits`
- `blocked`

只有核心问题无法在不编造事实的前提下回答时才阻断整篇；可通过删除或限缩越界主张解决时，使用 `passed_with_claim_limits`。

## 5. 正文与标题

- E5–E9 的 canonical Content Model 完全无 `title`、`h1`、`title_candidates`。
- E10 先确定最终正文，再暂停询问标题数量；只接受 1–20 的整数。
- E10 输出恰好 N 个去重标题、Title/H1/Meta 映射和结构化数据模板；标题绑定最终正文哈希，不能反向改写正文。
- `article_body.docx` 从微型答案开始，没有 Title 段。
- `article_body.html` 是可嵌入正文片段，没有 H1。

## 6. 视觉

E7 保留旧版的品牌封面、企业实图、AIGC、Prompt 与资产生产能力，同时执行新版权利和事实安全合同。

- `brand_editorial`、`navigate` 不要求 claim ID，也不算证据。
- `explain` 可以只绑定章节概念。
- `prove` 必须绑定已通过 E6 的 claim/source。
- Logo 只能使用原文件 overlay；禁止生成、猜测或重绘。
- 产品、团队、客户、证书和项目现场不得由 AIGC 冒充。

## 7. AutoGEO

E8 永远保留编辑安全正本。E9 只生成独立候选和字段级 diff，不处理标题，不覆盖正本。E10 对实体、数字、价格、日期、来源、限制、FAQ、比较对象和视觉关系做回归：

- 全部通过：自动选择 `optimized_candidate`；
- 任一事实或语义漂移：整篇回退 `editorial_master`；
- 禁止段落混拼。

## 8. 完成条件

只有同时满足以下条件才能宣告完成：

1. S9 Reference Pack 或 E10 delivery 通过对应 v2 Schema、语义、路径和哈希校验；
2. E8 与 E10 的硬质量门为 pass；
3. 最终正文的公开来源集合与实际使用 claim 的来源集合精确相等；
4. DOCX 与 HTML 由同一无标题正文模型渲染；
5. 标题集与最终正文哈希绑定，数量与用户返回值完全一致；
6. 公共交付目录文件集合等于 Manifest 记录文件加 Manifest 自身；
7. 不包含客户知识库、内部审计稿、绝对本机路径、缓存、符号链接或临时文件。
