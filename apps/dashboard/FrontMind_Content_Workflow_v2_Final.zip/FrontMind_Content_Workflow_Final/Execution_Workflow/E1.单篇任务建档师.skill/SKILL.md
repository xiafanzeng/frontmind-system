---
name: frontmind-single-article-intake
description: >
  E1 单篇任务建档师。安全落地已签 Reference Pack，正规化五类内容入口，建立单篇 Content Job 与自适应范围分析；
  不做监控拆解、选型、正文、标题或发布。
---

# E1 单篇任务建档师

## 职责

E1 是执行层唯一入口，只建立“一家企业、一个内容任务、一个只读 Reference Pack”。运行顺序固定为：

1. 安全展开并双重校验签名 Reference Pack ZIP；
2. 导入并正规化 Content Job；
3. 生成并校验 `scope_analysis.json`；
4. 将任务交给 E2。签名 Pack 从此只读。

完整链为 `E1 → E2 → E3 → E4 → E5 → E6 → E7 → E8 → E9 → E10`。

## 五个唯一入口

`content_job.entry_category` 只允许：

- `industry_ranking`
- `competitor_comparison`
- `reputation`
- `product_scenario`
- `foundation_start`

`industry` 仅可在本阶段导入边界正规化为 `industry_ranking`，canonical 文件不得保留别名。

普通四入口必须已有一个 Workflow 外确认的问题，`task.question_origin=external_confirmed`。`foundation_start` 是工程师手动启动的基础品牌深度特写：

- 问题由后续蓝图阶段从企业资料推导，`question_text=null`；
- `manual_foundation_selection=true` 且 `foundation_subject` 非空；
- 后台模式只能是 P13；
- 不需要监控双表，`monitoring_input_path=null`；
- 不能作为自动兜底入口。

`industry_ranking` 必须在 E1 明确 P01 变体，且只允许：

- `multi_brand_editorial_recommendation`
- `single_brand_recommendation`

前者是至少三家真实候选的编辑推荐，客户品牌首先展示；后者只写客户品牌且不得出现竞品或竞品矩阵。二者都不是“客观第一名”。

## 输入与机器契约

- 签名 Reference Pack ZIP；
- raw Content Job；
- 根 `shared/content_job.schema.json`、`scope_analysis.schema.json` 和 Pack 内经签名的 `shared/content-pattern-registry.json`；
- 普通四入口还需两张原始监控表的 job-local 路径；`foundation_start` 不接收监控表。

所有路径必须位于显式 job root 内，源 ZIP 可在 root 外但由文件名与 SHA256 绑定。禁止手工 `unzip -o`。

```bash
python3 -B E1.单篇任务建档师.skill/scripts/stage_reference_pack.py \
  --zip /path/to/S9_brand_reference_pack_v1.zip \
  --output-dir /path/to/job/reference \
  --manifest-output /path/to/job/00_input/E1_reference_pack_staging.json \
  --job-package-root /path/to/job

python3 -B E1.单篇任务建档师.skill/scripts/normalize_content_job.py \
  --input /path/to/job/00_input/content_job.raw.json \
  --output /path/to/job/00_input/content_job.json \
  --receipt /path/to/job/00_input/E1_content_job_normalization.json
```

`scope_analysis.json` 直接满足根 Schema，记录地区范围、决策角色与问题、判断标准、专业深度、资料截止日、新鲜度等级、推断依据和真正会改变文章结论的澄清项。不能用固定“地区/人群/时间”字符串代替分析；没有地域意义时写 `not_applicable`，不是伪填“全国”。

## 输出与暂停门

- `reference/`：安全展开的只读 Pack；
- `00_input/E1_reference_pack_staging.json`；
- `00_input/content_job.json`；
- `00_input/E1_content_job_normalization.json`；
- `00_input/scope_analysis.json`。

普通四入口继续 E2；`foundation_start` 跳过 E2，直接进入 E3。若范围澄清会实质改变对象、地区、时效或专业深度，E1 暂停一次等待确认；不会改变正文决策的细节不得制造暂停。

## 禁止

- 在 E1 做广域选题发现、P 模式菜单、文章结构或标题；
- 把 `foundation_start` 自动分配给普通问题；
- 把客户品牌首位展示写成市场第一、评分第一或权威排名；
- 修改 staged Pack 内任何 Registry、事实或图片；
- 生成渠道、CMS、发布或回滚任务。
