---
name: frontmind-body-regression-title-map-and-dual-format-delivery
description: >
  E10 回归选稿与双格式交付师。自动比较 E9 正文候选与 E8 安全正本；无事实漂移、证据变化或质量回归时整篇采用候选，否则整篇回退 E8。暂停询问 1–20 个标题数量，生成独立 Title Map，最后由同一无标题 Content Model 输出 DOCX 正文、HTML 正文片段、结构化数据模板与发布元数据映射；不做 CMS 或分发。
---

# E10 回归选稿与双格式交付师

## 1. 责任边界

E10 只完成四件事：

1. 在完整 E8 正本与完整 E9 候选之间自动二选一；
2. 暂停并询问用户需要多少个标题，只接受 1–20；
3. 将标题写入独立 Title Map，正文模型始终无 `title/h1/title_candidates/meta_description`；
4. 从同一个批准正文渲染无标题 DOCX 与无页面外壳的 HTML 正文片段。

任何候选失败均整篇回退 E8；禁止拼接两稿、局部采用或让 AutoGEO 覆盖安全正本。

## 2. 正文选择

运行 `scripts/regression_review.py`。必需输入是 E8 正文与 hash、E8 Quality Report、E9 report，候选成功时再传 candidate/diff，以及 E6 已批准的 runtime claim/source registries 与 evidence receipt。

自动采用 E9 的充分条件：

- 根 `content_model.schema.json` v2 通过，且 `entry_category/question_origin/pattern_id/pattern_variant` 不变；
- H2/H3、block/FAQ、claim/source/reference、visual、结构化数据类型和非正文拓扑完全不变；
- diff 逐字段覆盖真实变化，路径、before/after 与 hash 无伪造；
- 数字、日期、币种仍绑定原字段和局部语境，正文可见证据实体集合不变；
- Answer-first、材料主张绑定、信源精确集合、反模板腔、FAQ/章节差异化均无回归；
- 未新增表格、内部元语言、绝对排名或无证据结论。

机器无法确定即视为失败，选择 `editorial_master`。E9 未安装或调用失败不是内容失败，也直接沿用 E8。

## 3. 标题数量暂停点

正文选择完成后必须暂停并询问：

> 这篇文章需要生成多少个标题选项？请输入 1–20。

收到回答后运行 `scripts/create_title_count_receipt.py`，回执必须绑定批准正文 canonical SHA256。未取得回执不得生成标题或交付。随后按根 `title_map.schema.json` 生成恰好相同数量的 Title Map；每项包含 Title、H1 建议、Meta Description、公式/角度、支持 claim 和全部风险检查。

标题可体现编辑角度，但不得新增正文没有的实体、数字、年份、客观排名或结论。P01 的客户品牌先展示是编辑优先级，不得写成“第一名、榜首、得分最高”。

## 4. 无标题双格式交付

运行 `scripts/render_delivery.py`：

- `article_body.docx` 从微型答案开始，不含 Title/H1；
- `article_body.html` 仅为 `<article>` 正文片段，不含 `html/head/title/h1/script`；
- 两种正文都只有 H2/H3、无表格、FAQ/来源/图片顺序同源；
- 图片重新核验 E7 manifest、base/runtime registry hash、授权、角色、claim/source 相关性和正整数尺寸；
- `structured_data_template.json` 的 Article headline 使用 `{{TITLE_ID}}`，Meta 使用 `{{META_DESCRIPTION}}`；
- `publishing_metadata_map.json` 以同一个 title ID 同步映射 Title/H1/Meta/结构化 headline；
- Product/Review/ItemList 只能用 hash-bound context；Review 必须有经授权一手方法证据，P01-M ItemList 必须是无序编辑集合且不得输出 position。

结构化数据类型必须属于签名 Pack 内当前 P 模式的 `eligible_json_ld`。P01-S 只允许 FAQPage。

## 5. 公开交付与内部审计分离

公开目录必须为空，并且最终只含：

```text
article_body.docx
article_body.html
structured_data_template.json
title_options.md
title_map.json
publishing_metadata_map.json
images/*
delivery_manifest.json
```

`approved_body_source.md`、E10 regression、E8/E9/E6 receipts、render audit 和 final quality report 只放 job-local `internal_audit/`，不得登记进公开 Delivery Manifest，也不得复制进客户目录。公开 Manifest 只使用根 v2 允许的 artifact roles。

## 6. 最终硬门

- 标题数量没有用户回执，或不在 1–20；
- 标题 Map 数量、job/body hash 与回执不一致；
- E9 候选存在任一漂移仍被采用；
- DOCX/HTML 含标题/H1、表格、不同正文或未内嵌图片；
- HTML 不是片段，或结构化数据包含不可见/未绑定值；
- 公开目录混入审核收据、旧文件、绝对本机路径或未登记文件；
- 图片授权、hash、尺寸或语义绑定在交付前发生变化。

出现任一项，不交付；修复对应 E 阶段后重跑。
