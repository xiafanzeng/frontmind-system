# E10 正文候选自动回归契约

E8 是不可变安全正本，E9 仅产生正文候选。E10 只能完整采用其中一份，不能做段落级混合。

候选采用需要同时满足：根 Content Model v2、非正文拓扑不变、E9 diff 全覆盖、字段局部数字/日期/币种绑定不变、claim/source/reference/visual 结构不变、Answer-first 与内容特异性不退化、没有新增模板腔或表格。任一门无法机器确认即回退 E8。

回归输出的 `approved_sha256` 是 canonical JSON（UTF-8、key 排序、紧凑分隔）SHA256。Title Count Receipt、Title Map、结构化数据模板、发布元数据映射和 Delivery Manifest 都必须绑定该同一 hash。

标题不是正文候选的一部分。E10 先冻结正文，再取得 1–20 条数量回执，最后生成独立 Title Map；发布系统按同一 `title_id` 同步注入 Title、H1、Meta Description 和 Article headline。
