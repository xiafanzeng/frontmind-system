#!/usr/bin/env python3
"""Persist the user-selected E10 title count after the mandatory pause."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
ROOT_SHARED = Path(__file__).resolve().parents[3] / "shared"
sys.path.insert(0, str(ROOT_SHARED / "scripts"))
from validate_json_instance import load_json, validate_instance  # noqa: E402


def digest(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--approved-body", type=Path, required=True)
    parser.add_argument("--count", type=int, required=True, choices=range(1, 21), metavar="1..20")
    parser.add_argument("--requested-by", required=True)
    parser.add_argument("--requirement", action="append", default=[])
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    body = load_json(args.approved_body)
    receipt = {
        "schema_version": "2.0.0", "job_id": body.get("job_id"),
        "approved_body_sha256": digest(body), "requested_count": args.count,
        "requested_by": args.requested_by, "requested_at": datetime.now(timezone.utc).isoformat(),
        "requirements": args.requirement,
    }
    schema = load_json(ROOT_SHARED / "title_count_receipt.schema.json")
    errors = validate_instance(receipt, schema, ROOT_SHARED / "title_count_receipt.schema.json")
    if errors:
        raise ValueError("; ".join(error.message for error in errors))
    if args.output.exists() or args.output.is_symlink():
        raise FileExistsError("title-count receipt already exists; create a new E10 revision")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(receipt, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
