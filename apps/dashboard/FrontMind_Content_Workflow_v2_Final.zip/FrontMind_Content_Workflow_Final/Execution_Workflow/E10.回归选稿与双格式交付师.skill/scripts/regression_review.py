#!/usr/bin/env python3
"""Select the E8 safe body or the complete E9 body candidate.

E10 never merges fields from the two revisions.  A candidate is adopted only
when every deterministic identity, fact, evidence and text-quality regression
gate passes.  Any uncertainty selects the byte-for-byte canonical E8 body.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

sys.dont_write_bytecode = True
EXECUTION_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(EXECUTION_ROOT / "shared"))
sys.path.insert(0, str(EXECUTION_ROOT.parent / "shared"))
from reference_equivalence import reference_equivalence_errors  # noqa: E402
from schema_validation import validate_root, validate_schema  # noqa: E402
from text_quality import (  # noqa: E402
    answer_pair_errors,
    article_specificity_errors,
    material_claim_binding_errors,
)
from content_route import validate_entry_pattern_route  # noqa: E402
from candidate_binding import (  # noqa: E402
    model_candidate_binding_errors,
    model_used_claim_ids,
    p01_objective_rank_errors,
)
from source_state import source_state_errors  # noqa: E402


FORBIDDEN = (
    "资料较完整", "相关资料显示", "以审核为准", "服务边界", "信息边界", "保持克制",
    "用户提交资料", "需要说明", "不构成对", "Execution Layer", "证据单元", "待人工复核",
    "HarnessGEO", "AutoGEO", "optimized_by", "第一名", "榜首", "综合第一", "得分最高",
)
FACT_TOKEN_RE = re.compile(
    r"\d{4}年(?:\d{1,2}月(?:\d{1,2}日)?)?|\d{4}-\d{1,2}-\d{1,2}"
    r"|(?<![A-Za-z])\d+(?:\.\d+)?(?:%|％|倍|元|万元|美元)?"
    r"|人民币|美元|港币|欧元|CNY|RMB|USD|HKD|EUR",
    flags=re.I,
)


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain a JSON object")
    return value


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def digest(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def text_digest(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def iter_text_fields(model: dict[str, Any]) -> Iterable[tuple[tuple[Any, ...], str]]:
    lead = model.get("lead") or {}
    for key in ("direct_answer_sentence", "micro_answer"):
        if isinstance(lead.get(key), str):
            yield ("lead", key), lead[key]
    for section_index, section in enumerate(model.get("sections", [])):
        if not isinstance(section, dict):
            continue
        for block_index, block in enumerate(section.get("blocks", [])):
            if isinstance(block, dict) and isinstance(block.get("text"), str):
                yield ("sections", section_index, "blocks", block_index, "text"), block["text"]
        for subsection_index, subsection in enumerate(section.get("subsections", [])):
            if not isinstance(subsection, dict):
                continue
            for block_index, block in enumerate(subsection.get("blocks", [])):
                if isinstance(block, dict) and isinstance(block.get("text"), str):
                    yield (
                        "sections", section_index, "subsections", subsection_index,
                        "blocks", block_index, "text",
                    ), block["text"]
    for index, item in enumerate(model.get("faq", [])):
        if isinstance(item, dict) and isinstance(item.get("answer"), str):
            yield ("faq", index, "answer"), item["answer"]
    conclusion = model.get("conclusion") or {}
    for key in ("summary", "fit", "next_action"):
        if isinstance(conclusion.get(key), str):
            yield ("conclusion", key), conclusion[key]


def body_text(model: dict[str, Any]) -> str:
    chunks = [value for _, value in iter_text_fields(model)]
    chunks.extend(
        str(section.get("h2_question", ""))
        for section in model.get("sections", []) if isinstance(section, dict)
    )
    chunks.extend(
        str(item.get("question", "")) for item in model.get("faq", []) if isinstance(item, dict)
    )
    return "\n".join(chunks)


def fact_bindings(value: str) -> list[dict[str, str]]:
    """Bind every number/date/currency token to a short local subject context."""
    compact = re.sub(r"\s+", "", value)
    offsets: list[int] = []
    position = 0
    for char in value:
        offsets.append(position)
        if not char.isspace():
            position += 1
    offsets.append(position)
    result: list[dict[str, str]] = []
    for match in FACT_TOKEN_RE.finditer(value):
        start, end = offsets[match.start()], offsets[match.end()]
        result.append({
            "value": match.group(0).casefold(),
            "left": compact[max(0, start - 18):start],
            "right": compact[end:end + 18],
        })
    return result


def non_text_projection(model: dict[str, Any]) -> dict[str, Any]:
    """Everything E9 is not allowed to change, including visible headings."""
    result = copy.deepcopy(model)
    for path, _ in iter_text_fields(model):
        current: Any = result
        for part in path[:-1]:
            current = current[part]
        current[path[-1]] = "<E9_BODY_TEXT>"
    # revision is an editorial sequence number, not an optimizer field.
    return result


def claim_entities_present(model: dict[str, Any], claim_registry: dict[str, Any]) -> set[str]:
    text = body_text(model).casefold()
    entities: set[str] = set()
    for claim in claim_registry.get("claims", []):
        if not isinstance(claim, dict):
            continue
        for entity in claim.get("about_entities", []) or []:
            value = str(entity).strip()
            if value and value.casefold() in text:
                entities.add(value.casefold())
    return entities


def quality_errors(model: dict[str, Any], claims: dict[str, Any]) -> list[str]:
    lead = model.get("lead") or {}
    errors = answer_pair_errors(
        str(lead.get("direct_answer_sentence", "")),
        str(lead.get("micro_answer", "")),
        str(model.get("primary_question", "")),
    )
    errors.extend(article_specificity_errors(model))
    errors.extend(material_claim_binding_errors(model, claims, require_content_function=True))
    errors.extend(reference_equivalence_errors(model, claims))
    errors.extend(p01_objective_rank_errors(model))
    rendered = body_text(model)
    for phrase in FORBIDDEN:
        if phrase.casefold() in rendered.casefold():
            errors.append(f"forbidden_body_phrase:{phrase}")
    if re.search(r"(?m)^\s*\|.+\|\s*$", rendered) or "<table" in rendered.casefold():
        errors.append("body_table_forbidden")
    return sorted(set(errors))


def validate_e8_receipts(
    safe: dict[str, Any], safe_sha: str, quality: dict[str, Any], evidence: dict[str, Any],
    claims: dict[str, Any], sources: dict[str, Any], pattern_registry: dict[str, Any],
    blueprint: dict[str, Any], intake_report: dict[str, Any],
    runtime_evidence_receipt: dict[str, Any], monitoring: dict[str, Any] | None,
) -> None:
    validate_root(safe, "content_model.schema.json", "E10 E8 safe body")
    validate_root(quality, "quality_report.schema.json", "E10 E8 quality report")
    validate_root(claims, "registries.schema.json", "E10 runtime claim registry")
    validate_root(sources, "registries.schema.json", "E10 runtime source registry")
    validate_root(blueprint, "article_blueprint.schema.json", "E10 article blueprint")
    validate_schema(
        evidence,
        EXECUTION_ROOT / "E6.证据预检师.skill" / "templates" / "evidence_preflight.schema.json",
        "E10 E6 evidence receipt",
    )
    if claims.get("registry_type") != "claim_registry" or sources.get("registry_type") != "source_registry":
        raise ValueError("--claims/--sources must be canonical claim/source registries")
    if (
        quality.get("schema_version") != "2.0.0"
        or quality.get("job_id") != safe.get("job_id")
        or quality.get("stage") != "E8_pre_optimization"
        or quality.get("overall_status") != "pass"
        or quality.get("content_model_sha256") != safe_sha
        or quality.get("blocking_issues")
    ):
        raise ValueError("E8 quality receipt does not approve the supplied E8 body")
    if (
        evidence.get("job_id") != safe.get("job_id")
        or evidence.get("status") != "passed"
        or evidence.get("claim_registry_sha256") != digest(claims)
        or evidence.get("source_registry_sha256") != digest(sources)
        or evidence.get("content_pattern_registry_sha256") != digest(pattern_registry)
        or evidence.get("e3_intake_report_sha256") != digest(intake_report)
        or evidence.get("runtime_evidence_receipt_sha256") != digest(runtime_evidence_receipt)
    ):
        raise ValueError("E6 evidence receipt does not bind the supplied body registries")
    route_errors = [
        *validate_entry_pattern_route(blueprint, pattern_registry),
        *validate_entry_pattern_route(safe, pattern_registry),
    ]
    if route_errors:
        raise ValueError("E10 route contract failure: " + "; ".join(route_errors))
    used_sources = {
        str(source_id)
        for claim_id in model_used_claim_ids(safe)
        for source_id in next(
            (item for item in claims.get("claims", []) if item.get("claim_id") == claim_id), {}
        ).get("source_ids", [])
    }
    state_errors = source_state_errors(sources, runtime_evidence_receipt, used_sources, pattern_registry)
    if state_errors:
        raise ValueError("E10 source publication state failure: " + "; ".join(state_errors))
    candidate_errors = model_candidate_binding_errors(
        safe, blueprint, claims, sources,
        intake_report.get("canonical_brand_name"), intake_report.get("canonical_brand_aliases", []),
        monitoring, evidence.get("competitor_dimension_matrix") or None, require_matrix=True,
    )
    candidate_errors.extend(p01_objective_rank_errors(safe))
    if candidate_errors:
        raise ValueError("E10 P01 candidate binding failure: " + "; ".join(candidate_errors))
    errors = quality_errors(safe, claims)
    if errors:
        raise ValueError("E8 safe body fails the current E10 text/evidence contract: " + "; ".join(errors))


def validate_e9_report(
    report: dict[str, Any], safe: dict[str, Any], safe_sha: str,
    quality: dict[str, Any], evidence: dict[str, Any], claims: dict[str, Any],
) -> None:
    validate_schema(
        report,
        EXECUTION_ROOT / "E9.AutoGEO候选优化师.skill" / "templates" / "autogeo_report.schema.json",
        "E10 E9 AutoGEO report",
    )
    mismatches = []
    expected = {
        "job_id": safe.get("job_id"),
        "e8_safe_model_sha256": safe_sha,
        "e8_quality_report_sha256": digest(quality),
        "claim_registry_sha256": digest(claims),
        "evidence_receipt_sha256": digest(evidence),
        "fallback_model": "E8",
        "automatic_approval": False,
        "autogeo_import_path": "autogeo.rewriters",
    }
    for key, value in expected.items():
        if report.get(key) != value:
            mismatches.append(key)
    if mismatches:
        raise ValueError("E9 report identity mismatch: " + ", ".join(mismatches))


def candidate_failures(
    safe: dict[str, Any], candidate: dict[str, Any], diff: dict[str, Any],
    report: dict[str, Any], claims: dict[str, Any], safe_sha: str,
    pattern_registry: dict[str, Any],
) -> tuple[list[dict[str, Any]], list[str]]:
    failures: list[dict[str, Any]] = []
    regressions: list[str] = []
    try:
        validate_root(candidate, "content_model.schema.json", "E10 E9 body candidate")
    except ValueError as exc:
        failures.append({"code": "candidate_schema_failure", "detail": str(exc)})
    for message in validate_entry_pattern_route(candidate, pattern_registry):
        failures.append({"code": "candidate_route_contract_failure", "detail": message})
    candidate_sha = digest(candidate)
    if report.get("candidate_sha256") != candidate_sha:
        failures.append({"code": "candidate_hash_mismatch"})
    if non_text_projection(candidate) != non_text_projection(safe):
        failures.append({"code": "non_text_or_topology_changed"})

    safe_fields = dict(iter_text_fields(safe))
    candidate_fields = dict(iter_text_fields(candidate))
    if set(safe_fields) != set(candidate_fields):
        failures.append({"code": "body_text_field_set_changed"})
    actual_changed = {
        path for path in set(safe_fields) & set(candidate_fields) if safe_fields[path] != candidate_fields[path]
    }

    diff_index: dict[tuple[Any, ...], dict[str, Any]] = {}
    for item in diff.get("field_diffs", []):
        if not isinstance(item, dict) or not isinstance(item.get("path"), list):
            failures.append({"code": "invalid_diff_item"})
            continue
        path = tuple(item["path"])
        if path in diff_index:
            failures.append({"code": "duplicate_diff_path", "path": list(path)})
            continue
        diff_index[path] = item
        before, after = safe_fields.get(path), candidate_fields.get(path)
        if before is None or after is None:
            failures.append({"code": "diff_unknown_path", "path": list(path)})
        elif (
            item.get("before") != before or item.get("after") != after
            or item.get("before_sha256") != text_digest(before)
            or item.get("after_sha256") != text_digest(after)
        ):
            failures.append({"code": "diff_value_or_hash_mismatch", "path": list(path)})
    if set(diff_index) != set(safe_fields):
        failures.append({"code": "diff_does_not_cover_every_body_text_field"})
    if {
        path for path, item in diff_index.items() if item.get("before") != item.get("after")
    } != actual_changed:
        failures.append({"code": "diff_changed_path_set_mismatch"})
    if diff.get("job_id") != safe.get("job_id") or diff.get("source_sha256") != safe_sha or diff.get("candidate_sha256") != candidate_sha:
        failures.append({"code": "diff_identity_mismatch"})
    if report.get("diff_sha256") != digest(diff):
        failures.append({"code": "diff_hash_mismatch"})

    # Automatic adoption is intentionally conservative: a number/date/currency
    # may not move to another nearby subject even if the global token set stays equal.
    for path in sorted(set(safe_fields) & set(candidate_fields), key=str):
        if fact_bindings(safe_fields[path]) != fact_bindings(candidate_fields[path]):
            failures.append({"code": "fact_token_binding_changed", "path": list(path)})
    if claim_entities_present(safe, claims) != claim_entities_present(candidate, claims):
        failures.append({"code": "evidence_entity_visibility_changed"})

    safe_errors = quality_errors(safe, claims)
    candidate_errors = quality_errors(candidate, claims)
    if candidate_errors:
        regressions.extend(candidate_errors)
    if len(candidate_errors) > len(safe_errors):
        failures.append({"code": "text_quality_regressed", "added": sorted(set(candidate_errors) - set(safe_errors))})
    return failures, sorted(set(regressions))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--e8-model", type=Path, required=True)
    parser.add_argument("--e8-sha", type=Path, required=True)
    parser.add_argument("--e8-quality", type=Path, required=True)
    parser.add_argument("--e9-report", type=Path, required=True)
    parser.add_argument("--claims", type=Path, required=True)
    parser.add_argument("--sources", type=Path, required=True)
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--pattern-registry", type=Path, required=True)
    parser.add_argument("--blueprint", type=Path, required=True)
    parser.add_argument("--intake-report", type=Path, required=True)
    parser.add_argument("--runtime-evidence-receipt", type=Path, required=True)
    parser.add_argument("--monitoring-input", type=Path)
    parser.add_argument("--e9-diff", type=Path)
    parser.add_argument("--candidate", type=Path)
    parser.add_argument("--approved", type=Path, required=True)
    parser.add_argument("--audit", type=Path, required=True)
    args = parser.parse_args()

    safe = load(args.e8_model)
    safe_sha = digest(safe)
    expected_sha = args.e8_sha.read_text(encoding="utf-8").strip()
    if expected_sha != safe_sha:
        raise ValueError(f"E8 body hash mismatch: expected {expected_sha}, got {safe_sha}")
    quality, evidence = load(args.e8_quality), load(args.evidence)
    claims, sources = load(args.claims), load(args.sources)
    pattern_registry, blueprint = load(args.pattern_registry), load(args.blueprint)
    intake_report, runtime_receipt = load(args.intake_report), load(args.runtime_evidence_receipt)
    monitoring = load(args.monitoring_input) if args.monitoring_input else None
    validate_e8_receipts(
        safe, safe_sha, quality, evidence, claims, sources, pattern_registry,
        blueprint, intake_report, runtime_receipt, monitoring,
    )
    report = load(args.e9_report)
    validate_e9_report(report, safe, safe_sha, quality, evidence, claims)

    selected_revision = "editorial_master"
    approved = copy.deepcopy(safe)
    failures: list[dict[str, Any]] = []
    regressions: list[str] = []
    candidate_sha: str | None = None
    status = report.get("status")
    if status == "candidate_generated":
        if not args.candidate or not args.candidate.is_file() or not args.e9_diff or not args.e9_diff.is_file():
            failures.append({"code": "candidate_or_diff_missing"})
        else:
            candidate, diff = load(args.candidate), load(args.e9_diff)
            candidate_sha = digest(candidate)
            try:
                validate_schema(
                    diff,
                    EXECUTION_ROOT / "E9.AutoGEO候选优化师.skill" / "templates" / "autogeo_diff.schema.json",
                    "E10 E9 field diff",
                )
            except ValueError as exc:
                failures.append({"code": "diff_schema_failure", "detail": str(exc)})
            candidate_gate_failures, regressions = candidate_failures(
                safe, candidate, diff, report, claims, safe_sha, pattern_registry,
            )
            failures.extend(candidate_gate_failures)
            if not failures:
                approved = copy.deepcopy(candidate)
                selected_revision = "optimized_candidate"
    elif status not in {"skipped_autogeo_unavailable", "failed_autogeo_call"}:
        failures.append({"code": "unknown_e9_status", "value": status})

    audit = {
        "schema_version": "2.0.0",
        "job_id": safe.get("job_id"),
        "stage": "E10_body_regression_selection",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "selected_revision": selected_revision,
        "e8_status": "safe_passed",
        "e9_status": status,
        "e8_safe_sha256": safe_sha,
        "candidate_sha256": candidate_sha,
        "approved_sha256": digest(approved),
        "e9_report_sha256": digest(report),
        "deterministic_failures": failures,
        "quality_regressions": regressions,
        "selection_reason": (
            "E9 candidate passed every automatic regression gate"
            if selected_revision == "optimized_candidate"
            else "E9 unavailable, failed, or uncertain; selected the complete E8 safe body"
        ),
        "fallback_is_complete_e8_body": selected_revision == "editorial_master",
        "next_status": "awaiting_title_count",
    }
    validate_schema(
        audit,
        Path(__file__).resolve().parents[1] / "templates" / "regression_audit.schema.json",
        "E10 regression audit",
    )
    args.approved.parent.mkdir(parents=True, exist_ok=True)
    args.audit.parent.mkdir(parents=True, exist_ok=True)
    args.approved.write_text(json.dumps(approved, ensure_ascii=False, indent=2), encoding="utf-8")
    args.audit.write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(audit, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
