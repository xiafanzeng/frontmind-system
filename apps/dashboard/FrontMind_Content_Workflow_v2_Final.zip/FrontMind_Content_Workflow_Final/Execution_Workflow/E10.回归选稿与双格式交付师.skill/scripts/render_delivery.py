#!/usr/bin/env python3
"""Render a title-free DOCX body and HTML body fragment from one E10 body.

Public output contains only publication artifacts.  Quality reports and render
receipts are written to a separate internal-audit directory and are never
listed in the public Delivery Manifest.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import html
import json
import mimetypes
import os
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Iterable

sys.dont_write_bytecode = True
EXECUTION_ROOT = Path(__file__).resolve().parents[2]
WORKFLOW_ROOT = EXECUTION_ROOT.parent
ROOT_SHARED = WORKFLOW_ROOT / "shared"
sys.path.insert(0, str(EXECUTION_ROOT / "shared"))
sys.path.insert(0, str(ROOT_SHARED / "scripts"))
sys.path.insert(0, str(ROOT_SHARED))
from content_projections import visual_projection_sha256  # noqa: E402
from reference_equivalence import reference_equivalence_errors  # noqa: E402
from schema_validation import validate_root, validate_schema  # noqa: E402
from text_quality import answer_pair_errors, article_specificity_errors, material_claim_binding_errors  # noqa: E402
from visual_semantics import (  # noqa: E402
    ROLE_COMPATIBILITY,
    visual_claim_relevance_errors,
    visual_semantic_errors,
)
from content_route import validate_entry_pattern_route  # noqa: E402
from candidate_binding import model_candidate_binding_errors, p01_objective_rank_errors  # noqa: E402
from source_state import source_state_errors  # noqa: E402
from validate_title_map import (  # noqa: E402
    OBJECTIVE_RANK_RE,
    normalized_title,
    validate as validate_canonical_title_map,
)


PUBLIC_FILENAMES = {
    "article_body.docx", "article_body.html", "structured_data_template.json",
    "title_options.md", "title_map.json", "publishing_metadata_map.json",
    "delivery_manifest.json",
}
SAFE_PUBLIC_URL_RE = re.compile(r"^https?://[^\s]+$", flags=re.I)
FACT_TOKEN_RE = re.compile(
    r"\d{4}年(?:\d{1,2}月(?:\d{1,2}日)?)?|\d{4}-\d{1,2}-\d{1,2}"
    r"|(?<![A-Za-z])\d+(?:\.\d+)?(?:%|％|倍|元|万元|美元)?"
    r"|人民币|美元|港币|欧元|CNY|RMB|USD|HKD|EUR",
    flags=re.I,
)


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain a JSON object")
    return value


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def digest(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def file_hash(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def ensure_empty_directory(path: Path) -> None:
    if path.is_symlink():
        raise ValueError(f"directory must not be a symlink: {path}")
    if path.exists() and any(path.iterdir()):
        raise ValueError(f"public output directory must be new or empty: {path}")
    path.mkdir(parents=True, exist_ok=True)


def safe_relative_path(root: Path, stored: str) -> Path:
    path = Path(stored)
    if not stored or path.is_absolute() or ".." in path.parts or "\\" in stored:
        raise ValueError(f"unsafe package-relative path: {stored!r}")
    resolved = (root / path).resolve()
    try:
        resolved.relative_to(root.resolve())
    except ValueError as exc:
        raise ValueError(f"path escapes package root: {stored}") from exc
    return resolved


def is_safe_public_url(value: Any) -> bool:
    return isinstance(value, str) and bool(SAFE_PUBLIC_URL_RE.fullmatch(value.strip()))


def index_registry(registry: dict[str, Any], registry_type: str, id_key: str, values_key: str) -> dict[str, dict[str, Any]]:
    if registry.get("registry_type") != registry_type:
        raise ValueError(f"expected {registry_type}, got {registry.get('registry_type')!r}")
    return {
        str(item.get(id_key)): item
        for item in registry.get(values_key, []) if isinstance(item, dict) and item.get(id_key)
    }


def used_claim_ids(model: dict[str, Any]) -> set[str]:
    result = set(str(value) for value in (model.get("lead") or {}).get("claim_ids", []))
    for section in model.get("sections", []):
        if not isinstance(section, dict):
            continue
        groups = [section.get("blocks", [])]
        groups.extend(item.get("blocks", []) for item in section.get("subsections", []) if isinstance(item, dict))
        for group in groups:
            for block in group if isinstance(group, list) else []:
                if isinstance(block, dict):
                    result.update(str(value) for value in block.get("claim_ids", []))
    for item in model.get("faq", []):
        if isinstance(item, dict):
            result.update(str(value) for value in item.get("claim_ids", []))
    result.update(str(value) for value in (model.get("conclusion") or {}).get("claim_ids", []))
    return result


def validate_title_contract(
    model: dict[str, Any], receipt: dict[str, Any], title_map: dict[str, Any], claims: dict[str, Any],
    brand_facts: dict[str, Any] | None,
) -> None:
    validate_root(receipt, "title_count_receipt.schema.json", "E10 title-count receipt")
    validate_root(title_map, "title_map.schema.json", "E10 title map")
    canonical_errors = validate_canonical_title_map(title_map, receipt, model, claims, brand_facts)
    if canonical_errors:
        raise ValueError("canonical title-map gate failed: " + "; ".join(canonical_errors))
    body_sha = digest(model)
    for key, value in {
        "job_id": model.get("job_id"),
        "approved_body_sha256": body_sha,
    }.items():
        if receipt.get(key) != value or title_map.get(key) != value:
            raise ValueError(f"title receipt/map {key} does not bind the approved title-free body")
    if receipt.get("requested_count") != title_map.get("requested_count"):
        raise ValueError("title map count differs from the user title-count receipt")
    options = title_map.get("options", [])
    if len(options) != receipt.get("requested_count"):
        raise ValueError("title map must contain exactly the user-requested 1-20 options")
    ids = [item.get("title_id") for item in options if isinstance(item, dict)]
    normalized_titles = [normalized_title(str(item.get("title_text", ""))) for item in options if isinstance(item, dict)]
    if len(ids) != len(set(ids)) or len(normalized_titles) != len(set(normalized_titles)):
        raise ValueError("title IDs and normalized title text must be unique")
    claim_index = index_registry(claims, "claim_registry", "claim_id", "claims")
    allowed_claims = used_claim_ids(model)
    visible = visible_body_text(model)
    body_fact_tokens = {item.casefold() for item in FACT_TOKEN_RE.findall(visible)}
    for index, option in enumerate(options):
        checks = option.get("risk_checks", {}) if isinstance(option, dict) else {}
        if not isinstance(option, dict) or checks.get("passed") is not True or any(
            checks.get(key) is not True for key in (
                "body_supported", "no_new_entity", "no_new_number", "no_objective_rank_claim", "time_basis_valid",
            )
        ):
            raise ValueError(f"title option {index} has an incomplete risk review")
        support = set(str(value) for value in option.get("support_claim_ids", []))
        if support - allowed_claims or support - set(claim_index):
            raise ValueError(f"title option {index} uses a claim not used by the approved body")
        combined = "\n".join(str(option.get(key, "")) for key in ("title_text", "h1_suggestion", "meta_description"))
        added_facts = {item.casefold() for item in FACT_TOKEN_RE.findall(combined)} - body_fact_tokens
        if added_facts:
            raise ValueError(f"title option {index} introduces facts absent from the body: {sorted(added_facts)}")
        if model.get("pattern_id") == "P01" and OBJECTIVE_RANK_RE.search(normalized_title(combined)):
            raise ValueError(f"P01 title option {index} turns editorial priority into an objective ranking")
        # Independent defense for undeclared, previously unseen proper-name
        # tokens. The canonical validator handles all known entities; this
        # catches a fabricated Latin product/brand or Chinese organization name
        # that an attacker simply omitted from referenced_entity_names.
        body_norm = visible.casefold()
        generic_latin = {
            "ai", "geo", "faq", "html", "docx", "api", "saas", "b2b",
            "article", "product", "review", "howto", "itemlist", "faqpage",
        }
        latin_tokens = {
            value for value in re.findall(
                r"(?<![A-Za-z0-9])(?:[A-Z][A-Za-z0-9.+-]{2,}|[A-Za-z]+\d[A-Za-z0-9.+-]*)(?![A-Za-z0-9])",
                combined,
            ) if value.casefold() not in generic_latin
        }
        unseen_latin = sorted(value for value in latin_tokens if value.casefold() not in body_norm)
        if unseen_latin:
            raise ValueError(f"title option {index} introduces undeclared entity-like tokens: {unseen_latin}")
        generic_chinese = {"客户品牌", "企业品牌", "推荐品牌", "目标品牌", "中国品牌"}
        chinese_candidates = {
            value
            for segment in re.split(r"[\s，。；：、！？?（）()《》【】\[\]/|]+", combined)
            for value in re.findall(r"[\u3400-\u9fffA-Za-z0-9]{2,24}(?:公司|集团|研究院|协会|大学|品牌)", segment)
            if value not in generic_chinese
        }
        unseen_chinese = sorted(value for value in chinese_candidates if value.casefold() not in body_norm)
        if unseen_chinese:
            raise ValueError(f"title option {index} introduces undeclared organization entities: {unseen_chinese}")


def validate_regression_identity(
    model: dict[str, Any], regression: dict[str, Any], e8_model: dict[str, Any],
    e8_quality: dict[str, Any], e9_report: dict[str, Any],
) -> None:
    validate_root(model, "content_model.schema.json", "E10 approved body")
    validate_root(e8_model, "content_model.schema.json", "E10 E8 safe body")
    validate_root(e8_quality, "quality_report.schema.json", "E10 E8 quality report")
    validate_schema(
        regression,
        Path(__file__).resolve().parents[1] / "templates" / "regression_audit.schema.json",
        "E10 regression audit",
    )
    validate_schema(
        e9_report,
        EXECUTION_ROOT / "E9.AutoGEO候选优化师.skill" / "templates" / "autogeo_report.schema.json",
        "E10 E9 report",
    )
    if regression.get("job_id") != model.get("job_id") or regression.get("approved_sha256") != digest(model):
        raise ValueError("regression audit does not bind the approved body")
    if regression.get("e8_safe_sha256") != digest(e8_model):
        raise ValueError("regression audit does not bind the supplied E8 safe body")
    if regression.get("e9_report_sha256") != digest(e9_report):
        raise ValueError("regression audit does not bind the supplied E9 report")
    if (
        e8_quality.get("job_id") != model.get("job_id")
        or e8_quality.get("stage") != "E8_pre_optimization"
        or e8_quality.get("overall_status") != "pass"
        or e8_quality.get("content_model_sha256") != digest(e8_model)
    ):
        raise ValueError("E8 quality report is stale, forged or failed")
    if regression.get("selected_revision") == "editorial_master" and digest(model) != digest(e8_model):
        raise ValueError("editorial_master must be the complete, exact E8 body")
    if regression.get("selected_revision") == "optimized_candidate" and (
        regression.get("deterministic_failures") or regression.get("quality_regressions")
    ):
        raise ValueError("optimized candidate still has regression failures")


def validate_evidence_handoff(
    model: dict[str, Any], evidence: dict[str, Any], semantic: dict[str, Any],
    claims: dict[str, Any], sources: dict[str, Any],
) -> None:
    validate_schema(
        evidence,
        EXECUTION_ROOT / "E6.证据预检师.skill" / "templates" / "evidence_preflight.schema.json",
        "E10 E6 evidence receipt",
    )
    validate_schema(
        semantic,
        EXECUTION_ROOT / "E6.证据预检师.skill" / "templates" / "evidence_semantic_review.schema.json",
        "E10 evidence semantic review",
    )
    validate_root(claims, "registries.schema.json", "E10 runtime claim registry")
    validate_root(sources, "registries.schema.json", "E10 runtime source registry")
    if (
        evidence.get("job_id") != model.get("job_id")
        or evidence.get("status") != "passed"
        or evidence.get("claim_registry_sha256") != digest(claims)
        or evidence.get("source_registry_sha256") != digest(sources)
        or evidence.get("semantic_review_sha256") != digest(semantic)
        or semantic.get("overall_status") != "passed"
    ):
        raise ValueError("E6 evidence/semantic receipts do not bind the final registries")
    if reference_equivalence_errors(model, claims):
        raise ValueError("visible references no longer equal the exact used-claim source set")
    claim_errors = material_claim_binding_errors(model, claims, require_content_function=True)
    if claim_errors:
        raise ValueError("final body has an unbound or misaligned claim: " + "; ".join(claim_errors))


def validate_and_copy_visuals(
    model: dict[str, Any], visual_manifest: dict[str, Any], image_registry: dict[str, Any],
    base_registry: dict[str, Any], runtime_receipt: dict[str, Any], evidence: dict[str, Any],
    claims: dict[str, Any], sources: dict[str, Any], base_root: Path, job_root: Path, output_dir: Path,
) -> dict[str, dict[str, Any]]:
    validate_schema(
        visual_manifest,
        EXECUTION_ROOT / "E7.视觉论证与资产生产师.skill" / "templates" / "visual_argument_manifest.schema.json",
        "E10 E7 visual manifest",
    )
    validate_root(image_registry, "registries.schema.json", "E10 runtime image registry")
    validate_root(base_registry, "registries.schema.json", "E10 base image registry")
    validate_schema(
        runtime_receipt,
        EXECUTION_ROOT / "E3.全契约与运行时资产师.skill" / "templates" / "runtime_image_registry_receipt.schema.json",
        "E10 runtime image registry receipt",
    )
    image_index = index_registry(image_registry, "image_registry", "asset_id", "images")
    base_index = index_registry(base_registry, "image_registry", "asset_id", "images")
    if visual_manifest.get("job_id") != model.get("job_id") or visual_manifest.get("validation_status") != "passed":
        raise ValueError("E7 visual manifest is not a clean pass for this job")
    if visual_manifest.get("visual_projection_sha256") != visual_projection_sha256(model):
        raise ValueError("visual topology changed after E7")
    if visual_manifest.get("image_registry_sha256") != digest(image_registry):
        raise ValueError("runtime image registry changed after E7")
    if visual_manifest.get("base_image_registry_sha256") != digest(base_registry):
        raise ValueError("base image registry differs from the E7 receipt")
    if visual_manifest.get("runtime_registry_receipt_sha256") != digest(runtime_receipt):
        raise ValueError("runtime image receipt differs from the E7 receipt")
    if runtime_receipt.get("job_id") != model.get("job_id") or runtime_receipt.get("base_registry_sha256") != digest(base_registry):
        raise ValueError("runtime image registry receipt does not bind this job/base")
    for asset_id, base_asset in base_index.items():
        if image_index.get(asset_id) != base_asset:
            raise ValueError(f"runtime image registry modified signed base asset {asset_id}")
    placements = {
        str(item.get("visual_id")): item for item in model.get("visual_placements", []) if isinstance(item, dict)
    }
    manifest_items = {
        str(item.get("visual_id")): item for item in visual_manifest.get("visuals", []) if isinstance(item, dict)
    }
    if set(placements) != set(manifest_items):
        raise ValueError("Content Model and E7 manifest visual sets differ")
    claim_index = index_registry(claims, "claim_registry", "claim_id", "claims")
    source_index = index_registry(sources, "source_registry", "source_id", "sources")
    passed_claim_ids = {
        str(item.get("claim_id")) for item in evidence.get("claim_checks", [])
        if isinstance(item, dict) and item.get("status") == "passed"
    }
    copied: dict[str, dict[str, Any]] = {}
    image_dir = output_dir / "images"
    if placements:
        image_dir.mkdir()
    for visual_id, placement in placements.items():
        manifest = manifest_items[visual_id]
        for key in ("asset_id", "role", "alt_text", "after_section_id"):
            if manifest.get(key) != placement.get(key):
                raise ValueError(f"visual placement/manifest mismatch: {visual_id}:{key}")
        asset_id, role = str(placement.get("asset_id")), str(placement.get("role"))
        asset = image_index.get(asset_id)
        if not asset:
            raise ValueError(f"visual uses unknown asset: {asset_id}")
        if asset.get("rights_status") not in {"approved", "approved_with_credit"}:
            raise ValueError(f"visual rights unavailable or revoked: {asset_id}")
        if not isinstance(asset.get("width"), int) or not isinstance(asset.get("height"), int) or asset["width"] < 1 or asset["height"] < 1:
            raise ValueError(f"used visual must have positive canonical width/height: {asset_id}")
        if not (set(asset.get("allowed_roles", [])) & ROLE_COMPATIBILITY.get(role, set())):
            raise ValueError(f"asset role is incompatible with placement: {asset_id}:{role}")
        if asset.get("rights_status") == "approved_with_credit" and not str(asset.get("attribution_text") or "").strip():
            raise ValueError(f"approved_with_credit visual lacks attribution: {asset_id}")
        semantic_errors = visual_semantic_errors(
            visual_id=visual_id, role=role, argument=manifest.get("argument_function"), asset=asset,
            claim_ids=[str(value) for value in manifest.get("supports_claim_ids", [])],
            claims=claim_index, known_source_ids=set(source_index),
        )
        semantic_errors.extend(visual_claim_relevance_errors(
            visual_id=visual_id, role=role, argument=manifest.get("argument_function"),
            after_section_id=manifest.get("after_section_id"),
            claim_ids=[str(value) for value in manifest.get("supports_claim_ids", [])],
            model=model, passed_claim_ids=passed_claim_ids,
        ))
        if semantic_errors:
            raise ValueError("visual semantic/relevance gate failed: " + "; ".join(semantic_errors))
        root = base_root if asset_id in base_index else job_root
        source = safe_relative_path(root, str(asset.get("file_path") or ""))
        if not source.is_file() or file_hash(source) != asset.get("sha256"):
            raise ValueError(f"visual file missing or hash changed: {asset_id}")
        suffix = source.suffix.lower() or mimetypes.guess_extension(str(asset.get("mime_type"))) or ".bin"
        target = image_dir / f"{asset_id}{suffix}"
        shutil.copy2(source, target)
        caption = str(manifest.get("caption") or asset.get("caption") or "").strip()
        attribution = str(asset.get("attribution_text") or "").strip()
        if attribution and attribution not in caption:
            caption = (caption + " · " if caption else "") + f"图片署名：{attribution}"
        copied[asset_id] = {
            **asset,
            "caption": caption,
            "alt_text": placement.get("alt_text"),
            "delivery_path": f"images/{target.name}",
            "delivery_file": target,
        }
    return copied


def block_lines(block: dict[str, Any]) -> list[tuple[str, str]]:
    result: list[tuple[str, str]] = []
    text = str(block.get("text") or "").strip()
    if text:
        result.append(("p", text))
    items = [str(value).strip() for value in block.get("items", []) if str(value).strip()]
    if block.get("type") == "bullet_list":
        result.extend(("bullet", value) for value in items)
    elif block.get("type") == "numbered_list":
        result.extend(("number", value) for value in items)
    elif block.get("type") == "step":
        contract = block.get("step_contract") or {}
        for label, key in (("输入", "input"), ("动作", "action"), ("预期结果", "expected_result"), ("检查方法", "check_method")):
            value = str(contract.get(key) or "").strip()
            if value:
                result.append(("bullet", f"{label}：{value}"))
    return result


def render_nodes(model: dict[str, Any], visuals: dict[str, dict[str, Any]]) -> list[dict[str, str]]:
    by_section: dict[str, list[dict[str, str]]] = {}
    for placement in model.get("visual_placements", []):
        if not isinstance(placement, dict):
            continue
        key = str(placement.get("after_section_id") or "__cover__")
        asset = visuals[str(placement.get("asset_id"))]
        by_section.setdefault(key, []).append({
            "kind": "image", "src": str(asset["delivery_path"]),
            "alt": str(asset.get("alt_text") or ""), "caption": str(asset.get("caption") or ""),
            "width": str(asset.get("width")), "height": str(asset.get("height")),
        })
    nodes: list[dict[str, str]] = []
    nodes.extend(by_section.get("__cover__", []))
    nodes.append({"kind": "p", "text": f"资料截止：{model['metadata']['as_of']}"})
    nodes.append({"kind": "p", "text": str(model["lead"]["micro_answer"])})
    for section in model.get("sections", []):
        if not isinstance(section, dict):
            continue
        nodes.append({"kind": "h2", "text": str(section.get("h2_question"))})
        for block in section.get("blocks", []):
            if isinstance(block, dict):
                nodes.extend({"kind": kind, "text": text} for kind, text in block_lines(block))
        for subsection in section.get("subsections", []):
            if not isinstance(subsection, dict):
                continue
            nodes.append({"kind": "h3", "text": str(subsection.get("h3"))})
            for block in subsection.get("blocks", []):
                if isinstance(block, dict):
                    nodes.extend({"kind": kind, "text": text} for kind, text in block_lines(block))
        nodes.extend(by_section.get(str(section.get("section_id")), []))
    nodes.append({"kind": "h2", "text": "还有哪些常见问题需要确认？"})
    for item in model.get("faq", []):
        if isinstance(item, dict):
            nodes.append({"kind": "h3", "text": str(item.get("question"))})
            nodes.append({"kind": "p", "text": str(item.get("answer"))})
    nodes.append({"kind": "h2", "text": "最后应该如何作出选择？"})
    conclusion = model.get("conclusion") or {}
    for key in ("summary", "fit", "next_action"):
        nodes.append({"kind": "p", "text": str(conclusion.get(key) or "")})
    nodes.append({"kind": "h2", "text": "本文使用了哪些资料来源？"})
    for reference in model.get("references", []):
        if isinstance(reference, dict):
            nodes.append({
                "kind": "reference", "text": str(reference.get("display_name") or ""),
                "url": str(reference.get("url") or ""),
            })
    return nodes


def markdown_from_nodes(nodes: list[dict[str, str]]) -> str:
    lines: list[str] = []
    number = 0
    for node in nodes:
        kind = node["kind"]
        if kind == "h2":
            number = 0
            lines.extend((f"## {node['text']}", ""))
        elif kind == "h3":
            number = 0
            lines.extend((f"### {node['text']}", ""))
        elif kind == "bullet":
            lines.append(f"- {node['text']}")
        elif kind == "number":
            number += 1
            lines.append(f"{number}. {node['text']}")
        elif kind == "image":
            lines.extend((f"![{node['alt']}]({node['src']})", node.get("caption", ""), ""))
        elif kind == "reference":
            if node.get("url"):
                lines.append(f"- [{node['text']}]({node['url']})")
            else:
                lines.append(f"- {node['text']}")
        else:
            number = 0
            lines.extend((node.get("text", ""), ""))
    return "\n".join(lines).strip() + "\n"


def html_from_nodes(nodes: list[dict[str, str]], job_id: str) -> str:
    output = [f'<article class="frontmind-article-body" data-job-id="{html.escape(job_id, quote=True)}">']
    list_kind: str | None = None
    for node in nodes:
        kind = node["kind"]
        wanted = "ul" if kind == "bullet" else "ol" if kind == "number" else None
        if list_kind and wanted != list_kind:
            output.append(f"</{list_kind}>")
            list_kind = None
        if wanted:
            if list_kind is None:
                output.append(f"<{wanted}>")
                list_kind = wanted
            output.append(f"<li>{html.escape(node['text'])}</li>")
        elif kind in {"h2", "h3"}:
            output.append(f"<{kind}>{html.escape(node['text'])}</{kind}>")
        elif kind == "image":
            output.append(
                f'<figure><img src="{html.escape(node["src"], quote=True)}" '
                f'alt="{html.escape(node["alt"], quote=True)}" width="{node["width"]}" height="{node["height"]}">'
                f'<figcaption>{html.escape(node.get("caption", ""))}</figcaption></figure>'
            )
        elif kind == "reference":
            if node.get("url"):
                output.append(
                    f'<p class="reference"><a href="{html.escape(node["url"], quote=True)}" '
                    f'rel="noopener noreferrer">{html.escape(node["text"])}</a></p>'
                )
            else:
                output.append(f'<p class="reference">{html.escape(node["text"])}</p>')
        else:
            output.append(f"<p>{html.escape(node.get('text', ''))}</p>")
    if list_kind:
        output.append(f"</{list_kind}>")
    output.append("</article>")
    return "\n".join(output) + "\n"


def visible_body_text(model: dict[str, Any]) -> str:
    chunks = [str(model.get("primary_question") or ""), str((model.get("lead") or {}).get("micro_answer") or "")]
    for section in model.get("sections", []):
        if not isinstance(section, dict):
            continue
        chunks.append(str(section.get("h2_question") or ""))
        for group in [section.get("blocks", [])] + [
            item.get("blocks", []) for item in section.get("subsections", []) if isinstance(item, dict)
        ]:
            for block in group:
                if isinstance(block, dict):
                    chunks.append(str(block.get("text") or ""))
                    chunks.extend(str(value) for value in block.get("items", []))
                    contract = block.get("step_contract") or {}
                    if isinstance(contract, dict):
                        chunks.extend(str(value) for value in contract.values())
    for item in model.get("faq", []):
        if isinstance(item, dict):
            chunks.extend((str(item.get("question") or ""), str(item.get("answer") or "")))
    conclusion = model.get("conclusion") or {}
    chunks.extend(str(conclusion.get(key) or "") for key in ("summary", "fit", "next_action"))
    chunks.extend(str(item.get("display_name") or "") for item in model.get("references", []) if isinstance(item, dict))
    return "\n".join(chunks)


def build_structured_template(
    model: dict[str, Any], pattern_registry: dict[str, Any], context: dict[str, Any] | None,
    claims: dict[str, Any], approved_sha: str,
) -> dict[str, Any]:
    patterns = {str(item.get("id")): item for item in pattern_registry.get("patterns", []) if isinstance(item, dict)}
    pattern = patterns.get(str(model.get("pattern_id")))
    if not pattern:
        raise ValueError("pattern registry does not contain the approved pattern")
    requested = set(model.get("structured_data_types", []))
    allowed = set(pattern.get("eligible_json_ld", []))
    if requested - allowed:
        raise ValueError(f"structured-data types are not eligible for {model.get('pattern_id')}: {sorted(requested - allowed)}")
    if model.get("pattern_id") == "P01" and model.get("pattern_variant") == "single_brand_recommendation" and requested != {"FAQPage"}:
        raise ValueError("P01 single-brand recommendation may output FAQPage only")
    if context is not None:
        validate_schema(
            context,
            Path(__file__).resolve().parents[1] / "templates" / "structured_data_context.schema.json",
            "E10 structured-data context",
        )
        if context.get("job_id") != model.get("job_id") or context.get("approved_body_sha256") != approved_sha:
            raise ValueError("structured-data context does not bind the approved body")
    context = context or {"schema_version": "2.0.0", "job_id": model.get("job_id"), "approved_body_sha256": approved_sha}
    visible = visible_body_text(model)
    used = used_claim_ids(model)
    claim_index = index_registry(claims, "claim_registry", "claim_id", "claims")

    templates: list[dict[str, Any]] = []
    for kind in model.get("structured_data_types", []):
        if kind == "Article":
            payload = {
                "@context": "https://schema.org", "@type": "Article",
                "headline": "{{TITLE_ID}}", "description": "{{META_DESCRIPTION}}",
                "dateModified": model["metadata"]["as_of"], "inLanguage": model["metadata"]["language"],
            }
        elif kind == "FAQPage":
            payload = {
                "@context": "https://schema.org", "@type": "FAQPage",
                "mainEntity": [
                    {
                        "@type": "Question", "name": item["question"],
                        "acceptedAnswer": {"@type": "Answer", "text": item["answer"]},
                    }
                    for item in model.get("faq", [])
                ],
            }
        elif kind == "HowTo":
            steps = []
            for section in model.get("sections", []):
                for block in section.get("blocks", []) if isinstance(section, dict) else []:
                    if isinstance(block, dict) and block.get("type") == "step":
                        contract = block.get("step_contract") or {}
                        steps.append({
                            "@type": "HowToStep",
                            "name": str(block.get("text") or contract.get("action") or "操作步骤"),
                            "text": "；".join(
                                f"{label}：{contract.get(key)}" for label, key in (
                                    ("输入", "input"), ("动作", "action"),
                                    ("预期结果", "expected_result"), ("检查方法", "check_method"),
                                ) if contract.get(key)
                            ),
                        })
            if not steps:
                raise ValueError("HowTo requested but no visible step block exists")
            payload = {"@context": "https://schema.org", "@type": "HowTo", "name": "{{TITLE_ID}}", "step": steps}
        else:
            item = context.get(kind)
            if not isinstance(item, dict):
                raise ValueError(f"{kind} requires a hash-bound structured-data context")
            context_claims: set[str] = set()
            if kind in {"Product", "Review"}:
                context_claims.update(str(value) for value in item.get("claim_ids", []))
            else:
                for element in item.get("itemListElement", []):
                    if isinstance(element, dict):
                        context_claims.update(str(value) for value in element.get("claim_ids", []))
            if not context_claims or context_claims - used or context_claims - set(claim_index):
                raise ValueError(f"{kind} context claims must be visible-body claims")
            text_values: list[str] = []
            if kind == "Product":
                text_values = [str(item.get(key) or "") for key in ("name", "description", "sku", "brand_name")]
                payload = {"@context": "https://schema.org", "@type": "Product", **{
                    key: value for key, value in {
                        "name": item.get("name"), "description": item.get("description"),
                        "sku": item.get("sku"),
                        "brand": {"@type": "Brand", "name": item.get("brand_name")} if item.get("brand_name") else None,
                    }.items() if value
                }}
            elif kind == "Review":
                text_values = [str(item.get("itemReviewed", {}).get("name") or ""), str(item.get("reviewBody") or "")]
                original_types = {
                    (claim_index[claim_id].get("original_evidence") or {}).get("type")
                    for claim_id in context_claims if isinstance(claim_index[claim_id].get("original_evidence"), dict)
                    and (claim_index[claim_id].get("original_evidence") or {}).get("authorization_status") in {"public_approved", "anonymized_approved"}
                }
                allowed_types = {"independent_test", "actual_usage_test", "original_research"}
                if model.get("pattern_id") == "P11":
                    allowed_types.add("customer_case")
                if not (original_types & allowed_types):
                    raise ValueError("Review requires authorized first-hand methodology evidence")
                payload = {
                    "@context": "https://schema.org", "@type": "Review",
                    "itemReviewed": {"@type": "Thing", "name": item["itemReviewed"]["name"]},
                    "reviewBody": item["reviewBody"],
                }
            elif kind == "ItemList":
                if model.get("pattern_id") != "P01" or model.get("pattern_variant") != "multi_brand_editorial_recommendation":
                    raise ValueError("ItemList is exclusive to P01 multi-brand editorial recommendation")
                elements = item.get("itemListElement", [])
                candidate_names = [
                    str(value.get("entity_name"))
                    for value in (model.get("candidate_contract") or {}).get("ordered_candidates", [])
                    if isinstance(value, dict)
                ]
                element_names = [
                    str(value.get("name")) for value in elements if isinstance(value, dict)
                ]
                if element_names != candidate_names:
                    raise ValueError("P01 ItemList must exactly preserve candidate_contract order and names")
                text_values = [str(element.get("name") or "") for element in elements if isinstance(element, dict)]
                payload = {
                    "@context": "https://schema.org", "@type": "ItemList",
                    "itemListOrder": "https://schema.org/ItemListUnordered",
                    "itemListElement": [
                        {"@type": "ListItem", "name": element["name"]} for element in elements
                    ],
                }
            else:
                raise ValueError(f"unsupported structured-data type: {kind}")
            missing = [value for value in text_values if value and value not in visible]
            if missing:
                raise ValueError(f"{kind} contains values absent from visible body: {missing}")
        templates.append(payload)
    return {
        "schema_version": "2.0.0", "job_id": model.get("job_id"),
        "approved_body_sha256": approved_sha, "title_placeholder": "{{TITLE_ID}}",
        "meta_description_placeholder": "{{META_DESCRIPTION}}", "templates": templates,
    }


def publishing_metadata_map(model: dict[str, Any], title_map: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "2.0.0", "job_id": model.get("job_id"),
        "approved_body_sha256": digest(model),
        "entries": [
            {
                "title_id": item["title_id"], "title": item["title_text"],
                "h1": item["h1_suggestion"], "meta_description": item["meta_description"],
                "structured_data_replacements": {
                    "{{TITLE_ID}}": item["title_text"],
                    "{{META_DESCRIPTION}}": item["meta_description"],
                },
            }
            for item in title_map.get("options", [])
        ],
    }


def title_options_markdown(title_map: dict[str, Any]) -> str:
    lines = ["# 标题选项与发布元数据", ""]
    for index, item in enumerate(title_map.get("options", []), 1):
        lines.extend((
            f"## {index}. {item['title_text']}", "",
            f"- Title ID：`{item['title_id']}`",
            f"- H1 建议：{item['h1_suggestion']}",
            f"- Meta Description：{item['meta_description']}",
            f"- 标题公式：{item['title_formula']}",
            f"- 角度标签：{item['angle_tag']}", "",
        ))
    return "\n".join(lines).rstrip() + "\n"


class VisibleHTML(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.parts: list[str] = []
        self.heading_tags: list[str] = []
        self.has_forbidden_shell = False

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in {"html", "head", "title", "h1", "table"}:
            self.has_forbidden_shell = True
        if tag in {"h2", "h3"}:
            self.heading_tags.append(tag)

    def handle_data(self, data: str) -> None:
        if data.strip():
            self.parts.append(data.strip())


def normalize_visible(value: str) -> str:
    value = re.sub(r"(?m)^\s*(?:•|\d+[.、])\s*", "", value)
    return re.sub(r"[^\u3400-\u9fffA-Za-z0-9%％￥$€¥]+", "", value).casefold()


def validate_rendered_outputs(
    markdown: str, html_fragment: str, docx_path: Path, model: dict[str, Any], visual_count: int,
) -> dict[str, Any]:
    if re.search(r"(?m)^#\s+", markdown):
        raise ValueError("title-free Markdown unexpectedly contains H1")
    if re.search(r"(?m)^\s*\|.+\|\s*$", markdown):
        raise ValueError("rendered body contains a Markdown table")
    parser = VisibleHTML()
    parser.feed(html_fragment)
    if parser.has_forbidden_shell or "<script" in html_fragment.casefold():
        raise ValueError("HTML body fragment contains page shell, H1, table or embedded script")
    if any(tag not in {"h2", "h3"} for tag in parser.heading_tags):
        raise ValueError("HTML heading depth exceeds H2/H3")
    try:
        from docx import Document
    except ImportError as exc:
        raise RuntimeError("python-docx is required to verify E10 output") from exc
    document = Document(docx_path)
    if document.tables:
        raise ValueError("DOCX body contains a native table")
    title_paragraphs = [
        p for p in document.paragraphs
        if p.style and p.style.name in {"Title", "Heading 1"}
    ]
    if title_paragraphs:
        raise ValueError("DOCX body contains a Title/H1 paragraph")
    docx_headings = [p.style.name for p in document.paragraphs if p.style and p.style.name.startswith("Heading")]
    if any(name not in {"Heading 2", "Heading 3"} for name in docx_headings):
        raise ValueError("DOCX heading depth exceeds the title-free H2/H3 mapping")
    if len(document.inline_shapes) != visual_count:
        raise ValueError(f"DOCX embedded image count mismatch: {len(document.inline_shapes)} != {visual_count}")
    docx_text = "\n".join(p.text for p in document.paragraphs if p.text.strip())
    html_text = "\n".join(parser.parts)
    if normalize_visible(docx_text) != normalize_visible(html_text):
        raise ValueError("DOCX and HTML visible text are not semantically identical")
    lead = model.get("lead") or {}
    answer_errors = answer_pair_errors(
        str(lead.get("direct_answer_sentence") or ""), str(lead.get("micro_answer") or ""),
        str(model.get("primary_question") or ""),
    )
    if answer_errors or article_specificity_errors(model):
        raise ValueError("final rendered body fails answer-first/specificity gates")
    return {
        "docx_paragraph_count": len(document.paragraphs),
        "docx_inline_image_count": len(document.inline_shapes),
        "html_heading_count": len(parser.heading_tags),
        "html_h1_count": 0,
        "docx_title_count": 0,
        "docx_html_text_equivalent": True,
        "body_table_count": 0,
    }


def build_final_quality(
    model: dict[str, Any], e8_quality: dict[str, Any], regression: dict[str, Any],
    render_audit: dict[str, Any], visual_manifest: dict[str, Any],
) -> dict[str, Any]:
    existing = {
        str(item.get("gate_id")): copy.deepcopy(item)
        for item in e8_quality.get("gates", []) if isinstance(item, dict)
    }
    required = (
        "question_answered", "micro_answer_complete", "claim_evidence_complete",
        "statistics_and_price_scoped", "competitor_fairness", "entity_clarity",
        "freshness_and_dates", "first_party_publication_and_claim_limits", "faq_relevance",
        "pattern_consistency", "voice_and_no_meta_language", "visual_argument_and_rights",
        "html_structure_and_visible_schema", "docx_html_semantic_parity", "optimization_fact_integrity",
    )
    gates = []
    for gate_id in required:
        if gate_id in existing:
            gates.append(existing[gate_id])
        elif gate_id == "optimization_fact_integrity":
            gates.append({
                "gate_id": gate_id,
                "status": "pass" if regression.get("selected_revision") == "optimized_candidate" else "not_applicable",
                "evidence": regression.get("selection_reason", "E8 safe body selected"),
            })
        else:
            gates.append({"gate_id": gate_id, "status": "pass", "evidence": f"E10 render audit: {gate_id}"})
    metric_names = {
        "faq_count", "unsupported_claim_count", "unscoped_stat_count", "visual_total_count",
        "brand_editorial_visual_count", "navigation_visual_count", "explain_visual_count",
        "prove_visual_count", "prove_binding_failure_count", "heading_depth",
        "direct_answer_unicode_length", "direct_answer_substantive_length",
        "micro_answer_unicode_length", "micro_answer_substantive_length",
        "subquestion_coverage_count", "approved_first_party_source_count", "benchmark_page_count",
    }
    metrics = {key: value for key, value in (e8_quality.get("metrics") or {}).items() if key in metric_names}
    visuals = [item for item in visual_manifest.get("visuals", []) if isinstance(item, dict)]
    metrics.update({
        "faq_count": len(model.get("faq", [])), "visual_total_count": len(visuals), "heading_depth": 2,
        "brand_editorial_visual_count": sum(item.get("role") == "brand_editorial" for item in visuals),
        "navigation_visual_count": sum(item.get("argument_function") == "navigate" for item in visuals),
        "explain_visual_count": sum(item.get("argument_function") == "explain" for item in visuals),
        "prove_visual_count": sum(item.get("argument_function") == "prove" for item in visuals),
        "prove_binding_failure_count": 0,
    })
    report = {
        "schema_version": "2.0.0", "job_id": model.get("job_id"), "stage": "E10_final",
        "content_model_sha256": digest(model), "overall_status": "pass", "gates": gates,
        "blocking_issues": [], "warnings": [], "metrics": metrics,
    }
    validate_root(report, "quality_report.schema.json", "E10 final quality report")
    return report


def artifact(path: Path, output_dir: Path, role: str, media_type: str) -> dict[str, Any]:
    return {
        "role": role, "path": path.relative_to(output_dir).as_posix(),
        "sha256": file_hash(path), "media_type": media_type,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--regression", type=Path, required=True)
    parser.add_argument("--e8-model", type=Path, required=True)
    parser.add_argument("--e8-quality", type=Path, required=True)
    parser.add_argument("--e9-report", type=Path, required=True)
    parser.add_argument("--claims", type=Path, required=True)
    parser.add_argument("--sources", type=Path, required=True)
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--evidence-semantic-review", type=Path, required=True)
    parser.add_argument("--title-count-receipt", type=Path, required=True)
    parser.add_argument("--title-map", type=Path, required=True)
    parser.add_argument("--pattern-registry", type=Path, required=True)
    parser.add_argument("--blueprint", type=Path, required=True)
    parser.add_argument("--intake-report", type=Path, required=True)
    parser.add_argument("--runtime-evidence-receipt", type=Path, required=True)
    parser.add_argument("--monitoring-input", type=Path)
    parser.add_argument("--brand-facts", type=Path, required=True)
    parser.add_argument("--structured-data-context", type=Path)
    parser.add_argument("--visual-manifest", type=Path, required=True)
    parser.add_argument("--image-registry", type=Path, required=True)
    parser.add_argument("--base-image-registry", type=Path, required=True)
    parser.add_argument("--runtime-image-receipt", type=Path, required=True)
    parser.add_argument("--base-package-root", type=Path, required=True)
    parser.add_argument("--job-package-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--internal-audit-dir", type=Path, required=True)
    parser.add_argument(
        "--md2docx-script", type=Path,
        default=EXECUTION_ROOT / "E8.编辑终审师.skill" / "scripts" / "md2docx.py",
    )
    args = parser.parse_args()

    ensure_empty_directory(args.output_dir)
    args.internal_audit_dir.mkdir(parents=True, exist_ok=True)
    if args.internal_audit_dir.resolve() == args.output_dir.resolve():
        raise ValueError("internal audit directory must be separate from public output")
    model, regression = load(args.model), load(args.regression)
    e8_model, e8_quality, e9_report = load(args.e8_model), load(args.e8_quality), load(args.e9_report)
    claims, sources = load(args.claims), load(args.sources)
    evidence, semantic = load(args.evidence), load(args.evidence_semantic_review)
    validate_regression_identity(model, regression, e8_model, e8_quality, e9_report)
    validate_evidence_handoff(model, evidence, semantic, claims, sources)
    receipt, title_map = load(args.title_count_receipt), load(args.title_map)
    validate_title_contract(model, receipt, title_map, claims, load(args.brand_facts))
    pattern_registry = load(args.pattern_registry)
    if pattern_registry.get("schema_version") != "2.0.0":
        raise ValueError("E10 must consume the signed Pack pattern registry v2")
    blueprint, intake_report = load(args.blueprint), load(args.intake_report)
    runtime_evidence_receipt = load(args.runtime_evidence_receipt)
    monitoring = load(args.monitoring_input) if args.monitoring_input else None
    route_errors = [
        *validate_entry_pattern_route(blueprint, pattern_registry),
        *validate_entry_pattern_route(model, pattern_registry),
    ]
    if route_errors:
        raise ValueError("E10 route contract failure: " + "; ".join(route_errors))
    if (
        evidence.get("content_pattern_registry_sha256") != digest(pattern_registry)
        or evidence.get("e3_intake_report_sha256") != digest(intake_report)
        or evidence.get("runtime_evidence_receipt_sha256") != digest(runtime_evidence_receipt)
    ):
        raise ValueError("E10 pattern/intake/runtime evidence handoff is stale")
    candidate_errors = model_candidate_binding_errors(
        model, blueprint, claims, sources,
        intake_report.get("canonical_brand_name"), intake_report.get("canonical_brand_aliases", []),
        monitoring, evidence.get("competitor_dimension_matrix") or None, require_matrix=True,
    )
    candidate_errors.extend(p01_objective_rank_errors(model))
    if candidate_errors:
        raise ValueError("E10 P01 candidate binding failure: " + "; ".join(candidate_errors))
    used_sources = {
        str(source_id)
        for claim_id in used_claim_ids(model)
        for source_id in index_registry(claims, "claim_registry", "claim_id", "claims")
            .get(claim_id, {}).get("source_ids", [])
    }
    publication_errors = source_state_errors(sources, runtime_evidence_receipt, used_sources, pattern_registry)
    if publication_errors:
        raise ValueError("E10 source publication state failure: " + "; ".join(publication_errors))

    visual_manifest = load(args.visual_manifest)
    visuals = validate_and_copy_visuals(
        model, visual_manifest, load(args.image_registry), load(args.base_image_registry),
        load(args.runtime_image_receipt), evidence, claims, sources,
        args.base_package_root, args.job_package_root, args.output_dir,
    )
    nodes = render_nodes(model, visuals)
    markdown = markdown_from_nodes(nodes)
    fragment = html_from_nodes(nodes, str(model.get("job_id")))
    body_md = args.internal_audit_dir / "approved_body_source.md"
    body_md.write_text(markdown, encoding="utf-8")
    body_html = args.output_dir / "article_body.html"
    body_docx = args.output_dir / "article_body.docx"
    body_html.write_text(fragment, encoding="utf-8")
    result = subprocess.run(
        [
            sys.executable, "-B", str(args.md2docx_script), "--input", str(body_md),
            "--images-dir", str(args.output_dir / "images"), "--output", str(body_docx),
        ],
        env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
    )
    if result.returncode != 0:
        raise RuntimeError("DOCX renderer failed: " + (result.stderr.strip() or result.stdout.strip()))

    approved_sha = digest(model)
    context = load(args.structured_data_context) if args.structured_data_context else None
    structured = build_structured_template(model, pattern_registry, context, claims, approved_sha)
    structured_path = args.output_dir / "structured_data_template.json"
    structured_path.write_text(json.dumps(structured, ensure_ascii=False, indent=2), encoding="utf-8")
    public_title_map = args.output_dir / "title_map.json"
    public_title_map.write_text(json.dumps(title_map, ensure_ascii=False, indent=2), encoding="utf-8")
    title_md = args.output_dir / "title_options.md"
    title_md.write_text(title_options_markdown(title_map), encoding="utf-8")
    metadata_map = publishing_metadata_map(model, title_map)
    validate_schema(
        metadata_map,
        Path(__file__).resolve().parents[1] / "templates" / "publishing_metadata_map.schema.json",
        "E10 publishing metadata map",
    )
    metadata_path = args.output_dir / "publishing_metadata_map.json"
    metadata_path.write_text(json.dumps(metadata_map, ensure_ascii=False, indent=2), encoding="utf-8")

    render_metrics = validate_rendered_outputs(
        markdown, fragment, body_docx, model, len(model.get("visual_placements", [])),
    )
    render_audit = {
        "schema_version": "2.0.0", "job_id": model.get("job_id"), "stage": "E10_render_audit",
        "created_at": datetime.now(timezone.utc).isoformat(), "approved_body_sha256": approved_sha,
        "title_map_sha256": digest(title_map), "renderer": "E8/md2docx.py + E10/title-free-fragment-v2",
        "metrics": render_metrics, "status": "pass",
    }
    render_audit_path = args.internal_audit_dir / "E10_render_audit.json"
    render_audit_path.write_text(json.dumps(render_audit, ensure_ascii=False, indent=2), encoding="utf-8")
    final_quality = build_final_quality(model, e8_quality, regression, render_audit, visual_manifest)
    quality_path = args.internal_audit_dir / "E10_quality_report.json"
    quality_path.write_text(json.dumps(final_quality, ensure_ascii=False, indent=2), encoding="utf-8")

    artifacts = [
        artifact(body_docx, args.output_dir, "docx_body", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
        artifact(body_html, args.output_dir, "html_body_fragment", "text/html"),
        artifact(structured_path, args.output_dir, "structured_data_template", "application/json"),
        artifact(title_md, args.output_dir, "title_options_markdown", "text/markdown"),
        artifact(public_title_map, args.output_dir, "title_map", "application/json"),
        artifact(metadata_path, args.output_dir, "publishing_metadata_map", "application/json"),
    ]
    for value in visuals.values():
        artifacts.append(artifact(
            value["delivery_file"], args.output_dir, "visual", str(value.get("mime_type") or "application/octet-stream"),
        ))
    selected = regression["selected_revision"]
    e9_status = e9_report.get("status")
    manifest = {
        "schema_version": "2.0.0", "job_id": model.get("job_id"),
        "created_at": datetime.now(timezone.utc).isoformat(), "selected_revision": selected,
        "source_equivalence": {
            "content_model_sha256": approved_sha,
            "docx_rendered_from_same_model": True,
            "html_rendered_from_same_model": True,
            "title_map_bound_to_same_model": True,
            "structured_data_template_bound_to_title_map": True,
        },
        "artifacts": artifacts,
        "optimization": {
            "attempted": e9_status in {"failed_autogeo_call", "candidate_generated"},
            "candidate_selected": selected == "optimized_candidate",
            "fact_diff_status": (
                "pass" if selected == "optimized_candidate"
                else "fail" if e9_status == "candidate_generated" else "not_run"
            ),
        },
    }
    validate_root(manifest, "delivery_manifest.schema.json", "E10 public Delivery Manifest")
    manifest_path = args.output_dir / "delivery_manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    expected_files = set(PUBLIC_FILENAMES)
    expected_files.update(str(value["delivery_file"].relative_to(args.output_dir)) for value in visuals.values())
    actual_files = {
        str(path.relative_to(args.output_dir)) for path in args.output_dir.rglob("*") if path.is_file()
    }
    if actual_files != expected_files:
        raise ValueError(f"public output contains stale/unregistered files: expected={sorted(expected_files)} actual={sorted(actual_files)}")
    print(json.dumps({
        "status": "pass", "selected_revision": selected, "approved_body_sha256": approved_sha,
        "public_output": str(args.output_dir), "internal_audit": str(args.internal_audit_dir),
        "artifacts": sorted(actual_files), "metrics": render_metrics,
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
