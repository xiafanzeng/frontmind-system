---
name: frontmind-single-question-micro-tracking
description: >
  E2 单问题监控与标杆拆解师。对普通四入口的唯一正式问题读取非空答案表与信源表，重建答案和引用链，
  访问真实被引页面并蒸馏结构；不发现新问题、不复制原文。foundation_start 跳过本阶段。
---

# E2 单问题监控与标杆拆解师

## 输入边界

E2 只处理 `content_job.task.question_text`。`entry_category=foundation_start` 时不得伪造监控，直接交 E3；其余四入口必须同时提供：

- AI 答案表：平台、模型、采集时间、正式问题、完整答案及可选答案/截图/排序字段；
- 信源表：答案关联、HTTP(S) URL、标题、媒体/作者、引用上下文、被引主张、发布时间和访问时间；
- E1 Content Job 与 scope analysis。

任一表缺失、空表、只有表头或题面不一致且未排除，立即阻断。

## Micro Tracking 六步

1. **问题同一性**：逐行对照正式问题；不同决策问题进入 `excluded_observations`。
2. **答案格局**：记录直接答案、实体、立场、反复维度和未回答子问题；AI 顺序只是一项观察。
3. **候选对象**：只从未排除答案抽取真实出现对象，不凭常识补竞品。
4. **引用链**：标准化 URL，关联答案，保留作者、引用上下文、被引主张、来源类别、一手状态与新鲜度风险。
5. **标杆访问**：优先访问 3–5 篇同问题、同形态、可追溯的真实被引页面；真实不足可少但必须警告。`retrieved` 必须同时有访问时间、正文摘录、引用上下文/主张及来源分类。
6. **结构蒸馏**：逐页记录首段答案、H2/H3、子问题、比较维度、证据放置、条件式建议、限制、FAQ、视觉作用与缺口。只借抽象结构，不复制连续原文。

补充原始来源单列 `supplementary_primary_sources`；不得伪装成监控引用标杆。监控引用次数、排名或 AI 提及频率不能变成文章事实或客观排名。

## 输出

输出 `E2_{job_id}_monitoring_input.json`，直接满足根 `shared/monitoring_input.schema.json`。必须包含非空 `answers`、非空 `source_observations`、两张原始表安全相对路径与 SHA256，以及：

- `answer_landscape`
- `competitors`
- `excluded_observations`
- `benchmark_pages` 与 `benchmark_observation_ids`
- `supplementary_primary_sources`
- `recurring_subquestions`
- `structure_findings`
- `warnings`

`micro_tracking_builder.py` 负责确定性导入与根 Schema 校验；结构拆解先写入 `derived-analysis.json` 再合并。未访问或证据字段不完整的页面不得进入标杆。

## 交接门

E3 必须重新核验双表实体文件、哈希、题面、未排除答案和标杆访问证据。E2 不选 P 模式、不写蓝图、正文或标题，不做品牌全局诊断、分数、日历、分发或 CMS。

