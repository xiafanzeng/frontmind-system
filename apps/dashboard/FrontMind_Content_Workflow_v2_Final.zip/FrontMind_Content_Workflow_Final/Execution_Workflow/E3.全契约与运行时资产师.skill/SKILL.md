---
name: frontmind-job-contract-and-runtime-assets
description: >
  E3 全契约与运行时资产师。对 E1–E2 交接执行完整 intake，随后从只读签名 Pack 建立 job-local、追加式证据与图片 Registry；
  为 E4–E10 提供统一哈希锚点。
---

# E3 全契约与运行时资产师

## 职责

E3 是正式生产前的总契约门，不写文章。它分三步：

1. `intake_validator.py` 校验 staging receipt、ZIP SHA、Content Job、scope、Reference Pack、Pack 内 Registry 与规则注册表；普通四入口同时校验 E2 monitoring input 及原始双表哈希，`foundation_start` 明确跳过监控；
2. `build_runtime_evidence_bundle.py` 从签名 source/claim Registry 建立 job-local 追加式证据 Registry 与绑定回执；
3. `seed_runtime_image_registry.py` 建立 job-local 图片 Registry 与 seed receipt。

只有三步全部通过才进入 E4。

## 只读基础与追加式运行时资产

签名 Pack 永远只读。E3 生成两套 job-local 正本：

- runtime source/claim registries：保留 base 记录原值，只允许追加本问题新来源、新主张和证据文件；
- runtime image registry：保留 base 图片记录，只允许追加本问题补图、生成图及其权利/来源元数据。

每个 runtime receipt 必须绑定 `job_id`、base Registry canonical SHA256、extension 记录/证据文件哈希和输出 Registry SHA256；`pack_id` 由同一任务的 E3 intake 回执绑定。E4–E10 必须消费同一组路径与哈希，不能改回安装目录中的 Registry。

在 job root 运行下列命令。证据扩展必须显式传入已 stage 的 Pack 内 Pattern Registry，由其中的
`first_party_publication_contract` 判定 base/runtime 信源状态：

```bash
python3 -B scripts/build_runtime_evidence_bundle.py \
  --job-id job_xxx \
  --base-claims reference/registries/claim_registry.json \
  --base-sources reference/registries/source_registry.json \
  --pattern-registry reference/shared/content-pattern-registry.json \
  --extension 03_runtime_evidence/extension.json \
  --job-package-root /path/to/job \
  --runtime-claims 03_runtime_evidence/claim_registry.json \
  --runtime-sources 03_runtime_evidence/source_registry.json \
  --receipt 03_runtime_evidence/receipt.json
```

新增网页来源不得仅保存 URL 或自填 `verified`：必须保存 job-local snapshot/摘录文件，登记安全相对路径、SHA256、访问时间、来源 URL、检索状态、审核者及授权状态。新增 claim 必须引用 runtime source 或 monitoring observation，并记录核验状态。原创证据的 `record_refs` 必须命中签名 Pack 文件或 runtime evidence files；不得使用不存在的字符串洗白。

## 入口差异

- 普通四入口：`monitoring_input_path` 非空，E2 输出必须通过题面、有效答案、真实访问标杆与双表哈希门。
- `foundation_start`：`monitoring_input_path=null`，无 E2 文件；E3 仍必须校验 Pack、scope、五入口、P13 唯一路由前提及 runtime 资产。
- `industry_ranking`：保留 E1 已选 P01 variant，禁止后续静默改型。

## 输出

- `E3_intake_report.json`；
- runtime source Registry、runtime claim Registry、`E3_runtime_evidence_receipt.json`；
- runtime image Registry、`E3_runtime_image_receipt.json`；
- 阶段状态 `passed|blocked`。

报告必须包含 Pack、规则注册表、scope、monitoring（如适用）、base/runtime Registry 的 canonical SHA256。任一输入身份或实体文件哈希不一致即阻断。

## 边界

E3 不选择 P 模式、不写正文、不生产图片、不改 Pack，也不做分发/CMS。需长期复用的新事实、Logo 或企业事实图，应回到 S2／S6，并经 S8 确认、S9 重封装新版签名 Pack；单篇研究资产只留在 job-local runtime Registry。
