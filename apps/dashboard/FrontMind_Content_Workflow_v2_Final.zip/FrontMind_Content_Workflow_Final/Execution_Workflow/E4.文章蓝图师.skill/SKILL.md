---
name: frontmind-article-blueprint
description: >
  E4 文章蓝图师。基于 E1–E3 的任务、范围、监控与运行时证据，从签名 P01–P15 注册表自动选择恰好一个模式，
  产出单篇问题契约、结构、证据和视觉蓝图；只规划标题公式，不生成标题候选。
---

# E4 文章蓝图师

## 决策顺序

1. 锁定 `entry_category`、任务来源、范围与一个核心决策；
2. 普通四入口读取 E2 Micro Tracking，逐页决定采用、部分采用或拒绝标杆结构；`foundation_start` 不使用监控；
3. 从 Pack 内签名 `content-pattern-registry.json` 自动选择恰好一个 P 模式；
4. 锁定 5–8 个必要子问题、误解、顾虑、反对意见、替代方案、证据和品牌自然介入点；
5. 形成 lead、5–8 节正文、5–8 FAQ、结论和视觉槽位计划。

入口不是模板。用户不选择 P01–P15。`foundation_start` 只能选择 P13，并从 `foundation_subject`、scope 与企业资料推导主问题；普通任务不得选择 P13。

## P01 两种变体

E1 已明确的 `requested_pattern_variant` 必须原样进入蓝图：

- `multi_brand_editorial_recommendation`：至少三家真实候选，客户品牌首先展示并重点详写；所有候选仍按同一最低维度、日期和来源检查。顺序是编辑推荐顺序，不是量化客观名次。
- `single_brand_recommendation`：只写客户品牌，竞品名称和竞品矩阵均禁止；用定位、RTB、流程、案例、限制和适用条件形成深度推荐。

两种变体都禁止“第一名、榜首、综合第一、得分最高、市场最佳”等客观排名承诺。客户品牌首先展示属于服务商的编辑优先级，必须由 `priority_angle.editorial_priority_only=true` 明示，不能伪装成第三方结论。

## Micro Tracking 融合

普通任务的 `benchmark_fusion` 必须绑定 E2 monitoring canonical SHA256，并对每个 `benchmark_pages[].observation_id` 恰好做一次决定；采用结构要列明元素和理由，`structure_finding_indexes` 只能指向 E2 的真实发现。标杆提供回答方式，不提供可直接复用的事实或文字。

`foundation_start` 使用 `foundation_template_only`（无外部标杆）或 `foundation_benchmark`（有可追溯补充标杆），`monitoring_input_sha256=null`；不得伪造 E2 监控。

## 证据与内容计划

- `priority_angle` 绑定签名 Pack 中 S4 `brand_priority_angles`、proof bundle 与 claim，只决定客户品牌先写和详写的角度；不能越过证据推导排名、口碑或竞品优劣。P01-M 必须选择一个，P01-S 与其他模式可为 `null`；对象存在时必须完整包含 `angle_id/angle/proof_bundle_ids/claim_ids/editorial_priority_only`，并由 `--information-evidence` 逐项验证。
- lead 首句计划 40–80 字，微型答案计划覆盖结论、判断标准、关键依据、决策情境、时间基准与限定。
- 每个 H2 是完整用户问题；每节写结论、证据策略和读者建议。
- 所有事实型 lead、章节、FAQ 和结论 claim 均进入 `claim_plan`。
- `title_formula_plan` 只保存公式、可用形态词、时间规则和禁用承诺。标题数量在 E10 批准正文后询问，E4 不生成标题。
- 视觉槽位只使用 `brand_editorial/navigate/explain/prove` 四种文章功能；不是所有视觉都要证明，只有 `prove` 必须绑定通过 E6 的 claim 与 source。

## 输出与验证

输出 `E4_{job_id}_article_blueprint.json`，直接满足根 `shared/article_blueprint.schema.json`。运行：

```bash
python3 -B E4.文章蓝图师.skill/scripts/pattern_router.py \
  --registry /job/reference/shared/content-pattern-registry.json \
  --blueprint /job/03_blueprint/E4_job_article_blueprint.json \
  --content-job /job/00_input/content_job.json \
  --scope-analysis /job/00_input/scope_analysis.json \
  --monitoring-input /job/01_monitoring/E2_job_monitoring_input.json
```

`foundation_start` 省略 `--monitoring-input`。Schema、job/scope/hash、路由、variant、标杆、claim 与 answer-first 任一不一致即阻断。

## 禁止

不生成正文、标题列表、内容日历、渠道、CMS 或分发规则；不读取 legacy A/B/C 模板运行。旧结构只可通过 `professional-structure-migration.md` 中已提炼组件进入蓝图。
