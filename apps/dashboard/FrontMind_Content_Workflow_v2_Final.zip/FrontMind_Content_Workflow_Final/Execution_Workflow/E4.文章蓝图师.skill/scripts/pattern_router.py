#!/usr/bin/env python3
"""Validate an E4 blueprint against the signed job pattern registry."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "shared"))
sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "shared"))
from schema_validation import validate_root  # noqa: E402
from text_quality import question_key_tokens, substantive_text_errors  # noqa: E402
from content_route import P01_VARIANTS, validate_entry_pattern_route  # noqa: E402
from candidate_binding import blueprint_candidate_binding_errors  # noqa: E402


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain a JSON object")
    return value


def canonical_sha256(value: dict[str, Any]) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate(
    registry: dict[str, Any], blueprint: dict[str, Any], content_job: dict[str, Any],
    scope: dict[str, Any], scope_path: Path, monitoring: dict[str, Any] | None,
    information_evidence: dict[str, Any], e3_intake: dict[str, Any],
) -> dict[str, Any]:
    errors: list[str] = []
    for value, schema, label in (
        (blueprint, "article_blueprint.schema.json", "E4 article blueprint"),
        (content_job, "content_job.schema.json", "E1 Content Job"),
        (scope, "scope_analysis.schema.json", "E1 scope analysis"),
    ):
        try:
            validate_root(value, schema, label)
        except ValueError as exc:
            errors.append(str(exc))

    job_id, entry = content_job.get("job_id"), content_job.get("entry_category")
    task = content_job.get("task", {}) if isinstance(content_job.get("task"), dict) else {}
    if blueprint.get("job_id") != job_id or scope.get("job_id") != job_id:
        errors.append("job_id differs across Content Job, scope and blueprint")
    if blueprint.get("entry_category") != entry:
        errors.append("blueprint.entry_category differs from Content Job")
    if blueprint.get("question_origin") != task.get("question_origin"):
        errors.append("blueprint.question_origin differs from Content Job")
    if entry != "foundation_start" and blueprint.get("primary_question") != task.get("question_text"):
        errors.append("ordinary-entry blueprint must preserve the externally confirmed question")
    if blueprint.get("question_contract", {}).get("primary_question") != blueprint.get("primary_question"):
        errors.append("question_contract.primary_question differs from blueprint.primary_question")
    scope_ref = blueprint.get("scope_analysis_ref", {})
    if scope_ref.get("path") != content_job.get("scope_analysis_path") or scope_ref.get("sha256") != file_sha256(scope_path):
        errors.append("scope_analysis_ref path/hash does not bind the supplied scope analysis")
    if scope.get("clarification", {}).get("status") == "required":
        errors.append("scope clarification remains unresolved")
    try:
        validate_root(
            information_evidence, "information_evidence_architecture.schema.json",
            "E4 signed S4 information/evidence architecture",
        )
    except ValueError as exc:
        errors.append(str(exc))
    if (
        e3_intake.get("schema_version") != "2.0.0"
        or e3_intake.get("job_id") != job_id
        or e3_intake.get("stage") != "E3_intake"
        or e3_intake.get("status") != "passed"
        or e3_intake.get("information_evidence_architecture_sha256") != canonical_sha256(information_evidence)
    ):
        errors.append("E3 intake does not approve this exact information/evidence architecture")

    patterns = {
        str(item.get("id")): item for item in registry.get("patterns", []) if isinstance(item, dict)
    }
    routing = registry.get("routing", {}) if isinstance(registry.get("routing"), dict) else {}
    pattern_id, variant = blueprint.get("pattern_id"), blueprint.get("pattern_variant")
    route = routing.get(entry, {}) if isinstance(routing.get(entry), dict) else {}
    if registry.get("schema_version") != "2.0.0":
        errors.append("signed content pattern registry must use schema_version=2.0.0")
    errors.extend(validate_entry_pattern_route(blueprint, registry))
    errors.extend(blueprint_candidate_binding_errors(
        blueprint, e3_intake.get("canonical_brand_name"), monitoring,
    ))
    if entry == "foundation_start":
        if pattern_id != "P13" or blueprint.get("question_origin") != "foundation_derived":
            errors.append("foundation_start must derive one P13 blueprint")
        if monitoring is not None:
            errors.append("foundation_start must not consume monitoring input")
        benchmark = blueprint.get("benchmark_fusion", {})
        if benchmark.get("status") not in {"foundation_template_only", "foundation_benchmark"}:
            errors.append("foundation_start benchmark_fusion must use a canonical foundation status")
        if benchmark.get("monitoring_input_sha256") is not None:
            errors.append("foundation_start benchmark_fusion must not claim an E2 monitoring hash")
        if benchmark.get("status") == "foundation_template_only" and benchmark.get("benchmark_decisions"):
            errors.append("foundation_template_only must not contain benchmark decisions")
    else:
        if pattern_id == "P13":
            errors.append("P13 is exclusive to foundation_start")
        if monitoring is None:
            errors.append("ordinary entries require E2 monitoring input")
        else:
            try:
                validate_root(monitoring, "monitoring_input.schema.json", "E2 monitoring input")
            except ValueError as exc:
                errors.append(str(exc))
            if monitoring.get("job_id") != job_id or monitoring.get("question") != blueprint.get("primary_question"):
                errors.append("monitoring job/question does not bind the blueprint")
            fusion = blueprint.get("benchmark_fusion", {})
            if fusion.get("monitoring_input_sha256") != canonical_sha256(monitoring):
                errors.append("benchmark_fusion monitoring hash mismatch")
            derived = monitoring.get("derived", {}) if isinstance(monitoring.get("derived"), dict) else {}
            benchmark_ids = {
                str(item.get("observation_id")) for item in derived.get("benchmark_pages", []) if isinstance(item, dict)
            }
            decisions = fusion.get("benchmark_decisions", []) if isinstance(fusion.get("benchmark_decisions"), list) else []
            decision_ids = [str(item.get("observation_id")) for item in decisions if isinstance(item, dict)]
            if len(decision_ids) != len(set(decision_ids)) or set(decision_ids) != benchmark_ids:
                errors.append("benchmark decisions must cover every and only E2 benchmark page once")
            findings = derived.get("structure_findings", []) if isinstance(derived.get("structure_findings"), list) else []
            indexes = fusion.get("structure_finding_indexes", [])
            if any(not isinstance(i, int) or isinstance(i, bool) or not 0 <= i < len(findings) for i in indexes):
                errors.append("benchmark structure_finding_indexes contain an invalid index")

    if pattern_id == "P01":
        requested = task.get("requested_pattern_variant")
        if variant != requested or variant not in P01_VARIANTS:
            errors.append("P01 blueprint variant must equal the E1 requested canonical variant")
        forbidden = patterns.get("P01", {}).get("forbidden_objective_rank_terms", [])
        rendered = json.dumps(blueprint, ensure_ascii=False)
        hits = [term for term in forbidden if str(term).lower() in rendered.lower()]
        if hits:
            errors.append(f"P01 blueprint contains forbidden objective-rank language: {hits}")
    elif variant is not None:
        errors.append("only P01 may set pattern_variant")

    if entry == "product_scenario":
        subintent = blueprint.get("product_scenario_subintent")
        if not subintent:
            errors.append("E4 must infer and persist a product_scenario_subintent")
        primary_route = set(route.get("primary_patterns", []))
        if pattern_id in primary_route and pattern_id not in set(route.get("subintent_routing", {}).get(subintent, [])):
            errors.append("primary pattern is incompatible with inferred product subintent")
    elif blueprint.get("product_scenario_subintent") is not None:
        errors.append("non-product blueprint must set product_scenario_subintent=null")

    priority = blueprint.get("priority_angle")
    requires_priority = pattern_id == "P01" and variant == "multi_brand_editorial_recommendation"
    if requires_priority and not isinstance(priority, dict):
        errors.append("P01 multi-brand editorial recommendation requires one S4 priority_angle")
    if priority is not None:
        if isinstance(information_evidence, dict):
            angles = {
                str(item.get("angle_id")): item
                for item in information_evidence.get("brand_priority_angles", [])
                if isinstance(item, dict)
            }
            selected = angles.get(str(priority.get("angle_id"))) if isinstance(priority, dict) else None
            if not selected:
                errors.append("priority_angle.angle_id is absent from S4 brand_priority_angles")
            else:
                if priority.get("angle") != selected.get("angle"):
                    errors.append("priority_angle.angle must equal the selected S4 angle")
                if entry not in set(selected.get("eligible_entry_categories", [])):
                    errors.append("selected S4 priority angle is ineligible for this entry_category")
                if pattern_id not in set(selected.get("eligible_pattern_ids", [])):
                    errors.append("selected S4 priority angle is ineligible for this P pattern")
                selected_proofs = set(str(value) for value in selected.get("proof_refs", []))
                blueprint_proofs = set(str(value) for value in priority.get("proof_bundle_ids", []))
                if not blueprint_proofs or not blueprint_proofs <= selected_proofs:
                    errors.append("priority_angle.proof_bundle_ids must be a non-empty subset of the selected S4 proof_refs")
                proof_index = {
                    str(item.get("proof_id")): item
                    for item in information_evidence.get("proof_bundles", []) if isinstance(item, dict)
                }
                supported_claims = {
                    str(claim_id)
                    for proof_id in blueprint_proofs
                    for claim_id in (proof_index.get(proof_id, {}).get("claim_ids", []) or [])
                }
                priority_claims = set(str(value) for value in priority.get("claim_ids", []))
                if not priority_claims or not priority_claims <= supported_claims:
                    errors.append("priority_angle.claim_ids must be a non-empty subset of its S4 proof bundles")

    direct = str(blueprint.get("lead_plan", {}).get("direct_answer_sentence") or "")
    errors.extend(substantive_text_errors(direct, label="lead_plan.direct_answer_sentence", minimum=30, ratio=0.55, minimum_unique=8))
    tokens = question_key_tokens(str(blueprint.get("primary_question") or ""))
    if not tokens or not any(token in direct.lower() for token in tokens):
        errors.append("lead direct answer must contain a primary-question/entity key token")
    section_ids = {str(item.get("section_id")) for item in blueprint.get("section_plan", []) if isinstance(item, dict)}
    entry_ids = set(blueprint.get("question_contract", {}).get("brand_intervention", {}).get("entry_section_ids", []))
    if not entry_ids or entry_ids - section_ids:
        errors.append("brand intervention must point to existing sections")
    claim_plan = set(blueprint.get("claim_plan", []))
    local_claims: set[str] = set(blueprint.get("lead_plan", {}).get("claim_ids", []))
    local_claims.update(blueprint.get("conclusion_plan", {}).get("claim_ids", []))
    if isinstance(blueprint.get("priority_angle"), dict):
        local_claims.update(blueprint["priority_angle"].get("claim_ids", []))
    local_claims.update(blueprint.get("question_contract", {}).get("brand_intervention", {}).get("supported_claim_ids", []))
    for item in blueprint.get("section_plan", []):
        if isinstance(item, dict): local_claims.update(item.get("claim_ids", []))
    for item in blueprint.get("faq_plan", []):
        if isinstance(item, dict): local_claims.update(item.get("claim_ids", []))
    if local_claims - claim_plan:
        errors.append(f"local blueprint claims absent from claim_plan: {sorted(local_claims - claim_plan)}")

    return {
        "schema_version": "2.0.0", "job_id": job_id, "stage": "E4_blueprint_validation",
        "valid": not errors, "entry_category": entry, "pattern_id": pattern_id,
        "pattern_variant": variant, "registry_schema_version": registry.get("schema_version"), "errors": errors,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--registry", type=Path, required=True, help="signed Pack content-pattern-registry.json")
    parser.add_argument("--blueprint", type=Path, required=True)
    parser.add_argument("--content-job", type=Path, required=True)
    parser.add_argument("--scope-analysis", type=Path, required=True)
    parser.add_argument("--monitoring-input", type=Path, help="required except foundation_start")
    parser.add_argument("--information-evidence", type=Path, required=True,
                        help="signed Pack information_evidence_architecture_path")
    parser.add_argument("--e3-intake", type=Path, required=True)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    result = validate(
        load(args.registry), load(args.blueprint), load(args.content_job), load(args.scope_analysis),
        args.scope_analysis, load(args.monitoring_input) if args.monitoring_input else None,
        load(args.information_evidence), load(args.e3_intake),
    )
    rendered = json.dumps(result, ensure_ascii=False, indent=2)
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(rendered, encoding="utf-8")
    print(rendered)
    return 0 if result["valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
