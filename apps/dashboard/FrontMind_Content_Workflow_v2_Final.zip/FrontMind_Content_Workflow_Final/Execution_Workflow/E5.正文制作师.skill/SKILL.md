---
name: frontmind-canonical-body-writer
description: >
  E5 正文制作师。依据 E4 蓝图和 E3 runtime 证据，生成唯一、无标题的 canonical Content Model 及审阅 Markdown；
  每个实质主张绑定 claim，不生产标题、渠道版本或发布页面。
---

# E5 正文制作师

## 唯一正文正本

E5 只输出：

- `E5_{job_id}_content_model.draft.json`：直接满足根 `content_model.schema.json`；
- `E5_{job_id}_review.md`：由模型导出的无标题审阅视图，不是第二正本；
- `E5_{job_id}_validation.json`。

Content Model 顶层使用 `entry_category/question_origin/pattern_id/pattern_variant`。`metadata` **只能**包含 `language` 与 `as_of`；不得出现 `title`、`h1`、`title_candidates` 或 `meta_description`。标题在 E10 批准正文后单独生成。

## 写作规则

- 一篇只解决 E4 的一个主问题；5–8 个必要子问题、5–8 节问句式 H2、5–8 FAQ。
- 第一可见句 40–80 字直接回答；微型答案 200–300 字并以该句原文开头，包含完整实体、判断依据、决策情境、时间基准和限定。
- 每节按“结论—证据—建议”；一段一个观点、通常 2–4 句。
- 正文无表格、无 H1、无标题占位、无流程/审稿/Prompt 元话语。
- 教程步骤写输入、动作、预期结果和检查方法；比较对象用同维度、同口径、同日期；案例写背景、问题、动作、结果、周期与测量方法。
- 价格写币种、套餐、地区、版本、有效日期和附加条件；统计写时间、样本、单位、地区/人群和口径；所有对象写真实限制、不适用情况和门槛。

`content_function=factual_claim|analysis` 必须有字段本地 `claim_ids`；advice/instruction 若出现数字、时间、价格、完整实体能力断言或优越性信号，也必须绑定相关 claim。lead、FAQ factual answer 和 conclusion 同样使用本地 claim。不得用无关 claim ID 洗白。

可见 `references` 必须与正文实际使用 claims 的公开 `source_ids` 精确相等，显示名/URL 从 runtime source Registry 逐项复制。原创证据的公开 source 也必须进入该集合；没有独立“延伸阅读”字段，禁止混入未使用来源。

## 五入口与 P01

- `foundation_start` 必须是 P13，主问题来自 E4，不得伪造成外部用户原问。
- P01-M `multi_brand_editorial_recommendation`：客户品牌首先展示，至少三家真实候选，共同维度公平；不得写客观第一。
- P01-S `single_brand_recommendation`：只写客户品牌，禁止竞品名称、竞品矩阵和 ItemList。
- 其他模式 `pattern_variant=null`；P13 不得被普通四入口使用。

## 验证

运行 `scripts/content_model_validator.py`，传入 E3 runtime claim/source Registry、E3 intake/receipt、E1 scope、E4 blueprint 与 Pack 内签名 pattern registry。它同时检查根 Schema、身份/哈希、answer-first、具体性、claim 文本对齐、references 精确集合、P 模式与结构化数据资格。

视觉槽位在 E5 可为空；E7 才选择和生产资产并物化 `visual_placements`。E5 不得为通过视觉门虚填图片。

## 文风

采用第三方客观报道＋有证据的企业品牌表达。直接写结论、条件与风险；删除“资料较完整、相关资料显示、以审核为准、服务边界、信息边界、保持克制、用户提交资料、需要说明、不构成对……”等内部审稿腔。

