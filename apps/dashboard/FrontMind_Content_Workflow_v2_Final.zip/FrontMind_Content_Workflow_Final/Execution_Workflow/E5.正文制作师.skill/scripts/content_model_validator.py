#!/usr/bin/env python3
"""Validate the root canonical Content Model and its external registries."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "shared"))
sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "shared"))
from schema_validation import validate_root, validate_schema  # noqa: E402
from text_quality import answer_pair_errors, article_specificity_errors, material_claim_binding_errors  # noqa: E402
from registry_binding import canonical_sha256, validate_registry_binding  # noqa: E402
from reference_equivalence import reference_equivalence_errors  # noqa: E402
from content_route import P01_VARIANTS, validate_entry_pattern_route  # noqa: E402
from candidate_binding import model_candidate_binding_errors, p01_objective_rank_errors  # noqa: E402
from source_state import source_state_errors  # noqa: E402


INTERNAL_PHRASES = (
    "资料较完整", "相关资料显示", "以审核为准", "服务边界", "信息边界", "保持克制",
    "用户提交资料", "需要说明", "不构成对", "本文采用", "Execution Layer", "证据单元",
    "待人工复核", "optimized_by", "HarnessGEO", "AutoGEO",
)
EMPTY_OPENINGS = ("随着时代发展", "近年来越来越多", "众所周知")


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain an object")
    return value


def unicode_chars(text: str) -> int:
    """Match JSON Schema minLength/maxLength semantics for this workflow."""
    return len(text.strip())


def model_blocks(model: dict[str, Any]):
    for section in model.get("sections", []):
        if not isinstance(section, dict):
            continue
        for block in section.get("blocks", []):
            if isinstance(block, dict):
                yield section.get("section_id"), block
        for subsection in section.get("subsections", []):
            if isinstance(subsection, dict):
                for block in subsection.get("blocks", []):
                    if isinstance(block, dict):
                        yield section.get("section_id"), block


def all_text(model: dict[str, Any]) -> str:
    lead = model.get("lead", {})
    chunks = [str(lead.get(key, "")) for key in ("direct_answer_sentence", "micro_answer")]
    for section in model.get("sections", []):
        if not isinstance(section, dict):
            continue
        chunks.append(str(section.get("h2_question", "")))
        for subsection in section.get("subsections", []):
            if isinstance(subsection, dict):
                chunks.append(str(subsection.get("h3", "")))
    for _, block in model_blocks(model):
        chunks.append(str(block.get("text", "")))
        chunks.extend(str(item) for item in block.get("items", []) or [])
    for item in model.get("faq", []):
        if isinstance(item, dict):
            chunks.extend((str(item.get("question", "")), str(item.get("answer", ""))))
    conclusion = model.get("conclusion", {})
    if isinstance(conclusion, dict):
        chunks.extend(str(conclusion.get(key, "")) for key in ("summary", "fit", "next_action"))
    return "\n".join(chunks)


def validate(
    model: dict[str, Any], claim_registry: dict[str, Any], source_registry: dict[str, Any],
    content_job: dict[str, Any], blueprint: dict[str, Any], intake_report: dict[str, Any],
    runtime_evidence_receipt: dict[str, Any], scope: dict[str, Any], pattern_registry: dict[str, Any],
    monitoring: dict[str, Any] | None,
) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    for value, schema_name, label in (
        (model, "content_model.schema.json", "E2 content_model"),
        (claim_registry, "registries.schema.json", "E2 claim_registry"),
        (source_registry, "registries.schema.json", "E2 source_registry"),
        (content_job, "content_job.schema.json", "E2 content_job"),
        (blueprint, "article_blueprint.schema.json", "E2 article_blueprint"),
        (scope, "scope_analysis.schema.json", "E1 scope_analysis"),
    ):
        try:
            validate_root(value, schema_name, label)
        except ValueError as exc:
            errors.append(str(exc))
    try:
        validate_schema(
            runtime_evidence_receipt,
            Path(__file__).resolve().parents[2] / "E3.全契约与运行时资产师.skill" / "templates" / "runtime_evidence_bundle_receipt.schema.json",
            "E5 runtime evidence receipt",
        )
        validate_registry_binding(
            intake_report=intake_report, job_id=model.get("job_id"),
            claim_registry=claim_registry, source_registry=source_registry,
            runtime_receipt=runtime_evidence_receipt,
        )
    except ValueError as exc:
        errors.append(f"registry_binding:{exc}")
    task = content_job.get("task") if isinstance(content_job.get("task"), dict) else {}
    if content_job.get("job_id") != model.get("job_id") or blueprint.get("job_id") != model.get("job_id"):
        errors.append("content_job/blueprint/model job_id mismatch")
    for expected, actual, label in (
        (blueprint.get("primary_question"), model.get("primary_question"), "primary_question"),
        (content_job.get("entry_category"), model.get("entry_category"), "entry_category"),
        (task.get("question_origin"), model.get("question_origin"), "question_origin"),
        (blueprint.get("pattern_id"), model.get("pattern_id"), "pattern_id"),
        (blueprint.get("pattern_variant"), model.get("pattern_variant"), "pattern_variant"),
        (blueprint.get("product_scenario_subintent"), model.get("product_scenario_subintent"), "product_scenario_subintent"),
    ):
        if expected != actual:
            errors.append(f"content_job/blueprint/model identity mismatch:{label}")
    metadata_scope = model.get("metadata") if isinstance(model.get("metadata"), dict) else {}
    if metadata_scope.get("as_of") != scope.get("time_basis", {}).get("as_of"):
        errors.append("metadata.as_of_must_equal_scope_analysis.time_basis.as_of")
    if model.get("schema_version") != "2.0.0":
        errors.append("schema_version_must_be_2.0.0")
    if not str(model.get("job_id", "")).startswith("job_"):
        errors.append("invalid_job_id")
    category = model.get("entry_category")
    if category not in {"industry_ranking", "competitor_comparison", "reputation", "product_scenario", "foundation_start"}:
        errors.append("invalid_entry_category")
    if not str(model.get("primary_question", "")).strip():
        errors.append("missing_primary_question")
    subintent = model.get("product_scenario_subintent")
    valid_subintents = {"offering_definition", "feature_mechanism", "scenario_fit", "delivery_usage", "support_boundary", "price_selection"}
    if category == "product_scenario" and subintent not in valid_subintents:
        errors.append("product_scenario_requires_valid_subintent")
    if category != "product_scenario" and subintent is not None:
        errors.append("non_product_category_requires_null_subintent")
    if claim_registry.get("registry_type") != "claim_registry":
        errors.append("invalid_claim_registry_type")
    if source_registry.get("registry_type") != "source_registry":
        errors.append("invalid_source_registry_type")
    errors.extend(f"blueprint_route:{value}" for value in validate_entry_pattern_route(blueprint, pattern_registry))
    errors.extend(f"model_route:{value}" for value in validate_entry_pattern_route(model, pattern_registry))

    metadata = model.get("metadata", {})
    lead = model.get("lead", {})
    if set(metadata) != {"language", "as_of"} or metadata.get("language") != "zh-CN" or not metadata.get("as_of"):
        errors.append("metadata_must_be_title_free_and_contain_only_language_as_of")

    direct = str(lead.get("direct_answer_sentence", ""))
    micro = str(lead.get("micro_answer", ""))
    direct_count, micro_count = unicode_chars(direct), unicode_chars(micro)
    if not 40 <= direct_count <= 80:
        errors.append(f"direct_answer_unicode_chars:{direct_count}:expected_40_80")
    if not 200 <= micro_count <= 300:
        errors.append(f"micro_answer_unicode_chars:{micro_count}:expected_200_300")
    if direct and not micro.startswith(direct):
        errors.append("micro_answer_must_start_with_direct_answer_sentence")
    errors.extend(answer_pair_errors(direct, micro, str(model.get("primary_question", ""))))
    if any(direct.startswith(prefix) for prefix in EMPTY_OPENINGS):
        errors.append("empty_information_opening")

    sections = model.get("sections", [])
    if not isinstance(sections, list) or not 5 <= len(sections) <= 8:
        errors.append(f"section_count:{len(sections) if isinstance(sections, list) else 'invalid'}:expected_5_8")
    section_ids = [str(item.get("section_id")) for item in sections if isinstance(item, dict)] if isinstance(sections, list) else []
    if len(section_ids) != len(set(section_ids)):
        errors.append("duplicate_section_ids")
    for section in sections if isinstance(sections, list) else []:
        if not isinstance(section, dict) or not re.search(r"[？?]$", str(section.get("h2_question", "")).strip()):
            errors.append(f"h2_must_be_complete_question:{section.get('section_id') if isinstance(section, dict) else 'invalid'}")
    coverage = model.get("subquestion_coverage", [])
    if not isinstance(coverage, list) or not 5 <= len(coverage) <= 8:
        errors.append(f"subquestion_coverage_count:{len(coverage) if isinstance(coverage, list) else 'invalid'}:expected_5_8")
    elif len({str(item.get('subquestion')) for item in coverage if isinstance(item, dict)}) != len(coverage):
        errors.append("duplicate_subquestions")
    for item in coverage if isinstance(coverage, list) else []:
        if not isinstance(item, dict) or not item.get("section_ids"):
            errors.append("invalid_subquestion_coverage_item")
            continue
        unknown = set(str(value) for value in item.get("section_ids", [])) - set(section_ids)
        if unknown:
            errors.append(f"subquestion_coverage_unknown_sections:{','.join(sorted(unknown))}")

    faq = model.get("faq", [])
    if not isinstance(faq, list) or not 5 <= len(faq) <= 8:
        errors.append(f"faq_count:{len(faq) if isinstance(faq, list) else 'invalid'}:expected_5_8")
    for index, item in enumerate(faq if isinstance(faq, list) else [], 1):
        if not isinstance(item, dict) or not re.search(r"[？?]$", str(item.get("question", "")).strip()):
            errors.append(f"faq_question_must_end_with_question_mark:{index}")
    text = all_text(model)
    if re.search(r"(?m)^\s*\|.+\|\s*$", text) or "<table" in text.lower():
        errors.append("body_table_forbidden")
    for phrase in INTERNAL_PHRASES:
        if phrase.lower() in text.lower():
            errors.append(f"internal_process_phrase:{phrase}")
    errors.extend(article_specificity_errors(model))
    errors.extend(material_claim_binding_errors(model, claim_registry, require_content_function=True))

    claims = {str(item.get("claim_id")): item for item in claim_registry.get("claims", []) if isinstance(item, dict)}
    sources = {str(item.get("source_id")): item for item in source_registry.get("sources", []) if isinstance(item, dict)}
    referenced_claims: set[str] = {
        str(value) for value in lead.get("claim_ids", [])
    }
    for section_id, block in model_blocks(model):
        referenced_claims.update(str(value) for value in block.get("claim_ids", []))
        sentence_count = len(re.findall(r"[。！？!?]", str(block.get("text", ""))))
        if block.get("type") == "paragraph" and sentence_count > 4:
            warnings.append(f"paragraph_over_4_sentences:{section_id}:{block.get('block_id')}")
        if block.get("type") == "step":
            contract = block.get("step_contract") or {}
            missing = [key for key in ("input", "action", "expected_result", "check_method") if not contract.get(key)]
            if missing:
                errors.append(f"incomplete_step_contract:{block.get('block_id')}:{','.join(missing)}")
    for item in faq:
        if isinstance(item, dict):
            referenced_claims.update(str(value) for value in item.get("claim_ids", []))
    conclusion_for_claims = model.get("conclusion", {})
    if isinstance(conclusion_for_claims, dict):
        referenced_claims.update(str(value) for value in conclusion_for_claims.get("claim_ids", []))

    for claim_id in sorted(referenced_claims):
        claim = claims.get(claim_id)
        if not claim:
            errors.append(f"unknown_claim:{claim_id}")
            continue
        if claim.get("verification_status") in {"needs_verification", "disallowed"}:
            errors.append(f"unusable_claim:{claim_id}:{claim.get('verification_status')}")
        if claim.get("allowed_usage") in {"internal_only", "do_not_use"}:
            errors.append(f"nonpublic_claim_used:{claim_id}:{claim.get('allowed_usage')}")
        if claim.get("allowed_usage") in {"public_fact", "public_with_qualification"} and not claim.get("source_ids"):
            errors.append(f"public_claim_without_source:{claim_id}")
        for source_id in claim.get("source_ids", []):
            if str(source_id) not in sources:
                errors.append(f"unknown_source:{claim_id}:{source_id}")
        original = claim.get("original_evidence")
        if isinstance(original, dict):
            for source_id in original.get("source_ids", []):
                if str(source_id) not in sources:
                    errors.append(f"unknown_original_evidence_source:{claim_id}:{source_id}")
            if original.get("authorization_status") in {"public_approved", "anonymized_approved"}:
                if not (original.get("source_ids") or original.get("record_refs")):
                    errors.append(f"approved_original_evidence_without_trace:{claim_id}")
                for key in ("type", "methodology", "scope", "collected_at"):
                    if not original.get(key):
                        errors.append(f"incomplete_original_evidence:{claim_id}:{key}")

    used_source_ids = {
        str(source_id)
        for claim_id in referenced_claims
        for source_id in claims.get(claim_id, {}).get("source_ids", [])
    }
    errors.extend(
        f"source_publication_state:{value}"
        for value in source_state_errors(source_registry, runtime_evidence_receipt, used_source_ids, pattern_registry)
    )

    visible_reference_ids = {str(item.get("source_id")) for item in model.get("references", []) if isinstance(item, dict)}
    errors.extend(reference_equivalence_errors(model, claim_registry))
    for source_id in visible_reference_ids:
        if source_id not in sources:
            errors.append(f"visible_reference_not_in_registry:{source_id}")
    for index, reference in enumerate(model.get("references", [])):
        if not isinstance(reference, dict):
            continue
        source = sources.get(str(reference.get("source_id")))
        if source and (
            reference.get("display_name") != source.get("title")
            or reference.get("url") != source.get("url")
        ):
            errors.append(f"visible_reference_metadata_mismatch:{index}:{reference.get('source_id')}")

    pattern_id, variant = model.get("pattern_id"), model.get("pattern_variant")
    patterns = {str(item.get("id")): item for item in pattern_registry.get("patterns", []) if isinstance(item, dict)}
    pattern = patterns.get(str(pattern_id), {})
    allowed_structured = set(pattern.get("eligible_json_ld", []))
    disallowed_structured = set(model.get("structured_data_types", [])) - allowed_structured
    if disallowed_structured:
        errors.append(f"structured_data_not_eligible_for_pattern:{sorted(disallowed_structured)}")
    if pattern_id == "P01":
        if variant not in P01_VARIANTS:
            errors.append("P01_requires_canonical_pattern_variant")
        if variant == "single_brand_recommendation" and "ItemList" in model.get("structured_data_types", []):
            errors.append("P01_single_brand_forbids_ItemList")
        rendered_text = text.lower()
        for term in pattern.get("forbidden_objective_rank_terms", []):
            if str(term).lower() in rendered_text:
                errors.append(f"P01_forbidden_objective_rank_term:{term}")
    elif variant is not None:
        errors.append("non_P01_requires_null_pattern_variant")
    errors.extend(
        f"candidate_binding:{value}"
        for value in model_candidate_binding_errors(
            model, blueprint, claim_registry, source_registry,
            intake_report.get("canonical_brand_name"),
            intake_report.get("canonical_brand_aliases", []), monitoring,
        )
    )
    errors.extend(f"objective_rank:{value}" for value in p01_objective_rank_errors(model))
    if category == "foundation_start" and (pattern_id != "P13" or model.get("question_origin") != "foundation_derived"):
        errors.append("foundation_start_requires_P13_foundation_derived")
    if category != "foundation_start" and pattern_id == "P13":
        errors.append("P13_is_exclusive_to_foundation_start")
    conclusion = model.get("conclusion")
    if not isinstance(conclusion, dict) or any(not str(conclusion.get(key, "")).strip() for key in ("summary", "fit", "next_action")):
        errors.append("complete_conclusion_required")
    if not model.get("structured_data_types"):
        errors.append("at_least_one_structured_data_type_required")
    return {
        "schema_version": "2.0.0", "job_id": model.get("job_id"), "stage": "E5_content_model_validation",
        "valid": not errors, "errors": sorted(set(errors)), "warnings": sorted(set(warnings)),
        "claim_registry_sha256": canonical_sha256(claim_registry),
        "source_registry_sha256": canonical_sha256(source_registry),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("--claims", type=Path, required=True)
    parser.add_argument("--sources", type=Path, required=True)
    parser.add_argument("--content-job", type=Path, required=True)
    parser.add_argument("--blueprint", type=Path, required=True)
    parser.add_argument("--intake-report", type=Path, required=True)
    parser.add_argument("--runtime-evidence-receipt", type=Path, required=True)
    parser.add_argument("--scope-analysis", type=Path, required=True)
    parser.add_argument("--pattern-registry", type=Path, required=True,
                        help="signed Pack content-pattern-registry.json")
    parser.add_argument("--monitoring-input", type=Path,
                        help="canonical E2 monitoring input; required by P01-M candidate binding")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    result = validate(
        load(args.model), load(args.claims), load(args.sources), load(args.content_job),
        load(args.blueprint), load(args.intake_report),
        load(args.runtime_evidence_receipt), load(args.scope_analysis), load(args.pattern_registry),
        load(args.monitoring_input) if args.monitoring_input else None,
    )
    rendered = json.dumps(result, ensure_ascii=False, indent=2)
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(rendered, encoding="utf-8")
    print(rendered)
    return 0 if result["valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
