---
name: frontmind-evidence-preflight
description: >
  E6 证据预检师。逐主张校验 E5 无标题正文、运行时来源、比较矩阵和第一方资料可发布性；
  输出 passed / passed_with_claim_limits / blocked 的第一方证据门，并阻止不受支持内容进入视觉生产。
---

# E6 证据预检师

## 输入

- E5 Content Model、E4 Blueprint、E1 Content Job；
- E3 intake report、runtime source/claim Registry 及其 receipt；
- Pack 内签名 P registry、base/job roots；
- 比较矩阵（若需要）；
- 与正文 evidence projection、两类 Registry 及矩阵 hash 绑定的逐 claim 语义复核回执。

E6 首先用根 Schema 和 E3 哈希链验证身份，再检查每个 material claim 的字段本地 claim 绑定、claim 文本相关性、来源实体文件/URL 快照、时间/范围/价格/统计口径及可见 references 精确集合。机器结构通过不等于语义支持；语义回执必须逐个覆盖正文实际使用的全部 claim。

## 第一方资料三态门

读取签名 `first_party_publication_contract`：

### `passed`

经审批且哈希绑定的第一方公开资料可以支持本企业的身份、产品、规格、价格、政策、事件、限制、能力和案例结果；正文仅陈述其能证明的事实。

### `passed_with_claim_limits`

资料可发布，但 claim 是 `verified_with_limits` 或 `public_with_qualification`。限制必须已写入 E4 `claim_limitations` 和正文的范围、日期、条件；回执列出 claim ID、原因和允许表述范围。

### `blocked`

以下任一情形阻断：

- 使用 `first_party_internal` 或 authorization 为 internal/pending/prohibited 的来源；
- 只靠第一方资料推导市场口碑、行业认可、客观排名、竞品优劣、独立测试、专家共识、最佳/第一/领先；
- 第一方资料支撑了合同外 claim 类型；
- E4 未声明正文实际使用的第一方来源。

内部资料不能因挂到 public claim 上就变成公开来源。若加入真实第三方证据，应先进入 E3 runtime evidence bundle，再完整重跑 E5–E6。

## 比较公平门

- `entry_category=competitor_comparison` 或 P02 一律需要矩阵；
- P01-M 一律需要至少三家对象的矩阵；客户品牌可首先展示，但每个对象必须覆盖同一维度、来源、日期、范围和缺失说明；
- P01-S 禁止矩阵和竞品对象；
- 其他模式只要正文明确比较两个以上对象，也需要矩阵。

矩阵对象必须覆盖正文真实比较对象，不得用 X/Y 空壳替代 A/B。

## 视觉生命周期

E5 的 `visual_placements` 必须为空；E6 只审 E4 `visual_plan` 的证据需求。E7 才选择/生产资产并回写 placement。这样正文证据投影不因图片物化而失效。

## 输出

- `E6_{job_id}_evidence_preflight.json`；
- E6 evidence semantic review；
- 可选 competitor matrix。

整体 `status=passed` 才能进入 E7。第一方 gate 为 `passed_with_claim_limits` 时，只要限制已固化且语义复核一致，整体仍可通过；gate 为 `blocked` 必须停止。修复正文归 E5，补充证据归 E3，重选模式归 E4。

