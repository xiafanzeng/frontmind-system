#!/usr/bin/env python3
"""Deterministic evidence preflight for root Content Model + registries."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

sys.dont_write_bytecode = True
from matrix_contract import competitor_matrix_requirement, validate_competitor_matrix

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "shared"))
sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "shared"))
from schema_validation import validate_root, validate_schema  # noqa: E402
from text_quality import material_claim_binding_errors  # noqa: E402
from content_projections import evidence_projection_sha256  # noqa: E402
from registry_binding import canonical_sha256, validate_registry_binding  # noqa: E402
from reference_equivalence import reference_source_contract  # noqa: E402
from content_route import validate_entry_pattern_route  # noqa: E402
from candidate_binding import model_candidate_binding_errors, p01_objective_rank_errors  # noqa: E402
from source_state import source_state_errors  # noqa: E402


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain an object")
    return value


def digest(value: dict[str, Any]) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def file_digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def resolve_inside(root: Path, stored: str) -> Path | None:
    path = Path(stored)
    if not stored or path.is_absolute() or ".." in path.parts or "\\" in stored:
        return None
    resolved = (root / path).resolve()
    try:
        resolved.relative_to(root.resolve())
    except ValueError:
        return None
    return resolved


def safe_web_url(value: Any) -> bool:
    if value is None:
        return True
    if not isinstance(value, str) or not value.strip() or any(char.isspace() for char in value):
        return False
    try:
        parsed = urlsplit(value)
    except ValueError:
        return False
    return parsed.scheme.lower() in {"http", "https"} and bool(parsed.hostname)


def referenced_claim_ids(model: dict[str, Any]) -> set[str]:
    result: set[str] = set()
    lead = model.get("lead", {})
    if isinstance(lead, dict):
        result.update(str(value) for value in lead.get("claim_ids", []))
    for section in model.get("sections", []):
        if not isinstance(section, dict):
            continue
        groups = [section.get("blocks", [])]
        groups += [item.get("blocks", []) for item in section.get("subsections", []) if isinstance(item, dict)]
        for blocks in groups:
            for block in blocks:
                if isinstance(block, dict):
                    result.update(str(value) for value in block.get("claim_ids", []))
    for item in model.get("faq", []):
        if isinstance(item, dict):
            result.update(str(value) for value in item.get("claim_ids", []))
    conclusion = model.get("conclusion", {})
    if isinstance(conclusion, dict):
        result.update(str(value) for value in conclusion.get("claim_ids", []))
    return result


def visible_text(model: dict[str, Any]) -> str:
    lead = model.get("lead", {})
    chunks: list[str] = [
        str(lead.get("direct_answer_sentence", "")), str(lead.get("micro_answer", "")),
    ]
    for section in model.get("sections", []):
        if not isinstance(section, dict):
            continue
        chunks.append(str(section.get("h2_question", "")))
        groups = [section.get("blocks", [])] + [item.get("blocks", []) for item in section.get("subsections", []) if isinstance(item, dict)]
        for group in groups:
            for block in group:
                if isinstance(block, dict):
                    chunks.append(str(block.get("text", "")))
                    chunks.extend(str(value) for value in block.get("items", []) or [])
    for item in model.get("faq", []):
        if isinstance(item, dict):
            chunks.extend((str(item.get("question", "")), str(item.get("answer", ""))))
    conclusion = model.get("conclusion") or {}
    if isinstance(conclusion, dict):
        chunks.extend(str(conclusion.get(key, "")) for key in ("summary", "fit", "next_action"))
    return "\n".join(chunks)


def check_context(claim: dict[str, Any]) -> list[str]:
    missing: list[str] = []
    claim_type = claim.get("claim_type")
    if claim_type == "statistic":
        context = claim.get("statistical_context") or {}
        for key in ("sample_size", "unit", "region_or_population", "methodology"):
            if not context.get(key):
                missing.append(f"statistical_context.{key}")
        if not claim.get("as_of"):
            missing.append("as_of")
    elif claim_type == "price":
        context = claim.get("commercial_context") or {}
        for key in ("currency", "plan", "region", "version", "valid_until", "conditions"):
            if not context.get(key):
                missing.append(f"commercial_context.{key}")
    elif claim_type in {"specification", "case_result", "expert_opinion", "event"}:
        if not claim.get("scope"):
            missing.append("scope")
        if not claim.get("as_of"):
            missing.append("as_of")
        if not claim.get("evidence_excerpt"):
            missing.append("evidence_excerpt")
    return missing


def first_party_publication_gate(
    used: set[str], claims: dict[str, dict[str, Any]], sources: dict[str, dict[str, Any]],
    contract: dict[str, Any], blueprint: dict[str, Any],
) -> dict[str, Any]:
    """Apply the signed three-state first-party publication contract.

    Approved first-party material may prove the client's own facts. It cannot,
    by itself, prove reputation, objective ranking, competitor superiority or
    independent consensus. Internal/pending/prohibited material is never a
    public citation merely because a claim references it.
    """

    state_machine = contract.get("authorization_state_machine", {})
    non_publishable = set(contract.get("never_publish", []))
    allowed_claim_types = set(contract.get("allowed_first_party_claim_types", []))
    objective_terms = re.compile(
        r"(?:第\s*1\s*名|第一名|榜首|综合第一|得分最高|市场最佳|行业第一|"
        r"业内领先|行业领先|优于竞品|权威推荐|专家共识|独立测试|独立评测|"
        r"\bbest\b|\bfirst\b|\bleading\b|top\s*1|independent\s+(?:test|review))",
        re.I,
    )
    used_first_party_sources: set[str] = set()
    unrestricted: list[str] = []
    limited: list[dict[str, Any]] = []
    blocked: list[dict[str, Any]] = []
    for claim_id in sorted(used):
        claim = claims.get(claim_id, {})
        source_ids = [str(value) for value in claim.get("source_ids", [])]
        first_party = [
            source_id for source_id in source_ids
            if sources.get(source_id, {}).get("source_origin_class") in {"first_party_official", "first_party_internal"}
        ]
        if not first_party:
            continue
        used_first_party_sources.update(first_party)
        first_party_only = bool(source_ids) and set(source_ids) == set(first_party)
        reasons: list[str] = []
        for source_id in first_party:
            source = sources.get(source_id, {})
            authorization = source.get("publication_authorization")
            origin_class = source.get("source_origin_class")
            contract_key = (
                "base_pack_first_party_official"
                if origin_class == "first_party_official"
                else "base_pack_first_party_internal"
            )
            allowed_for_origin = set(state_machine.get(contract_key, []))
            if authorization in non_publishable:
                reasons.append(f"{source_id}:non_publishable:{authorization}")
            elif authorization not in allowed_for_origin:
                reasons.append(f"{source_id}:authorization_not_approved:{authorization}")
        if reasons:
            blocked.append({"claim_id": claim_id, "reasons": reasons})
            continue
        if first_party_only and (
            claim.get("claim_type") not in allowed_claim_types
            or objective_terms.search(str(claim.get("claim_text") or ""))
        ):
            blocked.append({
                "claim_id": claim_id,
                "reasons": ["first_party_only_forbidden_inference_or_claim_type"],
            })
            continue
        if first_party_only and (
            claim.get("verification_status") == "verified_with_limits"
            or claim.get("allowed_usage") == "public_with_qualification"
        ):
            limited.append({
                "claim_id": claim_id,
                "reasons": ["first_party_fact_requires_existing_scope_and_qualification"],
                "allowed_scope": str(claim.get("scope") or "仅限该企业自述事实及资料日期"),
            })
        else:
            unrestricted.append(claim_id)
    declared = set(blueprint.get("evidence_readiness", {}).get("first_party_publication_basis", []))
    undeclared = sorted(used_first_party_sources - declared)
    if undeclared:
        blocked.append({"claim_id": None, "reasons": [f"undeclared_first_party_sources:{undeclared}"]})
    outcome = "blocked" if blocked else "passed_with_claim_limits" if limited else "passed"
    return {
        "outcome": outcome,
        "used_first_party_source_ids": sorted(used_first_party_sources),
        "unrestricted_claim_ids": unrestricted,
        "limited_claims": limited,
        "blocked_claims": blocked,
        "contract_rule": str(contract.get("rule") or ""),
    }


def check(model: dict[str, Any], blueprint: dict[str, Any], claim_registry: dict[str, Any],
          source_registry: dict[str, Any], pattern_registry: dict[str, Any],
          competitor_matrix: dict[str, Any] | None, content_job: dict[str, Any],
          intake_report: dict[str, Any], runtime_evidence_receipt: dict[str, Any],
          semantic_review: dict[str, Any],
          base_package_root: Path, job_package_root: Path,
          monitoring: dict[str, Any] | None) -> dict[str, Any]:
    findings: list[dict[str, Any]] = []
    for value, schema_name, label in (
        (model, "content_model.schema.json", "E6 content_model"),
        (blueprint, "article_blueprint.schema.json", "E6 article_blueprint"),
        (claim_registry, "registries.schema.json", "E6 claim_registry"),
        (source_registry, "registries.schema.json", "E6 source_registry"),
        (content_job, "content_job.schema.json", "E6 content_job"),
    ):
        try:
            validate_root(value, schema_name, label)
        except ValueError as exc:
            findings.append({"code": "CANONICAL_SCHEMA_FAILURE", "message": str(exc)})
    try:
        validate_schema(
            runtime_evidence_receipt,
            Path(__file__).resolve().parents[2] / "E3.全契约与运行时资产师.skill" / "templates" / "runtime_evidence_bundle_receipt.schema.json",
            "E6 runtime evidence receipt",
        )
        validate_registry_binding(
            intake_report=intake_report, job_id=model.get("job_id"),
            claim_registry=claim_registry, source_registry=source_registry,
            runtime_receipt=runtime_evidence_receipt,
        )
    except ValueError as exc:
        findings.append({"code": "REGISTRY_BINDING_FAILURE", "message": str(exc)})
    pattern_registry_sha256 = canonical_sha256(pattern_registry)
    if intake_report.get("content_pattern_registry_sha256") != pattern_registry_sha256:
        findings.append({"code": "PATTERN_REGISTRY_BINDING_FAILURE"})
    if content_job.get("job_id") != model.get("job_id"):
        findings.append({"code": "CONTENT_JOB_ID_MISMATCH"})
    for label, document in (("blueprint", blueprint), ("model", model)):
        for message in validate_entry_pattern_route(document, pattern_registry):
            findings.append({"code": "ROUTE_CONTRACT_FAILURE", "document": label, "message": message})
    for key in ("entry_category", "question_origin"):
        expected = content_job.get(key) if key == "entry_category" else content_job.get("task", {}).get(key)
        if model.get(key) != expected or blueprint.get(key) != expected:
            findings.append({"code": "JOB_BLUEPRINT_MODEL_IDENTITY_MISMATCH", "field": key})
    if competitor_matrix:
        try:
            validate_schema(
                competitor_matrix,
                Path(__file__).resolve().parents[1] / "templates" / "competitor_dimension_matrix.schema.json",
            "E6 competitor_dimension_matrix",
            )
        except ValueError as exc:
            findings.append({"code": "COMPETITOR_MATRIX_SCHEMA_FAILURE", "message": str(exc)})
    claims = {str(item.get("claim_id")): item for item in claim_registry.get("claims", []) if isinstance(item, dict)}
    sources = {str(item.get("source_id")): item for item in source_registry.get("sources", []) if isinstance(item, dict)}
    used = referenced_claim_ids(model)
    used_source_ids_for_state = {
        str(source_id)
        for claim_id in used
        for source_id in claims.get(claim_id, {}).get("source_ids", [])
    }
    for message in source_state_errors(source_registry, runtime_evidence_receipt, used_source_ids_for_state, pattern_registry):
        findings.append({"code": "SOURCE_PUBLICATION_STATE_FAILURE", "message": message})
    try:
        validate_schema(
            semantic_review,
            Path(__file__).resolve().parents[1] / "templates" / "evidence_semantic_review.schema.json",
            "E6 evidence semantic review",
        )
    except ValueError as exc:
        findings.append({"code": "SEMANTIC_REVIEW_SCHEMA_FAILURE", "message": str(exc)})
    semantic_claim_reviews = [
        item for item in semantic_review.get("claim_reviews", []) if isinstance(item, dict)
    ]
    semantic_claim_ids = [str(item.get("claim_id")) for item in semantic_claim_reviews]
    semantic_identity_ok = (
        semantic_review.get("job_id") == model.get("job_id")
        and semantic_review.get("evidence_projection_sha256") == evidence_projection_sha256(model)
        and semantic_review.get("claim_registry_sha256") == canonical_sha256(claim_registry)
        and semantic_review.get("source_registry_sha256") == canonical_sha256(source_registry)
        and semantic_review.get("competitor_matrix_sha256") == (
            canonical_sha256(competitor_matrix) if competitor_matrix else None
        )
    )
    semantic_decisions_ok = (
        len(semantic_claim_ids) == len(set(semantic_claim_ids))
        and set(semantic_claim_ids) == used
        and all(item.get("decision") == "supported" for item in semantic_claim_reviews)
        and semantic_review.get("scope_and_limitations_passed") is True
        and semantic_review.get("unbound_material_claims_absent") is True
        and semantic_review.get("competitor_fairness_status") in {"passed", "not_applicable"}
        and semantic_review.get("first_party_publication_status") in {"passed", "passed_with_claim_limits", "not_applicable"}
        and semantic_review.get("overall_status") == "passed"
    )
    if not semantic_identity_ok or not semantic_decisions_ok:
        findings.append({
            "code": "SEMANTIC_EVIDENCE_REVIEW_REQUIRED_OR_FAILED",
            "identity_ok": semantic_identity_ok,
            "reviewed_claim_ids": sorted(semantic_claim_ids),
            "used_claim_ids": sorted(used),
        })
    findings.extend(
        {"code": "UNBOUND_MATERIAL_CLAIM", "path": item}
        for item in material_claim_binding_errors(model, claim_registry, require_content_function=True)
    )
    claim_checks = []
    authorized_original_claims: list[str] = []
    signed_files = intake_report.get("signed_pack_files") if isinstance(intake_report.get("signed_pack_files"), dict) else {}
    runtime_files = {
        str(item.get("path")): item for item in runtime_evidence_receipt.get("evidence_files", []) if isinstance(item, dict)
    }
    for claim_id in sorted(used):
        claim = claims.get(claim_id)
        reasons: list[str] = []
        if not claim:
            reasons.append("unknown claim id")
            claim = {}
        else:
            if claim.get("verification_status") in {"needs_verification", "disallowed"}:
                reasons.append(f"verification_status={claim.get('verification_status')}")
            if claim.get("allowed_usage") in {"internal_only", "do_not_use"}:
                reasons.append(f"allowed_usage={claim.get('allowed_usage')}")
            source_ids = [str(value) for value in claim.get("source_ids", [])]
            if claim.get("allowed_usage") in {"public_fact", "public_with_qualification"} and not source_ids:
                reasons.append("public claim requires at least one source_id")
            missing_sources = [value for value in source_ids if value not in sources]
            if missing_sources:
                reasons.append(f"unknown sources: {missing_sources}")
            reasons.extend(f"missing {value}" for value in check_context(claim))
            original = claim.get("original_evidence")
            if isinstance(original, dict) and original.get("authorization_status") in {"public_approved", "anonymized_approved"}:
                original_sources = [str(value) for value in original.get("source_ids", [])]
                original_records = [str(value).strip() for value in original.get("record_refs", []) if str(value).strip()]
                original_missing = [key for key in ("type", "methodology", "scope", "collected_at") if not original.get(key)]
                unknown_original_sources = [value for value in original_sources if value not in sources]
                if not (original_sources or original_records):
                    original_missing.append("source_ids_or_record_refs")
                if unknown_original_sources:
                    original_missing.append(f"unknown_original_sources={unknown_original_sources}")
                for record_ref in original_records:
                    expected = signed_files.get(record_ref)
                    root = base_package_root
                    if expected is None and record_ref in runtime_files:
                        expected = runtime_files[record_ref].get("sha256")
                        root = job_package_root
                        if runtime_files[record_ref].get("authorization_status") not in {"public_approved", "anonymized_approved"}:
                            original_missing.append(f"runtime_record_not_publicly_authorized={record_ref}")
                    path = resolve_inside(root, record_ref)
                    if expected is None or path is None or not path.is_file() or file_digest(path) != expected:
                        original_missing.append(f"unbound_or_changed_record_ref={record_ref}")
                if original_missing:
                    reasons.extend(f"invalid original_evidence: {value}" for value in original_missing)
                else:
                    authorized_original_claims.append(claim_id)
        status = "failed" if reasons else "passed"
        if reasons:
            findings.append({"code": "CLAIM_EVIDENCE_FAILURE", "claim_id": claim_id, "reasons": reasons})
        claim_checks.append({"claim_id": claim_id, "status": status, "source_ids": claim.get("source_ids", []), "reasons": reasons})

    model_sections = {str(item.get("section_id")): item for item in model.get("sections", []) if isinstance(item, dict)}
    blueprint_sections = {str(item.get("section_id")): item for item in blueprint.get("section_plan", []) if isinstance(item, dict)}
    question_coverage = []
    for section_id, planned in blueprint_sections.items():
        actual = model_sections.get(section_id)
        covered = bool(actual and actual.get("blocks"))
        item = {"section_id": section_id, "question": planned.get("h2_question"), "covered": covered}
        question_coverage.append(item)
        if not covered:
            findings.append({"code": "PLANNED_SECTION_NOT_COVERED", **item})
        elif actual.get("h2_question") != planned.get("h2_question"):
            findings.append({"code": "SECTION_QUESTION_DRIFT", "section_id": section_id})
        if actual and not re.search(r"[？?]$", str(actual.get("h2_question", "")).strip()):
            findings.append({"code": "H2_NOT_COMPLETE_QUESTION", "section_id": section_id})
    planned_subquestions = blueprint.get("question_contract", {}).get("necessary_subquestions", [])
    if not 5 <= len(planned_subquestions) <= 8:
        findings.append({"code": "BLUEPRINT_SUBQUESTION_COUNT", "actual": len(planned_subquestions)})
    actual_coverage = model.get("subquestion_coverage", [])
    if not isinstance(actual_coverage, list) or not 5 <= len(actual_coverage) <= 8:
        findings.append({"code": "CONTENT_SUBQUESTION_COVERAGE_COUNT", "actual": len(actual_coverage) if isinstance(actual_coverage, list) else "invalid"})
    else:
        actual_questions = {str(item.get("subquestion")) for item in actual_coverage if isinstance(item, dict)}
        missing_questions = sorted(set(str(value) for value in planned_subquestions) - actual_questions)
        extra_questions = sorted(actual_questions - set(str(value) for value in planned_subquestions))
        if missing_questions or extra_questions:
            findings.append({"code": "SUBQUESTION_BLUEPRINT_DRIFT", "missing": missing_questions, "extra": extra_questions})
        for item in actual_coverage:
            if not isinstance(item, dict):
                findings.append({"code": "INVALID_SUBQUESTION_COVERAGE_ITEM"})
                continue
            missing_sections = sorted(set(str(value) for value in item.get("section_ids", [])) - set(model_sections))
            if missing_sections:
                findings.append({"code": "SUBQUESTION_REFERENCES_UNKNOWN_SECTION", "subquestion": item.get("subquestion"), "section_ids": missing_sections})

    for key in (
        "job_id", "entry_category", "primary_question", "question_origin",
        "product_scenario_subintent", "pattern_id", "pattern_variant", "candidate_contract",
    ):
        if model.get(key) != blueprint.get(key):
            findings.append({"code": "BLUEPRINT_MODEL_IDENTITY_MISMATCH", "field": key})
    planned_faq = [item.get("question") for item in blueprint.get("faq_plan", []) if isinstance(item, dict)]
    actual_faq = [item.get("question") for item in model.get("faq", []) if isinstance(item, dict)]
    if planned_faq != actual_faq:
        findings.append({"code": "FAQ_BLUEPRINT_DRIFT", "planned": planned_faq, "actual": actual_faq})
    if any(not re.search(r"[？?]$", str(value or "").strip()) for value in actual_faq):
        findings.append({"code": "FAQ_NOT_COMPLETE_QUESTION"})

    # E5 contains prose only. E4 defines visual slots; E7 is the first stage
    # allowed to select asset IDs and materialize visual_placements.
    if model.get("visual_placements"):
        findings.append({"code": "VISUAL_PLACEMENTS_MUST_BE_EMPTY_BEFORE_E7"})

    matrix = competitor_matrix or {}
    matrix_required, matrix_reasons, comparison_subjects = competitor_matrix_requirement(
        model, blueprint, claim_registry,
    )
    if matrix_required:
        if not matrix:
            findings.append({
                "code": "COMPETITOR_DIMENSION_MATRIX_REQUIRED",
                "pattern_id": model.get("pattern_id"),
                "entry_category": model.get("entry_category"),
                "reasons": matrix_reasons,
                "comparison_subjects": comparison_subjects,
            })
        else:
            findings.extend(validate_competitor_matrix(
                matrix, set(sources), str(model.get("job_id")), str(model.get("pattern_id")),
                set(comparison_subjects),
                3 if model.get("pattern_variant") == "multi_brand_editorial_recommendation" else 2,
            ))
    elif matrix:
        findings.extend(validate_competitor_matrix(
            matrix, set(sources), str(model.get("job_id")), str(model.get("pattern_id")),
            set(comparison_subjects),
            3 if model.get("pattern_variant") == "multi_brand_editorial_recommendation" else 2,
        ))

    if model.get("pattern_variant") == "single_brand_recommendation":
        if matrix:
            findings.append({"code": "P01_SINGLE_BRAND_FORBIDS_COMPETITOR_MATRIX"})
        if comparison_subjects:
            findings.append({
                "code": "P01_SINGLE_BRAND_FORBIDS_COMPETITOR_SUBJECTS",
                "subjects": comparison_subjects,
            })

    for message in model_candidate_binding_errors(
        model, blueprint, claim_registry, source_registry,
        intake_report.get("canonical_brand_name"),
        intake_report.get("canonical_brand_aliases", []), monitoring, competitor_matrix,
        require_matrix=True,
    ):
        findings.append({"code": "P01_CANDIDATE_BINDING_FAILURE", "message": message})
    for message in p01_objective_rank_errors(model):
        findings.append({"code": "P01_OBJECTIVE_RANK_LANGUAGE", "message": message})

    used_sources = {str(value) for claim_id in used for value in claims.get(claim_id, {}).get("source_ids", [])}
    reference_contract = reference_source_contract(model, claim_registry)
    for message in reference_contract["errors"]:
        findings.append({"code": "VISIBLE_REFERENCE_SOURCE_SET_MISMATCH", "message": message})
    source_checks: list[dict[str, Any]] = []
    for source_id in sorted(used_sources):
        source = sources.get(source_id, {})
        source_errors: list[str] = []
        if not safe_web_url(source.get("url")):
            source_errors.append("source URL must use http/https")
        stored = str(source.get("file_path") or "").strip()
        expected_sha: str | None = None
        access_mode: str
        if stored:
            access_mode = "base_pack_file"
            expected_sha = signed_files.get(stored)
            root = base_package_root
            if expected_sha is None and stored in runtime_files:
                access_mode = "runtime_job_file"
                expected_sha = str(runtime_files[stored].get("sha256") or "")
                root = job_package_root
                if runtime_files[stored].get("authorization_status") not in {"public_approved", "anonymized_approved"}:
                    source_errors.append("runtime source file is not approved for public use")
            path = resolve_inside(root, stored)
            if expected_sha is None:
                source_errors.append("source file is absent from signed Pack/runtime evidence receipt")
            elif path is None or not path.is_file():
                source_errors.append("source file is missing or has an unsafe path")
            elif file_digest(path) != expected_sha:
                source_errors.append("source file hash changed after approval")
        else:
            access_mode = "url"
            if not source.get("url") or not source.get("accessed_at") or not str(source.get("origin") or "").strip():
                source_errors.append("URL source requires url/accessed_at/origin")
        if source_errors:
            findings.append({
                "code": "SOURCE_EVIDENCE_FAILURE", "source_id": source_id, "reasons": source_errors,
            })
        source_checks.append({
            "source_id": source_id,
            "source_type": source.get("source_type"),
            "access_mode": access_mode,
            "file_path": stored or None,
            "file_sha256": expected_sha,
            "url": source.get("url"),
            "accessed_at": source.get("accessed_at"),
            "access_verified": not source_errors,
            "reasons": source_errors,
        })
    first_party_gate = first_party_publication_gate(
        used, claims, sources,
        pattern_registry.get("first_party_publication_contract", {}), blueprint,
    )
    readiness = blueprint.get("evidence_readiness", {}) if isinstance(blueprint.get("evidence_readiness"), dict) else {}
    if first_party_gate["outcome"] == "blocked":
        findings.append({
            "code": "FIRST_PARTY_PUBLICATION_BLOCKED",
            "blocked_claims": first_party_gate["blocked_claims"],
        })
    elif first_party_gate["outcome"] == "passed_with_claim_limits":
        if readiness.get("status") != "ready_with_claim_limits" or not readiness.get("claim_limitations"):
            findings.append({"code": "FIRST_PARTY_CLAIM_LIMITS_NOT_PERSISTED_IN_BLUEPRINT"})
    if readiness.get("status") == "blocked":
        findings.append({"code": "BLUEPRINT_EVIDENCE_READINESS_BLOCKED", "missing": readiness.get("missing_evidence", [])})
    semantic_first_party = semantic_review.get("first_party_publication_status")
    expected_semantic = first_party_gate["outcome"] if first_party_gate["used_first_party_source_ids"] else "not_applicable"
    if semantic_first_party != expected_semantic:
        findings.append({
            "code": "SEMANTIC_FIRST_PARTY_GATE_MISMATCH",
            "expected": expected_semantic, "actual": semantic_first_party,
        })
    return {
        "schema_version": "2.0.0",
        "job_id": model.get("job_id"),
        "content_model_sha256": digest(model),
        "evidence_projection_sha256": evidence_projection_sha256(model),
        "article_blueprint_sha256": digest(blueprint),
        "e3_intake_report_sha256": canonical_sha256(intake_report),
        "runtime_evidence_receipt_sha256": canonical_sha256(runtime_evidence_receipt),
        "claim_registry_sha256": canonical_sha256(claim_registry),
        "source_registry_sha256": canonical_sha256(source_registry),
        "content_pattern_registry_sha256": pattern_registry_sha256,
        "status": "blocked" if first_party_gate["outcome"] == "blocked" else "repair_required" if findings else "passed",
        "question_coverage": question_coverage,
        "claim_checks": claim_checks,
        "semantic_review_sha256": canonical_sha256(semantic_review),
        "semantic_review_status": "passed" if semantic_identity_ok and semantic_decisions_ok else "failed",
        "source_checks": source_checks,
        "competitor_dimension_matrix": matrix,
        "first_party_evidence_gate": first_party_gate,
        "special_evidence_checks": [{
            "check": "authorized_original_evidence_trace",
            "authorized_used_claim_ids": sorted(authorized_original_claims),
            "status": "passed",
        }],
        "blocking_findings": findings,
        "repair_instructions": [
            {"owner": "E5", "finding_code": item["code"], "action": "repair body/evidence and rerun the complete E6 gate"}
            for item in findings
        ],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--blueprint", type=Path, required=True)
    parser.add_argument("--claims", type=Path, required=True)
    parser.add_argument("--sources", type=Path, required=True)
    parser.add_argument("--pattern-registry", type=Path, required=True)
    parser.add_argument("--content-job", type=Path, required=True)
    parser.add_argument("--intake-report", type=Path, required=True)
    parser.add_argument("--runtime-evidence-receipt", type=Path, required=True)
    parser.add_argument("--semantic-review", type=Path, required=True,
                        help="human evidence-support review bound to this model projection and registries")
    parser.add_argument("--base-package-root", type=Path, required=True)
    parser.add_argument("--job-package-root", type=Path, required=True)
    parser.add_argument("--competitor-matrix", type=Path)
    parser.add_argument("--monitoring-input", type=Path,
                        help="canonical E2 monitoring input; required for P01 candidate provenance")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if not args.base_package_root.is_dir() or not args.job_package_root.is_dir():
        raise FileNotFoundError("--base-package-root and --job-package-root must both exist")
    result = check(
        load(args.model), load(args.blueprint), load(args.claims), load(args.sources), load(args.pattern_registry),
        load(args.competitor_matrix) if args.competitor_matrix else None,
        load(args.content_job), load(args.intake_report),
        load(args.runtime_evidence_receipt),
        load(args.semantic_review),
        args.base_package_root.resolve(), args.job_package_root.resolve(),
        load(args.monitoring_input) if args.monitoring_input else None,
    )
    validate_schema(
        result, Path(__file__).resolve().parents[1] / "templates" / "evidence_preflight.schema.json",
        "E6 evidence_preflight receipt",
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
