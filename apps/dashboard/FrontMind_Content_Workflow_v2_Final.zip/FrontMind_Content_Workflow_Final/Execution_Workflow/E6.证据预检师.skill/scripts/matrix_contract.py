#!/usr/bin/env python3
"""Single machine contract for competitor dimension matrices used by E6/E8."""

from __future__ import annotations

from typing import Any


TOP_FIELDS = {"schema_version", "job_id", "pattern_id", "objects", "dimensions", "coverage"}
CELL_FIELDS = {"availability", "value", "source_ids", "as_of", "scope", "conditions"}
AVAILABILITY = {"available", "not_public", "not_applicable"}


def _used_claim_ids(model: dict[str, Any]) -> set[str]:
    result: set[str] = set()
    lead = model.get("lead") if isinstance(model.get("lead"), dict) else {}
    result.update(str(value) for value in lead.get("claim_ids", []))
    for section in model.get("sections", []):
        if not isinstance(section, dict):
            continue
        groups = [section.get("blocks", [])]
        groups.extend(
            subsection.get("blocks", []) for subsection in section.get("subsections", [])
            if isinstance(subsection, dict)
        )
        for group in groups:
            for block in group:
                if isinstance(block, dict):
                    result.update(str(value) for value in block.get("claim_ids", []))
    for item in model.get("faq", []):
        if isinstance(item, dict):
            result.update(str(value) for value in item.get("claim_ids", []))
    conclusion = model.get("conclusion") if isinstance(model.get("conclusion"), dict) else {}
    result.update(str(value) for value in conclusion.get("claim_ids", []))
    return result


def _visible_text(model: dict[str, Any]) -> str:
    chunks: list[str] = [str(model.get("primary_question", ""))]
    lead = model.get("lead") if isinstance(model.get("lead"), dict) else {}
    chunks.extend(str(lead.get(key, "")) for key in ("direct_answer_sentence", "micro_answer"))
    for section in model.get("sections", []):
        if not isinstance(section, dict):
            continue
        chunks.append(str(section.get("h2_question", "")))
        groups = [section.get("blocks", [])]
        groups.extend(
            subsection.get("blocks", []) for subsection in section.get("subsections", [])
            if isinstance(subsection, dict)
        )
        for group in groups:
            for block in group:
                if isinstance(block, dict):
                    chunks.append(str(block.get("text", "")))
                    chunks.extend(str(value) for value in block.get("items", []) or [])
    for item in model.get("faq", []):
        if isinstance(item, dict):
            chunks.extend((str(item.get("question", "")), str(item.get("answer", ""))))
    conclusion = model.get("conclusion") if isinstance(model.get("conclusion"), dict) else {}
    chunks.extend(str(conclusion.get(key, "")) for key in ("summary", "fit", "next_action"))
    return "\n".join(chunks)


def comparison_subjects(
    model: dict[str, Any], blueprint: dict[str, Any], claim_registry: dict[str, Any],
) -> list[str]:
    """Return explicit, visibly discussed comparison objects.

    Only comparison/price claims used by the article and named Blueprint
    alternatives count. This avoids treating every entity in a background
    source as a compared object while still catching multi-object P06/P08/etc.
    """

    visible = _visible_text(model)
    used = _used_claim_ids(model)
    claims = {
        str(item.get("claim_id")): item for item in claim_registry.get("claims", [])
        if isinstance(item, dict)
    }
    subjects: set[str] = set()
    for claim_id in used:
        claim = claims.get(claim_id, {})
        if claim.get("claim_type") not in {"comparison", "price"}:
            continue
        for raw in claim.get("about_entities", []):
            entity = str(raw).strip()
            if entity and entity in visible:
                subjects.add(entity)
    contract = blueprint.get("question_contract") if isinstance(blueprint.get("question_contract"), dict) else {}
    intent_tags = {str(contract.get("primary_intent_tag"))}
    intent_tags.update(str(value) for value in contract.get("secondary_intent_tags", []))
    if "comparison" in intent_tags or "alternative" in intent_tags:
        for raw in contract.get("alternatives", []):
            entity = str(raw).strip()
            if entity and entity in visible:
                subjects.add(entity)
    return sorted(subjects)


def competitor_matrix_requirement(
    model: dict[str, Any], blueprint: dict[str, Any], claim_registry: dict[str, Any],
) -> tuple[bool, list[str], list[str]]:
    subjects = comparison_subjects(model, blueprint, claim_registry)
    reasons: list[str] = []
    if model.get("entry_category") == "competitor_comparison":
        reasons.append("entry_category=competitor_comparison")
    if model.get("pattern_id") == "P02":
        reasons.append(f"pattern_id={model.get('pattern_id')}")
    if (
        model.get("pattern_id") == "P01"
        and model.get("pattern_variant") == "multi_brand_editorial_recommendation"
    ):
        reasons.append("P01_multi_brand_editorial_recommendation")
    if len(subjects) >= 2:
        reasons.append("two_or_more_explicit_comparison_subjects")
    return bool(reasons), reasons, subjects


def validate_competitor_matrix(
    matrix: dict[str, Any], known_source_ids: set[str], job_id: str, pattern_id: str,
    expected_subjects: set[str] | None = None, minimum_objects: int = 2,
) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    if not isinstance(matrix, dict) or set(matrix) != TOP_FIELDS:
        return [{"code": "COMPETITOR_MATRIX_TOP_CONTRACT_FAILURE", "expected_fields": sorted(TOP_FIELDS)}]
    if matrix.get("schema_version") != "2.0.0" or matrix.get("job_id") != job_id or matrix.get("pattern_id") != pattern_id:
        findings.append({"code": "COMPETITOR_MATRIX_IDENTITY_MISMATCH"})
    objects, dimensions, coverage = matrix.get("objects"), matrix.get("dimensions"), matrix.get("coverage")
    if (not isinstance(objects, list) or len(objects) < minimum_objects or len(objects) != len(set(objects))
            or any(not isinstance(value, str) or not value.strip() for value in objects)):
        findings.append({"code": "COMPETITOR_MATRIX_REQUIRES_MINIMUM_UNIQUE_OBJECTS", "minimum": minimum_objects})
        return findings
    missing_subjects = sorted((expected_subjects or set()) - set(objects))
    if missing_subjects:
        findings.append({
            "code": "COMPETITOR_MATRIX_MISSES_ARTICLE_COMPARISON_SUBJECTS",
            "missing_subjects": missing_subjects,
        })
    if (not isinstance(dimensions, list) or not dimensions or len(dimensions) != len(set(dimensions))
            or any(not isinstance(value, str) or not value.strip() for value in dimensions)):
        findings.append({"code": "COMPETITOR_MATRIX_REQUIRES_UNIQUE_DIMENSIONS"})
        return findings
    if not isinstance(coverage, dict) or set(coverage) != set(objects):
        findings.append({"code": "COMPETITOR_MATRIX_OBJECT_COVERAGE_MISMATCH"})
        return findings

    dates_by_dimension: dict[str, set[str]] = {dimension: set() for dimension in dimensions}
    for entity in objects:
        cells = coverage.get(entity)
        if not isinstance(cells, dict) or set(cells) != set(dimensions):
            findings.append({"code": "ASYMMETRIC_COMPETITOR_DIMENSIONS", "object": entity})
            continue
        for dimension in dimensions:
            cell = cells[dimension]
            if not isinstance(cell, dict) or set(cell) != CELL_FIELDS:
                findings.append({"code": "COMPETITOR_CELL_CONTRACT_FAILURE", "object": entity, "dimension": dimension})
                continue
            availability = cell.get("availability")
            source_ids = cell.get("source_ids")
            if availability not in AVAILABILITY:
                findings.append({"code": "COMPETITOR_CELL_AVAILABILITY_INVALID", "object": entity, "dimension": dimension})
                continue
            if not isinstance(source_ids, list) or len(source_ids) != len(set(source_ids)):
                findings.append({"code": "COMPETITOR_CELL_SOURCE_IDS_INVALID", "object": entity, "dimension": dimension})
                source_ids = []
            unknown = sorted(set(str(value) for value in source_ids) - known_source_ids)
            if unknown:
                findings.append({"code": "COMPETITOR_CELL_UNKNOWN_SOURCES", "object": entity, "dimension": dimension, "source_ids": unknown})
            scope = str(cell.get("scope") or "").strip()
            if not scope:
                findings.append({"code": "COMPETITOR_CELL_SCOPE_REQUIRED", "object": entity, "dimension": dimension})
            if availability == "available":
                if not str(cell.get("value") or "").strip() or not source_ids or not str(cell.get("as_of") or "").strip():
                    findings.append({"code": "AVAILABLE_COMPETITOR_CELL_INCOMPLETE", "object": entity, "dimension": dimension})
                else:
                    dates_by_dimension[dimension].add(str(cell["as_of"]))
            else:
                if cell.get("value") is not None or not str(cell.get("conditions") or "").strip():
                    findings.append({"code": "UNAVAILABLE_COMPETITOR_CELL_MUST_EXPLAIN", "object": entity, "dimension": dimension})
    for dimension, dates in dates_by_dimension.items():
        if len(dates) > 1:
            findings.append({"code": "COMPETITOR_DIMENSION_AS_OF_MISMATCH", "dimension": dimension, "as_of_values": sorted(dates)})
    return findings
