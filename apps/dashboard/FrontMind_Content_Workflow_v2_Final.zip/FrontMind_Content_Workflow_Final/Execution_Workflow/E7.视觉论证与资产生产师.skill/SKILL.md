---
name: frontmind-visual-argument-and-production
description: >
  E7 视觉论证与资产生产师。继承企业图库检索、缺图路由、S7 Prompt、AIGC 生成、原 Logo 叠加、重试、校验和去重能力，
  并以 E6 证据、runtime image Registry 和视觉语义门约束每张实际使用图片。
---

# E7 视觉论证与资产生产师

## 双层设计

E7 保留原视觉生产能力，但生产层始终位于安全层之下：

1. **论证设计**：把 E4 `visual_plan` 变成读者问题、插入位置、角色、`supports_claim_ids` 与所需来源；
2. **资产路由**：优先检索 E3 runtime image Registry；缺失时决定“请求客户补图、生成解释图、生成有来源数据图或取消可选槽位”；
3. **生产执行**：按 S7 `visual_patterns[].prompt_scaffold` 生成、重试、确定性绘图或使用现有企业资产；
4. **安全终检**：权利、哈希、尺寸、去重、claim/section 相关性、Logo、Caption/Alt 和 Registry receipt 全部通过后，才物化 Content Model `visual_placements`。

E6 必须为 `passed` 或 `passed_with_claim_limits`，且后一状态下越界主张已经在正文中删除或限缩；`blocked` 不得进入 E7。E7 不新增正文事实或 claim。

## 视觉角色不是全部 proof

- `brand_editorial → navigate`：品牌主视觉或段落识别，不证明实力；
- `navigate → navigate`：章节导航；
- `explain → explain`：机制、关系、流程或无评分的比较说明；可不绑定 claim，但呈现事实时仍须绑定；
- `prove → prove`：必须绑定 E6 passed claim，只使用语义匹配的企业实图、证书、项目记录或原始数据图。

生成式解释图不得声明 entity/product/case/event proof；Logo 只能证明身份存在，不能证明能力、统计、案例结果或领先。生成数据图必须绑定 runtime source IDs，具体数据还必须绑定 E6 passed claim IDs。

## 资产生产规则

### 现有企业资产

按 `allowed_roles/asset_kind/source_kind/semantic_tags` 检索；权利只能 approved/approved_with_credit，后者 Caption 必须包含 attribution。每个实际使用文件必须有正整数 width/height、SHA256 和安全相对路径；SVG 可从显式尺寸或 viewBox 登记尺寸。

### 缺图路由

- 客户案例、团队、证书、产品截图或真实现场缺失：输出缺图请求，禁止 AIGC 冒充；
- 机制、流程、抽象比较：可使用 S7 视觉模式生成 no-text 解释图；
- 数据图：只有来源和 claim 完整时可确定性生成；
- 可选槽位没有有用视觉：取消，不为固定图数凑图。

### Logo

`logo_policy.generation_rule` 必须为 `never_generate_or_redraw_logo`。Logo 不进入 img2img，不让模型绘制品牌名或标识；生成底图通过后，仅从签名 base image Registry 取 `asset_kind=logo`、entity_proof、S7 `logo_asset_refs` 且 `overlay_only` 的原始文件确定性叠加。

### 重试与完成

Prompt 不等于成图。每次生成保留工具、参数、Prompt、输出 hash 和失败原因；只允许针对构图、清晰度、无关文字、尺寸等重试，不得用重试改变事实。最终图经 `image_dedup_checker.py` 登记到 job-local Registry；不得修改 base 记录。

## 三方一致性门

`visual_claim_validator.py` 强制：

- manifest visuals、E4 slots 与 E7 后 Content Model placements 集合一致；
- supports claims ⊆ E6 passed claims ∩ 正文实际使用 claims；非品牌主视觉须与插入章节的 claims 相交；
- role↔argument、asset role↔claim type/source 语义匹配；
- base/runtime Registry、receipt、文件权利/hash/width/height 一致；
- Caption/Alt 不添加新事实，credit 可见。

## 输出

- `E7_prompt_plan.json` 与每图生产元数据；
- 选用/生成的图片和去重报告；
- `E7_visual_argument_manifest.json`；
- 只回写 `visual_placements` 的 E7 Content Model。

E7 model 与 E5 model 的 evidence projection 必须相同；visual manifest 绑定 E7 full model hash 与稳定 visual projection hash。正文/claim 变化回 E5–E6，视觉槽位变化回 E4。
