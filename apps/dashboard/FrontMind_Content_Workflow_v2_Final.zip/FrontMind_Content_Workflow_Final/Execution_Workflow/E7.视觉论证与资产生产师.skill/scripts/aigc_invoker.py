#!/usr/bin/env python3
"""Build an E7 prompt, validate a generated base, and overlay an original Logo.

This wrapper consumes the active S7 ``visual_patterns`` contract and the E7
``images`` prompt plan. It never asks an image model to draw or redraw a Logo.
"""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from PIL import Image

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "shared"))
from schema_validation import validate_root, validate_schema  # noqa: E402


LOGO_SEMANTIC_RE = re.compile(
    r"(?:^|[^a-z])(logo|logotype|wordmark|brand[ _-]?mark)(?:$|[^a-z])|品牌标识|企业标志|官方标志|徽标",
    re.IGNORECASE,
)
LOGO_GENERATION_REQUEST_RE = re.compile(
    r"(?:允许|可以|请|需要|应当|必须|尝试|make|create|generate|redraw|redesign|recreate)[^。；;\n]{0,28}"
    r"(?:logo|logotype|wordmark|brand[ _-]?mark|品牌标识|企业标志|官方标志|徽标)|"
    r"(?:生成|重绘|仿制|模仿|重新设计|重新绘制|创造)[^。；;\n]{0,20}"
    r"(?:logo|品牌标识|企业标志|官方标志|徽标)",
    re.IGNORECASE,
)
LOGO_NEGATION_RE = re.compile(
    r"(?:禁止|不得|不可|不要|严禁|避免|do\s+not|must\s+not|never|without)[^。；;\n]{0,35}"
    r"(?:生成|重绘|仿制|模仿|重新设计|create|generate|redraw|redesign|logo|品牌标识|企业标志|徽标)",
    re.IGNORECASE,
)


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain an object")
    return value


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def flatten_scaffold(value: Any) -> list[str]:
    if isinstance(value, str) and value.strip():
        return [value.strip()]
    if isinstance(value, list):
        result: list[str] = []
        for item in value:
            result.extend(flatten_scaffold(item))
        return result
    if isinstance(value, dict):
        result = []
        for key in sorted(value):
            if key in {"negative_prompt", "negative_constraints", "tool_params"}:
                continue
            result.extend(flatten_scaffold(value[key]))
        return result
    return []


def reject_logo_generation_semantics(values: list[str], label: str) -> None:
    """Reject affirmative Logo-generation instructions before prompt assembly."""
    for value in values:
        # Remove explicit negative clauses first; what remains must not request
        # Logo generation/redesign in Chinese or English.
        remaining = LOGO_NEGATION_RE.sub("", value)
        if LOGO_GENERATION_REQUEST_RE.search(remaining):
            raise ValueError(f"{label} requests generated/redrawn Logo; only original-file overlay is permitted")


def is_explicit_logo_asset(asset: dict[str, Any]) -> bool:
    """Require Logo semantics from the canonical registry, not from S7 alone.

    ``asset_kind=logo`` is the preferred v1 field.  The lexical branch keeps
    already-built v1 packs usable, but only accepts explicit Logo words in
    immutable registry metadata; generic tags such as ``identity`` or
    ``brand_identity`` are intentionally insufficient.
    """
    asset_kind = asset.get("asset_kind")
    if asset_kind is not None:
        return asset_kind == "logo"
    values: list[str] = []
    for key in ("caption", "alt_text", "url"):
        if asset.get(key):
            values.append(str(asset[key]))
    for key in ("semantic_tags", "aliases"):
        values.extend(str(value) for value in asset.get(key, []) if str(value).strip())
    return bool(LOGO_SEMANTIC_RE.search(" \n".join(values)))


def select_logo(
    registry: dict[str, Any], visual_reference: dict[str, Any], requested: str | None,
    visual_id: str, role: str,
) -> dict[str, Any] | None:
    if registry.get("schema_version") != "2.0.0" or registry.get("registry_type") != "image_registry":
        raise ValueError("--image-registry must be a root image_registry")
    images = {str(item.get("asset_id")): item for item in registry.get("images", []) if isinstance(item, dict)}
    logo_refs = {
        str(value) for value in visual_reference.get("brand_constraints", {}).get("logo_asset_refs", [])
    }
    usage = {
        str(item.get("asset_ref")): item for item in visual_reference.get("asset_usage", []) if isinstance(item, dict)
    }

    def eligible(asset_id: str) -> bool:
        rule = usage.get(asset_id, {})
        allowed_slots = {str(value) for value in rule.get("allowed_slots", [])}
        slot_ok = not allowed_slots or bool(allowed_slots & {visual_id, role, "*", "all"})
        asset = images.get(asset_id, {})
        return bool(
            asset_id in logo_refs
            and rule.get("usage_mode") == "overlay_only"
            and slot_ok
            and asset
            and asset.get("rights_status") in {"approved", "approved_with_credit"}
            and "entity_proof" in set(asset.get("allowed_roles", []))
            and is_explicit_logo_asset(asset)
        )

    if requested:
        if not eligible(requested):
            raise ValueError(
                f"requested Logo {requested} is not an approved canonical Logo with entity_proof, explicit Logo semantics, "
                "brand_constraints.logo_asset_refs and asset_usage.overlay_only for this slot"
            )
        return images[requested]
    for asset_id in sorted(logo_refs):
        if eligible(asset_id):
            return images[asset_id]
    return None


def resolve_asset(package_root: Path, asset: dict[str, Any]) -> Path:
    stored_text = str(asset.get("file_path") or "")
    stored = Path(stored_text)
    if not stored_text or stored.is_absolute() or ".." in stored.parts or "\\" in stored_text:
        raise ValueError(f"asset file_path must be package-relative without traversal: {stored_text!r}")
    path = (package_root / stored).resolve()
    try:
        path.relative_to(package_root.resolve())
    except ValueError as exc:
        raise ValueError(f"asset file_path escapes package root: {stored_text}") from exc
    if not path.is_file():
        raise FileNotFoundError(path)
    if asset.get("sha256") != sha256(path):
        raise ValueError(f"asset SHA256 mismatch: {asset.get('asset_id')}")
    return path


def build_prompt(visual_reference: dict[str, Any], spec: dict[str, Any], brand: str,
                 image_registry: dict[str, Any]) -> tuple[str, str, dict[str, Any]]:
    if spec.get("aigc_text_policy") == "no_aigc":
        raise ValueError("aigc_text_policy=no_aigc; use an approved existing asset")
    if spec.get("aigc_text_policy") != "no_text":
        raise ValueError("active E7 only permits no_text or no_aigc")
    pattern_id = str(spec.get("visual_pattern_id") or "")
    pattern = next((item for item in visual_reference.get("visual_patterns", [])
                    if isinstance(item, dict) and item.get("visual_pattern_id") == pattern_id), None)
    if not pattern:
        raise ValueError(f"S7 visual_pattern_id not found: {pattern_id}")
    positive_parts = flatten_scaffold(pattern.get("prompt_scaffold"))
    reject_logo_generation_semantics(positive_parts, f"S7 visual pattern {pattern_id}")
    generation_rules = flatten_scaffold(pattern.get("generation_rule"))
    reject_logo_generation_semantics(generation_rules, f"S7 visual pattern {pattern_id}.generation_rule")
    for value in (spec.get("context"), spec.get("prompt_guidance")):
        if isinstance(value, str) and value.strip():
            positive_parts.append(value.strip())
    reject_logo_generation_semantics(positive_parts, f"E7 prompt plan {spec.get('visual_id')}")
    if not positive_parts:
        raise ValueError(f"S7 pattern {pattern_id} has no usable prompt_scaffold")
    positive_parts.append(f"visual language for {brand}")
    positive_parts.append("no text, no words, no labels, no watermark, no signature")
    positive_parts.append("do not draw, imitate, invent, distort, or include any logo; reserve clean space for original logo overlay")
    negative = [str(value).strip() for value in pattern.get("negative_constraints", []) if str(value).strip()]
    negative.extend(str(value).strip() for value in spec.get("negative_constraints", []) if str(value).strip())
    negative.extend(["generated logo", "fake logo", "logo-like mark", "brand name text", "illegible text"])

    logo_required = spec.get("logo_overlay_required") is True
    requested_logo = spec.get("logo_overlay_asset_id")
    logo = select_logo(
        image_registry, visual_reference, str(requested_logo) if requested_logo else None,
        str(spec.get("visual_id", "")), str(spec.get("role", "")),
    )
    if logo_required and not logo:
        raise ValueError("logo overlay is required but image_registry has no approved original Logo")
    if logo and logo.get("rights_status") not in {"approved", "approved_with_credit"}:
        raise ValueError(f"Logo rights_status is not approved: {logo.get('rights_status')}")
    if logo and logo.get("rights_status") == "approved_with_credit" and not str(logo.get("attribution_text", "")).strip():
        raise ValueError("approved_with_credit Logo requires image_registry.attribution_text")
    metadata = {
        "visual_pattern_id": pattern_id,
        "logo_overlay_required": logo_required,
        "logo_overlay_asset_id": logo.get("asset_id") if logo else None,
        "logo_attribution_text": logo.get("attribution_text") if logo else None,
        "logo_redraw_forbidden": True,
        "generation_strategy": "text2img",
        "required_generation_tool": spec.get("required_generation_tool", "approved_image_generation_model"),
        "final_asset_origin_required": spec.get("final_asset_origin_required", ["approved_image_generation_model"]),
    }
    return ", ".join(dict.fromkeys(positive_parts)), ", ".join(dict.fromkeys(negative)), metadata


def validate_image(path: Path, min_width: int = 1024, min_height: int = 768, min_kb: int = 10) -> dict[str, Any]:
    result: dict[str, Any] = {"file": path.name, "passed": True, "checks": {}}
    if not path.is_file():
        return {"file": path.name, "passed": False, "checks": {"exists": False}}
    size_kb = path.stat().st_size / 1024
    result["checks"]["file_size"] = {"actual_kb": round(size_kb, 2), "minimum_kb": min_kb, "passed": size_kb >= min_kb}
    try:
        with Image.open(path) as image:
            width, height = image.size
            image.verify()
    except Exception as exc:
        return {"file": path.name, "passed": False, "checks": {"open": False, "error": str(exc)}}
    resolution_ok = width >= min_width and height >= min_height
    result["checks"]["resolution"] = {"width": width, "height": height, "minimum": [min_width, min_height], "passed": resolution_ok}
    result["checks"]["sha256"] = sha256(path)
    result["passed"] = size_kb >= min_kb and resolution_ok
    return result


def load_logo_rgba(path: Path) -> Image.Image:
    if path.suffix.lower() != ".svg":
        return Image.open(path).convert("RGBA")
    try:
        import cairosvg  # type: ignore
    except ImportError as exc:
        raise RuntimeError("SVG Logo overlay requires cairosvg; never use a generated redraw as fallback") from exc
    return Image.open(io.BytesIO(cairosvg.svg2png(url=str(path)))).convert("RGBA")


def overlay_logo(base_path: Path, logo_path: Path, output_path: Path,
                 position: str, scale: float) -> dict[str, Any]:
    base = Image.open(base_path).convert("RGBA")
    logo = load_logo_rgba(logo_path)
    width = max(1, int(base.width * min(max(scale, 0.05), 0.35)))
    height = max(1, int(logo.height * width / logo.width))
    if height > int(base.height * 0.30):
        height = int(base.height * 0.30)
        width = max(1, int(logo.width * height / logo.height))
    logo = logo.resize((width, height), Image.Resampling.LANCZOS)
    margin = max(12, int(min(base.size) * 0.04))
    positions = {
        "top_left": (margin, margin), "top_right": (base.width - width - margin, margin),
        "bottom_left": (margin, base.height - height - margin),
        "bottom_right": (base.width - width - margin, base.height - height - margin),
    }
    if position not in positions:
        raise ValueError(f"unsupported logo_overlay_position: {position}")
    base.alpha_composite(logo, dest=positions[position])
    output_path.parent.mkdir(parents=True, exist_ok=True)
    base.convert("RGB").save(output_path, format="PNG", optimize=True)
    return {"position": position, "scale": scale, "pixel_size": [width, height]}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--visual-reference", type=Path, required=True,
                        help="S7 visual_reference.json using visual_patterns[]")
    parser.add_argument("--prompt-plan", type=Path, required=True,
                        help="E7 prompt plan using images[]")
    parser.add_argument("--visual-id", required=True)
    parser.add_argument("--brand", required=True)
    parser.add_argument("--base-image-registry", type=Path, required=True,
                        help="signed Reference Pack image_registry; Logo overlays must come from this registry")
    parser.add_argument("--base-package-root", type=Path, required=True,
                        help="read-only staged Reference Pack root for original Logo files")
    parser.add_argument("--generated-image", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--logo-overlay-output", type=Path)
    parser.add_argument("--metadata-output", type=Path, required=True)
    args = parser.parse_args()

    package_root = args.base_package_root.resolve()
    if not package_root.is_dir():
        raise FileNotFoundError(package_root)
    visual_reference, plan, image_registry = load(args.visual_reference), load(args.prompt_plan), load(args.base_image_registry)
    validate_root(image_registry, "registries.schema.json", "E7 image_registry")
    validate_schema(
        plan, Path(__file__).resolve().parents[1] / "templates" / "prompt_plan_schema.json",
        "E7 prompt_plan",
    )
    if plan.get("schema_version") != "2.0.0" or not isinstance(plan.get("images"), list):
        raise ValueError("prompt plan must use schema_version=2.0.0 and images[]")
    if plan.get("brand") != args.brand:
        raise ValueError("--brand must exactly match prompt_plan.brand")
    if visual_reference.get("schema_version") != "2.0.0" or not isinstance(visual_reference.get("visual_patterns"), list):
        raise ValueError("visual reference must use schema_version=2.0.0 and visual_patterns[]")
    spec = next((item for item in plan["images"] if isinstance(item, dict) and item.get("visual_id") == args.visual_id), None)
    if not spec:
        raise ValueError(f"visual_id not found in prompt plan: {args.visual_id}")
    positive, negative, prompt_meta = build_prompt(visual_reference, spec, args.brand, image_registry)
    metadata: dict[str, Any] = {
        "schema_version": "2.0.0", "job_id": plan.get("job_id"), "visual_id": args.visual_id,
        "positive_prompt": positive, "negative_prompt": negative, **prompt_meta,
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }
    args.output_dir.mkdir(parents=True, exist_ok=True)
    if not args.generated_image:
        metadata.update({"status": "pending_generation", "validation": {"passed": False}})
        args.metadata_output.parent.mkdir(parents=True, exist_ok=True)
        args.metadata_output.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps(metadata, ensure_ascii=False, indent=2))
        return 2 if spec.get("finalization_required") is True else 0

    base_validation = validate_image(args.generated_image)
    if not base_validation["passed"]:
        metadata.update({"status": "failed_validation", "validation": base_validation})
        args.metadata_output.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
        return 3
    final_path = args.generated_image
    overlay_info = None
    if prompt_meta["logo_overlay_required"]:
        logo = select_logo(
            image_registry, visual_reference, prompt_meta["logo_overlay_asset_id"],
            str(spec.get("visual_id", "")), str(spec.get("role", "")),
        )
        if not logo:
            raise RuntimeError("approved Logo disappeared from image_registry")
        logo_path = resolve_asset(package_root, logo)
        final_path = args.logo_overlay_output or args.output_dir / f"{args.visual_id}_final.png"
        overlay_info = overlay_logo(
            args.generated_image, logo_path, final_path,
            str(spec.get("logo_overlay_position", "bottom_right")), float(spec.get("logo_overlay_scale", 0.18)),
        )
    final_validation = validate_image(final_path)
    if not final_validation["passed"]:
        raise RuntimeError(f"final image validation failed: {final_validation}")
    metadata.update({
        "status": "final", "finalization_method": "generated_then_original_logo_overlay" if overlay_info else "generated_final",
        "base_image_file": args.generated_image.name, "final_image_file": final_path.name,
        "logo_overlay": overlay_info, "validation": final_validation,
    })
    args.metadata_output.parent.mkdir(parents=True, exist_ok=True)
    args.metadata_output.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(metadata, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
