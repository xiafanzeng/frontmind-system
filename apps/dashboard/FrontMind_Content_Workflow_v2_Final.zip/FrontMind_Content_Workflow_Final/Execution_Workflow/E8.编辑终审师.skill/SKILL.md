---
name: frontmind-editorial-safe-master
description: >
  E8 编辑终审师。对 E7 后无标题 canonical Content Model 执行问题回答、主张证据、第一方限制、竞品公平、P 模式、文风、视觉与格式终审，
  冻结 E8 安全正文正本；不生成标题、不调用优化算法。
---

# E8 编辑终审师

## 安全正本地位

E8 输入必须是 E5 正文经 E6 clean pass、E7 仅物化视觉后的同一模型。证据 projection、visual projection、runtime Registry/receipt、E6 semantic review 与 visual manifest 必须逐项哈希一致。通过后输出：

- `E8_{job_id}_safe_content_model.json`；
- `E8_{job_id}_quality_report.json`；
- safe model SHA256。

E8 正本无标题；不得出现 title/H1/meta description/title candidates。E9 只能另产候选，E10 失败时整篇回退 E8。

## Gate 1–12

1. **问题回答**：首句直接回答；5–8 子问题和问句式 H2 均有实质答案；结尾不新增观点。
2. **微型答案**：40–80 字首句、200–300 字微型答案，含关键实体/依据/限定，非纯标点或模板句。
3. **主张证据**：字段本地 claim ID 与文字相关；E6 每个 claim/source/文件及语义复核通过；visible references 精确等于实际使用来源。
4. **统计与价格口径**：时间、样本、单位、地区/人群、方法、币种、套餐、版本、有效期和条件完整。
5. **竞品公平**：P01-M 至少三家同维度；P02/竞品入口/任意多对象比较有同源矩阵；P01-S 无竞品或矩阵。
6. **实体清晰**：使用完整品牌、机构、产品、型号、版本名。
7. **新鲜度**：`metadata.as_of` 与 E1 scope 一致，高变动信息有有效期或风险。
8. **第一方资料与 claim limits**：E6 三态门非 blocked；limited claims 的条件已在可见正文体现。
9. **FAQ**：5–8 个真实相关问题，答案不重复正文模板，也不偷渡第二主题。
10. **模式一致**：五入口、P 模式、P01 variant、结构化数据资格一致；`foundation_start ⇔ P13`。
11. **文风与模板感**：第三方客观报道＋有证据品牌表达；无内部审稿话术、元叙述、空开头、近重复章节/FAQ、正文表格。
12. **视觉论证与权利**：brand_editorial/navigate/explain/prove 分类正确；每张图与相邻章节、claim、资产语义、权利和署名一致。

格式渲染、跨格式同源与 AutoGEO 事实完整性在 E10 再执行，E8 质量报告相应 gate 为 `not_applicable`。

## 编辑规则

E8 审核脚本冻结与 E6 evidence projection 完全一致的模型。发现正文问题回 E5 并重跑 E6–E8；视觉问题回 E7；模式或槽位问题回 E4。不得在已签证据报告之后直接润色一个字形成未复核版本。

客户品牌在 P01-M 首先展示是明确的编辑优先级，不是质量分或客观名次；终审必须拦截“第一名、榜首、综合第一、得分最高、市场最佳”等承诺。P01-S 则拦截所有竞品名称和 ItemList。

运行 `scripts/editorial_audit.py`，传入 E6 evidence/semantic review、E7 visual manifest、E4 blueprint、runtime claim/source/image Registries 与 Pack 内签名 pattern registry。所有 blocking gate 不可用总分抵消。

