---
name: frontmind-autogeo-body-candidate
description: >
  E9 AutoGEO 候选优化师。读取 E8 无标题安全正文，使用 autogeo.rewriters 仅生成独立正文候选与字段 diff；
  不改标题、不覆盖 E8、不使用字符串替换 fallback。
---

# E9 AutoGEO 候选优化师

E8 是只读安全正本；E9 只是实验候选。先校验 E8 model SHA、E8 `stage=E8_pre_optimization` clean quality report、E6 evidence 与 runtime claim Registry。

唯一算法路径是 `from autogeo.rewriters import rewrite_document`。不可用或调用失败时输出明确 skip/failure report，`fallback_model=E8`；不得用第二个 LLM、同义词替换或全局词语替换冒充 AutoGEO。

## 可改字段

- lead 直接答案与微型答案；
- sections 的正文 block text；
- FAQ answer；
- conclusion summary/fit/next_action。

不得改：五入口、问题来源、主问题、P 模式与 variant、metadata、H2/H3、FAQ 问题、section/block IDs、content functions、claims、references、visuals、structured data 或任何标题字段。Content Model 本身不含标题。

允许改善结论前置、句子清晰度、实体指代和同一事实的表达顺序；禁止新增/删除事实、数字、日期、价格、对象、案例、限制、风险、来源或比较结论。

## 输出

- `E9_autogeo_report.json`：始终存在；
- `E9_autogeo_candidate.json` 与 `E9_field_diff.json`：仅成功时存在。

候选成功仍标记 `unknown_pending_E10_regression`，E9 无权批准。候选或 diff 输出必须位于全新显式 output dir，不能覆盖/别名输入、符号链接或任意调用者路径。

E10 对全部实际 changed fields 做事实与质量回归；任何漂移整篇回退 E8，不做段落混合。

