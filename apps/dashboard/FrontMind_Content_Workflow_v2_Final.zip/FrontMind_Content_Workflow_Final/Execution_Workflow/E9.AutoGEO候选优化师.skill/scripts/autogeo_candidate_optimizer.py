#!/usr/bin/env python3
"""Create a body-only AutoGEO candidate without replacing the E8 safe model."""

from __future__ import annotations

import argparse
import copy
import difflib
import hashlib
import importlib.metadata
import inspect
import json
import os
import re
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "shared"))
from schema_validation import validate_root, validate_schema  # noqa: E402
from text_quality import answer_pair_errors, article_specificity_errors, material_claim_binding_errors  # noqa: E402


def canonical_bytes(value: dict[str, Any]) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def digest(value: dict[str, Any]) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain an object")
    return value


def text_sha256(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def atomic_write_json(path: Path, value: dict[str, Any]) -> None:
    descriptor, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_name, path)
    except Exception:
        try:
            os.unlink(temp_name)
        except FileNotFoundError:
            pass
        raise


def write_report(path: Path, report: dict[str, Any]) -> None:
    validate_schema(
        report, Path(__file__).resolve().parents[1] / "templates" / "autogeo_report.schema.json",
        "E9 AutoGEO report",
    )
    atomic_write_json(path, report)


def validate_output_paths(args: argparse.Namespace) -> None:
    output_dir = args.output_dir
    if output_dir.is_symlink():
        raise ValueError("--output-dir must not be a symlink")
    output_dir.mkdir(parents=True, exist_ok=True)
    root = output_dir.resolve()
    outputs = (args.candidate, args.diff, args.report)
    if len({path.resolve(strict=False) for path in outputs}) != len(outputs):
        raise ValueError("candidate, diff and report paths must be distinct")
    inputs = {path.resolve() for path in (args.e8_model, args.e8_sha, args.e8_quality, args.content_job, args.claims, args.evidence)}
    for path in outputs:
        if path.parent.resolve() != root:
            raise ValueError(f"E9 outputs must be direct children of --output-dir: {path}")
        if path.resolve(strict=False) in inputs:
            raise ValueError(f"E9 output aliases an input: {path}")
        if path.exists() or path.is_symlink():
            raise FileExistsError(f"E9 output already exists; use a new revision directory: {path}")


def safe_import() -> tuple[Callable[..., str] | None, str | None, str | None]:
    try:
        from autogeo.rewriters import rewrite_document  # type: ignore
        try:
            version = importlib.metadata.version("autogeo")
        except importlib.metadata.PackageNotFoundError:
            version = "unknown"
        return rewrite_document, version, None
    except Exception as exc:  # package/API availability is a valid skip state
        return None, None, f"{type(exc).__name__}: {exc}"


def call_rewriter(rewriter: Callable[..., str], text: str, dataset: str, engine_llm: str, extra: dict[str, Any]) -> str:
    reserved = {"document", "text", "dataset", "engine_llm"}
    overlap = reserved & set(extra)
    if overlap:
        raise ValueError(f"optimizer_target.extra_options cannot override reserved fields: {sorted(overlap)}")
    parameters = inspect.signature(rewriter).parameters
    candidates = {"document": text, "text": text, "dataset": dataset, "engine_llm": engine_llm, **extra}
    kwargs: dict[str, Any] = {}
    for key, value in candidates.items():
        if key in parameters:
            kwargs[key] = value
    if "document" not in kwargs and "text" not in kwargs:
        # Only use the official callable; positional text is a conservative adapter,
        # not a rewrite fallback.
        result = rewriter(text, **{k: v for k, v in kwargs.items() if k not in {"document", "text"}})
    else:
        result = rewriter(**kwargs)
    if not isinstance(result, str) or not result.strip():
        raise RuntimeError("AutoGEO returned an empty or non-string value")
    return result.strip()


def iter_text_fields(model: dict[str, Any]):
    lead = model.get("lead", {})
    for key in ("direct_answer_sentence", "micro_answer"):
        if isinstance(lead.get(key), str) and lead[key].strip():
            yield ("lead", key), lead[key]
    for section_index, section in enumerate(model.get("sections", [])):
        if not isinstance(section, dict):
            continue
        for block_index, block in enumerate(section.get("blocks", [])):
            if isinstance(block, dict) and isinstance(block.get("text"), str) and block["text"].strip():
                yield ("sections", section_index, "blocks", block_index, "text"), block["text"]
        for subsection_index, subsection in enumerate(section.get("subsections", [])):
            if not isinstance(subsection, dict):
                continue
            for block_index, block in enumerate(subsection.get("blocks", [])):
                if isinstance(block, dict) and isinstance(block.get("text"), str) and block["text"].strip():
                    yield ("sections", section_index, "subsections", subsection_index, "blocks", block_index, "text"), block["text"]
    for faq_index, item in enumerate(model.get("faq", [])):
        if isinstance(item, dict) and isinstance(item.get("answer"), str) and item["answer"].strip():
            yield ("faq", faq_index, "answer"), item["answer"]
    conclusion = model.get("conclusion")
    if isinstance(conclusion, dict):
        for key in ("summary", "fit", "next_action"):
            if isinstance(conclusion.get(key), str) and conclusion[key].strip():
                yield ("conclusion", key), conclusion[key]


def set_path(model: dict[str, Any], path: tuple[Any, ...], value: str) -> None:
    current: Any = model
    for part in path[:-1]:
        current = current[part]
    current[path[-1]] = value


def tokens(text: str) -> dict[str, list[str]]:
    return {
        "numbers": sorted(set(re.findall(r"(?<![A-Za-z])\d+(?:\.\d+)?(?:%|％|倍|元|万元|美元)?", text))),
        "dates": sorted(set(re.findall(r"\d{4}年(?:\d{1,2}月(?:\d{1,2}日)?)?|\d{4}-\d{1,2}-\d{1,2}", text))),
        "currencies": sorted(set(re.findall(r"人民币|美元|港币|欧元|CNY|RMB|USD|HKD|EUR", text, flags=re.I))),
    }


def content_shape_errors(model: dict[str, Any], claim_registry: dict[str, Any]) -> list[str]:
    """Enforce the closed root Content Model invariants after rewriting."""
    errors: list[str] = []
    if model.get("schema_version") != "2.0.0" or not str(model.get("job_id", "")).startswith("job_"):
        errors.append("invalid_schema_or_job_id")
    category, subintent = model.get("entry_category"), model.get("product_scenario_subintent")
    valid_categories = {"industry_ranking", "competitor_comparison", "reputation", "product_scenario", "foundation_start"}
    valid_subintents = {"offering_definition", "feature_mechanism", "scenario_fit", "delivery_usage", "support_boundary", "price_selection"}
    if category not in valid_categories:
        errors.append("invalid_entry_category")
    if category == "product_scenario" and subintent not in valid_subintents:
        errors.append("missing_product_scenario_subintent")
    if category != "product_scenario" and subintent is not None:
        errors.append("unexpected_product_scenario_subintent")
    metadata, lead = model.get("metadata", {}), model.get("lead", {})
    if set(metadata) != {"language", "as_of"}:
        errors.append("content_model_metadata_must_remain_title_free")
    if category == "foundation_start" and (model.get("pattern_id") != "P13" or model.get("question_origin") != "foundation_derived"):
        errors.append("foundation_start_requires_P13_foundation_derived")
    if model.get("pattern_id") == "P01" and model.get("pattern_variant") not in {
        "multi_brand_editorial_recommendation", "single_brand_recommendation",
    }:
        errors.append("P01_requires_canonical_variant")
    direct, micro = str(lead.get("direct_answer_sentence", "")).strip(), str(lead.get("micro_answer", "")).strip()
    if not 40 <= len(direct) <= 80:
        errors.append("direct_answer_length")
    if not 200 <= len(micro) <= 300 or not micro.startswith(direct):
        errors.append("micro_answer_length_or_prefix")
    errors.extend(answer_pair_errors(direct, micro, str(model.get("primary_question", ""))))
    errors.extend(article_specificity_errors(model))
    errors.extend(material_claim_binding_errors(model, claim_registry, require_content_function=True))
    for field in ("sections", "subquestion_coverage", "faq"):
        value = model.get(field, [])
        if not isinstance(value, list) or not 5 <= len(value) <= 8:
            errors.append(f"{field}_count")
    if not model.get("structured_data_types"):
        errors.append("missing_structured_data_types")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--e8-model", type=Path, required=True)
    parser.add_argument("--e8-sha", type=Path, required=True)
    parser.add_argument("--e8-quality", type=Path, required=True)
    parser.add_argument("--content-job", type=Path, required=True)
    parser.add_argument("--claims", type=Path, required=True)
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--diff", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    validate_output_paths(args)

    safe = load(args.e8_model)
    validate_root(safe, "content_model.schema.json", "E9 E8 safe content_model")
    actual_sha = digest(safe)
    expected_sha = args.e8_sha.read_text(encoding="utf-8").strip()
    if actual_sha != expected_sha:
        raise ValueError(f"E8 safe model hash mismatch: expected {expected_sha}, got {actual_sha}")
    quality = load(args.e8_quality)
    validate_root(quality, "quality_report.schema.json", "E9 E8 quality report")
    if (
        quality.get("job_id") != safe.get("job_id")
        or quality.get("stage") != "E8_pre_optimization"
        or quality.get("overall_status") != "pass"
        or quality.get("content_model_sha256") != actual_sha
    ):
        raise ValueError("E8 quality report does not approve the supplied safe model")
    content_job = load(args.content_job)
    validate_root(content_job, "content_job.schema.json", "E9 content_job")
    claim_registry = load(args.claims)
    validate_root(claim_registry, "registries.schema.json", "E9 claim_registry")
    if claim_registry.get("registry_type") != "claim_registry":
        raise ValueError("--claims must be the canonical claim_registry")
    evidence = load(args.evidence)
    validate_schema(
        evidence,
        Path(__file__).resolve().parents[2] / "E6.证据预检师.skill" / "templates" / "evidence_preflight.schema.json",
        "E9 evidence receipt",
    )
    if evidence.get("job_id") != safe.get("job_id") or evidence.get("status") != "passed":
        raise ValueError("E9 requires a clean E6 receipt for the same job")
    if evidence.get("claim_registry_sha256") != digest(claim_registry):
        raise ValueError("claim_registry differs from the E6-approved registry")
    if content_job.get("job_id") != safe.get("job_id"):
        raise ValueError("Content Job and E8 safe model job_id differ")
    config = content_job.get("optimizer_target")
    if not isinstance(config, dict) or not str(config.get("dataset", "")).strip() or not str(config.get("engine_llm", "")).strip():
        raise ValueError("Content Job optimizer_target.dataset and engine_llm are required")
    rewriter, version, unavailable = safe_import()
    base_report: dict[str, Any] = {
        "schema_version": "2.0.0",
        "job_id": safe.get("job_id"),
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "e8_safe_model_file": args.e8_model.name,
        "e8_safe_model_sha256": actual_sha,
        "e8_quality_report_sha256": digest(quality),
        "autogeo_import_path": "autogeo.rewriters",
        "autogeo_version": version,
        "fallback_model": "E8",
        "automatic_approval": False,
        "claim_registry_sha256": digest(claim_registry),
        "evidence_receipt_sha256": digest(evidence),
    }
    if rewriter is None:
        base_report.update({
            "status": "skipped_autogeo_unavailable",
            "reason": unavailable,
            "candidate_created": False,
            "new_facts_status": "not_applicable_no_candidate",
        })
        write_report(args.report, base_report)
        print(json.dumps(base_report, ensure_ascii=False, indent=2))
        return 0

    candidate = copy.deepcopy(safe)
    field_diffs = []
    try:
        for path, before in iter_text_fields(safe):
            after = call_rewriter(rewriter, before, str(config["dataset"]), str(config["engine_llm"]), config.get("extra_options", {}))
            set_path(candidate, path, after)
            field_diffs.append({
                "path": list(path),
                "before": before,
                "after": after,
                "before_sha256": text_sha256(before),
                "after_sha256": text_sha256(after),
                "unified_diff": list(difflib.unified_diff(before.splitlines(), after.splitlines(), lineterm="")),
                "token_delta": {key: {"before": value, "after": tokens(after)[key]} for key, value in tokens(before).items()},
            })
    except Exception as exc:
        base_report.update({
            "status": "failed_autogeo_call",
            "reason": f"{type(exc).__name__}: {exc}",
            "candidate_created": False,
            "completed_field_count": len(field_diffs),
            "new_facts_status": "not_applicable_no_candidate",
        })
        write_report(args.report, base_report)
        print(json.dumps(base_report, ensure_ascii=False, indent=2))
        return 0

    shape_errors = content_shape_errors(candidate, claim_registry)
    try:
        validate_root(candidate, "content_model.schema.json", "E9 AutoGEO candidate")
    except ValueError as exc:
        shape_errors.append(str(exc))
    if shape_errors:
        base_report.update({
            "status": "failed_autogeo_call",
            "reason": "candidate violates root content_model contract: " + ", ".join(shape_errors),
            "candidate_created": False,
            "completed_field_count": len(field_diffs),
            "new_facts_status": "not_applicable_no_candidate",
        })
        write_report(args.report, base_report)
        print(json.dumps(base_report, ensure_ascii=False, indent=2))
        return 0

    diff_report = {
        "schema_version": "2.0.0",
        "job_id": safe.get("job_id"),
        "source_sha256": actual_sha,
        "candidate_sha256": digest(candidate),
        "field_diffs": field_diffs,
    }
    validate_schema(
        diff_report, Path(__file__).resolve().parents[1] / "templates" / "autogeo_diff.schema.json",
        "E9 AutoGEO field diff",
    )
    diff_sha256 = digest(diff_report)
    base_report.update({
        "status": "candidate_generated",
        "candidate_created": True,
        "candidate_file": args.candidate.name,
        "candidate_sha256": diff_report["candidate_sha256"],
        "diff_file": args.diff.name,
        "diff_sha256": diff_sha256,
        "changed_field_count": sum(1 for item in field_diffs if item["before"] != item["after"]),
        "new_facts_status": "unknown_pending_E10_regression",
        "e10_full_regression_required": True,
    })
    atomic_write_json(args.candidate, candidate)
    atomic_write_json(args.diff, diff_report)
    write_report(args.report, base_report)
    print(json.dumps(base_report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
