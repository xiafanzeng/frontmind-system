# FrontMind 内容执行层 v2

执行层只制作一篇文章，连续编号且没有隐藏的旧阶段：

`E1 任务建档 → E2 单问题监控/标杆拆解 → E3 全契约 intake 与 runtime 资产 → E4 蓝图/P 路由 → E5 无标题正文 → E6 证据预检 → E7 视觉论证与生产 → E8 安全正本 → E9 AutoGEO 正文候选 → E10 回归选稿、标题数量暂停与双格式交付`

完整可复制命令以包根 `RUNBOOK.md` 为唯一运行手册；本页只声明不可漂移的执行边界。

## 输入边界

- E1 接收签名 Reference Pack ZIP，安全展开到持久 job root，并建立五入口之一的 Content Job 与范围分析。
- 普通四入口必须在 E2 同时导入非空答案表与信源表；`foundation_start` 不消费监控，只允许人工启动 P13。
- E3 重新核验签名 Pack、任务、范围、监控和 `information_evidence_architecture_path`，随后从签名 base registries 建立 append-only runtime evidence/image registries。基础 Pack 永远只读。
- 单篇新增第三方资料必须保存为 job-local、哈希绑定、已审批的证据文件；新增 source 必须是 `source_origin_class=runtime_approved` 与 `publication_authorization=runtime_approved`。

## 内容与证据边界

- E4 从 Pack 内 `content-pattern-registry.json` 自动选择且只选择一个 P01–P15 模式；五入口、P13、P01 两个 variant 和 P01 客户品牌首位均按根合同验证。
- E5 Content Model 没有 title/H1/meta 字段，且 `metadata` 只含 `language/as_of`；正文不使用表格。
- E6 同时验证逐字段 claim、可见 references 精确集合、第一方资料三态、runtime source 状态、P01 候选和竞品矩阵。任何人工语义复核必须有 hash-bound receipt。
- E7 才能把蓝图视觉槽物化为资产；视觉功能只有 `brand_editorial|navigate|explain|prove`。只有 `prove` 强制绑定 E6 已通过 claim/source；Logo 只能使用原件叠加，禁止生成或重绘。
- E8 是唯一安全正本。E9 只能产独立正文候选，不得覆盖 E8。
- E10 对整篇候选自动回归：所有事实、实体、证据与结构无漂移才采用 E9，否则整篇回退 E8，禁止字段拼接。

## 标题与公开交付

E10 在正文批准后暂停询问标题数量（1–20），再生成独立 Title Map。每个标题必须绑定正文实际使用的 claim 和实体，不能新增实体、数字、日期、价格或把编辑优先级写成客观第一。

公开目录只允许：

- `article_body.docx`（无标题正文）
- `article_body.html`（无 H1 的 HTML fragment）
- `structured_data_template.json`
- `title_options.md`
- `title_map.json`
- `publishing_metadata_map.json`
- 已登记视觉文件与 `delivery_manifest.json`

监控原表、客户知识库、证据预检、质量报告、回归和渲染 receipt 全部留在独立内部审计目录，不进入公开 manifest；本流程不做分发、CMS 或发布。
