#!/usr/bin/env python3
"""Execution-side P01 bindings layered on the root candidate contract.

The root ``shared/content_route.py`` owns entry/pattern/variant structure.  This
module proves that a P01 candidate list is not merely well-shaped: it is tied
to the signed client brand, the single-question monitoring sample, the claims
actually used by the body, and (for P01-M) the E6 comparison matrix.
"""

from __future__ import annotations

import sys
import unicodedata
from pathlib import Path
from typing import Any

ROOT_SHARED = Path(__file__).resolve().parents[2] / "shared"
if str(ROOT_SHARED) not in sys.path:
    sys.path.insert(0, str(ROOT_SHARED))
ROOT_SCRIPTS = ROOT_SHARED / "scripts"
if str(ROOT_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(ROOT_SCRIPTS))

from content_route import normalized_name, validate_p01_candidate_contract  # noqa: E402
from validate_content_model import OBJECTIVE_RANK_RE  # noqa: E402


def model_used_claim_ids(model: dict[str, Any]) -> set[str]:
    result: set[str] = set()
    lead = model.get("lead") if isinstance(model.get("lead"), dict) else {}
    result.update(str(value) for value in lead.get("claim_ids", []))
    for section in model.get("sections", []):
        if not isinstance(section, dict):
            continue
        groups = [section.get("blocks", [])]
        groups.extend(
            item.get("blocks", []) for item in section.get("subsections", [])
            if isinstance(item, dict)
        )
        for group in groups:
            for block in group if isinstance(group, list) else []:
                if isinstance(block, dict):
                    result.update(str(value) for value in block.get("claim_ids", []))
    for item in model.get("faq", []):
        if isinstance(item, dict):
            result.update(str(value) for value in item.get("claim_ids", []))
    conclusion = model.get("conclusion") if isinstance(model.get("conclusion"), dict) else {}
    result.update(str(value) for value in conclusion.get("claim_ids", []))
    return result


def visible_body_text(model: dict[str, Any]) -> str:
    chunks: list[str] = [str(model.get("primary_question") or "")]
    lead = model.get("lead") if isinstance(model.get("lead"), dict) else {}
    chunks.extend(str(lead.get(key) or "") for key in ("direct_answer_sentence", "micro_answer"))
    for section in model.get("sections", []):
        if not isinstance(section, dict):
            continue
        chunks.append(str(section.get("h2_question") or ""))
        groups = [section.get("blocks", [])]
        groups.extend(
            item.get("blocks", []) for item in section.get("subsections", [])
            if isinstance(item, dict)
        )
        for group in groups:
            for block in group if isinstance(group, list) else []:
                if not isinstance(block, dict):
                    continue
                chunks.append(str(block.get("text") or ""))
                chunks.extend(str(value) for value in block.get("items", []) or [])
    for item in model.get("faq", []):
        if isinstance(item, dict):
            chunks.extend((str(item.get("question") or ""), str(item.get("answer") or "")))
    conclusion = model.get("conclusion") if isinstance(model.get("conclusion"), dict) else {}
    chunks.extend(str(conclusion.get(key) or "") for key in ("summary", "fit", "next_action"))
    return "\n".join(chunks)


def p01_objective_rank_errors(model: dict[str, Any]) -> list[str]:
    """Reject objective-rank wording in P01 prose after Unicode NFKC.

    The externally confirmed question itself is excluded because it may ask
    whether a brand is ``No.1``; the article answer/body may not assert it.
    """

    if model.get("pattern_id") != "P01":
        return []
    rendered = visible_body_text(model)
    body = rendered.split("\n", 1)[1] if "\n" in rendered else ""
    normalized = unicodedata.normalize("NFKC", body)
    hits = sorted({match.group(0) for match in OBJECTIVE_RANK_RE.finditer(normalized)})
    return [f"P01 uses forbidden objective-rank terms: {hits}"] if hits else []


def monitoring_entity_names(monitoring: dict[str, Any] | None) -> set[str]:
    if not isinstance(monitoring, dict):
        return set()
    derived = monitoring.get("derived") if isinstance(monitoring.get("derived"), dict) else {}
    result = {
        normalized_name(item.get("name"))
        for item in derived.get("competitors", [])
        if isinstance(item, dict) and normalized_name(item.get("name"))
    }
    for item in derived.get("answer_landscape", []):
        if not isinstance(item, dict):
            continue
        result.update(
            normalized_name(value) for value in item.get("entities", [])
            if normalized_name(value)
        )
    return result


def _candidate_names(document: dict[str, Any]) -> list[str]:
    contract = document.get("candidate_contract") if isinstance(document.get("candidate_contract"), dict) else {}
    return [
        str(item.get("entity_name") or "").strip()
        for item in contract.get("ordered_candidates", [])
        if isinstance(item, dict)
    ]


def blueprint_candidate_binding_errors(
    blueprint: dict[str, Any], canonical_brand: str | None,
    monitoring: dict[str, Any] | None,
) -> list[str]:
    errors = validate_p01_candidate_contract(blueprint, canonical_brand)
    if blueprint.get("pattern_id") != "P01":
        return errors
    if blueprint.get("pattern_variant") != "multi_brand_editorial_recommendation":
        return errors
    monitored = monitoring_entity_names(monitoring)
    for name in _candidate_names(blueprint)[1:]:
        if normalized_name(name) not in monitored:
            errors.append(f"P01-M other candidate is absent from E2 monitoring: {name}")
    return errors


def model_candidate_binding_errors(
    model: dict[str, Any], blueprint: dict[str, Any], claim_registry: dict[str, Any],
    source_registry: dict[str, Any], canonical_brand: str | None,
    canonical_aliases: list[str] | None = None,
    monitoring: dict[str, Any] | None = None,
    competitor_matrix: dict[str, Any] | None = None,
    require_matrix: bool = False,
) -> list[str]:
    """Validate all runtime P01 candidate bindings.

    ``candidate_contract.source_ids`` is exact: for each candidate it must equal
    the union of sources on used claims whose ``about_entities`` name that
    candidate. This prevents decorative source IDs and makes E10 references
    traceable to the displayed recommendation objects.
    """

    errors = validate_p01_candidate_contract(model, canonical_brand)
    if model.get("pattern_id") != "P01":
        return errors
    if model.get("candidate_contract") != blueprint.get("candidate_contract"):
        errors.append("Content Model candidate_contract differs from the E4 blueprint")
    contract = model.get("candidate_contract") if isinstance(model.get("candidate_contract"), dict) else {}
    candidates = [item for item in contract.get("ordered_candidates", []) if isinstance(item, dict)]
    names = [str(item.get("entity_name") or "").strip() for item in candidates]
    normalized_candidates = {normalized_name(value) for value in names}
    featured_aliases = {
        normalized_name(value) for value in [canonical_brand, *(canonical_aliases or [])]
        if normalized_name(value)
    }
    claims = {
        str(item.get("claim_id")): item for item in claim_registry.get("claims", [])
        if isinstance(item, dict)
    }
    source_ids = {
        str(item.get("source_id")) for item in source_registry.get("sources", [])
        if isinstance(item, dict)
    }
    used = model_used_claim_ids(model)
    text = visible_body_text(model)
    normalized_text = normalized_name(text)

    for index, candidate in enumerate(candidates):
        name = names[index]
        aliases = featured_aliases if index == 0 else {normalized_name(name)}
        matching_claims = [
            claims[claim_id] for claim_id in used if claim_id in claims
            and aliases & {
                normalized_name(value) for value in claims[claim_id].get("about_entities", [])
                if normalized_name(value)
            }
        ]
        expected_sources = {
            str(value) for claim in matching_claims for value in claim.get("source_ids", [])
            if str(value).strip()
        }
        declared_sources = {str(value) for value in candidate.get("source_ids", [])}
        if not matching_claims:
            errors.append(f"P01 candidate has no used claim naming it: {name}")
        if declared_sources != expected_sources:
            errors.append(
                f"P01 candidate source_ids differ from its used-claim source set: "
                f"{name}:declared={sorted(declared_sources)}:expected={sorted(expected_sources)}"
            )
        unknown = sorted(declared_sources - source_ids)
        if unknown:
            errors.append(f"P01 candidate uses unknown sources: {name}:{unknown}")
        if not any(alias and alias in normalized_text for alias in aliases):
            errors.append(f"P01 candidate is absent from visible body: {name}")

    # The first candidate must also be the first candidate entity encountered
    # in the visible body. An alias of the signed canonical brand counts.
    first_positions: list[tuple[int, int, str]] = []
    for index, name in enumerate(names):
        aliases = featured_aliases if index == 0 else {normalized_name(name)}
        positions = [normalized_text.find(alias) for alias in aliases if alias and alias in normalized_text]
        if positions:
            first_positions.append((min(positions), index, name))
    if first_positions and min(first_positions)[1] != 0:
        errors.append("P01 visible body mentions another candidate before the featured client brand")

    monitored = monitoring_entity_names(monitoring)
    monitored_competitors = set()
    if isinstance(monitoring, dict):
        derived = monitoring.get("derived") if isinstance(monitoring.get("derived"), dict) else {}
        monitored_competitors = {
            normalized_name(item.get("name")) for item in derived.get("competitors", [])
            if isinstance(item, dict) and normalized_name(item.get("name"))
        }
    if model.get("pattern_variant") == "multi_brand_editorial_recommendation":
        for name in names[1:]:
            if normalized_name(name) not in monitored:
                errors.append(f"P01-M other candidate is absent from E2 monitoring: {name}")
        extras = sorted(
            value for value in monitored_competitors - normalized_candidates - featured_aliases
            if value and value in normalized_text
        )
        if extras:
            errors.append(f"P01-M body names monitored competitors absent from candidate_contract: {extras}")
        if require_matrix and not competitor_matrix:
            errors.append("P01-M requires an E6 competitor matrix")
        if competitor_matrix:
            if competitor_matrix.get("objects") != names:
                errors.append("P01-M matrix objects must exactly preserve ordered_candidates")
            if competitor_matrix.get("dimensions") != contract.get("common_dimensions"):
                errors.append("P01-M matrix dimensions must exactly equal candidate common_dimensions")
    else:
        if competitor_matrix:
            errors.append("P01-S forbids a competitor matrix")
        forbidden_monitored = sorted(
            value for value in monitored_competitors - featured_aliases
            if value and value in normalized_text
        )
        if forbidden_monitored:
            errors.append(f"P01-S visible body names monitored competitors: {forbidden_monitored}")
        for claim_id in sorted(used):
            claim = claims.get(claim_id, {})
            other_entities = {
                normalized_name(value) for value in claim.get("about_entities", [])
                if normalized_name(value) and normalized_name(value) not in featured_aliases
            }
            if claim.get("claim_type") in {"comparison", "price", "reputation"} and other_entities:
                errors.append(
                    f"P01-S uses a competitor-like claim about another entity: {claim_id}:{sorted(other_entities)}"
                )
    return errors
