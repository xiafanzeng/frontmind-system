# 企业图片库与视觉资产政策

## 1. 唯一 registry

所有图片使用 [registries.schema.json](../../shared/registries.schema.json) 的 `image_registry`：顶层固定 `images[]`，每项固定 `asset_id/file_path/sha256/source_kind/rights_status/semantic_tags/allowed_roles`。不得再维护第二套 `entries/file_hash` 结构。

## 2. 来源

- 企业 Logo、产品、团队、场地、证书、客户现场、事件和案例实图必须来自企业提交或明确授权来源。
- 官网下载图与客户提交图分开标记；第三方图片需要许可和署名条件。
- 生成图只能作为解释、流程、比较或数据视觉，不能冒充真实人物、场景、客户、认证、事件或产品外观。

## 3. 自动扫描

E3 可扫描没有 manifest 的 job-local 补充图片库，计算 SHA-256、尺寸、类型和候选标签，但不得推断权利已获批。权利未知的图片不能进入终稿。重复哈希只登记一个 canonical asset，并记录原始路径别名。

## 4. P 模式要求

- P01/P02：比较图必须与正文使用相同维度和数据来源。
- P04/P10：机制、架构和流程图必须对应真实组件或步骤。
- P09：数据图标明样本、单位、时间和来源。
- P11：案例图必须绑定授权项目；匿名规则与正文一致。
- P12：事件现场图必须来自该事件的一手或授权记录。
- P13：品牌、团队与环境图必须真实且权利明确。
- P15：视觉克制，以正式 Logo、事实时间线或状态说明为主。

## 5. 缺图与质量门

需要事实性图片但 registry 无合格素材时输出 `asset_gap`，列明所需对象、用途、规格与权利要求。不得以网图、图库图或生成图偷偷替代。

E7 每张图必须明确属于 `brand_editorial|navigate|explain|prove` 之一；只有 `prove` 强制绑定 E6 已通过的 claim/source，`explain` 可在不陈述事实时不绑 claim。E8/E10 检查正文语义、来源、权利、哈希、尺寸、alt 与实际画面一致。
