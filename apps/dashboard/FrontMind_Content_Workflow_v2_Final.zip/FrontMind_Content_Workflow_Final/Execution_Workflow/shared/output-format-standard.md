# 执行层输出与同源渲染标准 v2

## 唯一正文正本

根 `content_model.schema.json` 是唯一正文合同。Content Model 无标题；E8 冻结安全正本，E9 只产生整篇候选，E10 通过自动事实回归后选择一份完整模型。DOCX body 与 HTML fragment 必须由同一个 `approved_body_sha256` 渲染，禁止分别写作或字段拼接。

## E1–E10 产物

| 阶段 | 必需产物 |
|---|---|
| E1 | staging receipt、`content_job.json`、scope analysis |
| E2 | canonical `monitoring_input.json`；基础启动为明确不适用 |
| E3 | intake report、runtime evidence/image registries 与 hash-bound receipts |
| E4 | `article_blueprint.json`，恰好一个 P 模式 |
| E5 | 无标题 draft Content Model |
| E6 | evidence semantic review、evidence preflight、可选 competitor matrix |
| E7 | 视觉版 Content Model、visual manifest、审核通过的视觉文件 |
| E8 | safe Content Model、SHA-256、Quality Report |
| E9 | AutoGEO report；成功时另有 candidate 与完整 field diff |
| E10 | regression audit、标题数量 receipt、Title Map、无标题 DOCX/HTML 与公开 Delivery Manifest |

## 公开交付

- `article_body.docx`：无 Title/H1、无表格，图片物理嵌入；
- `article_body.html`：无页面 shell、无 H1、无内嵌 script 的 HTML fragment；
- `structured_data_template.json`：标题与描述只使用 Title Map 占位符；
- `title_options.md`、`title_map.json`、`publishing_metadata_map.json`；
- manifest 登记的视觉文件与 `delivery_manifest.json`。

内部正文 JSON、监控、证据、质量、diff、回归和渲染报告只进入独立审计目录，不进入公开 manifest。PDF、渠道计划、CMS、发布和效果数据均不属于本工作流。
