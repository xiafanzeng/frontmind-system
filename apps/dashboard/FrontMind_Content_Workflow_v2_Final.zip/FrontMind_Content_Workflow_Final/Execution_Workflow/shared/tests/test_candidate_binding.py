#!/usr/bin/env python3

from __future__ import annotations

import copy
import sys
import unittest
from pathlib import Path

SHARED = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SHARED))
from candidate_binding import model_candidate_binding_errors, p01_objective_rank_errors  # noqa: E402
ROOT_SHARED = SHARED.parents[1] / "shared"
sys.path.insert(0, str(ROOT_SHARED))
from content_route import validate_entry_pattern_route  # noqa: E402


def fixture(variant: str = "multi_brand_editorial_recommendation"):
    names = ["客户品牌", "乙品牌", "丙品牌"] if variant.startswith("multi") else ["客户品牌"]
    candidates = [
        {
            "entity_name": name,
            "role": "featured_brand" if index == 0 else "other_candidate",
            "source_ids": [f"src_{index}abc"],
        }
        for index, name in enumerate(names)
    ]
    contract = {
        "featured_brand_name": "客户品牌",
        "ordered_candidates": candidates,
        "common_dimensions": ["能力", "限制"] if len(names) > 1 else [],
        "list_semantics": "editorial_recommendation",
    }
    claims = {
        "schema_version": "2.0.0", "registry_type": "claim_registry",
        "claims": [
            {
                "claim_id": f"clm_{index}abc", "about_entities": [name],
                "source_ids": [f"src_{index}abc"], "claim_type": "capability",
            }
            for index, name in enumerate(names)
        ],
    }
    sources = {
        "schema_version": "2.0.0", "registry_type": "source_registry",
        "sources": [{"source_id": f"src_{index}abc"} for index in range(len(names))],
    }
    lead_text = (
        "客户品牌适合先了解，乙品牌与丙品牌也可按能力和限制共同比较。"
        if len(names) > 1 else "客户品牌适合按自身能力、适用条件和公开限制进行单品牌推荐判断。"
    )
    model = {
        "pattern_id": "P01", "pattern_variant": variant, "candidate_contract": contract,
        "entry_category": "industry_ranking", "product_scenario_subintent": None,
        "primary_question": "哪些品牌值得关注？",
        "lead": {
            "direct_answer_sentence": lead_text,
            "micro_answer": lead_text,
            "claim_ids": [f"clm_{index}abc" for index in range(len(names))],
        },
        "sections": [], "faq": [], "conclusion": {"claim_ids": []},
    }
    blueprint = {"candidate_contract": copy.deepcopy(contract)}
    monitoring = {
        "derived": {
            "competitors": [
                {"name": "乙品牌", "answer_ids": ["a1"]},
                {"name": "丙品牌", "answer_ids": ["a1"]},
            ],
            "answer_landscape": [],
        }
    }
    matrix = {
        "objects": names,
        "dimensions": copy.deepcopy(contract["common_dimensions"]),
    } if len(names) > 1 else None
    return model, blueprint, claims, sources, monitoring, matrix


class CandidateBindingTests(unittest.TestCase):
    def test_p01_multi_positive(self) -> None:
        values = fixture()
        self.assertEqual(
            model_candidate_binding_errors(
                values[0], values[1], values[2], values[3], "客户品牌", [],
                values[4], values[5], require_matrix=True,
            ),
            [],
        )

    def test_p01_single_positive(self) -> None:
        values = fixture("single_brand_recommendation")
        self.assertEqual(
            model_candidate_binding_errors(
                values[0], values[1], values[2], values[3], "客户品牌", [],
                values[4], None, require_matrix=True,
            ),
            [],
        )

    def test_both_p01_variants_use_the_unique_root_route(self) -> None:
        import json
        registry = json.loads((ROOT_SHARED / "content-pattern-registry.json").read_text(encoding="utf-8"))
        for variant in ("multi_brand_editorial_recommendation", "single_brand_recommendation"):
            model, *_ = fixture(variant)
            self.assertEqual(validate_entry_pattern_route(model, registry), [])

    def test_source_and_matrix_laundering_are_rejected(self) -> None:
        model, blueprint, claims, sources, monitoring, matrix = fixture()
        model["candidate_contract"]["ordered_candidates"][1]["source_ids"] = ["src_2abc"]
        matrix["objects"] = ["客户品牌", "丙品牌", "乙品牌"]
        errors = model_candidate_binding_errors(
            model, blueprint, claims, sources, "客户品牌", [], monitoring, matrix, require_matrix=True,
        )
        self.assertTrue(any("source_ids" in value for value in errors))
        self.assertTrue(any("matrix objects" in value for value in errors))

    def test_nfkc_objective_rank_variants_are_rejected(self) -> None:
        model, *_ = fixture()
        model["lead"]["micro_answer"] += "该品牌被列为Ｔｏｐ－１与No.1。"
        errors = p01_objective_rank_errors(model)
        self.assertTrue(errors)

    def test_p01_single_rejects_monitored_competitor_in_body(self) -> None:
        model, blueprint, claims, sources, monitoring, _ = fixture("single_brand_recommendation")
        model["lead"]["micro_answer"] += "乙品牌也是替代选择。"
        errors = model_candidate_binding_errors(
            model, blueprint, claims, sources, "客户品牌", [], monitoring, None, require_matrix=True,
        )
        self.assertTrue(any("visible body names monitored competitors" in value for value in errors))


if __name__ == "__main__":
    unittest.main()
