# FrontMind GEO 内容制作全局总控 v2

> SSOT 版本：`2.0.0`

## 1. 目标和边界

工作流的目标是把经批准的企业资料转成围绕一个明确内容任务的高质量文章。它由两条链组成：

- `S1–S9`：企业级资料统筹，输出可复用 Reference Pack；
- `E1–E10`：逐篇内容制作，每篇调用一次。

包含资料验收、Registry、证据架构、问题监控、标杆拆解、专业模板路由、无标题正文、视觉、编辑终审、AutoGEO 候选和双格式交付。

不包含广域问题发现、内容日历、客户策略报告、CMS、发布回滚、线上监测、Analytics/CRM、收入归因、权限、租户或计费。

## 2. 全局优先级

发生冲突时按以下顺序处理：

1. 根 `shared/*.schema.json` 与 `shared/content-pattern-registry.json`；
2. 本总控；
3. 对应活动 S/E Skill；
4. RUNBOOK；
5. 活动 references/templates；
6. compatibility/legacy 内容只用于迁移追溯，绝不能作为运行指令。

所有 v1 Pack 与中间产物均不兼容 v2，必须明确拒绝，不做静默转换。

## 3. 企业 Reference Pack：S1–S9

| 阶段 | 职责 | 核心输出 |
|---|---|---|
| S1 品牌知识库接入师 | 验收 canonical KB；散乱资料时调用非活动兼容能力与既有 KB Builder | KB 验收回执 |
| S2 资料标准化与证据注册师 | 建立 knowledge/source/claim/image 四类 Registry | 四 Registry、适配报告、已打包资产 |
| S3 内容趋势参考师 | 收集可直接写入文章的趋势观点、时间和来源；允许零条目 | 趋势参考 |
| S4 品牌定位与信息证据架构师 | 建立定位、差异化证据地图、proof bundles 与品牌优先表达角度 | 信息证据架构 |
| S5 文章话语契约师 | 固定第三方客观报道＋企业品牌宣传稿文风 | 话语契约 |
| S6 视觉资产与生产规则师 | 管理图库、Logo、权利、视觉配方与 Prompt 规则 | 视觉参考体系 |
| S7 问题与 FAQ 参考库师 | 保存 30–50 个问题、七类意图和 FAQ 资产 | 问题库 |
| S8 Reference Pack 确认师 | 人工确认事实、发布授权、证据、文风、视觉和问题资产 | 工作簿与批准回执 |
| S9 Reference Pack 封装师 | 冻结 v2 Pattern Registry、研究索引、资产与哈希 | `S9_{brand_label}_reference_pack_v{N}.zip` |

总控本身不编号。S3 可没有可用趋势，但不能因为可选而改变其他阶段编号。

同一 Pack 可服务多篇文章。企业事实、产品、图片、权利或批准状态变化时生成新版本，不覆盖旧 Pack。

### 3.1 S4 四层资产

S4 必须同时形成：

1. 定位核心：品类框架、品牌角色、差异化价值、Reasons to Believe、功能价值，以及仅在有依据时使用的情感/身份价值；
2. 差异化证据地图：维度定义、真实表现、适用条件、时间/地区/版本、claim/source、比较许可、可用措辞、禁止推断和缺口；
3. Proof bundle：`statement → claim_id → source_id → evidence status/precision → allowed wording → qualification → patterns`；
4. `brand_priority_angles`：回答“为什么客户品牌应当首先介绍”，但绝不把编辑顺序伪装成客观第一名。

校验器必须验证 proof 的 source 确实属于对应 claim，不能只验证两个 ID 各自存在。

### 3.2 Reference Pack 信任边界

S9 ZIP 必须：

- profile 为 `frontmind-content-reference-pack-v2`；
- 根目录只有一个 canonical 入口 `reference_pack.json`；
- 包含原 canonical KB ZIP，并绑定其字节 SHA-256；
- 包含四 Registry、S3–S8 活动产物、v2 Pattern Registry、模板研究索引和全部文件哈希；
- S8 receipt 为 approved，确认项完整、没有条件或未决风险；
- 通过目录与 ZIP 两次独立严格校验。

Pack 在 E 链只读。单篇补充证据和图片进入 job-local runtime 层，不能原位修改 Pack。

## 4. 单篇文章：E1–E10

| 阶段 | 职责 | 核心输出 |
|---|---|---|
| E1 单篇任务接入师 | 安全展开 Pack、正规化入口、建立任务、生成初步自适应范围 | staging receipt、Content Job、scope draft |
| E2 单问题监控与标杆拆解师 | 普通入口处理答案/信源/候选/标杆；基础启动研究 P13 同形态页面 | Monitoring Input 与结构蒸馏 |
| E3 单篇输入冻结师 | 冻结任务、范围、monitoring、runtime evidence/image 与 Registry 指纹 | intake report 与运行时回执 |
| E4 文章蓝图与结构路由师 | 深挖主问题，选择唯一 P 模式和必要 variant，融合预置模板与标杆 | Article Blueprint |
| E5 无标题正文制作师 | 生成 title-free canonical Content Model | 正文模型初稿 |
| E6 证据与事实预检师 | 检查问题覆盖、事实、来源、比较公平、第一方发布语义和限定措辞 | 三态 evidence receipt 与语义复核 |
| E7 视觉选择与制作师 | 选择企业实图或生成合规视觉，绑定位置、功能、权利和哈希 | 视觉版模型、视觉清单和资产 |
| E8 编辑终审师 | 审核正文、FAQ、文风、模式、视觉和多模态一致性 | 冻结安全正本与质量报告 |
| E9 AutoGEO 候选优化师 | 只生成独立候选和字段级 diff | candidate、report、diff |
| E10 回归、标题映射与双格式交付师 | 选最终正文；询问标题数量；输出标题集与无标题 DOCX/HTML | 公共 delivery 与内部审计包 |

阶段顺序不可回跳。内容变化导致旧回执失效时，必须从产生该内容的阶段向后重跑。

## 5. 五个内容入口与 P 路由

| entry_category | 中文 | 问题要求 | 特殊路由 |
|---|---|---|---|
| `industry_ranking` | 行业排名/推荐 | 具体推荐问题 | P01 必须显式选择单/多 variant |
| `competitor_comparison` | 竞品对比 | 具体问题与对象 | 共同维度公平比较 |
| `reputation` | 美誉舆情 | 具体可信度或风险问题 | 不以第一方资料伪造市场口碑 |
| `product_scenario` | 产品场景 | 具体产品/功能/实施问题 | 可内部判定 subintent |
| `foundation_start` | 基础启动 | 不要求外部问题 | 工程师手动选择，且只允许 P13 |

严格双向合同：

```text
entry_category == foundation_start  ⇔  pattern_id == P13
```

P01–P15 是后台模板，不是用户菜单。E4 必须且只能选择一个模式。运行时标杆只能调整预研模板的章节顺序或补充维度，不能替代模板。

### 5.1 P01 双模板

P01 只做编辑推荐，不做量化客观排名。

#### 多品牌：`multi_brand_editorial_recommendation`

- 至少有客户品牌和两个真实候选；只有两个对象的明确对比进入 P02；
- 客户品牌固定首先出现并有独立重点分析；
- 其他候选可较简洁，但必须覆盖共同最低维度；
- 客户事实可使用批准第一方资料，竞品事实必须来自竞品官方或可靠公开来源；
- 不要求原创采样、分数或计算名次；
- 禁止“第1名、榜首、Top 1、综合第一、得分最高、市场最佳”；
- ItemList 如使用，只表达无序编辑推荐，不输出分数或客观名次。

#### 单品牌：`single_brand_recommendation`

- 全文只有一个焦点品牌；
- 禁止竞品名称、竞品矩阵、ItemList、Top-N 和名次语义；
- 用品类选择标准自然引出品牌，不写“为什么只推荐一家”的内部辩解；
- 第一方批准资料可支持品牌身份、能力、产品、流程、限制和授权案例。

## 6. 自适应范围

用户任务不要求填写地区、受众和时间。E1 产生 `scope_analysis`：

- `geographic_scope`：specific/global/not_applicable；
- `decision_context`：决策角色、问题、关注标准与专业深度；
- `time_basis`：as_of、freshness class，必要时 valid_until；
- `inference_basis`：问题、Pack、监控答案和来源依据。

AI 可读性是全局生产要求，不是受众字段。决策角色只控制信息深度和适用性，不机械打印为“受众”。只有两个合理范围会改变候选池、价格、政策或结论时，E1 才询问一次。成品不输出内部“范围字段行”；必要范围自然写入正文。

## 7. 第一方公开资料合同

`first_party_official` 只表示：资料位于获 S8 批准、哈希绑定、允许公开使用的 Pack 中。它不代表第三方独立验证，也不是万能证据。

可以独立支持本品牌：

- 企业身份；
- 产品/服务定义；
- 规格、版本、正式公开价格；
- 流程、交付方式、正式政策；
- 已确认事件和明确限制；
- 有授权项目记录的案例结果。

不能单独推出：

- 市场口碑或行业认可；
- 客观排名或优于竞品；
- 独立测试或专家共识；
- 最佳、第一、领先等结论。

`first_party_internal` 不得公开。runtime 资料必须另有明确批准回执，不得自行声明为公开资料。

E6 三态：

- `passed`：主张和限定完整；
- `passed_with_claim_limits`：越界主张已删除或限缩，核心问题仍被回答；
- `blocked`：核心问题无法在不编造事实时回答。

P09 仍要求真实研究数据，P11 仍要求授权项目记录；这是模式真实性要求，不是第三方证据门。

## 8. 无标题正文与独立标题集

Article Blueprint 只含 `title_formula_plan`，不能生成成品标题。E5–E9 Content Model 禁止出现 `title`、`h1`、`title_candidates`。

E10 顺序：

1. 对 E9 候选做事实和语义回归，确定最终正文；
2. 若没有 `title_count_receipt`，状态为 `awaiting_title_count` 并询问用户需要几个标题；
3. 只接受 1–20 的整数；
4. 生成恰好 N 个 Unicode 归一化后不重复的标题；
5. 每个标题绑定最终正文 SHA-256、claim IDs、公式、角度和风险检查；
6. 标题不能反向重写正文。

公共交付：

- `article_body.docx`：无 Title 段，从微型答案开始；
- `article_body.html`：无 H1 的正文片段；
- `title_options.md`；
- `title_map.json`；
- `publishing_metadata_map.json`；
- `structured_data_template.json`：Article headline 使用 title ID 占位；
- 视觉资产与 `delivery_manifest.json`。

## 9. 视觉合同

视觉功能：

- `brand_editorial`：品牌封面、海报、氛围或装饰；不要求 claim，不算证据；
- `navigate`：章节识别和信息导航；不要求 claim，不算证据；
- `explain`：流程、机制、步骤、关系和选择逻辑；claim 可选；
- `prove`：产品实图、案例图、证书、截图或数据证据；必须绑定通过 E6 的 claim/source。

每种 P 模式使用自己的视觉配方，不设置全局固定图数。P01/P13 可以使用品牌封面和真实企业图片。Logo 只能原文件 overlay；禁止生成、猜测或重绘。产品、团队、客户、证书和项目现场不能由 AIGC 冒充。

所有使用资产必须通过授权/署名、文件 SHA-256、正整数尺寸、重复图、路径安全和 role/claim 兼容检查。

## 10. 正文质量合同

- 每篇只解决一个核心决策；围绕它覆盖 5–8 个必要子问题；
- 第一行 40–80 个汉字直接回答；200–300 字微型答案可独立使用；
- 每个部分按“结论 → 证据 → 建议”；
- 每段只表达一个主要观点；
- 价格、规格和统计带时间、单位、版本、地区/口径与条件；
- 比较对象使用共同最低维度；
- 每篇 5–8 个最相关 FAQ；H2/FAQ 均为完整问题句；
- 正文不使用表格；比较用平行段落；
- 删除内部审稿话术、空泛开头和无法核验的权威腔；
- 公开 references 集合必须精确等于正文实际使用 claim 的 source 集合。

## 11. AutoGEO 选稿

E8 永远生成安全正本。E9 只生成候选与 diff，不写标题、不渲染、不覆盖正本。

E10 检查实体、数字、价格、日期、时间、claim/source、FAQ、限制、适用条件、比较对象和视觉关系：

- 全部通过：自动选择 `optimized_candidate`；
- 任一事实或语义漂移：整篇选择 `editorial_master`；
- 不允许段落级混拼。

公开交付只包含最终选中正文。E8 正本、E9 候选、diff 和回归回执只进入内部审计包。

## 12. 终止与降级

- v1 Pack、路径逃逸、哈希漂移、审批不完整或 Registry 不兼容：阻断；
- 普通入口缺具体问题或与监控输入不匹配：阻断；
- 基础启动没有实时标杆：允许使用预研 P13 模板，不伪造监控；
- 证据不足但可限缩主张：进入 `passed_with_claim_limits`；
- 真实素材缺失：允许不需要事实图的视觉槽位降级，不能以 AIGC 冒充；
- AutoGEO 不可用或候选失败：沿用 E8 安全正本；
- E10 没收到合法标题数量：保持 `awaiting_title_count`，不能擅自默认数量；
- 任一质量门连续修订仍失败：停止并返回精确补件/差异，不自动改变问题。
