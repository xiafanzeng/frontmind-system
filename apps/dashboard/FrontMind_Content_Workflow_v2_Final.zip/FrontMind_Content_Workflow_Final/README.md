# FrontMind GEO 内容制作 Workflow v2

> 定位：服务商内部使用的企业资料统筹与单篇 GEO 内容制作工作流。

本工作流不是选题产品、发布系统或数据分析平台。它把企业知识库和图库先整理成一个可复用的 Reference Pack，再针对每篇文章运行一次内容制作链。

## 怎么使用

### 企业资料变化时：运行一次 S1–S9

```text
S1 知识库接入
→ S2 资料标准化与四类 Registry
→ S3 内容趋势参考（可无条目）
→ S4 品牌定位、信息证据架构与优先表达角度
→ S5 文章话语契约
→ S6 视觉资产与生产规则
→ S7 问题与 FAQ 参考库
→ S8 人工确认与公开发布授权
→ S9 生成严格校验的 Reference Pack v2 ZIP
```

### 每想做一篇文章：上传同一个 Pack，再运行一次 E1–E10

```text
E1 单篇任务接入与自适应范围
→ E2 单问题监控与标杆拆解
→ E3 输入、证据与 Registry 指纹冻结
→ E4 选择唯一 P 模式并形成蓝图
→ E5 制作无标题正文
→ E6 证据、事实与限定措辞预检
→ E7 选择或制作视觉
→ E8 编辑终审并冻结安全正本
→ E9 生成独立 AutoGEO 候选
→ E10 回归选稿、询问标题数量、输出标题集与无标题 DOCX/HTML
```

同一个 Pack 可以复用到多篇文章。企业事实、产品、图片或发布授权变化时，重新运行受影响的 S 阶段并生成新 Pack 版本。

## 五个工程入口

| 入口 | 用途 | 工程师需要决定什么 |
|---|---|---|
| `industry_ranking` | 行业推荐与品牌名单 | P01 单品牌或多品牌 variant |
| `competitor_comparison` | 明确对象间的共同维度比较 | 具体问题和对象 |
| `reputation` | 可信度、口碑、风险与服务判断 | 具体问题 |
| `product_scenario` | 产品、功能、实施与适用场景 | 具体问题 |
| `foundation_start` | 新品牌前置基础认知稿 | 手动选择；只能生成 P13 |

P01–P15 是后台结构模式，不是给用户选择的 15 个入口。P01 内保留两套重要模板：

- `multi_brand_editorial_recommendation`：客户品牌首先出现并重点详写，另有至少两个真实候选；不计算客观名次。
- `single_brand_recommendation`：只写一个焦点品牌，不出现竞品、矩阵、ItemList 或 Top-N。

## v2 的关键变化

- 正式编号只使用连续的 S1–S9、E1–E10；旧能力的迁移关系见 [迁移矩阵](shared/workflow-migration-map.md)。
- 原始 Workflow 未修改；旧 S1 字节级保存在非活动兼容区，新活动 S1 只负责接入与验收。
- 地区、决策对象和时间由 E1 自适应分析，不要求用户填写；只有范围歧义会实质改变结论时才询问一次。
- Content Model 完全无标题；E10 在最终正文确定后询问 1–20 个标题，单独交付标题映射。
- DOCX 从微型答案开始，没有 Title 段；HTML 是没有 H1 的可嵌入正文片段。
- 审批并哈希绑定的第一方公开资料可以独立支持本品牌事实，不再因为“没有第三方”阻断新品牌文章；但不能据此推出排名、口碑、领先或优于竞品。
- E7 恢复旧版品牌封面、企业实图、AIGC 和 Prompt 生产能力，并保留权利、哈希、Logo、事实冒充和来源安全门。
- AutoGEO 候选事实与语义不变时自动采用；任一漂移整篇回退 E8 安全正本，绝不段落混拼。

## 模板库

唯一机器注册表是 [content-pattern-registry.json](shared/content-pattern-registry.json)。模板研究档案位于 [pattern-research](shared/pattern-research/README.md)：

- 16 套运行结构：P01-M、P01-S、P02–P15；
- 140 个全库去重标杆 URL，74 个唯一域名；
- P01-M、P01-S、P13 各 12 个标杆，其余各 8 个；
- 每套记录章节顺序、子问题、证据位置、视觉作用、FAQ、优缺点和不可借鉴元素。

运行时 E2 标杆拆解只能调整顺序和补充维度，不能取代预研模板。

## 机器合同

- Reference Pack profile：`frontmind-content-reference-pack-v2`。
- Reference Pack 文件名：`S9_{brand_label}_reference_pack_v{N}.zip`。
- 企业知识、来源、主张和图片只使用四个 canonical Registry。
- Content Model 是无标题正文唯一正本；DOCX/HTML 必须同源。
- 标题数量、标题集、发布元数据和结构化数据模板均绑定最终正文 SHA-256。
- 公开交付目录只包含最终正文、标题资产、结构化数据模板、视觉和 Manifest；编辑正本、候选、diff 与审计回执只在内部审计包。

## 唯一入口与文档

- [内容制作总控](00.FrontMind内容制作总控.skill/SKILL.md)
- [全局 SSOT](Master_Control/FrontMind_Content_Workflow_Master.md)
- [完整运行手册](RUNBOOK.md)
- [公共合同说明](shared/README.md)
- [验证报告](VALIDATION_REPORT.md)

## 依赖与验证

从 Workflow 根目录执行：

```bash
python3 -m pip install -r requirements.txt
python3 -B scripts/check_runtime_dependencies.py
python3 -B scripts/validate_workflow.py
python3 -B shared/scripts/check_cross_references.py .
python3 -B shared/scripts/validate_package.py shared/fixtures/minimal_reference_pack
```

SVG 转 DOCX、旧资料整理抓取与 AutoGEO 的可选依赖见 `requirements-optional.txt`。AutoGEO 不可用时必须明确跳过，并沿用 E8 安全正本。

## 明确不做

- 不恢复广域问题发现、关键词池、周期排期或选题日程；
- CMS 发布、回滚、线上监测、Analytics、CRM 或收入归因；
- 多租户、RBAC、计费或外部产品架构；
- 让用户从 P01–P15 菜单选择模板；
- 因缺少第三方材料自动阻断新品牌事实型文章；
- 让 AutoGEO 修改事实或直接覆盖编辑正本。
