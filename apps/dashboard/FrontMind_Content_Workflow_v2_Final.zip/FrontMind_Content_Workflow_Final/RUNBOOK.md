# FrontMind GEO 内容制作 Workflow v2 可复制运行手册

本手册是 S1–S9 与 E1–E10 的唯一命令入口。活动 Skill 解释专业判断，本手册负责阶段顺序、文件身份和真实 CLI 参数。

## 1. 先理解两条链

```text
企业资料或授权变化：S1 → S2 → S3（可选）→ S4 → S5 → S6 → S7 → S8 → S9
每制作一篇文章：    E1 → E2（基础启动跳过）→ E3 → E4 → E5 → E6 → E7 → E8 → E9 → E10
```

- S 链为一个企业生成可复用的 Reference Pack v2；同一 Pack 可以服务多篇文章。
- E 链一次只制作一篇文章；每个新问题建立新的 `job_id` 并重新运行 E1–E10。
- Pack 在 E 链中只读。单篇新证据和补图进入 job-local runtime Registry。
- 企业事实、产品、图片、权利或公开授权变化时，回到对应 S 阶段并生成新版 Pack。
- v1 Pack 和中间产物不兼容 v2，校验器会明确拒绝。

## 2. 环境和路径

Python 要求 3.10 或更高。建议为本 Workflow 建独立虚拟环境：

```bash
python3 -m venv /absolute/path/to/frontmind-v2-venv
/absolute/path/to/frontmind-v2-venv/bin/python -m pip install -r /absolute/path/to/FrontMind_Content_Workflow_Final/requirements.txt
```

从 Workflow 根目录先检查依赖与静态合同：

```bash
PYTHON=/absolute/path/to/frontmind-v2-venv/bin/python
WF=/absolute/path/to/FrontMind_Content_Workflow_Final

"$PYTHON" -B "$WF/scripts/check_runtime_dependencies.py"
"$PYTHON" -B "$WF/scripts/validate_workflow.py"
"$PYTHON" -B "$WF/shared/scripts/check_cross_references.py" "$WF"
```

SVG 资产需要 `requirements-optional.txt` 中的 CairoSVG。AutoGEO 是独立审核的可选依赖；不可用时 E9 记录 skip，E10 使用 E8 安全正本。

以下变量只作命令示例。全部换成真实绝对路径；不要把正式品牌名直接当路径标签：

```bash
BRAND='品牌正式名称'
BRAND_LABEL='stable_brand_label'
KB=/absolute/path/to/canonical-kb-v4.zip
PROJECT=/absolute/path/to/brand-reference-project
PACK=/absolute/path/to/brand-reference-project/ReferencePack/S9_stable_brand_label_reference_pack_v1.zip
JOB=/absolute/path/to/article-job
JOB_ID=job_example_20260811
```

`BRAND` 进入事实与正文；`BRAND_LABEL` 只用于文件名，必须稳定、安全且不含路径分隔符。

---

# 第一部分：S1–S9 企业 Reference Pack

## S1 企业资料与 canonical KB 接入

正式入口必须是 `schemaVersion=4`、`profile=dashboard-enterprise-v1` 的 canonical KB 原始 ZIP。

已有 canonical KB 时：

```bash
mkdir -p "$PROJECT/S1"
"$PYTHON" -B "$WF/Strategy_Workflow/S1.企业资料与知识库接入师.skill/scripts/canonical_kb_intake.py" \
  --brand "$BRAND" \
  --kb "$KB" \
  --source-mode existing_canonical_kb \
  --output "$PROJECT/S1/S1_${BRAND_LABEL}_canonical_kb_intake.json"
```

只有散乱资料时，先按 [S1 Skill](Strategy_Workflow/S1.企业资料与知识库接入师.skill/SKILL.md) 调用非活动兼容区的旧资料整理能力，再经既有 KB Builder 生成 canonical KB；随后使用 `legacy_s1_then_builder` 与 Builder receipt 执行同一验收命令。旧产物不能直接进入 S2。

## S2 资料标准化、四类 Registry 与逐来源授权

S2 必须运行两次。第一次只生成稳定 source ID 和授权模板；第一次输出目录必须放在正式 `$PROJECT` 外，避免 S9 发现重复产物：

```bash
S2_DRAFT=/absolute/path/to/frontmind-s2-authorization-draft
"$PYTHON" -B "$WF/Strategy_Workflow/S2.资料标准化适配器.skill/scripts/kb_v4_adapter.py" \
  --brand "$BRAND" \
  --kb "$KB" \
  --output-dir "$S2_DRAFT"
```

复制 `S2_${BRAND_LABEL}_source_publication_authorizations.template.json`，按照 [授权 Schema](Strategy_Workflow/S2.资料标准化适配器.skill/templates/source_publication_authorizations.schema.json) 对每个且仅每个第一方候选 `source_id` 选择：

- `public_approved`：原文可公开；
- `anonymized_approved`：完成脱敏后可公开；
- `internal_only`：只能内部使用。

不得遗漏来源、加入第三方 ID 或把内部资料自行标成公开。负责人填写审核人、角色、时间、依据和证据引用后，从同一原始 KB 重新生成正式 S2：

```bash
mkdir -p "$PROJECT/S2"
"$PYTHON" -B "$WF/Strategy_Workflow/S2.资料标准化适配器.skill/scripts/kb_v4_adapter.py" \
  --brand "$BRAND" \
  --kb "$KB" \
  --publication-authorizations /absolute/path/to/source_publication_authorizations.json \
  --output-dir "$PROJECT/S2"
```

必须得到四个 v2 Registry、adapter report、授权原件以及自包含 `assets/`、`sources/`。`formal_handoff_ready=true`、`fatal_errors=[]` 才能继续。

如需合并旧 S1 资料或客户图库，只能使用 S2 Skill 说明的 `--s1-facts`、`--s1-visual-manifest`、`--s1-assets-root`、`--gallery` 参数，并保持 provenance、权利和相对路径完整。

## S3 内容趋势参考（可选）

只有政策、标准、产品能力、技术或用户语言出现会实质改变文章的变化时才运行。按 [S3 Skill](Strategy_Workflow/S3.内容趋势参考.skill/SKILL.md) 形成带来源、时间和可写观点的 v2 JSON，再校验：

```bash
mkdir -p "$PROJECT/S3"
"$PYTHON" -B "$WF/Strategy_Workflow/S3.内容趋势参考.skill/scripts/signal_aggregator.py" \
  --validate "$PROJECT/S3/S3_${BRAND_LABEL}_trend_reference.json" \
  --source-registry "$PROJECT/S2/S2_${BRAND_LABEL}_source_registry.json" \
  --knowledge-registry "$PROJECT/S2/S2_${BRAND_LABEL}_knowledge_registry.json" \
  --pattern-registry "$WF/shared/content-pattern-registry.json"
```

没有可靠趋势时不制造内容，可不提供 S3 文件；S9 会写 `trend_viewpoints_path=null`。

## S4 品牌定位与信息证据架构

完整读取 S2 Registries，并按 [S4 Skill](Strategy_Workflow/S4.内容价值与证据架构师.skill/SKILL.md) 产出：

- `S4_${BRAND_LABEL}_information_evidence_architecture.json`；
- `S4_${BRAND_LABEL}_brand_facts.json`；
- 可选的人读说明 Markdown。

S4 必须包含定位核心、价值结构、差异化证据地图、proof bundles、五入口话语边界和 `brand_priority_angles`。P01-M 的客户品牌首先介绍理由来自 priority angle，不得变成客观第一名。

```bash
mkdir -p "$PROJECT/S4"
"$PYTHON" -B "$WF/Strategy_Workflow/S4.内容价值与证据架构师.skill/scripts/information_evidence_validator.py" \
  "$PROJECT/S4/S4_${BRAND_LABEL}_information_evidence_architecture.json" \
  --brand-facts "$PROJECT/S4/S4_${BRAND_LABEL}_brand_facts.json" \
  --knowledge-registry "$PROJECT/S2/S2_${BRAND_LABEL}_knowledge_registry.json" \
  --claim-registry "$PROJECT/S2/S2_${BRAND_LABEL}_claim_registry.json" \
  --source-registry "$PROJECT/S2/S2_${BRAND_LABEL}_source_registry.json" \
  --pattern-registry "$WF/shared/content-pattern-registry.json"
```

## S5 文章话语契约

按 [S5 Skill](Strategy_Workflow/S5.文章话语契约.skill/SKILL.md) 形成第三方客观报道＋企业品牌宣传稿的逐句规则，禁止内部审稿话术和无依据的权威腔：

```bash
mkdir -p "$PROJECT/S5"
"$PYTHON" -B "$WF/Strategy_Workflow/S5.文章话语契约.skill/scripts/article_voice_contract_validator.py" \
  "$PROJECT/S5/S5_${BRAND_LABEL}_voice_contract.json" \
  --architecture "$PROJECT/S4/S4_${BRAND_LABEL}_information_evidence_architecture.json" \
  --pattern-registry "$WF/shared/content-pattern-registry.json"
```

## S6 视觉资产与生产规则

按 [S6 Skill](Strategy_Workflow/S6.视觉参考体系.skill/SKILL.md) 将 Logo、图库、权利、视觉配方和 Prompt scaffold 组织为 `S6_${BRAND_LABEL}_visual_reference.json`：

```bash
mkdir -p "$PROJECT/S6"
"$PYTHON" -B "$WF/Strategy_Workflow/S6.视觉参考体系.skill/scripts/visual_reference_validator.py" \
  "$PROJECT/S6/S6_${BRAND_LABEL}_visual_reference.json" \
  --image-registry "$PROJECT/S2/S2_${BRAND_LABEL}_image_registry.json" \
  --pattern-registry "$WF/shared/content-pattern-registry.json"
```

Logo 只能使用原文件 overlay；真实产品、团队、客户、证书和项目现场不得由 AIGC 冒充。

## S7 问题与 FAQ 参考库

按 [S7 Skill](Strategy_Workflow/S7.问题与FAQ参考库.skill/SKILL.md) 整理 30–50 个有 provenance 的真实问题，覆盖七类意图和五入口参考资产。这里只保存答案边界，不写完整文章：

```bash
mkdir -p "$PROJECT/S7"
"$PYTHON" -B "$WF/Strategy_Workflow/S7.问题与FAQ参考库.skill/scripts/question_library_validator.py" \
  "$PROJECT/S7/S7_${BRAND_LABEL}_question_library.json" \
  --pattern-registry "$WF/shared/content-pattern-registry.json" \
  --knowledge-registry "$PROJECT/S2/S2_${BRAND_LABEL}_knowledge_registry.json" \
  --source-registry "$PROJECT/S2/S2_${BRAND_LABEL}_source_registry.json" \
  --claim-registry "$PROJECT/S2/S2_${BRAND_LABEL}_claim_registry.json" \
  --architecture "$PROJECT/S4/S4_${BRAND_LABEL}_information_evidence_architecture.json"
```

## S8 人工确认

S8 是资料层唯一暂停点。生成工作簿前，S2 的逐来源授权必须已经完成，S4–S7 必须基于最终 Registries 重建并通过校验：

```bash
mkdir -p "$PROJECT/S8"
"$PYTHON" -B "$WF/Strategy_Workflow/S8.ReferencePack确认师.skill/scripts/reference_pack_confirmation_generator.py" \
  --brand "$BRAND" \
  --work-dir "$PROJECT" \
  --pattern-registry "$WF/shared/content-pattern-registry.json" \
  --pattern-research-index "$WF/shared/pattern-research/index.json" \
  --out "$PROJECT/S8/S8_${BRAND_LABEL}_ReferencePack确认表.xlsx"
```

负责人逐项审阅每个第一方 source、claim、proof bundle、价值/差异化/优先角度、话语、问题和视觉对象。任何 `change`、`block`、附带条件或未决风险都必须回责任阶段修改，不能伪装批准。

全部 `keep` 后解析：

```bash
"$PYTHON" -B "$WF/Strategy_Workflow/S8.ReferencePack确认师.skill/scripts/reference_pack_approval_parser.py" \
  --confirmed "$PROJECT/S8/S8_${BRAND_LABEL}_ReferencePack确认表.xlsx" \
  --brand "$BRAND" \
  --out "$PROJECT/S8/S8_${BRAND_LABEL}_approval.json"
```

## S9 封装并双重校验 Reference Pack v2

先查看就绪状态：

```bash
"$PYTHON" -B "$WF/Strategy_Workflow/S9.ReferencePack装配师.skill/scripts/state_detector.py" \
  --work-dir "$PROJECT" \
  --kb "$KB"
```

再构包。输出文件名中的标签必须与项目采用的稳定 `BRAND_LABEL` 一致：

```bash
mkdir -p "$PROJECT/ReferencePack"
"$PYTHON" -B "$WF/Strategy_Workflow/S9.ReferencePack装配师.skill/scripts/pack_builder.py" \
  --brand "$BRAND" \
  --work-dir "$PROJECT" \
  --kb "$KB" \
  --pattern-registry "$WF/shared/content-pattern-registry.json" \
  --pattern-research-index "$WF/shared/pattern-research/index.json" \
  --version 1 \
  --output "$PACK"

"$PYTHON" -B "$WF/shared/scripts/validate_package.py" "$PACK"
```

S9 必须同时报告目录与 ZIP 校验 `pass`。Pack profile 固定为 `frontmind-content-reference-pack-v2`。

---

# 第二部分：E1–E10 每篇文章运行一次

## 3. 创建 job root 和 Content Job

每篇文章使用全新的 `$JOB` 和 `$JOB_ID`。先创建输入目录；`reference/` 必须不存在，交给 E1 安全展开：

```bash
mkdir -p "$JOB/00_input"
```

普通四入口的 raw Content Job 必须包含明确问题。`industry_ranking` 还必须由工程师显式选择 P01 单／多 variant：

```json
{
  "schema_version": "2.0.0",
  "job_id": "job_example_20260811",
  "pack_id": "rp_from_reference_pack",
  "created_at": "2026-08-11T10:00:00+08:00",
  "entry_category": "industry_ranking",
  "task": {
    "question_text": "某类服务有哪些品牌值得考虑？",
    "question_origin": "external_confirmed",
    "foundation_subject": null,
    "manual_foundation_selection": false,
    "requested_pattern_variant": "multi_brand_editorial_recommendation",
    "product_scenario_subintent": null
  },
  "scope_analysis_path": "00_input/scope_analysis.json",
  "monitoring_input_path": "01_monitoring/E2_job_example_20260811_monitoring_input.json",
  "optimizer_target": {"dataset": "frontmind_geo", "engine_llm": "configured_engine"},
  "deliverables": {"docx_body": true, "html_body_fragment": true, "title_map": true},
  "editorial_profile": "third_party_objective_with_evidence_based_brand_promotion",
  "user_constraints": []
}
```

基础启动由工程师手动选择，无外部问题、无 P01 variant、无 Monitoring：

```json
{
  "schema_version": "2.0.0",
  "job_id": "job_example_20260811",
  "pack_id": "rp_from_reference_pack",
  "created_at": "2026-08-11T10:00:00+08:00",
  "entry_category": "foundation_start",
  "task": {
    "question_text": null,
    "question_origin": "foundation_derived",
    "foundation_subject": "品牌正式名称",
    "manual_foundation_selection": true,
    "requested_pattern_variant": null,
    "product_scenario_subintent": null
  },
  "scope_analysis_path": "00_input/scope_analysis.json",
  "monitoring_input_path": null,
  "optimizer_target": {"dataset": "frontmind_geo", "engine_llm": "configured_engine"},
  "deliverables": {"docx_body": true, "html_body_fragment": true, "title_map": true},
  "editorial_profile": "third_party_objective_with_evidence_based_brand_promotion",
  "user_constraints": []
}
```

将对应 JSON 保存为 `$JOB/00_input/content_job.raw.json`。

## E1 安全落地、任务正规化与自适应范围

```bash
"$PYTHON" -B "$WF/Execution_Workflow/E1.单篇任务建档师.skill/scripts/stage_reference_pack.py" \
  --zip "$PACK" \
  --output-dir "$JOB/reference" \
  --manifest-output "$JOB/00_input/E1_reference_pack_staging.json" \
  --job-package-root "$JOB"

"$PYTHON" -B "$WF/Execution_Workflow/E1.单篇任务建档师.skill/scripts/normalize_content_job.py" \
  --input "$JOB/00_input/content_job.raw.json" \
  --output "$JOB/00_input/content_job.json" \
  --receipt "$JOB/00_input/E1_content_job_normalization.json"
```

按照 [Scope Analysis Schema](shared/scope_analysis.schema.json) 由 E1 分析问题、Pack 和必要资料，生成 `$JOB/00_input/scope_analysis.json`。地区不影响结论时写 `not_applicable`；决策角色只控制深度，不作为机械“受众”打印；时间以资料/监控截止日推断。只有两种合理范围会实质改变候选、价格、政策或结论时暂停询问一次。

```bash
"$PYTHON" -B "$WF/Execution_Workflow/E1.单篇任务建档师.skill/scripts/validate_scope_analysis.py" \
  --content-job "$JOB/00_input/content_job.json" \
  --scope-analysis "$JOB/00_input/scope_analysis.json" \
  --job-root "$JOB"
```

## E2 单问题监控与标杆拆解

`foundation_start` 跳过本阶段；E4 使用预研 P13 模板，也可在 E2 的人工研究部分审阅 1–5 篇同形态品牌特写，但不伪造 AI 问答监控表。

普通四入口按 [E2 Skill](Execution_Workflow/E2.单问题监控与标杆拆解师.skill/SKILL.md) 准备答案表、信源表和 derived analysis。被标记为 `retrieved` 的页面必须有访问时间、正文摘录、引用上下文、被引主张、来源类型、原始来源判断和新鲜度风险：

```bash
mkdir -p "$JOB/01_monitoring"
"$PYTHON" -B "$WF/Execution_Workflow/E2.单问题监控与标杆拆解师.skill/scripts/micro_tracking_builder.py" \
  --job-id "$JOB_ID" \
  --question '本篇已确认的具体问题' \
  --answers "$JOB/01_monitoring/answers.xlsx" \
  --citations "$JOB/01_monitoring/sources.xlsx" \
  --derived-analysis "$JOB/01_monitoring/derived.json" \
  --output "$JOB/01_monitoring/E2_${JOB_ID}_monitoring_input.json" \
  --raw-metadata-output "$JOB/01_monitoring/E2_${JOB_ID}_raw_metadata.json" \
  --package-root "$JOB"
```

运行时标杆只可调整预研模板的章节顺序或补充判断维度，不能替代 P 模式骨架。

## E3 全契约 intake 与 job-local runtime Registries

先冻结 Pack、Content Job、scope 和 Monitoring。基础启动省略 `--monitoring-input`：

```bash
mkdir -p "$JOB/03_runtime_evidence" "$JOB/03_runtime_images"
"$PYTHON" -B "$WF/Execution_Workflow/E3.全契约与运行时资产师.skill/scripts/intake_validator.py" \
  --content-job "$JOB/00_input/content_job.json" \
  --reference-pack "$JOB/reference/reference_pack.json" \
  --scope-analysis "$JOB/00_input/scope_analysis.json" \
  --monitoring-input "$JOB/01_monitoring/E2_${JOB_ID}_monitoring_input.json" \
  --staging-receipt "$JOB/00_input/E1_reference_pack_staging.json" \
  --source-zip "$PACK" \
  --package-root "$JOB" \
  --report "$JOB/E3_intake_report.json"
```

按照 [Runtime Evidence Schema](shared/runtime_evidence_extension.schema.json) 创建 `$JOB/03_runtime_evidence/extension.json`。没有单篇补证时也要显式写空的 `sources/claims/evidence_files` 数组；新增网页资料必须有本地 snapshot/摘录、SHA-256、访问时间和 job-local 审批，不能只保存 URL 或自报 verified。

```bash
"$PYTHON" -B "$WF/Execution_Workflow/E3.全契约与运行时资产师.skill/scripts/build_runtime_evidence_bundle.py" \
  --job-id "$JOB_ID" \
  --base-claims "$JOB/reference/registries/claim_registry.json" \
  --base-sources "$JOB/reference/registries/source_registry.json" \
  --pattern-registry "$JOB/reference/shared/content-pattern-registry.json" \
  --extension "$JOB/03_runtime_evidence/extension.json" \
  --job-package-root "$JOB" \
  --runtime-claims "$JOB/03_runtime_evidence/claim_registry.json" \
  --runtime-sources "$JOB/03_runtime_evidence/source_registry.json" \
  --receipt "$JOB/03_runtime_evidence/receipt.json"

"$PYTHON" -B "$WF/Execution_Workflow/E3.全契约与运行时资产师.skill/scripts/seed_runtime_image_registry.py" \
  --job-id "$JOB_ID" \
  --base-registry "$JOB/reference/registries/image_registry.json" \
  --runtime-registry "$JOB/03_runtime_images/image_registry.json" \
  --receipt "$JOB/03_runtime_images/receipt.json"
```

## E4 文章蓝图与唯一 P 路由

按 [E4 Skill](Execution_Workflow/E4.文章蓝图师.skill/SKILL.md) 生成 `$JOB/04_blueprint/E4_${JOB_ID}_article_blueprint.json`。E4 自动选择唯一 P 模式；用户不从 P01–P15 菜单选模板。唯一例外是工程师在任务入口显式选择 P01 单/多 variant 或 `foundation_start`。

```bash
mkdir -p "$JOB/04_blueprint"
"$PYTHON" -B "$WF/Execution_Workflow/E4.文章蓝图师.skill/scripts/pattern_router.py" \
  --registry "$JOB/reference/shared/content-pattern-registry.json" \
  --blueprint "$JOB/04_blueprint/E4_${JOB_ID}_article_blueprint.json" \
  --content-job "$JOB/00_input/content_job.json" \
  --scope-analysis "$JOB/00_input/scope_analysis.json" \
  --monitoring-input "$JOB/01_monitoring/E2_${JOB_ID}_monitoring_input.json" \
  --information-evidence "$JOB/reference/writing/information_evidence_architecture.json" \
  --e3-intake "$JOB/E3_intake_report.json" \
  --report "$JOB/04_blueprint/E4_${JOB_ID}_validation.json"
```

基础启动省略 `--monitoring-input`，并且必须严格路由 P13。P01-M 必须列出至少三个候选、客户品牌第一、共同最低维度和 priority angle；P01-S 必须只有一个焦点品牌。

## E5 制作无标题 Content Model

按 [E5 Skill](Execution_Workflow/E5.正文制作师.skill/SKILL.md) 生成 `$JOB/05_content/E5_${JOB_ID}_content_model.json`。正文从 40–80 字直接答案和 200–300 字微型答案开始；不得出现 `title`、`h1`、`title_candidates`，也不得使用正文表格。

```bash
mkdir -p "$JOB/05_content"
"$PYTHON" -B "$WF/Execution_Workflow/E5.正文制作师.skill/scripts/content_model_validator.py" \
  "$JOB/05_content/E5_${JOB_ID}_content_model.json" \
  --claims "$JOB/03_runtime_evidence/claim_registry.json" \
  --sources "$JOB/03_runtime_evidence/source_registry.json" \
  --content-job "$JOB/00_input/content_job.json" \
  --blueprint "$JOB/04_blueprint/E4_${JOB_ID}_article_blueprint.json" \
  --intake-report "$JOB/E3_intake_report.json" \
  --runtime-evidence-receipt "$JOB/03_runtime_evidence/receipt.json" \
  --scope-analysis "$JOB/00_input/scope_analysis.json" \
  --pattern-registry "$JOB/reference/shared/content-pattern-registry.json" \
  --monitoring-input "$JOB/01_monitoring/E2_${JOB_ID}_monitoring_input.json" \
  --report "$JOB/05_content/E5_${JOB_ID}_validation.json"
```

基础启动省略 `--monitoring-input`。

## E6 证据、事实和比较预检

证据编辑先按照 [E6 语义复核 Schema](Execution_Workflow/E6.证据预检师.skill/templates/evidence_semantic_review.schema.json) 逐一核对正文实际使用 claim，并生成 hash-bound `E6_${JOB_ID}_semantic_review.json`。P01-M 还必须准备共同维度、对象和来源精确绑定的 competitor matrix；P01-S 禁止提供 matrix。

```bash
mkdir -p "$JOB/06_evidence"
"$PYTHON" -B "$WF/Execution_Workflow/E6.证据预检师.skill/scripts/evidence_preflight.py" \
  --model "$JOB/05_content/E5_${JOB_ID}_content_model.json" \
  --blueprint "$JOB/04_blueprint/E4_${JOB_ID}_article_blueprint.json" \
  --claims "$JOB/03_runtime_evidence/claim_registry.json" \
  --sources "$JOB/03_runtime_evidence/source_registry.json" \
  --pattern-registry "$JOB/reference/shared/content-pattern-registry.json" \
  --content-job "$JOB/00_input/content_job.json" \
  --intake-report "$JOB/E3_intake_report.json" \
  --runtime-evidence-receipt "$JOB/03_runtime_evidence/receipt.json" \
  --semantic-review "$JOB/06_evidence/E6_${JOB_ID}_semantic_review.json" \
  --base-package-root "$JOB/reference" \
  --job-package-root "$JOB" \
  --monitoring-input "$JOB/01_monitoring/E2_${JOB_ID}_monitoring_input.json" \
  --output "$JOB/06_evidence/E6_${JOB_ID}_evidence_report.json"
```

P01-M 增加 `--competitor-matrix /absolute/job/path/to/matrix.json`；基础启动省略 Monitoring。第一方资料可支持本品牌事实，但不能单独推出口碑、客观排名、竞品优劣或领先。E6 允许 `passed_with_claim_limits`，前提是越界主张已经删除或限缩且核心问题仍被回答；无法诚实回答时才 `blocked`。

## E7 视觉选择与制作

按 [E7 Skill](Execution_Workflow/E7.视觉论证与资产生产师.skill/SKILL.md) 恢复旧视觉生产顺序：先匹配真实企业资产，再生成允许生成的品牌编辑、导航或解释性视觉；保留权利、Logo、哈希、尺寸、路径和事实冒充安全层。

视觉功能为：

- `brand_editorial` / `navigate`：可无 claim，不算证据；
- `explain`：可绑定章节概念，claim 可选；
- `prove`：必须绑定通过 E6 的 claim/source。

用 `aigc_invoker.py`、`image_dedup_checker.py` 按需生产并登记资产后，生成物化视觉后的 Content Model 和 draft manifest，再执行统一硬门：

```bash
mkdir -p "$JOB/07_visual"
"$PYTHON" -B "$WF/Execution_Workflow/E7.视觉论证与资产生产师.skill/scripts/visual_claim_validator.py" \
  --model "$JOB/07_visual/E7_${JOB_ID}_content_model.json" \
  --blueprint "$JOB/04_blueprint/E4_${JOB_ID}_article_blueprint.json" \
  --manifest "$JOB/07_visual/E7_${JOB_ID}_visual_manifest.draft.json" \
  --claims "$JOB/03_runtime_evidence/claim_registry.json" \
  --sources "$JOB/03_runtime_evidence/source_registry.json" \
  --evidence "$JOB/06_evidence/E6_${JOB_ID}_evidence_report.json" \
  --images "$JOB/03_runtime_images/image_registry.json" \
  --base-images "$JOB/reference/registries/image_registry.json" \
  --runtime-registry-receipt "$JOB/03_runtime_images/receipt.json" \
  --base-package-root "$JOB/reference" \
  --job-package-root "$JOB" \
  --report "$JOB/07_visual/E7_${JOB_ID}_validation.json" \
  --validated-manifest "$JOB/07_visual/E7_${JOB_ID}_visual_manifest.json"
```

## E8 编辑终审与安全正本

```bash
mkdir -p "$JOB/08_editorial"
"$PYTHON" -B "$WF/Execution_Workflow/E8.编辑终审师.skill/scripts/editorial_audit.py" \
  --model "$JOB/07_visual/E7_${JOB_ID}_content_model.json" \
  --evidence "$JOB/06_evidence/E6_${JOB_ID}_evidence_report.json" \
  --visuals "$JOB/07_visual/E7_${JOB_ID}_visual_manifest.json" \
  --blueprint "$JOB/04_blueprint/E4_${JOB_ID}_article_blueprint.json" \
  --claims "$JOB/03_runtime_evidence/claim_registry.json" \
  --sources "$JOB/03_runtime_evidence/source_registry.json" \
  --pattern-registry "$JOB/reference/shared/content-pattern-registry.json" \
  --image-registry "$JOB/03_runtime_images/image_registry.json" \
  --semantic-review "$JOB/06_evidence/E6_${JOB_ID}_semantic_review.json" \
  --intake-report "$JOB/E3_intake_report.json" \
  --runtime-evidence-receipt "$JOB/03_runtime_evidence/receipt.json" \
  --monitoring-input "$JOB/01_monitoring/E2_${JOB_ID}_monitoring_input.json" \
  --report "$JOB/08_editorial/E8_${JOB_ID}_quality_report.json" \
  --safe-output "$JOB/08_editorial/E8_${JOB_ID}_editorial_master.json" \
  --sha-output "$JOB/08_editorial/E8_${JOB_ID}_editorial_master.sha256"
```

基础启动省略 Monitoring。E8 正本是任何 AutoGEO 失败时的完整回退基线。

## E9 AutoGEO 独立候选

输出目录必须全新，候选不得覆盖 E8：

```bash
"$PYTHON" -B "$WF/Execution_Workflow/E9.AutoGEO候选优化师.skill/scripts/autogeo_candidate_optimizer.py" \
  --e8-model "$JOB/08_editorial/E8_${JOB_ID}_editorial_master.json" \
  --e8-sha "$JOB/08_editorial/E8_${JOB_ID}_editorial_master.sha256" \
  --e8-quality "$JOB/08_editorial/E8_${JOB_ID}_quality_report.json" \
  --content-job "$JOB/00_input/content_job.json" \
  --claims "$JOB/03_runtime_evidence/claim_registry.json" \
  --evidence "$JOB/06_evidence/E6_${JOB_ID}_evidence_report.json" \
  --output-dir "$JOB/09_autogeo" \
  --candidate "$JOB/09_autogeo/candidate.json" \
  --diff "$JOB/09_autogeo/diff.json" \
  --report "$JOB/09_autogeo/report.json"
```

AutoGEO 不可用时只会生成 skip report；不允许同义词全局替换或第二个 LLM 冒充优化器。

## E10 回归选稿、标题数量暂停与无标题交付

先选择最终正文。AutoGEO 成功时传 candidate/diff；skip 时省略这两个可选参数：

```bash
mkdir -p "$JOB/10_delivery"
"$PYTHON" -B "$WF/Execution_Workflow/E10.回归选稿与双格式交付师.skill/scripts/regression_review.py" \
  --e8-model "$JOB/08_editorial/E8_${JOB_ID}_editorial_master.json" \
  --e8-sha "$JOB/08_editorial/E8_${JOB_ID}_editorial_master.sha256" \
  --e8-quality "$JOB/08_editorial/E8_${JOB_ID}_quality_report.json" \
  --e9-report "$JOB/09_autogeo/report.json" \
  --e9-diff "$JOB/09_autogeo/diff.json" \
  --candidate "$JOB/09_autogeo/candidate.json" \
  --claims "$JOB/03_runtime_evidence/claim_registry.json" \
  --sources "$JOB/03_runtime_evidence/source_registry.json" \
  --evidence "$JOB/06_evidence/E6_${JOB_ID}_evidence_report.json" \
  --pattern-registry "$JOB/reference/shared/content-pattern-registry.json" \
  --blueprint "$JOB/04_blueprint/E4_${JOB_ID}_article_blueprint.json" \
  --intake-report "$JOB/E3_intake_report.json" \
  --runtime-evidence-receipt "$JOB/03_runtime_evidence/receipt.json" \
  --monitoring-input "$JOB/01_monitoring/E2_${JOB_ID}_monitoring_input.json" \
  --approved "$JOB/10_delivery/E10_${JOB_ID}_approved_body.json" \
  --audit "$JOB/10_delivery/E10_${JOB_ID}_regression.json"
```

基础启动省略 Monitoring。候选只有在实体、数字、价格、日期、claim/source、FAQ、限制、适用条件、比较对象和视觉关系全部不变时才自动成为正本；任一漂移整篇回退 E8，禁止段落混拼。

### 必须暂停：询问标题数量

此时向用户提问：

> 这篇文章需要生成多少个标题选项？请输入 1–20。

未收到整数时保持 `awaiting_title_count`，不能默认 5。收到用户回答后：

```bash
TITLE_COUNT=5
"$PYTHON" -B "$WF/Execution_Workflow/E10.回归选稿与双格式交付师.skill/scripts/create_title_count_receipt.py" \
  --approved-body "$JOB/10_delivery/E10_${JOB_ID}_approved_body.json" \
  --count "$TITLE_COUNT" \
  --requested-by 'user' \
  --output "$JOB/10_delivery/E10_${JOB_ID}_title_count_receipt.json"
```

按 [Title Map Schema](shared/title_map.schema.json) 生成恰好 N 个去重标题，保存为 `$JOB/10_delivery/E10_${JOB_ID}_title_map.json`，再运行正文、claim、实体、数字、日期和客观排名校验：

```bash
"$PYTHON" -B "$WF/shared/scripts/validate_title_map.py" \
  "$JOB/10_delivery/E10_${JOB_ID}_title_map.json" \
  "$JOB/10_delivery/E10_${JOB_ID}_title_count_receipt.json" \
  --content-model "$JOB/10_delivery/E10_${JOB_ID}_approved_body.json" \
  --claim-registry "$JOB/03_runtime_evidence/claim_registry.json" \
  --brand-facts "$JOB/reference/brand/brand_facts.json"
```

最后，公开目录和内部审计目录都必须是全新空目录；不要预先放入任何旧稿：

```bash
"$PYTHON" -B "$WF/Execution_Workflow/E10.回归选稿与双格式交付师.skill/scripts/render_delivery.py" \
  --model "$JOB/10_delivery/E10_${JOB_ID}_approved_body.json" \
  --regression "$JOB/10_delivery/E10_${JOB_ID}_regression.json" \
  --e8-model "$JOB/08_editorial/E8_${JOB_ID}_editorial_master.json" \
  --e8-quality "$JOB/08_editorial/E8_${JOB_ID}_quality_report.json" \
  --e9-report "$JOB/09_autogeo/report.json" \
  --claims "$JOB/03_runtime_evidence/claim_registry.json" \
  --sources "$JOB/03_runtime_evidence/source_registry.json" \
  --evidence "$JOB/06_evidence/E6_${JOB_ID}_evidence_report.json" \
  --evidence-semantic-review "$JOB/06_evidence/E6_${JOB_ID}_semantic_review.json" \
  --title-count-receipt "$JOB/10_delivery/E10_${JOB_ID}_title_count_receipt.json" \
  --title-map "$JOB/10_delivery/E10_${JOB_ID}_title_map.json" \
  --pattern-registry "$JOB/reference/shared/content-pattern-registry.json" \
  --blueprint "$JOB/04_blueprint/E4_${JOB_ID}_article_blueprint.json" \
  --intake-report "$JOB/E3_intake_report.json" \
  --runtime-evidence-receipt "$JOB/03_runtime_evidence/receipt.json" \
  --monitoring-input "$JOB/01_monitoring/E2_${JOB_ID}_monitoring_input.json" \
  --brand-facts "$JOB/reference/brand/brand_facts.json" \
  --visual-manifest "$JOB/07_visual/E7_${JOB_ID}_visual_manifest.json" \
  --image-registry "$JOB/03_runtime_images/image_registry.json" \
  --base-image-registry "$JOB/reference/registries/image_registry.json" \
  --runtime-image-receipt "$JOB/03_runtime_images/receipt.json" \
  --base-package-root "$JOB/reference" \
  --job-package-root "$JOB" \
  --output-dir "$JOB/10_delivery/public" \
  --internal-audit-dir "$JOB/10_delivery/internal_audit"
```

基础启动省略 Monitoring。需要 Product/Review/ItemList 结构化数据时，另传经过 hash 绑定且正文可见的 `--structured-data-context`；不得注入正文没有的价格、评分或声明。

公开交付目录固定包含：

```text
article_body.docx
article_body.html
title_options.md
title_map.json
publishing_metadata_map.json
structured_data_template.json
images/*                 # 仅实际使用时
delivery_manifest.json
```

DOCX 从微型答案开始，无 Title；HTML 是无 H1 的 `<article>` 正文片段。标题只在独立标题资产中，不反向写入 Content Model。

---

# 4. 什么时候回到哪一阶段

| 发生变化 | 回到 | 不允许的捷径 |
|---|---|---|
| 企业原始事实、产品、正式价格、Logo、长期图库或公开授权 | 对应 S2/S4/S6，并重新 S8、S9 | 修改已签名 Pack |
| 趋势资料更新 | S3，并重新 S8、S9 | 在正文直接加入未登记趋势 |
| 本篇问题或 P01 单/多选择变化 | 新建 E job，从 E1 开始 | 复用旧 blueprint/receipt |
| 本篇监控答案、信源或标杆变化 | E2 起向后重跑 | 只替换 Monitoring JSON |
| 单篇补证或补图变化 | E3 起向后重跑 | 改 base Registry |
| 正文事实、FAQ 或结构变化 | E5 起向后重跑 | 复用旧 E6/E8 回执 |
| 视觉变化 | E7 起向后重跑 | 复用旧视觉 hash |
| AutoGEO 候选变化 | E9、E10 | 手工拼接 E8/E9 段落 |
| 标题数量变化 | 重新生成 E10 count receipt、Title Map 和交付 | 修改已签 Title Map 数组 |

# 5. 发布前全局验证

从 Workflow 根目录运行：

```bash
"$PYTHON" -B "$WF/scripts/validate_workflow.py"
"$PYTHON" -B "$WF/shared/scripts/check_cross_references.py" "$WF"
"$PYTHON" -B "$WF/shared/scripts/validate_package.py" "$WF/shared/fixtures/minimal_reference_pack"
"$PYTHON" -B "$WF/shared/pattern-research/validate_pattern_research.py"
```

最终发布包必须无客户资料、绝对本机路径、缓存、符号链接和临时测试文件；活动流程中只允许 S1–S9、E1–E10 编号。迁移矩阵和非活动兼容区可保留旧编号用于审计，但绝不能作为运行输入。
