# FrontMind 内容资料工作流（S1–S9）

策略层只做一件事：把企业资料与图库加工成执行层可直接消费、逐项有来源、已经负责人确认的 `Reference Pack`。问题或 `foundation_start` 任务由工作流外确定；本层不做广域选题、AI 可见度监测、CMS 发布、业务行动规划或文章正文。

完整命令以包根 [运行手册](../RUNBOOK.md) 为唯一入口；本页只解释阶段职责与交接价值，不复制参数契约。

## 连续主流程

`S1 → S2 → S3（可选）→ S4 → S5 → S6 → S7 → S8 → S9`

| 阶段 | 内容生产职责 | 主要机器产物 |
|---|---|---|
| S1 | 验收已有 canonical KB；散乱资料先经原样 legacy S1 与既有 KB Builder 汇入同一入口 | canonical KB intake receipt |
| S2 | 将 KB 与图库标准化为稳定、可追溯对象 | knowledge/source/claim/image registries、adapter report |
| S3 | 可选补充会改变文章论证或刷新时间的新鲜趋势 | trend reference 或明确 skip 状态 |
| S4 | 组织受众决策、价值结构、差异化证据、品牌优先角度与声明边界 | information/evidence architecture、canonical brand facts |
| S5 | 把品牌原始语言转成逐句可检查的写作契约 | voice contract |
| S6 | 把真实品牌资产、图库权利和解释性视觉规则工程化 | visual reference |
| S7 | 建立 30–50 个有来源的问题与 FAQ 回答边界 | question library |
| S8 | 负责人集中确认事实、话语、问题和视觉边界 | confirmation workbook、approval receipt |
| S9 | 哈希绑定全部已批准资产并构造自包含交接包 | `S9_{brand_label}_reference_pack_v{N}.zip` |

总控编排属于包根运行手册，不占用策略阶段编号。旧 S1 完整目录位于 `compatibility/legacy-s1/`，只供 S1 的散乱资料分支调用，保持字节不变，不是活动节点。

## 公共契约

- 合法正式资料入口是 `schemaVersion=4`、`profile=dashboard-enterprise-v1` 的 canonical KB 原始 ZIP。
- 每个 S2 source 必须进入显式授权状态机：`first_party_official/first_party_internal/third_party_public/runtime_approved`；内部第一方不能被自动升级为公开来源。
- 四个问题型入口与工程师显式启动的 `foundation_start` 统一来自包根 `shared/content-pattern-registry.json`；策略产物使用字段 `entry_category`。
- `foundation_start` 只连接 P13；P01 的单品牌/多品牌 variant 也完全读取根 registry。策略层不得复制或改写这些路由。
- S4 的 Information/Evidence Architecture 以包根 schema 为唯一结构源；策略层只保留方法模板与语义 validator。
- S3 是唯一可选阶段；S8 未严格批准，S9 不得打包。
- S9 同时携带 `shared/content-pattern-registry.json` 和 `shared/pattern-research/index.json`，Reference Pack profile 固定为 v2。
- S4 公共产物固定落在 `writing/information_evidence_architecture.json`，Pack 字段/文件 role 均为 `information_evidence_architecture`，不保留旧 `positioning` 别名。

## 标准项目目录

```text
{brand_label}/
  S1/
  S2/
  S3/                  # 可缺失或保存 skip 状态
  S4/
  S5/
  S6/
  S7/
  S8/
  S9/
  ReferencePack/
```

Reference Pack 不是把阶段报告拼成长文。执行层按 ID 读取对象，并在 brief、正文、FAQ 与视觉说明中回写实际消费的 `source_id`、`claim_id`、`asset_id`、`question_id`、`angle_id` 与 `pattern_id`。
