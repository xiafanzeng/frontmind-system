---
name: frontmind-canonical-kb-intake
description: S1 企业资料与 canonical KB 接入师。已有合法 canonical KB v4 时直接验收；只有散乱企业资料时，先调用 compatibility 中原样保留的 legacy S1，再经既有 KB Builder 生成 canonical KB，最终统一输出可审计的 S1 接入回执。
---

# S1 企业资料与 canonical KB 接入师

## 1. 唯一目标

为连续的 S1–S9 内容资料流程建立一个明确入口。S1 不重新发明知识库，不生成选题，也不允许把 legacy S1 的事实图谱直接伪装成 canonical KB。

两条入口最终必须汇合到同一条件：一个原始 ZIP，包内恰好存在一份 `00_package_manifest.json`，并满足
`schemaVersion=4`、`profile=dashboard-enterprise-v1`，同时存在 `00_source_index.md` 与 `00_knowledge_tree.md`。

## 2. 接入分支

### A. 已有 canonical KB

直接使用 `source_mode=existing_canonical_kb` 运行 `scripts/canonical_kb_intake.py`。不得重复运行 legacy S1，也不得重新打包或改名原 ZIP。

### B. 只有散乱企业资料

1. 只读调用 `../compatibility/legacy-s1/`；该目录是 byte-identical 兼容资产，不属于活动编号，也不得编辑。
2. 将 legacy S1 产物交给既有 KB Builder。
3. KB Builder 完成 manifest、source index、knowledge tree 与原始 ZIP 后，以
   `source_mode=legacy_s1_then_builder` 运行本阶段，并同时提供 builder receipt。

legacy S1 输出本身不是 S2 输入。S2 只接受通过本阶段验收的 canonical KB 原始 ZIP。

## 3. 标准命令

已有 KB：

```bash
python3 -B scripts/canonical_kb_intake.py \
  --brand "品牌正式名称" \
  --kb /absolute/path/to/canonical-kb-v4.zip \
  --source-mode existing_canonical_kb \
  --output /absolute/path/to/project/S1/S1_brand_label_canonical_kb_intake.json
```

legacy S1 + KB Builder 路径：

```bash
python3 -B scripts/canonical_kb_intake.py \
  --brand "品牌正式名称" \
  --kb /absolute/path/to/canonical-kb-v4.zip \
  --source-mode legacy_s1_then_builder \
  --legacy-s1-dir ../compatibility/legacy-s1 \
  --builder-receipt /absolute/path/to/kb-builder-receipt.json \
  --output /absolute/path/to/project/S1/S1_brand_label_canonical_kb_intake.json
```

## 4. 输出与硬失败

唯一机器产物为 `S1_{brand_label}_canonical_kb_intake.json`，满足
`templates/canonical_kb_intake.schema.json`。回执记录 KB 文件名、字节数、SHA256、manifest 位置、文档/资产数量和接入来源；不保存绝对本机路径。

以下任一情况硬失败：

- 输入不是 ZIP、存在重复路径、绝对路径或 `..` 路径逃逸；
- manifest 不唯一，或版本/profile 不符；
- source index、knowledge tree 或 manifest 声明的文档/资产缺失；
- 选择 legacy 分支却未提供 legacy S1 目录或 KB Builder receipt；
- 试图用 legacy S1 事实图谱直接进入 S2。

S1 通过后进入 S2；本阶段不修改 canonical KB，不写文章，不做趋势、定位、FAQ、监控或发布动作。
