---
name: frontmind-reference-material-adapter
description: S2 将 S1 已验收的 canonical knowledge base v4 与可选 legacy 补充、客户图库统一成 v2 knowledge/source/claim/image registries，保留证据精度、内容状态、发布授权与图片权利边界。
---

# S2 资料标准化适配器

## 唯一目标

把 S1 已验收的资料变成所有后续内容阶段唯一使用的稳定对象。S2 不增强事实、不创造卖点、不把企业自述升级为第三方结论；只做兼容、稳定 ID、去重、来源绑定、证据状态与权利边界。

## 输入

必需：

- S1 接入回执；
- 与回执 SHA-256 完全一致的 canonical KB v4 原始 ZIP（`schemaVersion=4`、`profile=dashboard-enterprise-v1`）。

可选：

- `compatibility/legacy-s1` 形成的品牌事实图谱、视觉资产清单与物理文件；
- 客户另行上传的品牌图库。

已解压目录仅供本地诊断，不能进入正式 S9 构包。旧 flat/legacy 包只能隔离，不能伪装为 v4。

## 执行

先读 `references/registry-contract.md`，再运行：

```bash
python3 -B scripts/kb_v4_adapter.py \
  --brand "品牌正式名称" \
  --kb "/path/to/canonical-kb-v4.zip" \
  --s1-facts "/path/to/legacy/S1_品牌事实图谱.json" \
  --s1-visual-manifest "/path/to/legacy/S1_视觉资产清单.json" \
  --s1-assets-root "/path/to/legacy/visual_assets" \
  --gallery "/path/to/client-gallery" \
  --output-dir "/path/to/project/S2"
```

legacy 与 gallery 参数均可省略。默认 `--legacy-policy quarantine`：没有合法 v4 manifest 的文档进入隔离对象，相关声明固定 `do_not_use`。

### 第一方逐来源发布授权（两次运行）

S2 首次运行会给 canonical KB 中每个自有来源生成稳定 `src_*`，全部先落为 `first_party_internal/internal_only`，同时输出：

- `S2_{brand_label}_source_publication_authorizations.template.json`

工程师必须据此复制为独立的 `source_publication_authorizations.json`，按照 `templates/source_publication_authorizations.schema.json` 为每个且仅每个候选 `source_id` 填写 `public_approved`、`anonymized_approved` 或 `internal_only`，并填写审核人、角色、带时区的审核时间、授权依据与证据引用。然后从原始 S1 输入重新运行 S2：

```bash
python3 -B scripts/kb_v4_adapter.py \
  --brand "品牌正式名称" \
  --kb "/path/to/canonical-kb-v4.zip" \
  --publication-authorizations "/path/to/source_publication_authorizations.json" \
  --output-dir "/path/to/project/S2"
```

授权文件采用 exact-set：漏掉一个第一方候选、重复/伪造 ID、加入第三方或 legacy S1 来源、品牌不一致、匿名授权无脱敏确认，均整批失败且不提升任何来源。`internal_only` 是合法的显式决定；只有 canonical KB 自有来源可被提升为 `first_party_official + public_approved/anonymized_approved`。授权摘要与授权文件 SHA-256 写入 adapter report，最终 source registry 记录逐来源审核轨迹。

## 输出

- `S2_{brand_label}_knowledge_registry.json`
- `S2_{brand_label}_source_registry.json`
- `S2_{brand_label}_claim_registry.json`
- `S2_{brand_label}_image_registry.json`
- `S2_{brand_label}_adapter_report.json`
- `S2_{brand_label}_source_publication_authorizations.json`（仅在合规授权文件成功应用后生成，原字节留存）
- `S2_{brand_label}_source_publication_authorizations.template.json`（待填写模板，不是审批凭证）
- `assets/` 与 `sources/`：经哈希核验、可随包携带的物理资产。

所有 registry `schema_version=2.0.0`，且以包根 `shared/registries.schema.json` 为唯一结构契约。`brand_label` 只用于路径；正文对象始终保存正式品牌名。

## 强制语义规则

1. 上游 `evidenceStatus/contentStatus/evidence_precision` 必须保留；`verified_first_party` 不能自动变成独立客观事实。
2. 声明使用 `verification_status` 与 `allowed_usage` 双门：只有 exact/claim 级且已验证的证据才可 `public_fact`。
3. 每个来源必须写 `source_origin_class`：仅允许 `first_party_official`、`first_party_internal`、`third_party_public` 或 `runtime_approved`。官网标签、canonical KB 接入、客户/项目记录都不等于发布授权；未逐来源授权时统一为 `first_party_internal/internal_only`。`first_party_official` 只允许 `public_approved/anonymized_approved`，`first_party_internal` 只允许 `internal_only`；未经授权的 legacy 补充资料不得伪装成正式公开来源。
4. 第一方资料可支持本品牌身份、产品、规格、能力、价格、政策、事件和限制，但不能单独证明排名、市场口碑、竞品优劣或行业领先。
5. 图片只能使用根契约权利状态；`approved_with_credit` 必须保留署名文字。Logo 必须同时满足 `asset_kind=logo` 与 `allowed_roles` 含 `entity_proof`。
6. 二进制文件按 SHA-256 去重；包内路径必须相对、安全且实际存在。绝对本机路径不得写入任何产物。
7. supplemental 引用文件复制到安全相对路径，Source Registry 不得留下悬空证据。
8. 哈希不符、路径逃逸、非法授权或缺失文件写入 adapter report；严重问题非零退出。

## 交接门

进入 S3/S4 前确认：四 registry 通过根 schema；ID 采用 `kn_/src_/clm_/img_`；adapter report 的 `publication_authorizations.status` 与项目决定一致；所有公开声明都有真实且已授权来源；所有可用图片有权利依据；`fatal_errors=[]` 且 `formal_handoff_ready=true`。

后续阶段只引用 registry ID。需要原文时通过 `package_path/file_path` 回到材料，不复制一套失去 provenance 的文本。
