---
name: frontmind-content-trend-reference
description: S3 可选研究会实质改变当前文章论证、段落位置或刷新时间的品类趋势，输出 v2、有来源的 trend reference；无可靠信号时明确跳过，不阻断 S4。
---

# S3 内容趋势参考

## 目标

只回答“哪些外部变化会影响这次内容怎么论证、放在哪一段、何时刷新”。不做宏大趋势报告、不发现选题、不凑固定数量，也不把单一媒体转述当事实。

## 输入

- S2 knowledge/source/claim registries；
- S1 canonical KB intake receipt；
- 包根 `shared/content-pattern-registry.json`；
- 明确品类、目标地域与观察时间窗。

S3 不决定品牌定位或文章模式，只为后续资料包补充时效参考。`foundation_start` 也可接收企业发展所处行业背景，但趋势不能反向证明企业能力。

## 是否运行

满足任一条件才运行：近期政策/标准改变，技术或产品能力发生可验证变化，用户需求/语言发生实质变化，或内容必须解释“为什么现在”。否则输出 v2 skip 状态：

```json
{"schema_version":"2.0.0","status":"skipped_not_needed","reason":"...","trends":[]}
```

无可靠信号用 `skipped_no_reliable_signal`，继续 S4。

## 研究方法

1. 读 `references/trend-frameworks.md` 与 `references/signal-source-list.md`，优先原始、监管、标准或权威研究来源。
2. 先写可证伪的候选句，再找材料；记录发生时间、发布时间、地域与来源定位。
3. 一般趋势至少两个独立来源；法规、标准或论文原文可单源，但标 `primary_authoritative`。
4. 每条趋势连接 S2 的 `source_ids/knowledge_ids`，并用 `entry_category_refs` 与 `pattern_refs` 引用根 registry。
5. 说明是否采用、建议段落、影响方式与刷新条件；不得据此扩展新选题。

## 输出与校验

- `S3_{brand_label}_trend_reference.json`
- `S3_{brand_label}_内容趋势参考.md`

```bash
python3 -B scripts/signal_aggregator.py \
  --validate S3_brand_label_trend_reference.json \
  --knowledge-registry S2_brand_label_knowledge_registry.json \
  --source-registry S2_brand_label_source_registry.json \
  --pattern-registry /path/to/package/shared/content-pattern-registry.json
```

每条趋势必须包含 statement、what_changed、observed_at、region、来源、证据精度、confidence、content_impact、freshness_rule 与有效根 registry 引用。来源不存在、无时间地域、把相关写成因果或没有内容影响时阻断。

S3 不输出正文、FAQ 答案、选题排期或发布计划。
