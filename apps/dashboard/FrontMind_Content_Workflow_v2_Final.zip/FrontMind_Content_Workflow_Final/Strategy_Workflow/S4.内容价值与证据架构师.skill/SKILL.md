---
name: frontmind-content-value-evidence-architect
description: S4 将 S2 品牌事实、受众决策情境与可用证据组织成文章可直接消费的 v2 信息/价值/证据架构；输出定位锚点、三层价值结构、差异化证据地图、品牌优先角度、proof bundles 与声明边界。
---

# S4 内容价值与证据架构师

## 唯一目标

回答六件事：写给谁、发生在哪个决策时刻、品牌能提供什么价值、真正与替代方案有什么差异、每个说法拿什么证明、正文最多能说到什么强度。输出必须能进入单篇 brief、正文论证或事实检查，而不是抽象品牌战略报告。

## 输入

必需：

- S2 knowledge/source/claim registries；
- 包根 `shared/content-pattern-registry.json`。

可选：S3 trend reference；客户对目标市场、决策角色与禁区的明确说明；经 S2 纳入并保留来源状态的 legacy 补充。

先读：

- `references/audience-decision-context-method.md`：角色—场景—任务—决策标准；
- `references/positioning-frameworks.md`：定位锚点与价值结构；
- `references/competitive-analysis-method.md`：对称、可核验的比较；
- `references/evidence-boundaries.md`：声明强度、时点与第一方来源边界。

## 工作步骤

### 1. 受众决策情境

以 `角色 × 触发事件 × 任务 × 约束 × 决策标准` 建立 3–8 个 context，区分使用者、影响者、技术/合规把关者和最终决策者。每项连接 S2 `knowledge_ids/source_ids` 并标 `validated/client_asserted/hypothesis`。

### 2. 定位锚点

输出目标受众、品类/使用情境、品牌在决策中的 `brand_role`、差异化价值与 reasons to believe。没有比较证据时只能写品牌选择或能力描述，不写“唯一、第一、最佳、领先”。

### 3. 三层价值结构

深度借鉴旧 S4 的价值三角，但改成可执行对象：

- `functional`：具体解决什么问题、带来什么可核验结果；
- `emotional`：在什么条件下带来何种感受，只能事实支持或明确归因于品牌表达；
- `self_expression`：选择该方案代表什么决策身份，证据不足时只能标研究假设。

每个 `value_id` 必须连接受众 context、proof refs、`expression_mode`、可用措辞与不得暗示的结论。不能为了填满三层而发明价值。

### 4. 差异化证据地图

不再生成主观“竞品价值曲线”。逐个记录维度定义、相对对象/替代路径、品牌表现、适用条件、地域/版本范围、claim/source/proof refs、是否允许比较、证据缺口、时点与 `supported/qualified/unsupported`：

- `supported` 只能使用 `public_fact` proof；
- `qualified` 必须保存限定措辞；
- `unsupported` 只进入补证清单，不能进入正文。

每个 proof 的 `source_ids` 必须真实属于它引用的 `claim_ids`；公开使用的第一方来源必须有可发布 `publication_authorization`。竞品资料采用相同维度、相同时间点和相同证据门。

### 5. 品牌优先角度

从价值与差异化中提炼 1–6 个 `brand_priority_angles`，供执行层在已确定任务内选择品牌最值得强调的论证角度。每项连接触发条件、context、value、differentiation、proof、适用 `entry_category` 与 `eligible_pattern_ids`；它不是新选题、排期或标题清单。

### 6. 信息支柱与 Proof Bundles

每个 message pillar 写核心信息、服务情境、proof refs、适用 pattern refs 和禁止越界表述。Proof Bundle 固定链路为：

`statement → claim_ids → claim所属source_ids/locator → evidence_precision → verification_status/allowed_usage → allowed_wording/necessary_qualification → caveat → applicable_patterns`

第一方资料能证明“企业如何公开表述与提供什么”，不能单独证明排名、市场口碑或竞品优劣。

### 7. 五入口指导但不提前选模式

`entry_tone_guidance` 必须覆盖根 registry 五个入口，字段名固定 `entry_category`。前四个问题型入口沿用用户的四大类；`foundation_start` 是工程师显式启动的品牌基础特写，只能按根 registry 路由 P13，不要求外部问题或监控。

P01 的 `multi_brand_editorial_recommendation` 与 `single_brand_recommendation` 也只引用根 registry：S4 提供候选/比较证据和品牌优先角度，不复制 variant 结构，不在本阶段选择。

### 8. Canonical Brand Facts

同步生成 `S4_{brand_label}_brand_facts.json`，严格符合包根 `shared/brand_facts.schema.json`。`brand_identity/positioning/offerings/capabilities/proof_points/limitations` 只能来自 S2 `src_/clm_`；缺失 required 事实必须补资料或缩窄表达，不能用 TBD 冒充。

## 输出

- `S4_{brand_label}_information_evidence_architecture.json`
- `S4_{brand_label}_brand_facts.json`
- `S4_{brand_label}_内容价值与证据架构.md`

Information/Evidence Architecture 的唯一 JSON Schema 位于包根 `shared/information_evidence_architecture.schema.json`；本阶段模板只提供人审结构，不维护第二份 schema。

## 校验

```bash
python3 -B scripts/information_evidence_validator.py \
  S4_brand_label_information_evidence_architecture.json \
  --brand-facts S4_brand_label_brand_facts.json \
  --knowledge-registry S2_brand_label_knowledge_registry.json \
  --claim-registry S2_brand_label_claim_registry.json \
  --source-registry S2_brand_label_source_registry.json \
  --pattern-registry /path/to/package/shared/content-pattern-registry.json
```

核心信息无 proof、proof source 不属于 claim、第一方来源未获发布授权、差异结论强度超过证据、priority angle 无 value/proof、入口覆盖不全或 brand facts 使用未知 ID，均阻断。
