# {{brand}} 内容价值与证据架构

## 1. 使用边界

- 版本与日期：
- 主要输入哈希：
- S3 状态：已使用 / 未运行 / 无可靠信号
- 仍需客户确认：

## 2. 定位锚点

| 要素 | 内容 | Claim/Proof refs | 表达边界 |
|---|---|---|---|
| 目标受众 |  |  |  |
| 品类/使用情境 |  |  |  |
| 品牌角色 |  |  |  |
| 差异化价值 |  |  |  |
| Reasons to believe |  |  |  |

## 3. 受众决策情境

每个情境写：角色、触发、任务、约束、决策标准、资料来源与假设状态。

## 4. 价值结构

分别记录功能价值、情感价值与自我表达价值。每个可用价值必须写受众情境、proof refs、可用措辞和不得暗示的结论；没有证据的情感或身份表达应明确标为研究假设，不得进入正文。

## 5. 差异化证据地图

| ID | 维度定义 | 相对对象/替代方案 | 品牌表现与适用范围 | Evidence state / comparison allowed | Claim/Source/Proof refs | 可用措辞/证据缺口 | 截止时间 |
|---|---|---|---|---|---|---|---|

同时写明每项不得推断的“领先、唯一、最佳”等结论。`unsupported` 项只进入补证清单，不进入正文。

## 6. 信息支柱

每个支柱写：核心信息、服务情境、需要解释的实体/机制、proof bundle、共享 pattern refs、禁止越界表述。

每个品牌优先角度另写触发条件、eligible entries/patterns、value/differentiation/proof refs 与不得宣称事项。

## 7. Proof Bundles

| ID | Statement / Claim IDs | 来源定位 | 证据精度 | 可用措辞 / 必要限定 | Applicable patterns / 时点 |
|---|---|---|---|---|---|

## 8. 比较边界

- 可比较维度：
- 必须使用的来源与时点：
- 禁止推断：

## 9. 五入口决策口吻

| Entry category | Decision tone | Must consume | Proof minimum | Candidate pattern refs | Avoid |
|---|---|---|---|---|---|

可选补充 publication form（objective article/news/technical 等）的文体规则，但不建立新的运行时分类。

`foundation_start` 是工程师显式启动入口，只按共享 registry 的 P13 路由处理，不在此复制其结构规则。

## 10. 缺口与未决项

只记录会影响文章正确性、可信度或决策价值的缺口。
