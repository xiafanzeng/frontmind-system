---
name: frontmind-article-voice-contract
description: S5 将品牌原始语言与 S4 内容价值/证据架构转成可注入文章任务的 v2 话语契约，统一术语、语气、证据措辞、竞品比较与五入口文风，不创造口号或无证据卖点。
---

# S5 文章话语契约

## 目标

把“品牌调性”变成逐句可检查的写作规则：术语怎么用、复杂机制怎样解释、何时必须归因、怎样公平比较、什么绝不能说。产物可直接注入执行层写作上下文。

## 输入

- S4 information/evidence architecture（含价值、差异化与 priority angles）；
- S2 knowledge/claim/source registries 中的品牌真实术语、官网文案与声明；
- 包根 `shared/content-pattern-registry.json`。

读 `references/verbal-identity-method.md`，保留语言考古、Tone of Voice、Messaging House 与证据砖方法，但一律受 S4 proof 状态约束。

## 工作步骤

1. 从 S2 抽取品牌真实术语、句式与语气，记录 knowledge/source ID；不自创“像这个行业”的语言。
2. 用句长、主动/被动、解释密度、直接程度、情绪强度与人称写默认语气。
3. 建首选词、允许变体、首次解释与禁用词；每个禁用词写理由。
4. 将 S4 message/value/priority angle 转成 Messaging House，每项保留 proof refs 和允许措辞。
5. 对 `public_fact/public_with_qualification/internal_only/do_not_use` 分别定义允许句型与禁止转换。
6. 竞品比较必须服从 S4 差异化证据地图：同维度、同时间、有来源；证据不足时只讲选择标准。
7. `entry_tone_overrides` 用字段 `entry_category` 覆盖根 registry 五入口。`foundation_start` 保持第三方报道距离与事实型品牌特写语气；P01 variants 只引用 ID，不复制结构。

## 输出

- `S5_{brand_label}_voice_contract.json`
- `S5_{brand_label}_文章话语契约.md`

结构见 `templates/article_voice_contract_schema.json` 与 `templates/article_voice_contract_template.md`。

## 注入顺序

```text
S4 事实、价值与证据边界
→ S5 default voice
→ entry_category tone override
→ 可选 publication form override
→ 执行层选择的 pattern/variant
→ 单篇 brief 的受众、问题与视觉约束
```

后层可以更具体，但不能放宽证据与禁止声明。`system_prompt_fragment` 只汇总规则和 ID，不嵌入未经核验的新事实。

## 校验

```bash
python3 -B scripts/article_voice_contract_validator.py \
  S5_brand_label_voice_contract.json \
  --architecture S4_brand_label_information_evidence_architecture.json \
  --pattern-registry /path/to/package/shared/content-pattern-registry.json
```

核心话语无 proof、无归因规则、比较规则无条件放行/禁止点名、五入口缺失、复制根模式枚举或只有“专业可信有温度”等空泛词时阻断。
