---
name: frontmind-article-visual-reference-system
description: S6 将 S2 真实品牌资产与客户图库、S4 论证需求和 S5 话语约束工程化为文章可消费的视觉参考体系；输出权利、稳定ID、解释槽位、prompt scaffold 与验收规则，不直接生成成品图片。
---

# S6 视觉参考体系

## “保留并工程化”

保留旧流程中有价值的真实 Logo、配色、字体、企业实拍、三层视觉符号方法和工具 prompt 语法；工程化是把它们变成每篇文章可调用的结构化对象：`asset_id`、权利状态、允许用途、信息槽位、尺寸、构图、prompt 变量、负面约束与验收门。

## 输入

- S2 image registry（唯一 `img_` ID、哈希、权利与 `asset_kind` 来源）；
- 已由 S2 纳入的客户图库与 legacy 视觉资产；
- S4 message/value/proof/priority angles；
- S5 voice contract；
- 包根 `shared/content-pattern-registry.json`。

先读 `references/visual-symbol-system-method.md` 与 `references/ai-image-tool-prompt-syntax.md`。工具语法不得覆盖品牌事实、论证需求或图片权利。

## 工作步骤

### 1. 资产分诊

- `direct_use`：只限 `approved/approved_with_credit`；
- `overlay_only`：真实 Logo、徽标、认证标识；
- `reference_only`：只提炼抽象色彩/构图原则，不复刻画面；
- `blocked`：不使用。

权利状态来自 S2，S6 不私自升级。`approved_with_credit` 必须把 `attribution_text` 带入图注；无法署名则阻断。

### 2. 品牌约束

记录颜色、字体回退、Logo 安全区、背景、摄影/插画倾向、人物与产品真实性及禁用风格。无正式 VI 时标 `inferred_reference`，不能称官方规范。

### 3. 视觉语法

- 核心识别层：真实 Logo、颜色、品牌形状；
- 叙事符号层：重复构图、隐喻与信息层次；
- 应用层：封面、解释图、流程图、比较图、案例图与图注。

每个 motif 必须说明它解释或证明什么，不能仅作装饰。

### 4. 文章视觉 Pattern

每个视觉模式连接 S4 message/proof/angle 与根 `pattern_refs`，明确封面/正文槽位、直接资产、生成部分、prompt scaffold、negative constraints、alt/caption 与验收标准。S6 自有视觉 ID 不是第二套内容模式。

### 5. Logo 与真实材料

生成模型不得重绘 Logo、认证标识、产品界面文字。`logo_policy.generation_rule=never_generate_or_redraw_logo`，`mode=overlay_real_asset`。Logo 引用必须是 S2 中 `asset_kind=logo` 且允许 `entity_proof` 的真实文件。

## 输出与校验

- `S6_{brand_label}_visual_reference.json`
- `S6_{brand_label}_视觉参考体系.md`

```bash
python3 -B scripts/visual_reference_validator.py \
  S6_brand_label_visual_reference.json \
  --image-registry S2_brand_label_image_registry.json \
  --pattern-registry /path/to/package/shared/content-pattern-registry.json
```

`templates/visual_reference_schema.json` 是结构契约；`scripts/visual_consistency_helper.py` 只做可选色彩/一致性辅助。直接使用权利不明资产、缺署名、Logo 身份不成立、让模型生成 Logo、视觉不对应信息或缺 alt/caption 时阻断。
