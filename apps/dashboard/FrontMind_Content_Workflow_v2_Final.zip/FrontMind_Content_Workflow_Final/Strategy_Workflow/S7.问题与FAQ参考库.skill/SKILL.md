---
name: frontmind-question-faq-reference-library
description: S7 基于 S4 决策/价值/证据、S2 registries、S5 话语与 S6 视觉，建立 30–50 个有 provenance 的问题与 FAQ 参考；使用五入口 entry_category 和候选 pattern ID，只写回答边界，不写完整答案或排期。
---

# S7 问题与 FAQ 参考库

## 目标

把企业事实、受众决策标准、证据缺口与内容模式连接到可复用问题资产。它服务已经确定的问题及 `foundation_start` 品牌特写，不承担广域选题，不生产标准答案。

## 输入

- S4 audience contexts、value structure、brand priority angles、message pillars 与 proof bundles；
- S2 knowledge/source/claim registries；
- S5 voice contract；
- S6 visual reference；
- 可选 S3 trends；
- 包根 `shared/content-pattern-registry.json` 与 guide。

根 registry 是七意图、五入口、产品子意图、P01–P15 与 routing 的唯一源。问题对象字段固定 `entry_category`，只保存 ID。

## 整理方法

先读 `references/faq-question-asset-method.md`、`references/question-path-framework.md` 与 `references/faq-answer-boundary-method.md`。

1. 从 S4 context 的触发、任务、约束与决策标准产生问题种子。
2. 从客户咨询、销售记录、站内搜索、搜索建议、社区讨论与资料原话提取可定位问题；不能获得的渠道不得假称已观察。
3. 从 proof bundle 反推“现有证据能回答什么”，从 research gaps 反推“目前不能可靠回答什么”。
4. 合并同一决策的同义问题，不能靠品牌替换或地区词凑到 30 条。
5. 每题标一个主意图、可选次意图、一个 `entry_category`、候选 `pattern_refs` 与 provenance。
6. `research_hypothesis` 必须给理由，不能伪装真实搜索数据。

## 数量与覆盖

- 总数 30–50；七意图全覆盖，按实际价值分配而非平均。
- 五入口作为参考资产全覆盖。前四类对应普通具体问题；`foundation_start` 只整理品牌身份、能力、方法、限制等可用于 P13 特写的 FAQ，不把它假装成工作流外已确定问题，也不要求监控数据。
- 每个相关 S4 context 至少被一个问题引用；每个核心 proof bundle 至少被一个可回答问题消费，或写明不使用原因。

每题用 `faq_relevance=core/supporting/edge` 说明与当前企业决策问题的关系。它不是优先级、排期或生产顺序。

## FAQ 回答边界

只写：一句 `answer_thesis`、`must_cover`、`proof_refs`、`must_not_claim`、`freshness_rule` 与必要 `visual_pattern_refs`。研究不足或阻断问题不得提供 thesis。

禁止完整答案、FAQPage JSON-LD、页面蓝图、内容日历或制作排期；这些属于单篇执行。

## 输出与校验

- `S7_{brand_label}_question_library.json`
- `S7_{brand_label}_问题与FAQ参考库.md`

```bash
python3 -B scripts/question_library_validator.py \
  S7_brand_label_question_library.json \
  --pattern-registry /path/to/package/shared/content-pattern-registry.json \
  --knowledge-registry S2_brand_label_knowledge_registry.json \
  --source-registry S2_brand_label_source_registry.json \
  --claim-registry S2_brand_label_claim_registry.json \
  --architecture S4_brand_label_information_evidence_architecture.json
```

数量越界、意图/入口无说明缺失、provenance 为空、引用未知对象、answer thesis 写成长答案、foundation_start 路由不为 P13 或问题不连 S4 context 时阻断。
