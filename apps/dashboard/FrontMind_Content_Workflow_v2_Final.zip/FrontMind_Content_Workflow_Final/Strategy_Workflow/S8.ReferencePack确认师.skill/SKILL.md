---
name: frontmind-reference-pack-approver
description: S8 对 S2 registries、S4 内容价值/证据架构、S5 话语、S6 视觉与 S7 问题库进行集中人审，输出 v2、哈希绑定的 Reference Pack 审批记录；是执行层前唯一暂停点。
---

# S8 Reference Pack 确认师

## 目标

让品牌/项目负责人明确批准：文章能用什么事实、怎样说、为谁写、优先强调什么、回答哪些问题、可用哪些图片。S8 不重新汇总报告，不改写上游对象；只做对象级审阅、风险显示、回退归属与审批凭证。

## 输入

- S2 adapter report 与四类 registry；
- S4 information/evidence architecture 与 canonical brand facts；
- S5 voice contract；
- S6 visual reference；
- S7 question library；
- S3 trend reference 或 skip 状态（可选）；
- 包根 content pattern registry。

## 生成前硬门

- S2 `fatal_errors=[]` 且 formal handoff ready；
- S4 每个 message/value/priority angle 有合法 proof，差异化强度不超过证据，proof source 属于 claim；
- 每个来源具备合法 `source_origin_class`；公开第一方仅允许 `public_approved/anonymized_approved`，内部第一方仅允许 `internal_only`；
- “声明与证据”必须出现最终 Source Registry 中每一个 `first_party_official/first_party_internal` 的原始 `source_id`，负责人逐项确认来源标题、授权状态、适用边界与审计轨迹；总确认不能代替逐来源决定；
- S5 有四种证据状态的措辞规则与五入口覆盖；
- S6 直接资产有可用权利，Logo 为真实文件 overlay；
- S7 有 30–50 个问题，七意图/五入口参考覆盖、每题 provenance；
- 所有 `*_refs` 指向存在对象。

任一失败都回到责任阶段，不能“批准但稍后补”。

## 生成确认工作簿

```bash
python3 -B scripts/reference_pack_confirmation_generator.py \
  --brand "品牌正式名称" \
  --work-dir "/path/to/project" \
  --pattern-registry "/path/to/package/shared/content-pattern-registry.json" \
  --pattern-research-index "/path/to/package/shared/pattern-research/index.json" \
  --out "/path/to/project/S8/S8_brand_label_ReferencePack确认表.xlsx"
```

工作簿只展示需要负责人决定的声明、价值与品牌优先角度、受众/话语、问题覆盖、视觉资产、未决风险和最终审批，并保留对象 ID、来源状态与输入指纹。

第一方来源授权必须在最终工作簿生成前完成：先按 S2 首次输出的稳定 ID 填写 `source_publication_authorizations.json`，用 `--publication-authorizations` 重跑 S2，再重建引用这些来源的 S4、S5/S7 和本工作簿。S8 发现来源授权需要变化时，必须选择 `change` 并回 S2；不得在已签署工作簿之后修改 Source Registry，因为这会使 source registry 指纹和整个 Reference Pack 信任链失效。

## 审批与解析

负责人逐项选择 `keep/change/block`。任何 change/block、附带条件或未决风险都只能得到 `changes_requested`；只有所有对象 keep、六项确认均真、无条件和风险时才是 `approved`。

```bash
python3 -B scripts/reference_pack_approval_parser.py \
  --confirmed S8_brand_label_ReferencePack确认表.xlsx \
  --brand "品牌正式名称" \
  --out S8_brand_label_approval.json
```

解析器拒绝伪 approved、必选确认缺失、任一第一方 `source_id` 未逐项 keep、来源指纹丢失或审批后输入已变化。

## 输出与回退

- `S8_{brand_label}_ReferencePack确认表.xlsx`
- `S8_{brand_label}_approval.json`

回退：KB/接入错误→S1；registry/授权/权利错误→S2；价值、证据或信息结构→S4；表达→S5；视觉→S6；问题→S7。修改后重新生成工作簿，保留上一版审批记录。

只有严格 approved 才交 S9 构包。S8 不生成标题、正文、完整 FAQ、制作排期、PDF、CMS 或监测方案。
