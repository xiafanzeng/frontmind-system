---
name: frontmind-reference-pack-assembler
description: S9 将 S1–S8 已完成且严格批准的 v2 策略资产与 canonical KB 装配为自包含、逐文件哈希、双重验证的 FrontMind Reference Pack v2 ZIP；不承担总控、选题、写作或发布。
---

# S9 Reference Pack 装配师

## 唯一目标

把执行层真正需要的资料原样、完整、安全地装入一个可复验 ZIP。S9 不分析、不补写、不替负责人批准，不从已有文件反推一套新策略。

总控顺序与可复制全链命令由包根 `RUNBOOK.md` 负责；S9 只检查构包就绪并装配。

## 必需输入

- 与 S1/S2 指纹一致的 canonical KB v4 原始 ZIP；
- S2 adapter report 与四 registry；
- S4 information/evidence architecture 与 canonical brand facts；
- S5 voice contract；
- S6 visual reference；
- S7 question library；
- S8 strict approved receipt 与其原始确认工作簿；
- 包根 `shared/content-pattern-registry.json`；
- 包根 `shared/pattern-research/index.json`。

S3 trend reference 可选；缺失时 pack 明确写 `trend_viewpoints_path=null`。

## 就绪检查

可先运行：

```bash
python3 -B scripts/state_detector.py \
  --work-dir /path/to/project \
  --kb /path/to/canonical-kb-v4.zip
```

状态工具只报告 S1–S8 是否存在及下一步，不替代各 stage validator 或审批。

## 标准构包命令

```bash
python3 -B scripts/pack_builder.py \
  --brand "品牌正式名称" \
  --work-dir "/path/to/project" \
  --kb "/path/to/canonical-kb-v4.zip" \
  --pattern-registry "/path/to/package/shared/content-pattern-registry.json" \
  --pattern-research-index "/path/to/package/shared/pattern-research/index.json" \
  --output "/path/to/project/ReferencePack/S9_brand_label_reference_pack_v1.zip"
```

## 阻断门

1. 所有机器产物必须是 v2 并通过其唯一 JSON Schema 与语义 validator。
2. S4 proof source 必须属于所引 claim；第一方来源的公开授权必须通过。
3. 根 registry 必须包含五入口、P01–P15、P01 两个 canonical variants 和 `foundation_start ⇔ P13`。
4. S8 必须无附带条件、无未决风险、六项确认全真、对象审核全 keep；其 `input_files` 文件名、字节数与 SHA-256 必须匹配本次输入。
5. `--kb` 哈希必须等于 S2 adapter report 的 KB 指纹；registry 内相对文件必须存在且哈希正确。
6. 路径不得绝对、越界、反斜杠、重复或 zip-slip；包中不得出现本机缓存、API key 或临时路径。
7. staging 目录和最终 ZIP 都必须通过包根 `shared/scripts/validate_package.py`。

## Reference Pack v2 合同

- 根入口唯一为 `reference_pack.json`；`schema_version=2.0.0`、`profile=frontmind-content-reference-pack-v2`。
- `content_pattern_registry_path=shared/content-pattern-registry.json`。
- `content_pattern_research_index_path=shared/pattern-research/index.json`，并在 `files[]` 使用 role `content_pattern_research_index`。
- 已应用的 S2 逐来源授权原件位于 `diagnostics/`，`files[]` role 固定为 `source_publication_authorizations`；其实际字节 SHA-256 必须同时等于 adapter report 与文件清单登记值。
- `writing_assets.information_evidence_architecture_path=writing/information_evidence_architecture.json`，对应 `files[]` role 只允许 `information_evidence_architecture`。
- `files[]` 记录除自引用入口外每个实际文件的 SHA-256、media type 与 role。
- canonical KB 原始 ZIP、正规化知识树、引用的补充证据与图片都必须自包含。

## 输出

- `S9_{brand_label}_reference_pack_v{version}.zip`
- 一行构包回执：版本、ZIP SHA-256、文件数、目录验证状态与 ZIP 验证状态。

S9 不生成全景报告、合并 PDF、标题、正文、CMS 任务或发布动作。
