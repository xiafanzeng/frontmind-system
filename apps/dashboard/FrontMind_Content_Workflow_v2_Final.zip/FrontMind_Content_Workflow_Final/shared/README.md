# FrontMind v2 全局共享事实源

本目录是 S1-S9 与 E1-E10 唯一共享事实源。两层工作流不得复制五入口、P01-P15、第一方发布规则或根 JSON Schema。

## v2 Canonical contracts

- `reference_pack.schema.json`：可被多篇文章复用的企业 Reference Pack；正式 profile 为 `frontmind-content-reference-pack-v2`。
- `registries.schema.json`：knowledge/source/claim/image 四类 Registry；第一方来源区分已批准公开与仅内部。
- `brand_facts.schema.json`：策略层与执行层共用品牌事实结构。
- `information_evidence_architecture.schema.json`：S4 定位核心、价值结构、差异化证据地图、Proof Bundles 与品牌优先表达角度。
- `content_job.schema.json`：一篇文章任务；只暴露五个工程入口，不要求用户填写地区、受众或时间。
- `scope_analysis.schema.json`：E1/E3 自适应生成的地区、决策情境、时间依据与一次性澄清记录。
- `monitoring_input.schema.json`：E2 对当前具体问题的答案、信源和标杆拆解；`foundation_start` 不要求该输入。
- `runtime_evidence_extension.schema.json`：不改写签名 Pack 的单篇追加 source/claim 与授权证据。
- `article_blueprint.schema.json`：E4 单篇规划、唯一 P 模式、P01 variant、结构融合及标题公式计划；不含成品标题。
- `content_model.schema.json`：E5-E10 共同使用的无标题正文语义正本；出现 `title`、`h1` 或 `title_candidates` 即失败。
- `quality_report.schema.json`：E8/E10 质量门。
- `title_count_receipt.schema.json`：E10 的 1-20 标题数量确认。
- `title_map.schema.json`：绑定最终正文哈希的独立标题、H1 建议与 Meta 映射。
- `delivery_manifest.schema.json`：无标题正文、标题映射及最终交付物的逐文件哈希。

## Canonical policies and pattern research

- `content-pattern-registry.json`：五个工程入口、P01-P15、P01-M/P01-S 与第一方发布语义的机器注册表。
- `content-pattern-guide.md`：十五个后台结构的触发条件、骨架和证据边界。
- `pattern-research/`：每个模式的公开来源、结构审计、不可借鉴元素和版本依据；E2 的单问题标杆只能微调顺序和维度，不能替代预研模板。
- `writing-policy.md`：第三方客观报道 + 有证据的企业品牌宣传文风、微型答案、FAQ、竞品和视觉规则。
- `html-structured-data-policy.md`：无标题 HTML 片段、无标题 DOCX 和 Title Map/结构化数据模板规则。
- `workflow-migration-map.md`：原版与中间版能力如何迁入 v2，仅用于审计。

## 五入口与后台模式

工程入口只有：`industry_ranking`、`competitor_comparison`、`reputation`、`product_scenario`、`foundation_start`。P01-P15 是 E4 后台结构，不向用户提供十五项菜单。

- `foundation_start ⇔ P13`，必须由工程师显式选择。
- P01 必须显式选择 `multi_brand_editorial_recommendation` 或 `single_brand_recommendation`。
- P01-M 的客户品牌首先出现并重点详写，但不产生客观第一名主张。
- 其余四入口需要工作流外已确认的具体问题，不恢复广域问题发现。

## Validator 与 Fixture 原则

`shared/scripts/` 的运行时负责 Schema、路径、哈希、Registry 交叉引用、Reference Pack 信任链和 Content Model 语义门；根 `scripts/validate_workflow.py` 负责活动树阶段编号、引用完整性、研究档案覆盖、匿名性与缓存卫生。

严格匿名 Fixture 位于 `shared/fixtures/minimal_reference_pack/`。它只用于合同正向测试，不代表真实客户审批内容。任何 v1 Pack 必须明确拒绝，不能静默转换。

常用验证命令：

```bash
python3 -B shared/scripts/test_validate_json_instance.py
python3 -B shared/scripts/test_validate_package.py
python3 -B shared/scripts/validate_package.py shared/fixtures/minimal_reference_pack
python3 -B scripts/validate_workflow.py
```

Markdown 链接与 JSON Schema `$ref` 按所在文件目录解析；机器产物的 `file_path`/`*_path` 按字段指定的 Reference Pack 根或 job 根解析，禁止绝对路径、反斜杠与 `..` 越界。
