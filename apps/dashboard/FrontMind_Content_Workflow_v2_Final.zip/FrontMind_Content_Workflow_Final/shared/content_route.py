#!/usr/bin/env python3
"""Shared v2 entry, P-pattern and P01 candidate contract validation."""

from __future__ import annotations

import unicodedata
from typing import Any


P01_VARIANTS = {
    "multi_brand_editorial_recommendation",
    "single_brand_recommendation",
}


def normalized_name(value: Any) -> str:
    return unicodedata.normalize("NFKC", str(value or "")).strip().casefold()


def allowed_patterns(registry: Any, entry: str) -> set[str]:
    if not isinstance(registry, dict):
        return set()
    route = (registry.get("routing") or {}).get(entry)
    if not isinstance(route, dict):
        return set()
    return set(route.get("primary_patterns") or []) | set(route.get("secondary_patterns") or [])


def validate_entry_pattern_route(document: Any, registry: Any) -> list[str]:
    if not isinstance(document, dict):
        return ["route document must be an object"]
    entry = document.get("entry_category")
    pattern_id = document.get("pattern_id")
    variant = document.get("pattern_variant")
    subintent = document.get("product_scenario_subintent")
    errors: list[str] = []

    allowed = allowed_patterns(registry, str(entry or ""))
    if not allowed:
        errors.append(f"unknown or unroutable entry_category: {entry!r}")
    elif pattern_id not in allowed:
        errors.append(f"pattern {pattern_id!r} is not allowed for entry {entry!r}")

    if (entry == "foundation_start") != (pattern_id == "P13"):
        errors.append("foundation_start and P13 must be a strict two-way mapping")
    if pattern_id == "P01":
        if variant not in P01_VARIANTS:
            errors.append("P01 requires one exact pattern_variant")
        if entry != "industry_ranking":
            errors.append("P01 is only available through industry_ranking")
    elif variant is not None:
        errors.append("non-P01 route must persist pattern_variant as null")

    if entry == "product_scenario":
        product_route = (((registry or {}).get("routing") or {}).get("product_scenario") or {})
        subroutes = product_route.get("subintent_routing") or {}
        primary_patterns = set(product_route.get("primary_patterns") or [])
        if subintent not in subroutes:
            errors.append("product_scenario requires a canonical subintent")
        elif pattern_id in primary_patterns and pattern_id not in set(subroutes.get(subintent) or []):
            errors.append(f"pattern {pattern_id!r} is not allowed for product subintent {subintent!r}")
    elif subintent is not None:
        errors.append("non-product route must persist product_scenario_subintent as null")
    return errors


def validate_p01_candidate_contract(document: Any, canonical_brand: str | None = None) -> list[str]:
    if not isinstance(document, dict):
        return ["candidate document must be an object"]
    pattern_id = document.get("pattern_id")
    variant = document.get("pattern_variant")
    contract = document.get("candidate_contract")
    errors: list[str] = []
    if pattern_id != "P01":
        if contract is not None:
            errors.append("non-P01 document must persist candidate_contract as null")
        return errors
    if not isinstance(contract, dict):
        return ["P01 requires candidate_contract"]

    featured = str(contract.get("featured_brand_name") or "").strip()
    candidates = contract.get("ordered_candidates")
    dimensions = contract.get("common_dimensions")
    if not featured:
        errors.append("candidate_contract.featured_brand_name is required")
    if canonical_brand and normalized_name(featured) != normalized_name(canonical_brand):
        errors.append("P01 featured brand does not match the Reference Pack canonical brand")
    if not isinstance(candidates, list):
        return [*errors, "candidate_contract.ordered_candidates must be an array"]
    names = [normalized_name(item.get("entity_name")) for item in candidates if isinstance(item, dict)]
    if len(names) != len(candidates) or any(not name for name in names):
        errors.append("every P01 candidate requires a non-empty entity_name")
    if len(names) != len(set(names)):
        errors.append("P01 candidate names must be unique after Unicode normalization")
    if not candidates or not isinstance(candidates[0], dict):
        errors.append("P01 candidate list must start with the featured brand")
    else:
        if candidates[0].get("role") != "featured_brand":
            errors.append("the first P01 candidate must have role featured_brand")
        if normalized_name(candidates[0].get("entity_name")) != normalized_name(featured):
            errors.append("the first P01 candidate must equal featured_brand_name")
    for item in candidates[1:]:
        if not isinstance(item, dict) or item.get("role") != "other_candidate":
            errors.append("only the first P01 candidate may be featured_brand")
            break
    if contract.get("list_semantics") != "editorial_recommendation":
        errors.append("P01 list_semantics must be editorial_recommendation")

    if variant == "multi_brand_editorial_recommendation":
        if len(candidates) < 3:
            errors.append("P01-M requires at least three candidates")
        if not isinstance(dimensions, list) or not dimensions:
            errors.append("P01-M requires common comparison dimensions")
    elif variant == "single_brand_recommendation":
        if len(candidates) != 1:
            errors.append("P01-S requires exactly one candidate")
        if dimensions not in ([], None):
            errors.append("P01-S must not declare common competitor dimensions")
    return errors
