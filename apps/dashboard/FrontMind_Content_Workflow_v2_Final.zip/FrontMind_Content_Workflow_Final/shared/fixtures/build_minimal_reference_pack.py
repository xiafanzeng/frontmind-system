#!/usr/bin/env python3
"""Rebuild the strict, anonymous Reference Pack conformance fixture.

The XLSX itself is deliberately produced by the companion artifact-tool script;
this module prepares its data and then hash-binds the reviewed workbook.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import mimetypes
import zipfile
from collections import Counter
from pathlib import Path
from typing import Any


BRAND = "匿名示例企业"
STAMP = "2026-08-10T00:00:00+08:00"
FIXTURE_ROOT = Path(__file__).resolve().parent / "minimal_reference_pack"
PACKAGE_ROOT = Path(__file__).resolve().parents[2]
PATTERN_SOURCE = PACKAGE_ROOT / "shared/content-pattern-registry.json"
PATTERN_RESEARCH_SOURCE = PACKAGE_ROOT / "shared/pattern-research/index.json"
CONFIRMATIONS = [
    "第一方资料公开授权与声明边界已确认",
    "自适应决策情境与适用范围已确认",
    "话语与竞品比较边界已确认",
    "七意图与五入口参考资产已确认",
    "图片权利与Logo规则已确认",
    "未决风险与附带条件已确认",
]
FINGERPRINT_PATHS = {
    "adapter_report": ("diagnostics/adapter_report.json", "S2_Anonymous_adapter_report.json"),
    "knowledge_registry": ("registries/knowledge_registry.json", "S2_Anonymous_knowledge_registry.json"),
    "source_registry": ("registries/source_registry.json", "S2_Anonymous_source_registry.json"),
    "claim_registry": ("registries/claim_registry.json", "S2_Anonymous_claim_registry.json"),
    "image_registry": ("registries/image_registry.json", "S2_Anonymous_image_registry.json"),
    "brand_facts": ("brand/brand_facts.json", "S4_Anonymous_brand_facts.json"),
    "information_evidence_architecture": ("writing/information_evidence_architecture.json", "S4_Anonymous_information_evidence_architecture.json"),
    "voice_contract": ("writing/voice_contract.json", "S5_Anonymous_voice_contract.json"),
    "visual_reference": ("writing/visual_reference.json", "S6_Anonymous_visual_reference.json"),
    "question_library": ("writing/question_library.json", "S7_Anonymous_question_library.json"),
    "pattern_registry": ("shared/content-pattern-registry.json", "content-pattern-registry.json"),
    "pattern_research_index": ("shared/pattern-research/index.json", "index.json"),
}
REVIEW_OBJECTS = {
    "声明与证据": [
        "src_fixture_official", "clm_fixture_scope", "proof_bundle_fixture", "brand:identity", "brand:positioning",
        "off_fixture_pack", "cap_fixture_validation", "proof_brand_fixture", "lim_fixture_only",
    ],
    "受众与话语": [
        "ctx_fixture_validation", "msg_fixture_integrity",
        "val_fixture_functional", "val_fixture_emotional", "val_fixture_identity",
        "diff_fixture_integrity", "angle_fixture_trust_chain",
        "voice:default", "voice:terminology", "voice:comparison",
    ],
    "问题覆盖": [f"q:fixture:{index:02d}" for index in range(1, 31)],
    "视觉资产": ["img_fixture_logo", "visual:logo-policy"],
}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def write_bytes(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


def json_bytes(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def write_json(relative: str, value: Any) -> None:
    write_bytes(FIXTURE_ROOT / relative, json_bytes(value))


def deterministic_zip(path: Path, files: dict[str, bytes]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as archive:
        for name, data in sorted(files.items()):
            info = zipfile.ZipInfo(f"anonymous_kb/{name}", (2026, 8, 10, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data)


def prepare(state_path: Path) -> None:
    FIXTURE_ROOT.mkdir(parents=True, exist_ok=True)
    logo = base64.b64decode(
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII="
    )
    overview = (
        "# 匿名示例企业\n\n"
        "匿名示例企业提供经过审批的内容参考包校验服务。公开表述仅限于包结构、证据绑定与审批一致性。\n"
    ).encode("utf-8")
    source_index = (
        "# 来源索引\n\n- source-fixture-official：匿名示例企业内部批准的测试资料，仅用于工作流自测。\n"
    ).encode("utf-8")
    knowledge_tree = "# 知识树\n\n- 品牌概览\n- 校验能力\n- 使用边界\n".encode("utf-8")
    manifest = {
        "schemaVersion": 4,
        "profile": "dashboard-enterprise-v1",
        "buildRevision": 1,
        "documents": [{
            "id": "fixture-overview", "path": "brand_overview.md", "kind": "leaf",
            "title": "匿名品牌概览", "branchId": "identity", "sourceIds": ["source-fixture-official"],
            "assetIds": ["asset-fixture-logo"], "customerVisible": True,
        }],
        "assets": [{
            "id": "asset-fixture-logo", "path": "09_media_assets/fixture-logo.png",
            "mimeType": "image/png", "width": 1, "height": 1,
        }],
    }
    kb_files = {
        "00_package_manifest.json": json_bytes(manifest),
        "00_source_index.md": source_index,
        "00_knowledge_tree.md": knowledge_tree,
        "brand_overview.md": overview,
        "09_media_assets/fixture-logo.png": logo,
    }
    for name, data in kb_files.items():
        write_bytes(FIXTURE_ROOT / "sources/knowledge_base" / name, data)
    original = FIXTURE_ROOT / "sources/original_kb.zip"
    deterministic_zip(original, kb_files)
    kb_hash = sha256(original.read_bytes())
    write_bytes(FIXTURE_ROOT / "assets/fixture-logo.png", logo)

    content = overview.decode("utf-8").strip()
    write_json("registries/knowledge_registry.json", {
        "schema_version": "2.0.0", "registry_type": "knowledge_registry",
        "knowledge_units": [{
            "knowledge_id": "kn_fixture_overview", "title": "匿名品牌概览", "kind": "leaf",
            "content": content, "package_path": "sources/knowledge_base/brand_overview.md",
            "source_document_id": "fixture-overview", "branch_id": "identity",
            "source_ids": ["src_fixture_official"], "evidence_document_refs": ["fixture-overview"],
            "asset_ids": ["img_fixture_logo"], "origin": "kbv4", "customer_visible": True,
            "evidence_status": "verified", "content_status": "customer_visible",
            "evidence_precision": "claim", "content_sha256": sha256(content.encode("utf-8")),
        }],
    })
    write_json("registries/source_registry.json", {
        "schema_version": "2.0.0", "registry_type": "source_registry",
        "sources": [{
            "source_id": "src_fixture_official", "title": "匿名示例企业批准资料",
            "publisher": BRAND, "source_type": "first_party_official", "authority_tier": 2,
            "source_origin_class": "first_party_official",
            "publication_authorization": "anonymized_approved",
            "url": None, "file_path": "sources/knowledge_base/00_source_index.md",
            "published_at": None, "accessed_at": STAMP, "language": "zh-CN",
            "notes": "仅供严格匿名工作流自测。", "origin": "kbv4",
            "source_document_id": "source-fixture-official", "locator": "00_source_index.md",
            "evidence_status": "verified_first_party", "content_status": "source_index",
            "evidence_precision": "document",
        }],
    })
    write_json("registries/claim_registry.json", {
        "schema_version": "2.0.0", "registry_type": "claim_registry",
        "claims": [{
            "claim_id": "clm_fixture_scope",
            "claim_text": "匿名示例企业的本夹具仅证明 Reference Pack 的结构、证据绑定与审批一致性。",
            "claim_type": "capability", "importance": "core", "about_entities": [BRAND],
            "source_ids": ["src_fixture_official"], "origin": "kbv4",
            "knowledge_ids": ["kn_fixture_overview"], "evidence_document_refs": ["fixture-overview"],
            "evidence_status": "verified_first_party", "content_status": "limited_evidence",
            "evidence_precision": "claim", "reason": "范围限定后可公开使用。",
            "evidence_excerpt": "仅证明包结构、证据绑定与审批一致性。",
            "scope": "Reference Pack validator fixture", "as_of": STAMP,
            "verification_status": "verified_with_limits", "allowed_usage": "public_with_qualification",
        }],
    })
    write_json("registries/image_registry.json", {
        "schema_version": "2.0.0", "registry_type": "image_registry",
        "images": [{
            "asset_id": "img_fixture_logo", "asset_kind": "logo",
            "file_path": "assets/fixture-logo.png", "url": None, "sha256": sha256(logo),
            "mime_type": "image/png", "width": 1, "height": 1,
            "source_kind": "first_party_reference", "rights_status": "approved",
            "source_ids": ["src_fixture_official"], "semantic_tags": ["logo", "fixture"],
            "allowed_roles": ["entity_proof"], "depicts_real_event_or_case": False,
            "caption": "匿名夹具 Logo", "alt_text": "匿名示例企业标识",
            "origin": "kbv4", "source_document_id": "asset-fixture-logo",
            "ownership": "fixture", "evidence_status": "verified_asset",
            "content_status": "visual_asset", "evidence_precision": "document", "aliases": [],
        }],
    })
    publication_authorizations = {
        "schema_version": "2.0.0", "brand": BRAND,
        "authorization_id": "auth_fixture_anonymized_release_001",
        "reviewer": "fixture-publication-reviewer", "reviewer_role": "publication-owner",
        "reviewed_at": STAMP,
        "authorizations": [{
            "source_id": "src_fixture_official",
            "publication_authorization": "anonymized_approved",
            "authorization_basis": "严格匿名夹具发布边界确认",
            "evidence_refs": ["fixture/anonymous-publication-approval"],
            "anonymization_attestation": "夹具不含真实客户、人员或商业数据",
            "notes": "Strict anonymous fixture only.",
        }],
    }
    publication_authorization_name = "S2_Anonymous_source_publication_authorizations.json"
    write_json(f"diagnostics/{publication_authorization_name}", publication_authorizations)
    write_json("brand/brand_facts.json", {
        "schema_version": "2.0.0",
        "brand_identity": {
            "canonical_name": BRAND, "aliases": ["匿名品牌"], "legal_entity_name": None,
            "founded_at": None, "headquarters": None, "official_website": None,
            "source_ids": ["src_fixture_official"],
        },
        "positioning": {
            "category": "内容参考包校验夹具", "target_audiences": ["工作流工程师"],
            "value_proposition": "用最小但完整的匿名资料证明跨阶段契约与审批证据可验证。",
            "reasons_to_believe": ["全链路对象均绑定来源和哈希"], "source_ids": ["src_fixture_official"],
        },
        "offerings": [{
            "offering_id": "off_fixture_pack", "name": "匿名 Reference Pack", "offering_type": "solution",
            "definition": "用于自动化正反例验证的完整匿名参考包。", "fit": ["契约回归测试"],
            "limitations": ["不代表真实企业或真实商业能力"], "versions": ["2.0.0"],
            "source_ids": ["src_fixture_official"],
        }],
        "capabilities": [{
            "capability_id": "cap_fixture_validation", "name": "跨文件一致性验证",
            "description": "验证根包、阶段资产、审批工作簿与文件哈希的一致性。",
            "verification": "由本夹具的正反例测试验证。", "source_ids": ["src_fixture_official"],
        }],
        "proof_points": [{
            "proof_id": "proof_brand_fixture", "proof_type": "process",
            "statement": "夹具覆盖五入口、七意图、S4–S7 内容资产与 S8 审批证据。",
            "claim_ids": ["clm_fixture_scope"], "source_ids": ["src_fixture_official"],
        }],
        "limitations": [{
            "limitation_id": "lim_fixture_only", "statement": "仅用于工作流验证，不能作为市场声明。",
            "applies_to": ["所有夹具内容"], "source_ids": ["src_fixture_official"],
        }],
    })

    categories = ["industry_ranking", "competitor_comparison", "reputation", "product_scenario", "foundation_start"]
    category_patterns = {
        "industry_ranking": "P01", "competitor_comparison": "P02", "reputation": "P03",
        "product_scenario": "P04", "foundation_start": "P13",
    }
    eligible_patterns = ["P01", "P02", "P03", "P04", "P13"]
    write_json("writing/information_evidence_architecture.json", {
        "schema_version": "2.0.0", "brand": BRAND,
        "upstream": {"brand_facts": "brand/brand_facts.json"},
        "positioning_anchor": {
            "target_audience": "维护 FrontMind 内容工作流的工程师",
            "category_context": "内容参考资产契约验证",
            "brand_role": "匿名、可公开审计的 Reference Pack 回归夹具",
            "differentiated_value": "以匿名最小资产覆盖完整的真实信任链。",
            "reasons_to_believe": ["每个公开声明都绑定来源与 proof bundle"],
            "claim_ids": ["clm_fixture_scope"],
        },
        "audience_decision_contexts": [{
            "context_id": "ctx_fixture_validation", "role": "工作流工程师",
            "trigger": "修改 Reference Pack 契约后需要回归验证",
            "job": "确认有效包通过且伪造包失败", "constraints": ["不得依赖真实客户资料"],
            "decision_criteria": [{"criterion_id": "dc_schema", "criterion": "Schema 完整"}, {"criterion_id": "dc_binding", "criterion": "哈希绑定"}],
            "knowledge_ids": ["kn_fixture_overview"], "source_ids": ["src_fixture_official"],
            "provenance_status": "validated",
        }],
        "value_structure": {
            "functional": [{
                "value_id": "val_fixture_functional",
                "statement": "帮助工程师验证包结构、证据边与审批哈希保持一致。",
                "audience_context_refs": ["ctx_fixture_validation"],
                "proof_refs": ["proof_bundle_fixture"], "expression_mode": "evidence_backed",
                "allowed_wording": "本匿名夹具可用于验证 Reference Pack v2 的一致性。",
                "must_not_imply": ["不得暗示它证明真实企业的商业效果"],
            }],
            "emotional": [{
                "value_id": "val_fixture_emotional",
                "statement": "让回归结果更容易复核。",
                "audience_context_refs": ["ctx_fixture_validation"],
                "proof_refs": ["proof_bundle_fixture"], "expression_mode": "attributed_brand_expression",
                "allowed_wording": "匿名示例企业将可复核性作为夹具设计目标。",
                "must_not_imply": ["不得把设计目标写成第三方评价"],
            }],
            "self_expression": [{
                "value_id": "val_fixture_identity",
                "statement": "体现证据优先的内容工程实践。",
                "audience_context_refs": ["ctx_fixture_validation"],
                "proof_refs": ["proof_bundle_fixture"], "expression_mode": "attributed_brand_expression",
                "allowed_wording": "该夹具体现证据优先的工程取向。",
                "must_not_imply": ["不得推导行业领先地位"],
            }],
        },
        "differentiation_evidence_map": [{
            "differentiation_id": "diff_fixture_integrity", "dimension": "可验证信任链",
            "dimension_definition": "阶段资产、审批证据和 files[] 哈希可被同一验证器交叉复核。",
            "compared_against": ["未绑定哈希的内容资料包"],
            "brand_performance": "本夹具把所有被审阅输入和工作簿纳入包内哈希绑定。",
            "statement": "本夹具支持在限定范围内验证 Reference Pack v2 的信任链完整性。",
            "applicability_conditions": ["仅用于 FrontMind Reference Pack v2 回归验证"],
            "geographic_scope": "不适用地域限制（匿名技术夹具）",
            "version_scope": "FrontMind Reference Pack v2",
            "audience_context_refs": ["ctx_fixture_validation"],
            "claim_ids": ["clm_fixture_scope"], "source_ids": ["src_fixture_official"],
            "proof_refs": ["proof_bundle_fixture"], "evidence_state": "qualified",
            "comparison_allowed": True,
            "allowed_wording": "相较未绑定哈希的资料包，本夹具提供可复核的包内信任链。",
            "must_not_claim": ["不得据此宣称优于任何真实商业产品"],
            "evidence_gap": "", "as_of": STAMP,
        }],
        "brand_priority_angles": [{
            "angle_id": "angle_fixture_trust_chain", "angle": "可复核的 Reference Pack 信任链",
            "trigger_conditions": ["内容任务需要证明输入、审批与交付文件未被替换"],
            "audience_context_refs": ["ctx_fixture_validation"],
            "value_refs": ["val_fixture_functional"],
            "differentiation_refs": ["diff_fixture_integrity"],
            "proof_refs": ["proof_bundle_fixture"],
            "eligible_entry_categories": categories,
            "eligible_pattern_ids": eligible_patterns,
            "allowed_wording": "在需要回归验证时，优先说明哈希绑定与审批一致性。",
            "must_not_claim": ["不得把技术夹具包装成市场排名或真实客户案例"],
        }],
        "message_pillars": [{
            "message_id": "msg_fixture_integrity", "message": "本夹具验证结构、语义与审批证据的一致性。",
            "audience_context_refs": ["ctx_fixture_validation"], "proof_refs": ["proof_bundle_fixture"],
            "pattern_refs": eligible_patterns, "must_not_claim": ["不得宣称真实商业效果"],
        }],
        "proof_bundles": [{
            "proof_id": "proof_bundle_fixture", "statement": "夹具仅证明工作流校验能力。",
            "claim_ids": ["clm_fixture_scope"], "source_ids": ["src_fixture_official"],
            "verification_status": "verified_with_limits", "allowed_usage": "public_with_qualification",
            "evidence_precision": "claim", "allowed_wording": "本匿名夹具通过完整 Reference Pack 校验。",
            "necessary_qualification": "结论只适用于本夹具和对应 v2 校验器。",
            "caveat": "结论仅适用于工作流自测，不代表客户或市场表现。",
            "applicable_patterns": eligible_patterns, "as_of": STAMP,
        }],
        "claim_policy": {"public_use": "只使用 public_fact 或 public_with_qualification。"},
        "comparison_boundary": {"rule": "仅按一致维度比较并披露资料时间。"},
        "entity_coverage": [{"entity": BRAND, "claim_ids": ["clm_fixture_scope"]}],
        "entry_tone_guidance": [{
            "entry_category": category, "decision_tone": "客观、明确、可复核",
            "must_consume": ["proof_bundle_fixture"], "proof_minimum": "至少一个已验证 proof bundle",
            "avoid": ["未经证据支持的绝对化表述"], "pattern_refs": [category_patterns[category]],
        } for category in categories],
        "publication_form_guidance": [], "research_gaps": [],
    })
    write_json("writing/voice_contract.json", {
        "schema_version": "2.0.0", "brand": BRAND, "contract_version": "2.0.0",
        "upstream_refs": {"information_evidence_architecture": "writing/information_evidence_architecture.json"},
        "default_voice": {
            "principle": "先给结论，再给证据和适用条件。",
            "observable_rules": [
                {"rule": "第一句直接回答问题"}, {"rule": "每个主张绑定证据"}, {"rule": "限制条件紧邻结论"},
            ],
            "sentence_style": {"length": "2–4 句一段", "order": "结论—证据—建议"},
            "explanation_style": {"definition": "是什么—用途—适合—不适合"},
        },
        "terminology": {
            "preferred_terms": [{"term": "Reference Pack", "usage": "指正式参考资料包"}],
            "avoid_terms": [{"term": "绝对领先", "reason": "无法由夹具证据支持"}],
        },
        "messaging_house": {
            "core_message": "匿名夹具验证完整内容参考资产契约。",
            "pillars": [{"message": "所有可公开表述都由证据包约束。", "proof_refs": ["proof_bundle_fixture"]}],
        },
        "claim_expression_rules": {
            state: {"allowed": ["按证据状态表达"], "forbidden": ["越过状态边界扩写"]}
            for state in ("public_fact", "public_with_qualification", "internal_only", "do_not_use")
        },
        "comparison_rules": {
            "named_competitors": "evidence_conditional",
            "named_comparison_conditions": ["所有对象使用相同维度且有同期来源"],
            "no_evidence_fallback": "改写为选择标准，不点名比较。",
        },
        "entry_tone_overrides": [{
            "entry_category": category, "tone": "客观决策型", "pattern_refs": [category_patterns[category]],
        } for category in categories],
        "publication_form_overrides": [], "pattern_refs": eligible_patterns,
        "system_prompt_fragment": "使用第三方客观报道与企业品牌宣传稿之间的分析语气；结论必须带证据、条件和真实限制。",
    })
    write_json("writing/visual_reference.json", {
        "schema_version": "2.0.0", "brand": BRAND,
        "upstream_refs": {"image_registry": "registries/image_registry.json"},
        "brand_constraints": {
            "logo_asset_refs": ["img_fixture_logo"], "colors": [{"hex": "#17324D", "role": "primary"}],
            "typography": {"principle": "无衬线、高可读"},
            "forbidden_styles": [{"style": "伪造 Logo"}],
        },
        "asset_usage": [{
            "asset_ref": "img_fixture_logo", "usage_mode": "overlay_only",
            "allowed_slots": ["header", "footer"], "rationale": "真实 Logo 仅作为覆盖层使用。",
        }],
        "visual_language": {
            "recognition_layer": "深蓝品牌色与真实 Logo", "narrative_layer": "证据链与校验路径",
            "application_layer": "解释型图示", "motifs": ["节点", "校验勾"],
        },
        "visual_patterns": [{
            "visual_pattern_id": "vp_fixture_evidence_chain", "purpose": "解释 Reference Pack 信任链",
            "message_refs": ["msg_fixture_integrity"], "pattern_refs": ["P04"],
            "slots": [{"slot": "input"}, {"slot": "evidence"}, {"slot": "approval"}],
            "prompt_scaffold": {"instruction": "绘制结构、证据与审批三段关系图，不生成任何品牌标识。"},
            "negative_constraints": ["不得生成或重绘 Logo", "不得使用装饰图替代证据图"],
            "quality_gates": ["关系方向清晰", "每个节点可对应正文对象"],
        }],
        "logo_policy": {
            "mode": "overlay_real_asset", "generation_rule": "never_generate_or_redraw_logo",
            "overlay_rule": "只覆盖 img_fixture_logo 原文件并保持比例。",
        },
        "accessibility": {
            "alt_template": "{brand}：{visual_purpose}", "caption_rule": "说明图示证明的关系与适用范围。",
            "contrast_rule": "正文与背景对比度至少满足 WCAG AA。",
        },
    })

    intents = ["recommendation", "price", "comparison", "tutorial", "evaluation", "risk", "alternative"]
    questions = []
    for offset in range(30):
        number = offset + 1
        category = categories[offset % len(categories)]
        intent = intents[offset % len(intents)]
        questions.append({
            "question_id": f"q:fixture:{number:02d}",
            "canonical_question": f"匿名示例企业第{number:02d}项内容参考包决策应如何评估证据与适用范围？",
            "observed_variants": [{"text": f"第{number:02d}项夹具问题如何判断", "source": "fixture"}],
            "primary_intent_tag": intent,
            "secondary_intent_tags": [intents[(offset + 1) % len(intents)]],
            "entry_category": category,
            "product_scenario_subintent_ref": "offering_definition" if category == "product_scenario" else None,
            "pattern_refs": [category_patterns[category]],
            "audience_context_refs": ["ctx_fixture_validation"],
            "decision_criteria_refs": ["dc_schema", "dc_binding"],
            "knowledge_ids": ["kn_fixture_overview"], "source_ids": ["src_fixture_official"],
            "claim_ids": ["clm_fixture_scope"], "trend_refs": [],
            "provenance": [{
                "type": "source_derived", "source_id": "src_fixture_official",
                "knowledge_id": "kn_fixture_overview", "locator": "00_source_index.md",
            }],
            "answerability": "answerable_with_attribution", "faq_candidate": number <= 8,
            "answer_boundary": {
                "answer_thesis": "先验证结构、语义与审批哈希，再在明确限制内使用参考资产。",
                "must_cover": ["输入契约", "证据绑定", "审批状态"],
                "proof_refs": ["proof_bundle_fixture"], "must_not_claim": ["不得推导真实商业效果"],
                "freshness_rule": "按 Reference Pack created_at 与来源 accessed_at 判断。",
                "visual_pattern_refs": ["vp_fixture_evidence_chain"],
            },
            "path_group_id": "fixture-integrity", "faq_relevance": "core" if number <= 8 else "supporting",
            "relevance_reason": "用于覆盖五入口、七意图与证据边界的严格回归验证。",
        })
    write_json("writing/question_library.json", {
        "schema_version": "2.0.0", "brand": BRAND,
        "pattern_registry_ref": "shared/content-pattern-registry.json",
        "upstream_refs": {"information_evidence_architecture": "writing/information_evidence_architecture.json"},
        "questions": questions,
        "coverage": {
            "primary_intent_tag_counts": dict(Counter(item["primary_intent_tag"] for item in questions)),
            "entry_category_counts": dict(Counter(item["entry_category"] for item in questions)),
        },
        "coverage_exceptions": [], "unanswered_gaps": [],
    })
    write_bytes(FIXTURE_ROOT / "shared/content-pattern-registry.json", PATTERN_SOURCE.read_bytes())
    write_bytes(FIXTURE_ROOT / "shared/pattern-research/index.json", PATTERN_RESEARCH_SOURCE.read_bytes())

    write_json("diagnostics/adapter_report.json", {
        "schema_version": "2.0.0", "brand": BRAND, "generated_at": STAMP,
        "mode": "canonical_v4", "canonical": True,
        "manifest": {"schemaVersion": 4, "profile": "dashboard-enterprise-v1", "buildRevision": 1, "documents": 1, "assets": 1},
        "input_fingerprints": {"kb": kb_hash},
        "publication_authorizations": {
            "status": "applied",
            "candidate_source_ids": ["src_fixture_official"],
            "decisions": [{
                "source_id": "src_fixture_official",
                "publication_authorization": "anonymized_approved",
                "resulting_source_type": "first_party_official",
                "resulting_source_origin_class": "first_party_official",
            }],
            "template_file": "S2_Anonymous_source_publication_authorizations.template.json",
            "file_name": publication_authorization_name,
            "sha256": sha256((FIXTURE_ROOT / "diagnostics" / publication_authorization_name).read_bytes()),
            "authorization_id": "auth_fixture_anonymized_release_001",
            "reviewer": "fixture-publication-reviewer",
            "reviewer_role": "publication-owner",
            "reviewed_at": STAMP,
        },
        "registries": {
            "knowledge": "S2_Anonymous_knowledge_registry.json", "source": "S2_Anonymous_source_registry.json",
            "claim": "S2_Anonymous_claim_registry.json", "image": "S2_Anonymous_image_registry.json",
        },
        "counts": {"knowledge": 1, "sources": 1, "claims": 1, "images": 1},
        "warnings": [], "fatal_errors": [], "input_mode": "canonical_direct", "formal_handoff_ready": True,
    })

    fingerprints = []
    for role, (relative, source_name) in FINGERPRINT_PATHS.items():
        data = (FIXTURE_ROOT / relative).read_bytes()
        fingerprints.append({"role": role, "file_name": source_name, "sha256": sha256(data), "bytes": len(data)})
    reviews = [
        {"sheet": sheet, "object_id": object_id, "decision": "keep", "requested_change": "", "notes": ""}
        for sheet, object_ids in REVIEW_OBJECTS.items() for object_id in object_ids
    ]
    state = {
        "brand": BRAND, "schema_version": "2.0.0", "approved_at": "2026-08-10",
        "reviewer": "fixture-reviewer", "reviewer_role": "workflow-validator",
        "notes": "Strict anonymous fixture approval.", "confirmations": CONFIRMATIONS,
        "input_files": fingerprints,
        "pattern_registry_sha256": sha256((FIXTURE_ROOT / "shared/content-pattern-registry.json").read_bytes()),
        "pattern_research_index_sha256": sha256((FIXTURE_ROOT / "shared/pattern-research/index.json").read_bytes()),
        "review_decisions": reviews,
    }
    state_path.parent.mkdir(parents=True, exist_ok=True)
    state_path.write_bytes(json_bytes(state))


def media_type(path: Path) -> str:
    if path.suffix == ".json":
        return "application/json"
    if path.suffix == ".md":
        return "text/markdown"
    if path.suffix == ".xlsx":
        return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    if path.suffix == ".zip":
        return "application/zip"
    return mimetypes.guess_type(path.name)[0] or "application/octet-stream"


def file_role(relative: str) -> str:
    exact = {
        "sources/original_kb.zip": "knowledge_source_package",
        "sources/knowledge_base/00_package_manifest.json": "knowledge_manifest",
        "sources/knowledge_base/00_source_index.md": "knowledge_index",
        "sources/knowledge_base/00_knowledge_tree.md": "knowledge_tree",
        "diagnostics/adapter_report.json": "adapter_report",
        "diagnostics/S2_Anonymous_source_publication_authorizations.json": "source_publication_authorizations",
        "approval/approval.json": "approval_receipt",
        "approval/confirmation_workbook.xlsx": "approval_evidence",
        "brand/brand_facts.json": "brand_facts",
        "registries/knowledge_registry.json": "knowledge_registry",
        "registries/source_registry.json": "source_registry",
        "registries/claim_registry.json": "claim_registry",
        "registries/image_registry.json": "image_registry",
        "writing/information_evidence_architecture.json": "information_evidence_architecture",
        "writing/voice_contract.json": "voice_tokens",
        "writing/visual_reference.json": "visual_rules",
        "writing/question_library.json": "faq_library",
        "shared/content-pattern-registry.json": "content_pattern_registry",
        "shared/pattern-research/index.json": "content_pattern_research_index",
    }
    return exact.get(relative, "supporting_reference")


def finalize(state_path: Path) -> None:
    state = json.loads(state_path.read_text("utf-8"))
    workbook_path = FIXTURE_ROOT / "approval/confirmation_workbook.xlsx"
    workbook_data = workbook_path.read_bytes()
    receipt = {
        "schema_version": "2.0.0", "brand": BRAND,
        "approval": {
            "status": "approved", "reviewer": state["reviewer"], "reviewer_role": state["reviewer_role"],
            "approved_at": state["approved_at"], "conditions": [], "unresolved_risks": [], "notes": state["notes"],
        },
        "input_files": state["input_files"],
        "pattern_registry_sha256": state["pattern_registry_sha256"],
        "pattern_research_index_sha256": state["pattern_research_index_sha256"],
        "review_decisions": state["review_decisions"],
        "confirmations": {label: True for label in state["confirmations"]},
        "workbook": {"file_name": "S8_Anonymous_confirmation.xlsx", "sha256": sha256(workbook_data)},
    }
    write_json("approval/approval.json", receipt)
    original_hash = sha256((FIXTURE_ROOT / "sources/original_kb.zip").read_bytes())
    files = []
    for path in sorted(item for item in FIXTURE_ROOT.rglob("*") if item.is_file() and item.name != "reference_pack.json"):
        relative = path.relative_to(FIXTURE_ROOT).as_posix()
        data = path.read_bytes()
        files.append({"path": relative, "sha256": sha256(data), "media_type": media_type(path), "role": file_role(relative)})
    pack = {
        "schema_version": "2.0.0", "profile": "frontmind-content-reference-pack-v2",
        "pack_id": "rp_anonymous_fixture_v2", "version": 1, "created_at": STAMP,
        "brand": {"canonical_name": BRAND, "aliases": ["匿名品牌"], "legal_entity_name": None, "official_website": None},
        "knowledge_base": {
            "schema_version": "4", "profile": "dashboard-enterprise-v1", "package_sha256": original_hash,
            "original_package_path": "sources/original_kb.zip",
            "package_manifest_path": "sources/knowledge_base/00_package_manifest.json",
            "source_index_path": "sources/knowledge_base/00_source_index.md",
            "knowledge_tree_path": "sources/knowledge_base/00_knowledge_tree.md",
        },
        "diagnostics": {"adapter_report_path": "diagnostics/adapter_report.json"},
        "approval_receipt_path": "approval/approval.json",
        "approval_evidence_path": "approval/confirmation_workbook.xlsx",
        "content_pattern_registry_path": "shared/content-pattern-registry.json",
        "content_pattern_research_index_path": "shared/pattern-research/index.json",
        "brand_facts_path": "brand/brand_facts.json",
        "registries": {
            "knowledge_registry_path": "registries/knowledge_registry.json",
            "source_registry_path": "registries/source_registry.json",
            "claim_registry_path": "registries/claim_registry.json",
            "image_registry_path": "registries/image_registry.json",
        },
        "writing_assets": {
            "information_evidence_architecture_path": "writing/information_evidence_architecture.json", "trend_viewpoints_path": None,
            "voice_token_path": "writing/voice_contract.json", "visual_rules_path": "writing/visual_reference.json",
            "faq_library_path": "writing/question_library.json",
        },
        "files": files, "warnings": ["Strict anonymous conformance fixture; not customer data."],
    }
    write_json("reference_pack.json", pack)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("prepare", "finalize"))
    parser.add_argument("--state", type=Path, required=True)
    args = parser.parse_args()
    if args.mode == "prepare":
        prepare(args.state.resolve())
    else:
        finalize(args.state.resolve())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
