import fs from "node:fs/promises";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const [statePath, outputPath, renderDir] = process.argv.slice(2);
if (!statePath || !outputPath || !renderDir) {
  throw new Error("usage: node build_minimal_reference_pack_workbook.mjs STATE OUTPUT_XLSX RENDER_DIR");
}
const state = JSON.parse(await fs.readFile(statePath, "utf8"));
await fs.mkdir(renderDir, { recursive: true });
await fs.mkdir(outputPath.slice(0, outputPath.lastIndexOf("/")), { recursive: true });

const workbook = Workbook.create();
const NAVY = "#17324D";
const TEAL = "#148A83";
const PALE = "#EAF3F5";
const LIGHT = "#F6F8FA";
const BORDER = "#CBD5E1";
const TEXT = "#1F2937";

function columnLetters(column) {
  let result = "";
  for (let current = column; current > 0; current = Math.floor((current - 1) / 26)) {
    result = String.fromCharCode(65 + ((current - 1) % 26)) + result;
  }
  return result;
}

function titleBlock(sheet, title, subtitle, columns) {
  const last = columnLetters(columns);
  sheet.showGridLines = false;
  sheet.mergeCells(`A1:${last}1`);
  sheet.getRange("A1").values = [[title]];
  sheet.getRange(`A1:${last}1`).format = {
    fill: NAVY,
    font: { bold: true, color: "#FFFFFF", size: 16 },
    verticalAlignment: "center",
  };
  sheet.getRange(`A1:${last}1`).format.rowHeight = 30;
  sheet.mergeCells(`A2:${last}2`);
  sheet.getRange("A2").values = [[subtitle]];
  sheet.getRange(`A2:${last}2`).format = {
    fill: PALE,
    font: { color: NAVY, italic: true, size: 10 },
    wrapText: true,
    verticalAlignment: "center",
  };
  sheet.getRange(`A2:${last}2`).format.rowHeight = 32;
}

function headerRow(sheet, headers) {
  const last = columnLetters(headers.length);
  sheet.getRange(`A3:${last}3`).values = [headers];
  sheet.getRange(`A3:${last}3`).format = {
    fill: TEAL,
    font: { bold: true, color: "#FFFFFF" },
    wrapText: true,
    verticalAlignment: "center",
    borders: { preset: "all", style: "thin", color: BORDER },
  };
  sheet.getRange(`A3:${last}3`).format.rowHeight = 30;
  sheet.freezePanes.freezeRows(3);
}

function bodyStyle(sheet, rows, columns) {
  if (rows < 4) return;
  const last = columnLetters(columns);
  sheet.getRange(`A4:${last}${rows}`).format = {
    font: { color: TEXT, size: 10 },
    wrapText: true,
    verticalAlignment: "top",
    borders: { preset: "all", style: "thin", color: BORDER },
  };
  for (let row = 4; row <= rows; row += 2) {
    sheet.getRange(`A${row}:${last}${row}`).format.fill = LIGHT;
  }
}

function writeReviewSheet(name, objectIds, typeLabel, subtitle) {
  const sheet = workbook.worksheets.add(name);
  titleBlock(sheet, name, subtitle, 7);
  const headers = ["对象ID", "对象类型", "审阅摘要", "证据/上游refs", "审核决定", "修改要求", "备注"];
  headerRow(sheet, headers);
  const rows = objectIds.map((objectId) => [
    objectId,
    typeLabel,
    `确认 ${objectId} 的边界、完整性与可追溯性。`,
    "由同一 Reference Pack 中的 canonical JSON 与审批指纹绑定。",
    "keep",
    "",
    "",
  ]);
  sheet.getRange(`A4:G${3 + rows.length}`).values = rows;
  bodyStyle(sheet, 3 + rows.length, 7);
  const widths = [24, 18, 50, 52, 14, 34, 28];
  widths.forEach((width, index) => {
    sheet.getRange(`${columnLetters(index + 1)}:${columnLetters(index + 1)}`).format.columnWidth = width;
  });
  sheet.getRange(`E4:E${3 + rows.length}`).format = {
    fill: "#DCFCE7",
    font: { bold: true, color: "#166534" },
    horizontalAlignment: "center",
    verticalAlignment: "center",
    borders: { preset: "all", style: "thin", color: BORDER },
  };
  return sheet;
}

const overview = workbook.worksheets.add("说明与总览");
titleBlock(overview, "Reference Pack 严格匿名审批夹具", "只用于自动化契约、语义、哈希与审批证据的正向回归；不代表真实企业或商业声明。", 5);
headerRow(overview, ["检查域", "状态", "对象数", "硬门槛", "说明"]);
const overviewRows = [
  ["S4 声明与证据", "PASS", state.review_decisions.filter((x) => x.sheet === "声明与证据").length, "Schema + semantic", "公开主张、品牌事实和 proof bundle 全覆盖"],
  ["S4/S5 受众与话语", "PASS", state.review_decisions.filter((x) => x.sheet === "受众与话语").length, "Executable contract", "决策情境、价值结构、差异证据、品牌角度与话语契约全覆盖"],
  ["S7 问题覆盖", "PASS", state.review_decisions.filter((x) => x.sheet === "问题覆盖").length, "5 entries + 7 intents", "30 个参考问题，每题带 provenance 与回答边界"],
  ["S6 视觉资产", "PASS", state.review_decisions.filter((x) => x.sheet === "视觉资产").length, "Rights + asset_kind", "真实 Logo 分类、entity_proof 权限和 overlay-only 策略"],
  ["S8 审批", "PASS", state.confirmations.length, "Six confirmations", "六项确认全部 YES，无条件、无未决风险"],
];
overview.getRange("A4:E8").values = overviewRows;
bodyStyle(overview, 8, 5);
[28, 14, 12, 30, 60].forEach((width, index) => {
  overview.getRange(`${columnLetters(index + 1)}:${columnLetters(index + 1)}`).format.columnWidth = width;
});
overview.getRange("B4:B8").format = {
  fill: "#DCFCE7", font: { bold: true, color: "#166534" }, horizontalAlignment: "center",
  borders: { preset: "all", style: "thin", color: BORDER },
};

writeReviewSheet("声明与证据", state.review_decisions.filter((x) => x.sheet === "声明与证据").map((x) => x.object_id), "claim / evidence", "逐项确认声明状态、证据精度、允许措辞与品牌事实边界。");
writeReviewSheet("受众与话语", state.review_decisions.filter((x) => x.sheet === "受众与话语").map((x) => x.object_id), "audience / voice", "逐项确认文章写给谁、决策标准和可执行表达规则。");
writeReviewSheet("问题覆盖", state.review_decisions.filter((x) => x.sheet === "问题覆盖").map((x) => x.object_id), "question", "逐题确认五入口、七意图、provenance、可回答性与 proof refs。");
writeReviewSheet("视觉资产", state.review_decisions.filter((x) => x.sheet === "视觉资产").map((x) => x.object_id), "visual policy", "逐项确认资产分类、来源、权利、允许角色和真实 Logo 覆盖规则。");

const approval = workbook.worksheets.add("审批决议");
titleBlock(approval, "最终审批决议", "只有六项全部 YES、所有对象均 keep、且无附带条件或未决风险时，Reference Pack 才可进入执行层。", 4);
const approvalRows = [
  ["品牌", state.brand],
  ...state.confirmations.map((label) => [label, "YES"]),
  ["审批状态", "approved"],
  ["负责人", state.reviewer],
  ["负责人角色", state.reviewer_role],
  ["审批日期", state.approved_at],
  ["附带条件（每行一项）", ""],
  ["未决风险（每行一项）", ""],
  ["总备注", state.notes],
];
approval.getRange(`A3:B${2 + approvalRows.length}`).values = approvalRows;
approval.getRange(`A3:A${2 + approvalRows.length}`).format = {
  fill: PALE, font: { bold: true, color: NAVY }, wrapText: true,
  borders: { preset: "all", style: "thin", color: BORDER },
};
approval.getRange(`B3:B${2 + approvalRows.length}`).format = {
  font: { color: TEXT }, wrapText: true,
  borders: { preset: "all", style: "thin", color: BORDER },
};
approval.getRange("A:A").format.columnWidth = 42;
approval.getRange("B:B").format.columnWidth = 74;
approval.freezePanes.freezeRows(2);

const meta = workbook.worksheets.add("_meta");
meta.showGridLines = false;
const metaRows = [
  ["schema_version", state.schema_version],
  ["brand", state.brand],
  ["input_files", JSON.stringify(state.input_files)],
  ["pattern_registry_sha256", state.pattern_registry_sha256],
  ["pattern_research_index_sha256", state.pattern_research_index_sha256],
];
meta.getRange("A1:B5").values = metaRows;
meta.getRange("A1:A5").format = {
  fill: NAVY, font: { bold: true, color: "#FFFFFF" },
  borders: { preset: "all", style: "thin", color: BORDER },
};
meta.getRange("B1:B5").format = {
  font: { color: TEXT }, wrapText: true,
  borders: { preset: "all", style: "thin", color: BORDER },
};
meta.getRange("A:A").format.columnWidth = 30;
meta.getRange("B:B").format.columnWidth = 120;
meta.getRange("1:5").format.rowHeight = 28;
meta.getRange("3:3").format.rowHeight = 240;

const inspectTargets = [
  ["说明与总览", "A1:E8"], ["声明与证据", "A1:G12"], ["受众与话语", "A1:G13"],
  ["问题覆盖", "A1:G33"], ["视觉资产", "A1:G5"], ["审批决议", "A1:B16"], ["_meta", "A1:B5"],
];
for (const [sheetName, range] of inspectTargets) {
  const check = await workbook.inspect({ kind: "table", range: `${sheetName}!${range}`, include: "values,formulas", tableMaxRows: 14, tableMaxCols: 8 });
  if (!check?.ndjson) throw new Error(`inspect returned no data for ${sheetName}`);
}
const formulaErrors = await workbook.inspect({
  kind: "match", searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 100 }, summary: "final formula error scan",
});
if (formulaErrors?.ndjson && !formulaErrors.ndjson.includes('"matchCount":0') && formulaErrors.ndjson.includes("#")) {
  throw new Error(`formula error scan was not clean: ${formulaErrors.ndjson}`);
}
for (const [sheetName] of inspectTargets) {
  const preview = await workbook.render({ sheetName, autoCrop: "all", scale: 1, format: "png" });
  const safeName = sheetName === "_meta" ? "meta" : sheetName;
  await fs.writeFile(`${renderDir}/${safeName}.png`, new Uint8Array(await preview.arrayBuffer()));
}
const exported = await SpreadsheetFile.exportXlsx(workbook);
await exported.save(outputPath);
console.log(JSON.stringify({ status: "ok", outputPath, sheets: inspectTargets.map(([name]) => name), rendered: inspectTargets.length }));
