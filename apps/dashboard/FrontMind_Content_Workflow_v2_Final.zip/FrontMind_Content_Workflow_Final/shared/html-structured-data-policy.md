# HTML 与结构化数据政策

## 1. 同源渲染

HTML 正文片段和 DOCX 正文必须由 E10 选中的同一个无标题 `content_model.json` 渲染。渲染器只能改变呈现，不能改写正文、FAQ、引用、图片含义或结论。Delivery Manifest 记录同一个 `content_model_sha256`。

## 2. HTML 结构

- `article_body.html` 是可嵌入 CMS 的 `<article>` 正文片段，不包含 `<html>`、`<head>`、`<title>` 或 H1。
- 正文只使用 H2、H3，最多两级且不跳级；每个 H2 是一个完整、自然的用户子问题，H3 只拆价格、功能、案例、限制等判断维度。
- DOCX 同样不渲染 Title/H1，从微型答案开始；H2/H3 分别映射到可导航的 Word Heading 样式。
- 可见正文不使用表格。竞品、价格和规格使用平行小节或列表。
- 图片必须有与正文一致的 `alt`，事实性图片保留来源/权利记录；不把内部 asset_id 当可见替代文本。
- 参考来源名称与链接在正文或文末可见，不能只藏在 JSON-LD。

## 3. JSON-LD 选择

| 类型 | 使用条件 |
|---|---|
| `Article` | 只输出 `structured_data_template.json` 模板；`headline` 使用 `{{TITLE_ID}}` 占位，发布时从 `publishing_metadata_map.json` 选择同一 title ID 注入。资料截止日期必须在正文可见，不得臆造作者、发布者、评分或价格 |
| `FAQPage` | 页面可见 5-8 个 FAQ，JSON-LD 问答逐字对应可见内容 |
| `ItemList` | 仅 P01-M 的可见正文存在完整候选集合时使用；必须表达无序编辑推荐集合，不输出评分、客观名次或排名 position |
| `HowTo` | P07 或具有真实连续步骤的 P10；每个步骤在页面可见并含动作 |
| `Product` | 正文围绕一个明确产品，名称、品牌、型号、版本等字段在正文可见 |
| `Review` | 存在真实第一手评测/体验、明确评价主体、方法与可复核结论；不能把公开资料汇编、案例叙事或企业宣传稿伪装为评测 |

不得为了覆盖更多 Schema 类型而添加正文没有的价格、评分、库存、评价、步骤、FAQ、作者资质或发布日期。

## 4. 一致性验证

E10 必须检查：

1. HTML 片段和 DOCX 正文均无标题/H1，标题只存在于独立 Title Map 与发布元数据映射；
2. HTML 只有 H2/H3 且不跳级，DOCX 对应 Word Heading 样式；
3. FAQ、HowTo、Product、Review 的结构化字段均能在可见正文逐项定位；
4. JSON-LD 中的实体名称、日期、价格、版本和结论绑定相同 claim/source；
5. HTML 文本与 DOCX 的语义块顺序、FAQ、引用和视觉位置一致。

任一不一致都必须回到无标题 Content Model 修复并重新渲染，不允许只手工修改 HTML。发布系统选择某个 title ID 时，只能填充 Title/H1/Meta/Article headline 占位，不得改写正文片段。
