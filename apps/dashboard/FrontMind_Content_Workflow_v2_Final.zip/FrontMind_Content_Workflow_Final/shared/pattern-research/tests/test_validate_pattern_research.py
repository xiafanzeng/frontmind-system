#!/usr/bin/env python3
from __future__ import annotations

import copy
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "pattern_validator", ROOT / "validate_pattern_research.py"
)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader
SPEC.loader.exec_module(MODULE)


class PatternResearchValidatorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.canonical = json.loads((ROOT / "index.json").read_text(encoding="utf-8"))

    def validate_mutation(self, mutate):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp)
            data = copy.deepcopy(self.canonical)
            mutate(data)
            (target / "index.json").write_text(
                json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            for pattern in data["patterns"]:
                source = ROOT / pattern["dossier_path"]
                if source.exists():
                    (target / pattern["dossier_path"]).write_text(
                        source.read_text(encoding="utf-8"), encoding="utf-8"
                    )
            return MODULE.validate_index(target / "index.json", target)

    def test_canonical_library_passes(self):
        self.assertEqual(MODULE.validate_index(ROOT / "index.json", ROOT), [])

    def test_quota_underflow_fails(self):
        errors = self.validate_mutation(lambda data: data["patterns"][2]["benchmarks"].pop())
        self.assertTrue(any("below minimum" in error for error in errors), errors)

    def test_global_duplicate_url_fails(self):
        def mutate(data):
            data["patterns"][2]["benchmarks"][0]["url"] = data["patterns"][0]["benchmarks"][0]["url"]
            data["patterns"][2]["benchmarks"][0]["domain"] = data["patterns"][0]["benchmarks"][0]["domain"]
        errors = self.validate_mutation(mutate)
        self.assertTrue(any("duplicate of" in error for error in errors), errors)

    def test_http_or_private_url_fails(self):
        def mutate(data):
            item = data["patterns"][3]["benchmarks"][0]
            item["url"] = "http://127.0.0.1/private"
            item["domain"] = "127.0.0.1"
        errors = self.validate_mutation(mutate)
        self.assertTrue(any("only https" in error for error in errors), errors)
        self.assertTrue(any("private IP" in error for error in errors), errors)

    def test_missing_required_field_fails(self):
        def mutate(data):
            del data["patterns"][4]["benchmarks"][0]["visual_observation"]
        errors = self.validate_mutation(mutate)
        self.assertTrue(any("visual_observation" in error for error in errors), errors)

    def test_source_diversity_fails(self):
        def mutate(data):
            pattern = data["patterns"][5]
            for item in pattern["benchmarks"]:
                item["source_class"] = "vendor_documentation"
            pattern["source_class_summary"] = ["vendor_documentation"]
        errors = self.validate_mutation(mutate)
        self.assertTrue(any("need >=3 source classes" in error for error in errors), errors)

    def test_statistics_tampering_fails(self):
        def mutate(data):
            data["statistics"]["benchmark_count"] = 139
        errors = self.validate_mutation(mutate)
        self.assertTrue(any("root.statistics" in error for error in errors), errors)

    def test_dossier_traceability_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp)
            data = copy.deepcopy(self.canonical)
            (target / "index.json").write_text(
                json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            for pattern in data["patterns"]:
                text = (ROOT / pattern["dossier_path"]).read_text(encoding="utf-8")
                if pattern["pattern_id"] == "P02":
                    text = text.replace(pattern["benchmarks"][0]["url"], "URL_REMOVED")
                (target / pattern["dossier_path"]).write_text(text, encoding="utf-8")
            errors = MODULE.validate_index(target / "index.json", target)
            self.assertTrue(any("dossier must contain" in error for error in errors), errors)


if __name__ == "__main__":
    unittest.main()
