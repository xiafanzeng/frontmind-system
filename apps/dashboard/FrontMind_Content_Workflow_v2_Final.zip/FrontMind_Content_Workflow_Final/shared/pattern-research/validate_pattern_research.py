#!/usr/bin/env python3
"""Validate the FrontMind pattern research library without network access."""

from __future__ import annotations

import argparse
import ipaddress
import json
import re
import sys
from datetime import date
from pathlib import Path
from typing import Any
from urllib.parse import parse_qsl, urlsplit

EXPECTED_PATTERNS = [
    "P01-M", "P01-S", "P02", "P03", "P04", "P05", "P06", "P07",
    "P08", "P09", "P10", "P11", "P12", "P13", "P14", "P15",
]
MINIMUMS = {pattern_id: (12 if pattern_id in {"P01-M", "P01-S", "P13"} else 8)
            for pattern_id in EXPECTED_PATTERNS}
SOURCE_CLASSES = {
    "government_or_intergovernmental",
    "standards_or_nonprofit",
    "vendor_documentation",
    "consumer_editorial",
    "professional_guidance",
    "university_guidance",
    "peer_reviewed_research",
    "academic_preprint",
    "github_repository",
}
BENCHMARK_ARRAY_FIELDS = {
    "structure_observation",
    "subquestions_observed",
    "evidence_positions_observed",
    "visual_observation",
    "strengths",
    "weaknesses",
    "do_not_copy",
}
DESIGN_ARRAY_FIELDS = {
    "recommended_structure",
    "required_subquestions",
    "evidence_placement_rules",
    "visual_roles",
    "faq_topics",
    "quality_gates",
    "anti_patterns",
}
TRACKING_KEYS = {"ref", "source", "click", "msockid", "abtest"}
LONG_QUOTE = re.compile(r"[“\"]([^”\"]{160,})[”\"]")


def _nonempty_text(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _check_text_array(value: Any, label: str, errors: list[str], minimum: int = 1) -> None:
    if not isinstance(value, list) or len(value) < minimum:
        errors.append(f"{label}: expected at least {minimum} items")
        return
    for index, item in enumerate(value):
        if not _nonempty_text(item):
            errors.append(f"{label}[{index}]: expected non-empty text")


def _canonical_url(raw: Any, label: str, errors: list[str]) -> tuple[str, str] | None:
    if not _nonempty_text(raw):
        errors.append(f"{label}: missing URL")
        return None
    parts = urlsplit(raw)
    if parts.scheme != "https":
        errors.append(f"{label}: only https URLs are allowed")
    if not parts.hostname:
        errors.append(f"{label}: hostname is missing")
        return None
    if parts.username or parts.password or parts.port:
        errors.append(f"{label}: credentials and explicit ports are forbidden")
    hostname = parts.hostname.lower().rstrip(".")
    if hostname in {"localhost", "localhost.localdomain"} or hostname.endswith(".local"):
        errors.append(f"{label}: local host is forbidden")
    try:
        if ipaddress.ip_address(hostname).is_private:
            errors.append(f"{label}: private IP is forbidden")
    except ValueError:
        pass
    if parts.fragment:
        errors.append(f"{label}: fragments are forbidden; cite the stable page URL")
    for key, _ in parse_qsl(parts.query, keep_blank_values=True):
        if key.lower().startswith("utm_") or key.lower().startswith("hubs_") or key.lower() in TRACKING_KEYS:
            errors.append(f"{label}: tracking parameter {key!r} is forbidden")
    canonical = raw.rstrip("/")
    return canonical, hostname


def _walk_forbidden_quotes(value: Any, label: str, errors: list[str]) -> None:
    if isinstance(value, dict):
        if "quote" in value or "verbatim_quote" in value:
            errors.append(f"{label}: verbatim quote fields are forbidden")
        for key, item in value.items():
            _walk_forbidden_quotes(item, f"{label}.{key}", errors)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            _walk_forbidden_quotes(item, f"{label}[{index}]", errors)
    elif isinstance(value, str) and LONG_QUOTE.search(value):
        errors.append(f"{label}: possible long verbatim quotation (160+ chars)")


def validate_index(index_path: Path, dossier_root: Path | None = None, require_dossiers: bool = True) -> list[str]:
    errors: list[str] = []
    dossier_root = dossier_root or index_path.parent
    try:
        data = json.loads(index_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return [f"{index_path}: cannot read valid JSON: {exc}"]

    if data.get("schema_version") != "2.0.0":
        errors.append("root.schema_version: expected 2.0.0")
    if data.get("authority") != "research_reference_only":
        errors.append("root.authority: must remain research_reference_only")
    if data.get("canonical_runtime_authority") != "../content-pattern-registry.json":
        errors.append("root.canonical_runtime_authority: unexpected runtime authority")
    try:
        date.fromisoformat(data.get("accessed_at", ""))
    except (TypeError, ValueError):
        errors.append("root.accessed_at: expected ISO date")
    if data.get("required_pattern_ids") != EXPECTED_PATTERNS:
        errors.append("root.required_pattern_ids: exact ordered pattern set required")

    patterns = data.get("patterns")
    if not isinstance(patterns, list):
        return errors + ["root.patterns: expected array"]
    ids = [item.get("pattern_id") for item in patterns if isinstance(item, dict)]
    if ids != EXPECTED_PATTERNS:
        errors.append(f"root.patterns: expected exact order {EXPECTED_PATTERNS}, got {ids}")

    seen_urls: dict[str, str] = {}
    seen_domains: set[str] = set()
    seen_ids: set[str] = set()

    for p_index, pattern in enumerate(patterns):
        label = f"patterns[{p_index}]"
        if not isinstance(pattern, dict):
            errors.append(f"{label}: expected object")
            continue
        pattern_id = pattern.get("pattern_id")
        if pattern_id not in MINIMUMS:
            errors.append(f"{label}.pattern_id: unknown value {pattern_id!r}")
            continue
        expected_canonical = "P01" if pattern_id.startswith("P01-") else pattern_id
        if pattern.get("canonical_pattern_id") != expected_canonical:
            errors.append(f"{label}.canonical_pattern_id: expected {expected_canonical}")
        if pattern.get("minimum_benchmarks") != MINIMUMS[pattern_id]:
            errors.append(f"{label}.minimum_benchmarks: expected {MINIMUMS[pattern_id]}")
        if not _nonempty_text(pattern.get("pattern_name")):
            errors.append(f"{label}.pattern_name: missing")
        if not _nonempty_text(pattern.get("research_scope")):
            errors.append(f"{label}.research_scope: missing")

        design = pattern.get("design_contract")
        if not isinstance(design, dict):
            errors.append(f"{label}.design_contract: expected object")
        else:
            for field in DESIGN_ARRAY_FIELDS:
                _check_text_array(design.get(field), f"{label}.design_contract.{field}", errors, 2)

        dossier_path = pattern.get("dossier_path")
        if dossier_path != f"{pattern_id}.md":
            errors.append(f"{label}.dossier_path: expected {pattern_id}.md")
        dossier_text = ""
        if require_dossiers:
            dossier = dossier_root / str(dossier_path)
            try:
                dossier_text = dossier.read_text(encoding="utf-8")
            except OSError as exc:
                errors.append(f"{label}.dossier_path: cannot read {dossier}: {exc}")

        benchmarks = pattern.get("benchmarks")
        if not isinstance(benchmarks, list):
            errors.append(f"{label}.benchmarks: expected array")
            continue
        if len(benchmarks) < MINIMUMS[pattern_id]:
            errors.append(
                f"{label}.benchmarks: {len(benchmarks)} is below minimum {MINIMUMS[pattern_id]}"
            )

        actual_classes: set[str] = set()
        for b_index, benchmark in enumerate(benchmarks):
            b_label = f"{label}.benchmarks[{b_index}]"
            if not isinstance(benchmark, dict):
                errors.append(f"{b_label}: expected object")
                continue
            expected_id = f"{pattern_id.replace('-', '')}-B{b_index + 1:02d}"
            benchmark_id = benchmark.get("benchmark_id")
            if benchmark_id != expected_id:
                errors.append(f"{b_label}.benchmark_id: expected {expected_id}")
            if benchmark_id in seen_ids:
                errors.append(f"{b_label}.benchmark_id: duplicate {benchmark_id}")
            seen_ids.add(str(benchmark_id))
            if not _nonempty_text(benchmark.get("title")):
                errors.append(f"{b_label}.title: missing")
            parsed = _canonical_url(benchmark.get("url"), f"{b_label}.url", errors)
            if parsed:
                canonical, hostname = parsed
                prior = seen_urls.get(canonical)
                if prior:
                    errors.append(f"{b_label}.url: duplicate of {prior}: {canonical}")
                else:
                    seen_urls[canonical] = benchmark_id
                if benchmark.get("domain") != hostname.removeprefix("www."):
                    errors.append(f"{b_label}.domain: expected {hostname.removeprefix('www.')}")
                seen_domains.add(hostname.removeprefix("www."))
            source_class = benchmark.get("source_class")
            if source_class not in SOURCE_CLASSES:
                errors.append(f"{b_label}.source_class: unsupported {source_class!r}")
            else:
                actual_classes.add(source_class)
            try:
                date.fromisoformat(benchmark.get("accessed_at", ""))
            except (TypeError, ValueError):
                errors.append(f"{b_label}.accessed_at: expected ISO date")
            access = benchmark.get("access_evidence")
            if not isinstance(access, dict):
                errors.append(f"{b_label}.access_evidence: expected object")
            else:
                if access.get("verified_via") not in {"web_search_result", "page_open"}:
                    errors.append(f"{b_label}.access_evidence.verified_via: unsupported")
                if access.get("status") not in {"indexed_and_metadata_reviewed", "page_opened"}:
                    errors.append(f"{b_label}.access_evidence.status: unsupported")
                try:
                    date.fromisoformat(access.get("checked_at", ""))
                except (TypeError, ValueError):
                    errors.append(f"{b_label}.access_evidence.checked_at: expected ISO date")
            for field in BENCHMARK_ARRAY_FIELDS:
                _check_text_array(benchmark.get(field), f"{b_label}.{field}", errors, 2)
            for field in ("faq_observation", "selection_rationale", "audit_note"):
                if not _nonempty_text(benchmark.get(field)):
                    errors.append(f"{b_label}.{field}: missing")
            if dossier_text and (
                str(benchmark_id) not in dossier_text or str(benchmark.get("url")) not in dossier_text
            ):
                errors.append(f"{b_label}: dossier must contain benchmark id and exact URL")

        if len(actual_classes) < 3:
            errors.append(f"{label}.benchmarks: need >=3 source classes, got {sorted(actual_classes)}")
        summary = pattern.get("source_class_summary")
        if summary != sorted(actual_classes):
            errors.append(f"{label}.source_class_summary: must equal sorted actual classes")

    if len(seen_urls) < sum(MINIMUMS.values()):
        errors.append(
            f"root: only {len(seen_urls)} globally unique URLs; expected at least {sum(MINIMUMS.values())}"
        )
    actual_statistics = {
        "dossier_count": len(patterns),
        "benchmark_count": sum(
            len(pattern.get("benchmarks", []))
            for pattern in patterns
            if isinstance(pattern, dict) and isinstance(pattern.get("benchmarks"), list)
        ),
        "unique_url_count": len(seen_urls),
        "unique_domain_count": len(seen_domains),
    }
    if data.get("statistics") != actual_statistics:
        errors.append(
            f"root.statistics: expected computed values {actual_statistics}, "
            f"got {data.get('statistics')!r}"
        )
    _walk_forbidden_quotes(data, "root", errors)
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "index",
        nargs="?",
        type=Path,
        default=Path(__file__).with_name("index.json"),
    )
    parser.add_argument("--dossier-root", type=Path)
    parser.add_argument("--index-only", action="store_true", help="validate the complete machine index without requiring Markdown dossiers")
    args = parser.parse_args()
    errors = validate_index(args.index.resolve(), args.dossier_root, require_dossiers=not args.index_only)
    if errors:
        print(f"FAIL: {len(errors)} validation error(s)", file=sys.stderr)
        for error in errors:
            print(f"- {error}", file=sys.stderr)
        return 1
    data = json.loads(args.index.read_text(encoding="utf-8"))
    count = sum(len(pattern["benchmarks"]) for pattern in data["patterns"])
    print(
        f"PASS: {len(data['patterns'])} dossiers, {count} globally unique benchmarks, "
        "all quotas/fields/URLs/source-diversity checks satisfied"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
