#!/usr/bin/env python3
"""Regression tests for the stdlib-only JSON Schema runtime."""

from __future__ import annotations

import copy
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from validate_json_instance import (
    JsonSchemaValidator,
    ReferenceResolutionError,
    load_json,
    validate_instance,
)


SHARED = Path(__file__).resolve().parents[1]
FIXTURE = SHARED / "fixtures" / "minimal_reference_pack"
HASH = "a" * 64
STAMP = "2026-08-10T00:00:00+08:00"


def fixture_information_evidence_path() -> Path:
    """Follow the v2 canonical fixture name while tolerating the in-flight rename."""
    canonical = FIXTURE / "writing" / "information_evidence.json"
    return canonical if canonical.exists() else FIXTURE / "writing" / "information_evidence_architecture.json"


def valid_content_job() -> dict:
    return {
        "schema_version": "2.0.0",
        "job_id": "job_schema_runtime_001",
        "pack_id": "rp_schema_runtime_001",
        "created_at": STAMP,
        "entry_category": "reputation",
        "task": {
            "question_text": "示例企业是否适合当前决策需求？",
            "question_origin": "external_confirmed",
            "foundation_subject": None,
            "manual_foundation_selection": False,
            "requested_pattern_variant": None,
            "product_scenario_subintent": None,
        },
        "scope_analysis_path": "job/scope_analysis.json",
        "monitoring_input_path": "monitoring/micro_tracking.json",
        "optimizer_target": {"dataset": "fixture", "engine_llm": "fixture-model"},
        "deliverables": {"docx_body": True, "html_body_fragment": True, "title_map": True},
        "editorial_profile": "third_party_objective_with_evidence_based_brand_promotion",
    }


def valid_scope_analysis() -> dict:
    return {
        "schema_version": "2.0.0",
        "job_id": "job_schema_runtime_001",
        "geographic_scope": {
            "status": "not_applicable",
            "value": None,
            "basis": ["问题与价格、法规和候选范围均无地区依赖。"],
        },
        "decision_context": {
            "roles": ["方案评估者"],
            "problem": "判断示例企业是否符合当前的决策需求。",
            "decision_criteria": ["适用条件", "能力边界", "证据完整性"],
            "professional_depth": "professional",
        },
        "time_basis": {
            "as_of": "2026-08-10",
            "freshness_class": "moderate",
            "valid_until": None,
            "basis": ["以 Reference Pack 与监控资料的最新日期为准。"],
        },
        "inference_basis": {
            "knowledge_ids": ["kn_fixture_identity"],
            "source_ids": ["src_fixture_official"],
            "monitoring_observation_ids": ["observation_1"],
            "notes": ["未发现需要用户补充的实质性范围分歧。"],
        },
        "clarification": {
            "status": "not_required",
            "question": None,
            "answer": None,
            "material_effect": None,
        },
    }


def valid_monitoring() -> dict:
    return {
        "schema_version": "2.0.0",
        "job_id": "job_schema_runtime_001",
        "question": "示例企业是否适合目标用户？",
        "captured_at": STAMP,
        "analysis_status": "available",
        "input_files": {
            "answers_table_path": "inputs/answers.csv",
            "sources_table_path": "inputs/sources.csv",
            "answers_table_sha256": HASH,
            "sources_table_sha256": HASH,
        },
        "answers": [
            {
                "answer_id": "answer_1",
                "platform": "example-ai",
                "sampled_at": STAMP,
                "answer_text": "这是用于运行时测试的回答。",
                "citations": [{"citation_id": "citation_1", "url": "https://example.com/a"}],
            }
        ],
        "source_observations": [
            {
                "observation_id": "observation_1",
                "url": "https://example.com/a",
                "retrieval_status": "retrieved",
                "question_similarity": 0.9,
            }
        ],
        "derived": {
            "competitors": [],
            "excluded_observations": [],
            "answer_landscape": [
                {
                    "platform": "example-ai",
                    "answer_id": "answer_1",
                    "direct_answer": "测试回答直接回应了问题。",
                    "entities": ["示例企业"],
                    "stance": "neutral",
                    "dimensions": ["适合对象"],
                    "unanswered_subquestions": [],
                }
            ],
            "benchmark_observation_ids": ["observation_1"],
            "benchmark_pages": [
                {
                    "observation_id": "observation_1",
                    "similarity": 0.9,
                    "content_form": "分析文章",
                    "opening_answer_function": "直接回答",
                    "section_sequence": ["结论", "证据", "建议"],
                    "covered_subquestions": ["适合对象"],
                    "comparison_dimensions": [],
                    "evidence_placement": ["结论之后"],
                    "conditional_recommendation": "在满足条件时采用。",
                    "limitations_and_alternatives": ["不适合缺少数据的场景"],
                    "faq_topics": ["适合谁"],
                    "visual_argument_roles": ["explain"],
                    "strengths": ["直接回答"],
                    "gaps": ["样本有限"],
                    "borrowable_abstract_patterns": ["先结论后证据"],
                    "non_borrowable_elements": ["原文措辞"],
                }
            ],
            "supplementary_primary_sources": [],
            "recurring_subquestions": ["适合谁"],
            "structure_findings": ["采用问题式小标题"],
            "warnings": [],
        },
    }


def valid_blueprint() -> dict:
    sections = []
    for index in range(1, 6):
        sections.append(
            {
                "section_id": f"sec_part_{index}",
                "h2_question": f"第{index}个必要判断是什么？",
                "answer_goal": "回答该子问题并形成可执行判断。",
                "section_conclusion": "本节先给出清晰且有限定条件的结论。",
                "evidence_strategy": "使用已登记来源与明确口径支持结论。",
                "reader_advice": "按自身条件核对。",
                "claim_ids": [],
                "suggested_length": 300,
            }
        )
    faqs = []
    for index in range(1, 6):
        faqs.append(
            {
                "question": f"第{index}个常见问题是什么？",
                "answer_plan": "直接回答问题，再说明证据、适用条件、限制和下一步核对方法。" + "答" * 20,
                "claim_ids": [],
                "intent_tag": "evaluation",
                "provenance": {"kind": "derived_from_primary_question", "reference_ids": []},
            }
        )
    return {
        "schema_version": "2.0.0",
        "job_id": "job_schema_runtime_001",
        "entry_category": "reputation",
        "primary_question": "示例企业是否适合当前决策需求？",
        "question_origin": "external_confirmed",
        "scope_analysis_ref": {"path": "job/scope_analysis.json", "sha256": HASH},
        "product_scenario_subintent": None,
        "pattern_id": "P04",
        "pattern_variant": None,
        "routing_reason": "该问题要求解释定义、适用条件与判断边界，因此采用机制解释结构。",
        "priority_angle": None,
        "candidate_contract": None,
        "question_contract": {
            "primary_question": "示例企业是否适合当前决策需求？",
            "primary_intent_tag": "evaluation",
            "secondary_intent_tags": ["risk"],
            "direct_decision": "读者需要判断该企业是否适合自己的具体使用条件。",
            "necessary_subquestions": [f"必要子问题{i}" for i in range(1, 6)],
            "misconceptions": [],
            "decision_concerns": ["证据是否适用于当前场景"],
            "objections": [],
            "alternatives": [],
            "evidence_needed": ["官方说明与适用边界"],
            "brand_intervention": {
                "entry_section_ids": ["sec_part_3"],
                "rationale": "只在证据能够支撑的判断位置引入品牌。",
                "supported_claim_ids": [],
                "non_promotional_boundary": "不得把未验证信息改写成确定性宣传结论。",
            },
        },
        "benchmark_fusion": {
            "status": "available",
            "monitoring_input_sha256": HASH,
            "benchmark_decisions": [
                {
                    "observation_id": "obs_1",
                    "disposition": "adopted",
                    "adopted_elements": ["先结论后证据"],
                    "rationale": "该抽象结构能缩短读者获得判断所需的路径。",
                }
            ],
            "structure_finding_indexes": [0],
            "retained_template_elements": ["问题式小标题"],
            "benchmark_elements_adopted": ["先结论后证据"],
            "elements_rejected": ["无来源断言"],
            "final_structure_rationale": "结构同时覆盖核心问题与五个必要子问题。",
        },
        "title_formula_plan": {
            "formula": "年份＋必要场景＋核心品类＋内容形态＋决策问题",
            "allowed_type_words": ["评测", "指南"],
            "temporal_rule": "只有正文事实已更新到对应年份时才能使用年份。",
            "forbidden_promises": ["行业第一", "最佳"],
        },
        "lead_plan": {
            "direct_answer_sentence": "结" * 40,
            "micro_answer_plan": "先直接回答，再说明判断标准、证据、适合对象、时间范围和必要限制。" + "答" * 20,
            "claim_ids": ["clm_fixture_scope"],
            "required_elements": [
                "explicit_conclusion",
                "judgment_criteria",
                "decision_context",
                "time_basis",
                "necessary_qualification",
                "named_entities",
            ],
        },
        "section_plan": sections,
        "claim_plan": [],
        "visual_plan": [],
        "faq_plan": faqs,
        "conclusion_plan": {
            "summary_decision": "总结已展开的适用性判断与限制条件。",
            "fit_audience": "符合前述条件的目标读者。",
            "next_action": "核对来源与条件。",
            "forbid_new_points": True,
            "claim_ids": ["clm_fixture_scope"],
        },
        "evidence_readiness": {
            "status": "ready_with_claim_limits",
            "missing_evidence": [],
            "claim_limitations": ["不将第一方事实推导为市场口碑或行业排名。"],
            "first_party_publication_basis": ["src_fixture_official"],
        },
    }


def valid_content_model() -> dict:
    sections = []
    coverage = []
    for index in range(1, 6):
        section_id = f"sec_part_{index}"
        sections.append(
            {
                "section_id": section_id,
                "h2_question": f"第{index}个必要判断是什么？",
                "blocks": [
                    {
                        "block_id": f"blk_part_{index}",
                        "type": "paragraph",
                        "content_function": "advice",
                        "text": "先给结论，再给证据，最后给出适用建议。",
                        "claim_ids": [],
                    }
                ],
            }
        )
        coverage.append({"subquestion": f"必要子问题{index}", "section_ids": [section_id]})
    faq = [
        {
            "question": f"第{index}个常见问题是什么？",
            "answer": "这是一条包含判断条件、适用边界和核对方法的完整回答。",
            "content_function": "decision_advice",
            "claim_ids": [],
        }
        for index in range(1, 6)
    ]
    return {
        "schema_version": "2.0.0",
        "job_id": "job_schema_runtime_001",
        "revision": 1,
        "entry_category": "reputation",
        "primary_question": "示例企业是否适合当前决策需求？",
        "question_origin": "external_confirmed",
        "product_scenario_subintent": None,
        "pattern_id": "P04",
        "pattern_variant": None,
        "candidate_contract": None,
        "metadata": {
            "language": "zh-CN",
            "as_of": "2026-08-10",
        },
        "lead": {
            "direct_answer_sentence": "答" * 40,
            "micro_answer": "微" * 200,
            "claim_ids": ["clm_fixture_scope"],
        },
        "sections": sections,
        "subquestion_coverage": coverage,
        "faq": faq,
        "conclusion": {
            "summary": "总结前文已经展开的判断、证据、适用条件与限制范围。",
            "fit": "适合能够满足前述条件并核对来源的目标读者。",
            "next_action": "核对实际条件后行动。",
            "claim_ids": ["clm_fixture_scope"],
        },
        "references": [],
        "visual_placements": [],
        "structured_data_types": ["Article", "FAQPage"],
    }


def valid_quality_report() -> dict:
    gate_ids = [
        "question_answered",
        "micro_answer_complete",
        "claim_evidence_complete",
        "statistics_and_price_scoped",
        "competitor_fairness",
        "entity_clarity",
        "freshness_and_dates",
        "first_party_publication_and_claim_limits",
        "faq_relevance",
        "pattern_consistency",
        "voice_and_no_meta_language",
        "visual_argument_and_rights",
    ]
    return {
        "schema_version": "2.0.0",
        "job_id": "job_schema_runtime_001",
        "stage": "E8_pre_optimization",
        "content_model_sha256": HASH,
        "overall_status": "pass",
        "gates": [{"gate_id": gate_id, "status": "pass", "evidence": "测试通过。"} for gate_id in gate_ids],
        "blocking_issues": [],
        "warnings": [],
    }


def valid_delivery_manifest() -> dict:
    roles = [
        "docx_body",
        "html_body_fragment",
        "structured_data_template",
        "title_options_markdown",
        "title_map",
        "publishing_metadata_map",
    ]
    return {
        "schema_version": "2.0.0",
        "job_id": "job_schema_runtime_001",
        "created_at": STAMP,
        "selected_revision": "editorial_master",
        "source_equivalence": {
            "content_model_sha256": HASH,
            "docx_rendered_from_same_model": True,
            "html_rendered_from_same_model": True,
            "title_map_bound_to_same_model": True,
            "structured_data_template_bound_to_title_map": True,
        },
        "artifacts": [
            {"role": role, "path": f"delivery/{role}", "sha256": HASH, "media_type": "application/json"}
            for role in roles
        ],
        "optimization": {"attempted": False, "candidate_selected": False, "fact_diff_status": "not_run"},
    }


def valid_runtime_evidence_extension() -> dict:
    return {
        "schema_version": "2.0.0",
        "job_id": "job_schema_runtime_001",
        "sources": [],
        "claims": [],
        "evidence_files": [],
    }


def valid_title_count_receipt() -> dict:
    return {
        "schema_version": "2.0.0",
        "job_id": "job_schema_runtime_001",
        "approved_body_sha256": HASH,
        "requested_count": 2,
        "requested_by": "fixture-editor",
        "requested_at": STAMP,
        "requirements": ["标题不得超过正文已支持的事实强度。"],
    }


def valid_title_map() -> dict:
    return {
        "schema_version": "2.0.0",
        "job_id": "job_schema_runtime_001",
        "approved_body_sha256": HASH,
        "requested_count": 2,
        "generated_at": STAMP,
        "options": [
            {
                "title_id": f"ttl_fixture_{index}",
                "title_text": f"示例企业适用性评测与决策指南{index}",
                "h1_suggestion": f"示例企业适用性评测与决策指南{index}",
                "meta_description": "围绕示例企业的适用条件、能力边界与证据完整性，提供可核对的决策信息和条件式建议。",
                "title_formula": "核心实体＋评测＋具体决策问题",
                "angle_tag": "适用性判断",
                "temporal_basis": None,
                "support_claim_ids": ["clm_fixture_scope"],
                "referenced_entity_names": ["示例企业"],
                "risk_checks": {
                    "body_supported": True,
                    "no_new_entity": True,
                    "no_new_number": True,
                    "no_objective_rank_claim": True,
                    "time_basis_valid": True,
                    "passed": True,
                },
            }
            for index in range(1, 3)
        ],
    }


class RuntimeKeywordTests(unittest.TestCase):
    def test_supported_keyword_subset_and_error_paths(self) -> None:
        schema = {
            "type": "object",
            "required": ["name", "count", "tags", "when", "where"],
            "additionalProperties": {"type": "boolean"},
            "properties": {
                "name": {"type": "string", "minLength": 2, "maxLength": 5, "pattern": "^[a-z]+$"},
                "count": {"type": "integer", "minimum": 1, "maximum": 3},
                "tags": {"type": "array", "items": {"enum": ["a", "b"]}, "minItems": 1, "maxItems": 2, "uniqueItems": True},
                "when": {"type": "string", "format": "date-time"},
                "where": {"type": "string", "format": "uri"},
            },
            "allOf": [{"properties": {"name": {"const": "alpha"}}}],
            "if": {"properties": {"count": {"const": 3}}, "required": ["count"]},
            "then": {"required": ["approved"]},
            "else": {"properties": {"approved": {"const": False}}},
        }
        instance = {
            "name": "alpha",
            "count": 3,
            "tags": ["a", "b"],
            "when": STAMP,
            "where": "https://example.com/a",
            "approved": True,
        }
        with tempfile.TemporaryDirectory() as temp:
            schema_path = Path(temp) / "schema.json"
            errors = validate_instance(instance, schema, schema_path)
            self.assertEqual(errors, [])
            invalid = copy.deepcopy(instance)
            invalid["tags"] = ["a", "a"]
            invalid["where"] = "not a uri"
            errors = validate_instance(invalid, schema, schema_path)
        self.assertEqual({error.keyword for error in errors}, {"uniqueItems", "format"})
        self.assertIn("$.tags[1]", {error.json_path for error in errors})
        self.assertIn("$.where", {error.json_path for error in errors})
        self.assertTrue(all(error.schema_path for error in errors))

    def test_one_of_any_of_and_integer_rejects_boolean(self) -> None:
        schema = {
            "type": "object",
            "required": ["value", "choice"],
            "properties": {
                "value": {"type": "integer"},
                "choice": {"oneOf": [{"const": "a"}, {"const": "b"}]},
                "nullable": {"anyOf": [{"type": "string"}, {"type": "null"}]},
            },
        }
        with tempfile.TemporaryDirectory() as temp:
            schema_path = Path(temp) / "schema.json"
            self.assertEqual(validate_instance({"value": 1.0, "choice": "a", "nullable": None}, schema, schema_path), [])
            errors = validate_instance({"value": True, "choice": "c", "nullable": 1}, schema, schema_path)
        self.assertEqual({error.keyword for error in errors}, {"type", "oneOf", "anyOf"})

    def test_not_and_prefix_items_follow_draft_2020(self) -> None:
        schema = {
            "type": "array",
            "minItems": 2,
            "prefixItems": [{"const": "featured"}],
            "items": {"not": {"const": "featured"}},
        }
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "schema.json"
            self.assertEqual(validate_instance(["featured", "other"], schema, path), [])
            errors = validate_instance(["other", "featured"], schema, path)
        self.assertEqual({error.keyword for error in errors}, {"const", "not"})

    def test_formats_use_real_parsing(self) -> None:
        schema = {
            "type": "object",
            "properties": {
                "day": {"type": "string", "format": "date"},
                "instant": {"type": "string", "format": "date-time"},
                "url": {"type": "string", "format": "uri"},
            },
        }
        bad = {"day": "2026-02-30", "instant": "2026-08-10T12:00:00", "url": "https://exa mple.com"}
        with tempfile.TemporaryDirectory() as temp:
            errors = validate_instance(bad, schema, Path(temp) / "schema.json")
        self.assertEqual(len(errors), 3)
        self.assertTrue(all(error.keyword == "format" for error in errors))

    def test_relative_ref_cycle_and_escape_control(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            defs = root / "defs.json"
            defs.write_text(
                json.dumps({"$defs": {"identifier": {"type": "string", "pattern": "^id_"}}}),
                encoding="utf-8",
            )
            schema = {"$ref": "defs.json#/$defs/identifier"}
            validator = JsonSchemaValidator(root / "entry.json", schema=schema)
            self.assertEqual(validator.validate("id_ok"), [])
            self.assertEqual(validator.validate("bad")[0].keyword, "pattern")

            cyclic = JsonSchemaValidator(root / "cycle.json", schema={"$ref": "#"})
            self.assertEqual(cyclic.validate({"finite": True}), [])

            unsafe = JsonSchemaValidator(root / "unsafe.json", schema={"$ref": "../outside.json"})
            with self.assertRaises(ReferenceResolutionError):
                unsafe.validate({})

    def test_cli_exit_codes_and_report(self) -> None:
        runtime = Path(__file__).with_name("validate_json_instance.py")
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            schema = root / "schema.json"
            valid = root / "valid.json"
            invalid = root / "invalid.json"
            report = root / "report.json"
            schema.write_text('{"type":"integer"}', encoding="utf-8")
            valid.write_text("1", encoding="utf-8")
            invalid.write_text("true", encoding="utf-8")

            passed = subprocess.run(
                [sys.executable, str(runtime), str(schema), str(valid), "--report", str(report)],
                check=False,
                capture_output=True,
                text=True,
            )
            failed = subprocess.run(
                [sys.executable, str(runtime), str(schema), str(invalid)],
                check=False,
                capture_output=True,
                text=True,
            )
            runtime_error = subprocess.run(
                [sys.executable, str(runtime), str(root / "missing.json"), str(valid)],
                check=False,
                capture_output=True,
                text=True,
            )
            self.assertEqual(passed.returncode, 0, passed.stderr)
            self.assertTrue(json.loads(report.read_text(encoding="utf-8"))["valid"])
            self.assertEqual(failed.returncode, 1, failed.stderr)
            self.assertEqual(runtime_error.returncode, 2, runtime_error.stderr)


class ProjectSchemaTests(unittest.TestCase):
    @classmethod
    def valid_root_instances(cls) -> dict[str, dict]:
        return {
            "reference_pack.schema.json": load_json(FIXTURE / "reference_pack.json"),
            "brand_facts.schema.json": load_json(FIXTURE / "brand" / "brand_facts.json"),
            "registries.schema.json": load_json(FIXTURE / "registries" / "knowledge_registry.json"),
            "content_job.schema.json": valid_content_job(),
            "scope_analysis.schema.json": valid_scope_analysis(),
            "monitoring_input.schema.json": valid_monitoring(),
            "article_blueprint.schema.json": valid_blueprint(),
            "content_model.schema.json": valid_content_model(),
            "quality_report.schema.json": valid_quality_report(),
            "delivery_manifest.schema.json": valid_delivery_manifest(),
            "runtime_evidence_extension.schema.json": valid_runtime_evidence_extension(),
            "title_count_receipt.schema.json": valid_title_count_receipt(),
            "title_map.schema.json": valid_title_map(),
            "information_evidence_architecture.schema.json": load_json(fixture_information_evidence_path()),
        }

    def test_every_root_schema_accepts_typical_valid_and_rejects_negative(self) -> None:
        discovered = {path.name for path in SHARED.glob("*.schema.json")}
        instances = self.valid_root_instances()
        self.assertEqual(discovered, set(instances), "add an explicit positive example for every root schema")
        for name, instance in instances.items():
            with self.subTest(schema=name, case="positive"):
                schema_path = SHARED / name
                errors = JsonSchemaValidator(schema_path).validate(instance)
                self.assertEqual(errors, [], [error.to_dict() for error in errors])
            with self.subTest(schema=name, case="negative"):
                invalid = copy.deepcopy(instance)
                invalid["schema_version"] = "9.9.9"
                errors = JsonSchemaValidator(SHARED / name).validate(invalid)
                self.assertTrue(errors)
                expected_keywords = {"oneOf"} if name == "registries.schema.json" else {"const"}
                self.assertTrue(expected_keywords & {error.keyword for error in errors})

    def test_all_fixture_instances_with_canonical_schema_are_valid(self) -> None:
        cases = [
            ("reference_pack.schema.json", FIXTURE / "reference_pack.json"),
            ("brand_facts.schema.json", FIXTURE / "brand" / "brand_facts.json"),
            ("registries.schema.json", FIXTURE / "registries" / "knowledge_registry.json"),
            ("registries.schema.json", FIXTURE / "registries" / "source_registry.json"),
            ("registries.schema.json", FIXTURE / "registries" / "claim_registry.json"),
            ("registries.schema.json", FIXTURE / "registries" / "image_registry.json"),
        ]
        for schema_name, instance_path in cases:
            with self.subTest(instance=str(instance_path.relative_to(FIXTURE))):
                errors = JsonSchemaValidator(SHARED / schema_name).validate_path(instance_path)
                self.assertEqual(errors, [], [error.to_dict() for error in errors])

    def test_content_job_accepts_all_five_entries_and_enforces_manual_fields(self) -> None:
        schema = JsonSchemaValidator(SHARED / "content_job.schema.json")
        jobs = {}
        for entry in ("industry_ranking", "competitor_comparison", "reputation", "product_scenario"):
            job = valid_content_job()
            job["entry_category"] = entry
            job["task"]["requested_pattern_variant"] = (
                "multi_brand_editorial_recommendation" if entry == "industry_ranking" else None
            )
            job["task"]["product_scenario_subintent"] = "scenario_fit" if entry == "product_scenario" else None
            jobs[entry] = job

        foundation = valid_content_job()
        foundation["entry_category"] = "foundation_start"
        foundation["task"] = {
            "question_text": None,
            "question_origin": "foundation_derived",
            "foundation_subject": "示例企业品牌深度特写",
            "manual_foundation_selection": True,
            "requested_pattern_variant": None,
            "product_scenario_subintent": None,
        }
        foundation["monitoring_input_path"] = None
        jobs["foundation_start"] = foundation

        for entry, job in jobs.items():
            with self.subTest(entry=entry):
                self.assertEqual(schema.validate(job), [])

        bad_industry = copy.deepcopy(jobs["industry_ranking"])
        bad_industry["task"]["requested_pattern_variant"] = None
        self.assertTrue(schema.validate(bad_industry))

        bad_foundation = copy.deepcopy(foundation)
        bad_foundation["task"]["question_text"] = "用户不应为基础启动填写问题？"
        bad_foundation["monitoring_input_path"] = "monitoring/not-allowed.json"
        self.assertTrue(schema.validate(bad_foundation))

    def test_p01_variants_candidate_contract_and_foundation_p13_bijection(self) -> None:
        schema = JsonSchemaValidator(SHARED / "article_blueprint.schema.json")

        multi = valid_blueprint()
        multi.update(
            {
                "entry_category": "industry_ranking",
                "pattern_id": "P01",
                "pattern_variant": "multi_brand_editorial_recommendation",
                "priority_angle": {
                    "angle_id": "angle_fixture_priority",
                    "angle": "从已审批的适用性证据角度首先介绍客户品牌。",
                    "proof_bundle_ids": ["proof_fixture"],
                    "claim_ids": ["clm_fixture_scope"],
                    "editorial_priority_only": True,
                },
                "candidate_contract": {
                    "featured_brand_name": "示例企业",
                    "ordered_candidates": [
                        {"entity_name": "示例企业", "role": "featured_brand", "source_ids": ["src_fixture_official"]},
                        {"entity_name": "候选乙", "role": "other_candidate", "source_ids": ["src_candidate_b"]},
                        {"entity_name": "候选丙", "role": "other_candidate", "source_ids": ["src_candidate_c"]},
                    ],
                    "common_dimensions": ["适用条件", "能力边界"],
                    "list_semantics": "editorial_recommendation",
                },
            }
        )
        self.assertEqual(schema.validate(multi), [])

        single = copy.deepcopy(multi)
        single["pattern_variant"] = "single_brand_recommendation"
        single["priority_angle"] = None
        single["candidate_contract"]["ordered_candidates"] = single["candidate_contract"]["ordered_candidates"][:1]
        single["candidate_contract"]["common_dimensions"] = []
        self.assertEqual(schema.validate(single), [])

        bad_first = copy.deepcopy(multi)
        bad_first["candidate_contract"]["ordered_candidates"][0]["role"] = "other_candidate"
        self.assertTrue(schema.validate(bad_first))

        bad_single = copy.deepcopy(single)
        bad_single["candidate_contract"]["ordered_candidates"].append(
            {"entity_name": "候选乙", "role": "other_candidate", "source_ids": ["src_candidate_b"]}
        )
        self.assertTrue(schema.validate(bad_single))

        foundation = valid_blueprint()
        foundation.update(
            {
                "entry_category": "foundation_start",
                "pattern_id": "P13",
                "question_origin": "foundation_derived",
            }
        )
        foundation["benchmark_fusion"].update(
            {"status": "foundation_template_only", "monitoring_input_sha256": None, "benchmark_decisions": []}
        )
        self.assertEqual(schema.validate(foundation), [])

        wrong_foundation = copy.deepcopy(foundation)
        wrong_foundation["pattern_id"] = "P04"
        self.assertTrue(schema.validate(wrong_foundation))
        wrong_external = valid_blueprint()
        wrong_external["pattern_id"] = "P13"
        self.assertTrue(schema.validate(wrong_external))

    def test_content_model_is_title_free_and_foundation_route_is_closed(self) -> None:
        schema = JsonSchemaValidator(SHARED / "content_model.schema.json")
        model = valid_content_model()
        self.assertEqual(schema.validate(model), [])

        titled = copy.deepcopy(model)
        titled["metadata"]["title"] = "正文模型不得携带标题"
        self.assertTrue(schema.validate(titled))

        foundation = copy.deepcopy(model)
        foundation.update(
            {
                "entry_category": "foundation_start",
                "pattern_id": "P13",
                "question_origin": "foundation_derived",
            }
        )
        self.assertEqual(schema.validate(foundation), [])
        foundation["pattern_id"] = "P04"
        self.assertTrue(schema.validate(foundation))

    def test_title_count_boundaries_and_title_map_shape(self) -> None:
        receipt_schema = JsonSchemaValidator(SHARED / "title_count_receipt.schema.json")
        for value in (1, 20):
            receipt = valid_title_count_receipt()
            receipt["requested_count"] = value
            self.assertEqual(receipt_schema.validate(receipt), [])
        for value in (0, 21, True, 1.5):
            receipt = valid_title_count_receipt()
            receipt["requested_count"] = value
            self.assertTrue(receipt_schema.validate(receipt))

        title_schema = JsonSchemaValidator(SHARED / "title_map.schema.json")
        self.assertEqual(title_schema.validate(valid_title_map()), [])
        bad = valid_title_map()
        del bad["options"][0]["referenced_entity_names"]
        self.assertTrue(title_schema.validate(bad))


if __name__ == "__main__":
    unittest.main(verbosity=2)
