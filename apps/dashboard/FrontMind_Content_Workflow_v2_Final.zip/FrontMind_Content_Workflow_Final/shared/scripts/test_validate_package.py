#!/usr/bin/env python3
"""Adversarial regression tests for the standalone Reference Pack trust gate."""

from __future__ import annotations

import copy
import hashlib
import json
import shutil
import tempfile
import unittest
import zipfile
from pathlib import Path

from validate_json_instance import JsonSchemaValidator, load_json
from validate_package import DirectoryView, ZipView, validate


PACKAGE_ROOT = Path(__file__).resolve().parents[2]
SHARED = PACKAGE_ROOT / "shared"
FIXTURE = SHARED / "fixtures/minimal_reference_pack"


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_json(root: Path, relative: str) -> dict:
    return json.loads((root / relative).read_text("utf-8"))


def write_json(root: Path, relative: str, value: dict) -> bytes:
    data = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    (root / relative).write_bytes(data)
    return data


def rebind_file_record(root: Path, relative: str) -> None:
    pack = read_json(root, "reference_pack.json")
    data = (root / relative).read_bytes()
    for record in pack["files"]:
        if record["path"] == relative:
            record["sha256"] = digest(data)
            break
    else:
        raise AssertionError(f"fixture has no files[] record for {relative}")
    write_json(root, "reference_pack.json", pack)


def rebind_approval_input(root: Path, role: str, relative: str) -> None:
    receipt = read_json(root, "approval/approval.json")
    data = (root / relative).read_bytes()
    for item in receipt["input_files"]:
        if item["role"] == role:
            item["sha256"] = digest(data)
            item["bytes"] = len(data)
            break
    else:
        raise AssertionError(f"fixture has no approval input role {role}")
    write_json(root, "approval/approval.json", receipt)
    rebind_file_record(root, "approval/approval.json")


class ReferencePackTrustGateTests(unittest.TestCase):
    maxDiff = None

    def test_strict_anonymous_directory_and_zip_pass(self) -> None:
        directory_report = validate(DirectoryView(FIXTURE))
        self.assertEqual(directory_report["errors"], [], directory_report)
        self.assertEqual(directory_report["status"], "pass")
        with tempfile.TemporaryDirectory(prefix="frontmind-pack-zip-test-") as temporary:
            archive_path = Path(temporary) / "S9_匿名示例企业_reference_pack_v1.zip"
            with zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED) as archive:
                for path in sorted(FIXTURE.rglob("*")):
                    if path.is_file():
                        archive.write(path, path.relative_to(FIXTURE).as_posix())
            zip_report = validate(ZipView(archive_path))
        self.assertEqual(zip_report["errors"], [], zip_report)
        self.assertEqual(zip_report["status"], "pass")

    def test_empty_stages_and_forged_approved_receipt_fail_semantic_gates(self) -> None:
        with tempfile.TemporaryDirectory(prefix="frontmind-empty-stage-attack-") as temporary:
            root = Path(temporary) / "pack"
            shutil.copytree(FIXTURE, root)
            mutations = {
                "information_evidence_architecture": "writing/information_evidence_architecture.json",
                "voice_contract": "writing/voice_contract.json",
                "visual_reference": "writing/visual_reference.json",
                "question_library": "writing/question_library.json",
            }
            for role, relative in mutations.items():
                write_json(root, relative, {"schema_version": "2.0.0", "brand": "匿名示例企业"})
                rebind_file_record(root, relative)
                rebind_approval_input(root, role, relative)
            report = validate(DirectoryView(root))
        self.assertEqual(report["status"], "fail")
        joined = "\n".join(report["errors"])
        self.assertIn("schema required", joined)
        self.assertIn("semantic gate", joined)
        self.assertNotIn("Traceback", joined)

    def test_decorative_asset_cannot_be_spoofed_as_logo(self) -> None:
        with tempfile.TemporaryDirectory(prefix="frontmind-logo-attack-") as temporary:
            root = Path(temporary) / "pack"
            shutil.copytree(FIXTURE, root)
            registry = read_json(root, "registries/image_registry.json")
            registry["images"][0]["asset_kind"] = "decorative"
            write_json(root, "registries/image_registry.json", registry)
            rebind_file_record(root, "registries/image_registry.json")
            rebind_approval_input(root, "image_registry", "registries/image_registry.json")
            report = validate(DirectoryView(root))
        self.assertEqual(report["status"], "fail")
        joined = "\n".join(report["errors"])
        self.assertIn("asset_kind='logo'", joined)

    def test_review_receipt_must_cover_exact_canonical_object_set(self) -> None:
        with tempfile.TemporaryDirectory(prefix="frontmind-review-attack-") as temporary:
            root = Path(temporary) / "pack"
            shutil.copytree(FIXTURE, root)
            receipt = read_json(root, "approval/approval.json")
            receipt["review_decisions"] = [
                {"sheet": sheet, "object_id": f"dummy:{index}", "decision": "keep", "requested_change": "", "notes": ""}
                for index, sheet in enumerate(("声明与证据", "受众与话语", "问题覆盖", "视觉资产"), 1)
            ]
            write_json(root, "approval/approval.json", receipt)
            rebind_file_record(root, "approval/approval.json")
            report = validate(DirectoryView(root))
        self.assertEqual(report["status"], "fail")
        joined = "\n".join(report["errors"])
        self.assertIn("omits reviewable", joined)
        self.assertIn("contains unknown", joined)

    def test_normalized_kb_is_byte_bound_to_original_zip(self) -> None:
        with tempfile.TemporaryDirectory(prefix="frontmind-kb-splice-attack-") as temporary:
            root = Path(temporary) / "pack"
            shutil.copytree(FIXTURE, root)
            relative = "sources/knowledge_base/brand_overview.md"
            (root / relative).write_text("# Spliced knowledge\n", encoding="utf-8")
            rebind_file_record(root, relative)
            report = validate(DirectoryView(root))
        self.assertEqual(report["status"], "fail")
        self.assertIn("normalized KB file differs from original ZIP", "\n".join(report["errors"]))

    def test_generated_image_proof_role_contracts(self) -> None:
        registry = load_json(FIXTURE / "registries/image_registry.json")
        schema = SHARED / "registries.schema.json"
        explanatory = copy.deepcopy(registry)
        explanatory["images"][0]["source_kind"] = "generated_explanatory"
        explanatory["images"][0]["allowed_roles"] = ["entity_proof"]
        errors = JsonSchemaValidator(schema).validate(explanatory)
        self.assertTrue(errors, "generated explanatory image unexpectedly accepted an entity_proof role")
        chart = copy.deepcopy(registry)
        chart["images"][0]["source_kind"] = "generated_data_chart"
        chart["images"][0]["asset_kind"] = "data_visual"
        chart["images"][0]["allowed_roles"] = ["data_evidence"]
        chart["images"][0].pop("source_ids", None)
        errors = JsonSchemaValidator(schema).validate(chart)
        self.assertTrue(errors, "generated data chart unexpectedly passed without source_ids")

    def test_original_evidence_record_ref_must_be_hash_bound_pack_file(self) -> None:
        with tempfile.TemporaryDirectory(prefix="frontmind-original-record-attack-") as temporary:
            root = Path(temporary) / "pack"
            shutil.copytree(FIXTURE, root)
            registry = read_json(root, "registries/claim_registry.json")
            registry["claims"][0]["original_evidence"] = {
                "type": "independent_test",
                "authorization_status": "public_approved",
                "source_ids": [],
                "record_refs": ["evidence/does-not-exist.csv"],
                "methodology": "匿名夹具攻击测试",
                "scope": "单项记录",
                "collected_at": "2026-08-10T00:00:00Z",
                "limitations": [],
            }
            write_json(root, "registries/claim_registry.json", registry)
            rebind_file_record(root, "registries/claim_registry.json")
            rebind_approval_input(root, "claim_registry", "registries/claim_registry.json")
            report = validate(DirectoryView(root))
        self.assertEqual(report["status"], "fail")
        self.assertIn("not a hash-bound Pack file", "\n".join(report["errors"]))

    def test_first_party_origin_class_and_authorization_cannot_be_relabelled(self) -> None:
        with tempfile.TemporaryDirectory(prefix="frontmind-source-origin-attack-") as temporary:
            root = Path(temporary) / "pack"
            shutil.copytree(FIXTURE, root)
            registry = read_json(root, "registries/source_registry.json")
            registry["sources"][0]["source_origin_class"] = "third_party_public"
            write_json(root, "registries/source_registry.json", registry)
            rebind_file_record(root, "registries/source_registry.json")
            rebind_approval_input(root, "source_registry", "registries/source_registry.json")
            report = validate(DirectoryView(root))
        self.assertEqual(report["status"], "fail")
        self.assertIn("source_registry.json: schema", "\n".join(report["errors"]))

    def test_publication_authorization_bytes_are_bound_to_adapter_report(self) -> None:
        with tempfile.TemporaryDirectory(prefix="frontmind-publication-auth-attack-") as temporary:
            root = Path(temporary) / "pack"
            shutil.copytree(FIXTURE, root)
            relative = "diagnostics/S2_Anonymous_source_publication_authorizations.json"
            authorization = read_json(root, relative)
            authorization["authorizations"][0]["notes"] = "tampered after S2 approval"
            write_json(root, relative, authorization)
            # An attacker may make files[] internally self-consistent, but cannot
            # replace the S2 adapter handoff without invalidating its approved hash.
            rebind_file_record(root, relative)
            report = validate(DirectoryView(root))
        self.assertEqual(report["status"], "fail")
        self.assertIn(
            "authorization artifact hash differs from adapter_report",
            "\n".join(report["errors"]),
        )

    def test_template_research_index_is_bound_by_receipt_and_workbook(self) -> None:
        with tempfile.TemporaryDirectory(prefix="frontmind-pattern-research-attack-") as temporary:
            root = Path(temporary) / "pack"
            shutil.copytree(FIXTURE, root)
            index = read_json(root, "shared/pattern-research/index.json")
            index["fixture_tamper"] = "substituted after approval"
            write_json(root, "shared/pattern-research/index.json", index)
            rebind_file_record(root, "shared/pattern-research/index.json")
            rebind_approval_input(root, "pattern_research_index", "shared/pattern-research/index.json")
            report = validate(DirectoryView(root))
        self.assertEqual(report["status"], "fail")
        joined = "\n".join(report["errors"])
        self.assertIn("pattern_research_index_sha256", joined)
        self.assertIn("workbook:_meta input_files", joined)


if __name__ == "__main__":
    unittest.main(verbosity=2)
