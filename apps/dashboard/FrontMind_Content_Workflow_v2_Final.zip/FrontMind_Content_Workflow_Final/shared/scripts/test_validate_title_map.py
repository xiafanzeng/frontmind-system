#!/usr/bin/env python3
"""Regression tests for E10 title-count, evidence and entity invariants."""

from __future__ import annotations

import unittest

from validate_title_map import canonical_sha256, validate


BODY = {
    "schema_version": "2.0.0",
    "job_id": "job_fixture_title",
    "pattern_id": "P04",
    "metadata": {"language": "zh-CN", "as_of": "2026-08-11"},
    "lead": {"claim_ids": ["clm_title_001"], "direct_answer_sentence": "匿名品类应按事实和适用条件判断。"},
}
CLAIMS = {
    "schema_version": "2.0.0",
    "registry_type": "claim_registry",
    "claims": [
        {"claim_id": "clm_title_001", "about_entities": ["匿名品类"], "claim_text": "匿名品类有明确适用条件。"},
        {"claim_id": "clm_other_001", "about_entities": ["其他品牌"], "claim_text": "其他品牌是无关实体。"},
    ],
}
SHA = canonical_sha256(BODY)
LABELS = list("甲乙丙丁戊己庚辛壬癸子丑寅卯辰巳午未申酉")


def receipt(count: object = 1) -> dict:
    return {
        "schema_version": "2.0.0",
        "job_id": "job_fixture_title",
        "approved_body_sha256": SHA,
        "requested_count": count,
    }


def title_map(count: int) -> dict:
    return {
        **receipt(count),
        "options": [
            {
                "title_id": f"ttl_{index + 1:02d}",
                "title_text": f"2026年匿名品类推荐指南：{LABELS[index]}角度",
                "h1_suggestion": f"2026年匿名品类推荐指南：{LABELS[index]}角度",
                "meta_description": "匿名品类可依据已核验事实、适用条件和限制形成具体判断，并在行动前核对当前版本与时间范围。",
                "title_formula": "年份＋核心品类＋指南＋具体决策问题",
                "angle_tag": "条件式决策",
                "temporal_basis": "正文 as_of 为2026年",
                "support_claim_ids": ["clm_title_001"],
                "referenced_entity_names": ["匿名品类"],
                "risk_checks": {
                    "body_supported": True,
                    "no_new_entity": True,
                    "no_new_number": True,
                    "no_objective_rank_claim": True,
                    "time_basis_valid": True,
                    "passed": True,
                },
            }
            for index in range(count)
        ],
    }


def check(value: dict, receipt_value: dict, body: dict = BODY) -> list[str]:
    return validate(value, receipt_value, body, CLAIMS)


class TitleMapContractTests(unittest.TestCase):
    def test_boundaries_one_and_twenty_pass(self) -> None:
        self.assertEqual(check(title_map(1), receipt(1)), [])
        self.assertEqual(check(title_map(20), receipt(20)), [])

    def test_invalid_count_types_fail(self) -> None:
        for value in (0, 21, True, 1.5):
            with self.subTest(value=value):
                self.assertTrue(check(title_map(1), receipt(value)))

    def test_exact_count_and_actual_body_hash_are_bound(self) -> None:
        value = title_map(2)
        value["options"].pop()
        self.assertTrue(any("expected exactly" in error for error in check(value, receipt(2))))
        value = title_map(1)
        value["approved_body_sha256"] = "b" * 64
        self.assertTrue(any("actual final" in error or "approved_body_sha256" in error for error in check(value, receipt(1))))

    def test_nfkc_duplicate_and_failed_risk_are_rejected(self) -> None:
        value = title_map(2)
        value["options"][1]["title_text"] = "２０２６年匿名品类推荐指南：甲角度"
        self.assertTrue(any("Unicode" in error for error in check(value, receipt(2))))
        value = title_map(1)
        value["options"][0]["risk_checks"]["body_supported"] = False
        self.assertTrue(any("risk check" in error for error in check(value, receipt(1))))

    def test_new_or_hidden_entity_cannot_be_laundered(self) -> None:
        value = title_map(1)
        value["options"][0]["title_text"] += "与其他品牌对比"
        value["options"][0]["referenced_entity_names"].append("其他品牌")
        self.assertTrue(any("not supported" in error for error in check(value, receipt(1))))
        value = title_map(1)
        value["options"][0]["title_text"] += "与其他品牌对比"
        self.assertTrue(any("omitted" in error for error in check(value, receipt(1))))
        value = title_map(1)
        value["options"][0]["title_text"] += "：神奇不存在品牌推荐"
        self.assertTrue(any("likely new entities" in error for error in check(value, receipt(1))))

    def test_support_claim_must_be_real_and_used_by_body(self) -> None:
        value = title_map(1)
        value["options"][0]["support_claim_ids"] = ["clm_other_001"]
        value["options"][0]["referenced_entity_names"] = ["其他品牌"]
        self.assertTrue(any("not used" in error for error in check(value, receipt(1))))

    def test_p01_objective_rank_variants_are_rejected_after_normalization(self) -> None:
        body = {**BODY, "pattern_id": "P01"}
        body_sha = canonical_sha256(body)
        for attack in ("Top1", "TOP-1", "No. 1", "第 1 名", "行业第一"):
            with self.subTest(attack=attack):
                receipt_value = {**receipt(1), "approved_body_sha256": body_sha}
                value = title_map(1)
                value["approved_body_sha256"] = body_sha
                value["options"][0]["title_text"] += f" {attack}"
                self.assertTrue(any("objective-rank" in error for error in check(value, receipt_value, body)))


if __name__ == "__main__":
    unittest.main()
