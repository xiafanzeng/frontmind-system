#!/usr/bin/env python3
"""Validate v2 title-free FrontMind Content Model invariants."""

from __future__ import annotations

import argparse
import json
import re
import unicodedata
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from content_route import validate_entry_pattern_route, validate_p01_candidate_contract


ENTRIES = {"industry_ranking", "competitor_comparison", "reputation", "product_scenario", "foundation_start"}
SUBINTENTS = {"offering_definition", "feature_mechanism", "scenario_fit", "delivery_usage", "support_boundary", "price_selection"}
P01_VARIANTS = {"multi_brand_editorial_recommendation", "single_brand_recommendation"}
FORBIDDEN_MODEL_KEYS = {"title", "h1", "title_candidates"}
OBJECTIVE_RANK_RE = re.compile(
    r"(?:第\s*1\s*名|第一名|榜首|综合第一|得分最高|市场最佳|行业第一|"
    r"(?:top|no\.?|number)\s*[-_#]?\s*1\b)",
    flags=re.IGNORECASE,
)


def substantive_length(value: str) -> int:
    return sum(1 for char in value if not char.isspace() and not unicodedata.category(char).startswith(("P", "S")))


def add(errors: list[str], condition: bool, message: str) -> None:
    if not condition:
        errors.append(message)


def forbidden_key_paths(value: Any, path: str = "$") -> list[str]:
    hits: list[str] = []
    if isinstance(value, dict):
        for key, child in value.items():
            child_path = f"{path}.{key}"
            if key.lower() in FORBIDDEN_MODEL_KEYS:
                hits.append(child_path)
            hits.extend(forbidden_key_paths(child, child_path))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            hits.extend(forbidden_key_paths(child, f"{path}[{index}]"))
    return hits


def visible_text(value: Any) -> str:
    chunks: list[str] = []
    if isinstance(value, str):
        chunks.append(value)
    elif isinstance(value, dict):
        for child in value.values():
            chunks.extend([visible_text(child)])
    elif isinstance(value, list):
        for child in value:
            chunks.extend([visible_text(child)])
    return "\n".join(chunk for chunk in chunks if chunk)


def validate(model: dict[str, Any], pattern_registry: dict[str, Any] | None = None, canonical_brand: str | None = None) -> dict[str, Any]:
    errors: list[str] = []
    add(errors, model.get("schema_version") == "2.0.0", "schema_version must be 2.0.0")
    entry = model.get("entry_category")
    add(errors, entry in ENTRIES, "entry_category must be one of the five canonical entries")
    add(errors, "question_category" not in model, "question_category is a v1 field; use entry_category")
    add(errors, isinstance(model.get("primary_question"), str) and len(model["primary_question"]) >= 4, "primary_question is required")

    subintent = model.get("product_scenario_subintent")
    if entry == "product_scenario":
        add(errors, subintent in SUBINTENTS, "product_scenario requires a canonical product_scenario_subintent")
    else:
        add(errors, subintent is None, "non-product entry must persist product_scenario_subintent as null")

    pattern_id = model.get("pattern_id")
    variant = model.get("pattern_variant")
    if pattern_id == "P01":
        add(errors, variant in P01_VARIANTS, "P01 requires one exact pattern_variant")
    else:
        add(errors, variant is None, "non-P01 model must persist pattern_variant as null")
    add(errors, (entry == "foundation_start") == (pattern_id == "P13"), "foundation_start and P13 must be a strict two-way mapping")
    if pattern_registry is not None:
        errors.extend(validate_entry_pattern_route(model, pattern_registry))
    errors.extend(validate_p01_candidate_contract(model, canonical_brand))

    title_paths = forbidden_key_paths(model)
    if title_paths:
        errors.append(f"title-free Content Model contains forbidden fields: {', '.join(title_paths)}")

    lead = model.get("lead") if isinstance(model.get("lead"), dict) else {}
    direct = lead.get("direct_answer_sentence", "")
    micro = lead.get("micro_answer", "")
    add(errors, isinstance(direct, str) and 40 <= len(direct) <= 80, "direct_answer_sentence must contain 40-80 Unicode code points")
    add(errors, isinstance(micro, str) and 200 <= len(micro) <= 300, "micro_answer must contain 200-300 Unicode code points")
    add(errors, isinstance(direct, str) and substantive_length(direct) >= 30, "direct_answer_sentence lacks substantive information")
    add(errors, isinstance(micro, str) and substantive_length(micro) >= 120, "micro_answer lacks substantive information")

    sections = model.get("sections")
    coverage = model.get("subquestion_coverage")
    faq = model.get("faq")
    add(errors, isinstance(sections, list) and 5 <= len(sections) <= 8, "sections must contain 5-8 items")
    add(errors, isinstance(coverage, list) and 5 <= len(coverage) <= 8, "subquestion_coverage must contain 5-8 items")
    add(errors, isinstance(faq, list) and 5 <= len(faq) <= 8, "faq must contain 5-8 items")

    section_ids = {
        section.get("section_id") for section in sections or []
        if isinstance(section, dict) and isinstance(section.get("section_id"), str)
    }
    for index, section in enumerate(sections or []):
        if not isinstance(section, dict) or not isinstance(section.get("h2_question"), str) or not section["h2_question"].endswith(("？", "?")):
            errors.append(f"sections[{index}].h2_question must end with ？ or ?")
    for index, item in enumerate(coverage or []):
        if not isinstance(item, dict):
            errors.append(f"subquestion_coverage[{index}] must be an object")
            continue
        refs = item.get("section_ids")
        if not isinstance(refs, list) or not refs:
            errors.append(f"subquestion_coverage[{index}].section_ids must not be empty")
            continue
        unknown = sorted(set(refs) - section_ids)
        if unknown:
            errors.append(f"subquestion_coverage[{index}] references unknown sections: {', '.join(unknown)}")
    for index, item in enumerate(faq or []):
        if not isinstance(item, dict) or not isinstance(item.get("question"), str) or not item["question"].endswith(("？", "?")):
            errors.append(f"faq[{index}].question must end with ？ or ?")

    structured = set(model.get("structured_data_types") or [])
    if pattern_id == "P01" and variant == "single_brand_recommendation":
        add(errors, "ItemList" not in structured, "P01-S must not request ItemList")
    if pattern_id == "P01":
        body = unicodedata.normalize(
            "NFKC", visible_text({key: value for key, value in model.items() if key not in {"references"}})
        )
        forbidden = sorted({match.group(0) for match in OBJECTIVE_RANK_RE.finditer(body)})
        if forbidden:
            errors.append(f"P01 uses forbidden objective-rank terms: {forbidden}")

    add(errors, isinstance(model.get("conclusion"), dict), "conclusion is required")
    metrics = {
        "direct_answer_unicode_length": len(direct) if isinstance(direct, str) else None,
        "direct_answer_substantive_length": substantive_length(direct) if isinstance(direct, str) else None,
        "micro_answer_unicode_length": len(micro) if isinstance(micro, str) else None,
        "micro_answer_substantive_length": substantive_length(micro) if isinstance(micro, str) else None,
        "section_count": len(sections) if isinstance(sections, list) else None,
        "coverage_count": len(coverage) if isinstance(coverage, list) else None,
        "faq_count": len(faq) if isinstance(faq, list) else None,
    }
    return {"status": "pass" if not errors else "fail", "metrics": metrics, "errors": errors}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("content_model", type=Path)
    parser.add_argument("--pattern-registry", type=Path, default=Path(__file__).resolve().parents[1] / "content-pattern-registry.json")
    parser.add_argument("--canonical-brand")
    args = parser.parse_args()
    try:
        value = json.loads(args.content_model.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("JSON root must be an object")
        registry = json.loads(args.pattern_registry.read_text(encoding="utf-8"))
        if not isinstance(registry, dict):
            raise ValueError("pattern registry root must be an object")
        report = validate(value, registry, args.canonical_brand)
    except (OSError, UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
        report = {"status": "fail", "metrics": {}, "errors": [str(exc)]}
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
