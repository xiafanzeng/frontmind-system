#!/usr/bin/env python3
"""Validate an E10 title map against the actual final body and evidence graph."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import unicodedata
from pathlib import Path
from typing import Any

from validate_json_instance import load_json, validate_instance


FACT_TOKEN_RE = re.compile(r"\d+(?:\.\d+)?%?|20\d{2}(?:年|[-/.]\d{1,2})?|(?:人民币|美元|元|万元|亿元|¥|￥|\$)\s*\d+(?:\.\d+)?")
OBJECTIVE_RANK_RE = re.compile(
    r"(?:第\s*1\s*名|第一名|榜首|综合第一|得分最高|市场最佳|行业第一|"
    r"(?:top|no\.?|number)\s*[-_#]?\s*1\b)",
    flags=re.IGNORECASE,
)
CHINESE_ENTITY_RE = re.compile(r"[\u4e00-\u9fffA-Za-z0-9·＆&_-]{2,24}(?:品牌|公司|集团|机构|平台)")
LATIN_ENTITY_RE = re.compile(r"\b[A-Z][A-Za-z0-9&._-]{2,}\b")
GENERIC_LATIN_TOKENS = {"AI", "GEO", "FAQ", "HTML", "DOCX", "API", "TOP", "B2B", "B2C"}


def canonical_sha256(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def normalized_text(value: Any) -> str:
    return " ".join(unicodedata.normalize("NFKC", str(value or "")).casefold().split())


def normalized_title(value: str) -> str:
    return normalized_text(value)


def collect_claim_ids(value: Any) -> set[str]:
    result: set[str] = set()
    if isinstance(value, dict):
        for key, child in value.items():
            if key == "claim_ids" and isinstance(child, list):
                result.update(str(item) for item in child if isinstance(item, str))
            else:
                result.update(collect_claim_ids(child))
    elif isinstance(value, list):
        for child in value:
            result.update(collect_claim_ids(child))
    return result


def entity_catalog(claim_registry: dict[str, Any], brand_facts: dict[str, Any] | None) -> dict[str, str]:
    catalog: dict[str, str] = {}
    for claim in claim_registry.get("claims", []):
        if not isinstance(claim, dict):
            continue
        for entity in claim.get("about_entities", []):
            normalized = normalized_text(entity)
            if normalized:
                catalog[normalized] = str(entity)
    if isinstance(brand_facts, dict):
        identity = brand_facts.get("brand_identity") if isinstance(brand_facts.get("brand_identity"), dict) else {}
        for entity in [identity.get("canonical_name"), identity.get("legal_entity_name"), *(identity.get("aliases") or [])]:
            normalized = normalized_text(entity)
            if normalized:
                catalog[normalized] = str(entity)
        for offering in brand_facts.get("offerings", []):
            if isinstance(offering, dict):
                normalized = normalized_text(offering.get("name"))
                if normalized:
                    catalog[normalized] = str(offering["name"])
    return catalog


def undeclared_likely_entities(visible: str, body_text: str, declared: set[str]) -> list[str]:
    """Catch common invented brand/company tokens that are absent from the body graph.

    Full named-entity recognition remains part of E10 semantic review, but these
    deterministic suffix/proper-token checks prevent a self-attested risk flag
    from laundering the most common Chinese and Latin brand injections.
    """

    normalized_visible = unicodedata.normalize("NFKC", visible)
    normalized_body = normalized_text(body_text)
    findings: set[str] = set()
    for candidate in CHINESE_ENTITY_RE.findall(normalized_visible):
        normalized = normalized_text(candidate)
        if normalized in normalized_body or any(name in normalized or normalized in name for name in declared):
            continue
        findings.add(candidate)
    for candidate in LATIN_ENTITY_RE.findall(normalized_visible):
        if candidate.upper() in GENERIC_LATIN_TOKENS:
            continue
        normalized = normalized_text(candidate)
        if normalized in normalized_body or any(name in normalized or normalized in name for name in declared):
            continue
        findings.add(candidate)
    return sorted(findings)


def validate(
    title_map: dict[str, Any],
    receipt: dict[str, Any],
    content_model: dict[str, Any],
    claim_registry: dict[str, Any],
    brand_facts: dict[str, Any] | None = None,
) -> list[str]:
    errors: list[str] = []
    actual_body_sha = canonical_sha256(content_model)
    for field in ("schema_version", "job_id", "approved_body_sha256", "requested_count"):
        if title_map.get(field) != receipt.get(field):
            errors.append(f"title_map.{field} does not match title-count receipt")
    if title_map.get("job_id") != content_model.get("job_id"):
        errors.append("title_map.job_id does not match the final Content Model")
    if title_map.get("approved_body_sha256") != actual_body_sha or receipt.get("approved_body_sha256") != actual_body_sha:
        errors.append("title assets are not bound to the actual final Content Model")

    options = title_map.get("options")
    requested = receipt.get("requested_count")
    if not isinstance(requested, int) or isinstance(requested, bool) or not 1 <= requested <= 20:
        errors.append("requested_count must be a non-boolean integer from 1 through 20")
    if not isinstance(options, list):
        errors.append("title_map.options must be an array")
        return errors
    if isinstance(requested, int) and not isinstance(requested, bool) and len(options) != requested:
        errors.append(f"title_map contains {len(options)} options; expected exactly {requested}")
    title_ids = [item.get("title_id") for item in options if isinstance(item, dict)]
    if len(title_ids) != len(set(title_ids)):
        errors.append("title_id values must be unique")
    normalized = [normalized_title(str(item.get("title_text") or "")) for item in options if isinstance(item, dict)]
    if len(normalized) != len(set(normalized)):
        errors.append("title_text values must be unique after Unicode NFKC/case/space normalization")

    claims = {
        item.get("claim_id"): item for item in claim_registry.get("claims", [])
        if isinstance(item, dict) and isinstance(item.get("claim_id"), str)
    }
    used_claim_ids = collect_claim_ids(content_model)
    catalog = entity_catalog(claim_registry, brand_facts)
    body_visible_text = json.dumps(content_model, ensure_ascii=False, sort_keys=True)
    body_tokens = set(
        FACT_TOKEN_RE.findall(
            unicodedata.normalize("NFKC", json.dumps(content_model, ensure_ascii=False, sort_keys=True))
        )
    )
    for index, option in enumerate(options):
        if not isinstance(option, dict):
            errors.append(f"options[{index}] must be an object")
            continue
        checks = option.get("risk_checks") or {}
        if checks.get("passed") is not True or any(checks.get(key) is not True for key in ("body_supported", "no_new_entity", "no_new_number", "no_objective_rank_claim", "time_basis_valid")):
            errors.append(f"options[{index}] has an incomplete or failed risk check")
        support_ids = option.get("support_claim_ids")
        if not isinstance(support_ids, list) or not support_ids:
            errors.append(f"options[{index}] must bind at least one claim used by the final body")
            support_ids = []
        unknown_claims = sorted(set(support_ids) - set(claims))
        hidden_claims = sorted(set(support_ids) - used_claim_ids)
        if unknown_claims:
            errors.append(f"options[{index}] references unknown claims: {unknown_claims}")
        if hidden_claims:
            errors.append(f"options[{index}] references claims not used by the final body: {hidden_claims}")

        supported_entities = {
            normalized_text(entity)
            for claim_id in support_ids
            for entity in (claims.get(claim_id) or {}).get("about_entities", [])
            if normalized_text(entity)
        }
        declared_entities = option.get("referenced_entity_names")
        if not isinstance(declared_entities, list):
            errors.append(f"options[{index}].referenced_entity_names must be an array")
            declared_entities = []
        declared_normalized = {normalized_text(entity) for entity in declared_entities if normalized_text(entity)}
        unsupported_entities = sorted(declared_normalized - supported_entities)
        if unsupported_entities:
            errors.append(f"options[{index}] declares entities not supported by its claims: {unsupported_entities}")
        visible = normalized_text(" ".join(str(option.get(key) or "") for key in ("title_text", "h1_suggestion", "meta_description")))
        detected_known = {name for name in catalog if name and name in visible}
        undeclared = sorted(detected_known - declared_normalized)
        if undeclared:
            errors.append(f"options[{index}] contains known entities omitted from referenced_entity_names: {undeclared}")
        missing_visible = sorted(name for name in declared_normalized if name not in visible)
        if missing_visible:
            errors.append(f"options[{index}] declares entities not visible in its title metadata: {missing_visible}")
        likely_injected = undeclared_likely_entities(visible, body_visible_text, declared_normalized)
        if likely_injected:
            errors.append(f"options[{index}] contains likely new entities absent from body/claims: {likely_injected}")

        option_tokens = set(
            FACT_TOKEN_RE.findall(
                unicodedata.normalize(
                    "NFKC",
                    " ".join(str(option.get(key) or "") for key in ("title_text", "h1_suggestion", "meta_description")),
                )
            )
        )
        new_tokens = sorted(option_tokens - body_tokens)
        if new_tokens:
            errors.append(f"options[{index}] introduces numbers, dates or prices absent from the final body: {new_tokens}")
        if content_model.get("pattern_id") == "P01":
            forbidden = sorted({match.group(0) for match in OBJECTIVE_RANK_RE.finditer(visible)})
            if forbidden:
                errors.append(f"options[{index}] introduces forbidden objective-rank language: {forbidden}")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("title_map", type=Path)
    parser.add_argument("title_count_receipt", type=Path)
    parser.add_argument("--content-model", type=Path, required=True)
    parser.add_argument("--claim-registry", type=Path, required=True)
    parser.add_argument("--brand-facts", type=Path)
    args = parser.parse_args()
    shared = Path(__file__).resolve().parents[1]
    try:
        title_map = load_json(args.title_map)
        receipt = load_json(args.title_count_receipt)
        content_model = load_json(args.content_model)
        claim_registry = load_json(args.claim_registry)
        brand_facts = load_json(args.brand_facts) if args.brand_facts else None
        schema_errors = [
            *(error.to_dict() for error in validate_instance(title_map, load_json(shared / "title_map.schema.json"), shared / "title_map.schema.json")),
            *(error.to_dict() for error in validate_instance(receipt, load_json(shared / "title_count_receipt.schema.json"), shared / "title_count_receipt.schema.json")),
        ]
        errors = [f"schema:{error['json_path']}:{error['message']}" for error in schema_errors]
        if not errors:
            errors.extend(validate(title_map, receipt, content_model, claim_registry, brand_facts))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
        errors = [str(exc)]
    report = {"status": "pass" if not errors else "fail", "errors": errors}
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
