#!/usr/bin/env python3
"""Audit all active FrontMind content-workflow contracts with the Python stdlib."""

from __future__ import annotations

import argparse
import json
import os
import py_compile
import re
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any


CANONICAL_SCHEMAS = {
    "reference_pack.schema.json",
    "content_job.schema.json",
    "monitoring_input.schema.json",
    "registries.schema.json",
    "article_blueprint.schema.json",
    "content_model.schema.json",
    "quality_report.schema.json",
    "delivery_manifest.schema.json",
    "brand_facts.schema.json",
    "scope_analysis.schema.json",
    "title_count_receipt.schema.json",
    "title_map.schema.json",
    "runtime_evidence_extension.schema.json",
    "information_evidence_architecture.schema.json",
}
CATEGORIES = ["industry_ranking", "competitor_comparison", "reputation", "product_scenario", "foundation_start"]
INTENTS = ["recommendation", "price", "comparison", "tutorial", "evaluation", "risk", "alternative"]
PATTERNS = [f"P{index:02d}" for index in range(1, 16)]
MARKDOWN_LINK = re.compile(r"\[[^\]]*\]\(([^)]+)\)")
SCHEMA_REFERENCE = re.compile(r"(?<![A-Za-z0-9_.-])(?P<path>(?:\.\.?/|/)[^\s)`'\"]+\.schema\.json)")
PROHIBITED_ACTIVE = {
    "deleted_S2_dependency": re.compile(r"\bS2(?:\.|\s)*(?:营销图谱|营销图谱专家)"),
    "deleted_S5_dependency": re.compile(r"\bS5(?:\.|\s)*(?:品牌诊断|品牌诊断专家|问题监控)"),
    "deleted_S5_5_dependency": re.compile(r"\bS5\.5(?:\.|\s)*(?:品牌语义|语义资产|评分)"),
    "deleted_S9_dependency": re.compile(r"\bS9(?:\.|\s)*(?:业务赋能|业务赋能规划|行动建议)"),
    "legacy_24_type_contract": re.compile(r"(?:24|二十四)\s*(?:种|个)?\s*(?:文章|内容)?类型"),
    "legacy_optimizer": re.compile(r"HarnessGEO", re.IGNORECASE),
    "legacy_distribution": re.compile(r"分发编排师|渠道分发|分发正本|distribution_history", re.IGNORECASE),
    "legacy_calendar": re.compile(r"内容日历|12\s*周(?:内容)?(?:日历|排期)"),
    "legacy_strategy_stage_id": re.compile(r"(?<![A-Za-z0-9_.-])(?:R0|S0|S10)(?![A-Za-z0-9_.-])"),
    "legacy_execution_stage_id": re.compile(r"(?<![A-Za-z0-9_.-])(?:E0(?:-[AB])?|E0\.5|E2\.5)(?![A-Za-z0-9_.-])"),
}
LEGACY_SCHEMA_ALIASES = re.compile(
    r"(?:strategy[_-]pack|content[-_]job|monitoring[-_]input|article[-_]blueprint|content[-_]model|quality[-_]report|delivery[-_]manifest)[_-]schema\.json",
    re.IGNORECASE,
)
NEGATION_MARKERS = ("不再", "不恢复", "不会", "不得", "不做", "不写", "不生成", "不负责", "不包含", "不承担", "禁止", "禁用", "删除", "取消", "移除", "弃用", "废止", "旧 ", "旧版")
OUTPUT_GUARD_SCRIPTS = {"content_model_validator.py", "editorial_audit.py", "regression_review.py"}


def is_legacy_artifact(path: Path) -> bool:
    return (
        "compatibility" in path.parts
        or any(part.startswith("legacy-") or ".legacy-" in part for part in path.parts)
        or path.name.startswith("legacy_")
    )


def is_ignored(path: Path) -> bool:
    return path.name == ".DS_Store" or "__pycache__" in path.parts


def issue(bucket: list[dict[str, Any]], check: str, path: Path, message: str, line: int | None = None) -> None:
    value: dict[str, Any] = {"check": check, "file": str(path), "message": message}
    if line is not None:
        value["line"] = line
    bucket.append(value)


def check_package_hygiene(root: Path, errors: list[dict[str, Any]]) -> None:
    """Reject generated filesystem debris that must never enter the release ZIP."""
    for path in sorted(root.rglob("*")):
        if path.name == ".DS_Store":
            issue(errors, "package_hygiene", path, ".DS_Store must be removed before packaging")
        elif path.name == "__pycache__" and path.is_dir():
            issue(errors, "package_hygiene", path, "__pycache__ must be removed before packaging")
        elif path.is_file() and path.suffix == ".pyc":
            issue(errors, "package_hygiene", path, ".pyc must be removed before packaging")


def line_number(text: str, offset: int) -> int:
    return text.count("\n", 0, offset) + 1


def check_skill_frontmatter(root: Path, errors: list[dict[str, Any]], counts: dict[str, int]) -> None:
    for path in sorted(root.rglob("SKILL.md")):
        if is_ignored(path) or is_legacy_artifact(path):
            continue
        counts["skills"] += 1
        lines = path.read_text(encoding="utf-8").splitlines()
        if not lines or lines[0].strip() != "---":
            issue(errors, "skill_frontmatter", path, "first line must be ---")
            continue
        try:
            end = next(index for index, value in enumerate(lines[1:], 1) if value.strip() == "---")
        except StopIteration:
            issue(errors, "skill_frontmatter", path, "closing --- is missing")
            continue
        keys: list[str] = []
        values: dict[str, str] = {}
        for index, value in enumerate(lines[1:end], 2):
            match = re.match(r"^([A-Za-z_][A-Za-z0-9_-]*):\s*(.*)$", value)
            if match:
                keys.append(match.group(1))
                values[match.group(1)] = match.group(2).strip()
        unknown = sorted(set(keys) - {"name", "description"})
        if unknown:
            issue(errors, "skill_frontmatter", path, f"only name and description are allowed; found {unknown}")
        for required in ("name", "description"):
            if required not in values or not values[required]:
                issue(errors, "skill_frontmatter", path, f"missing non-empty {required}")
        name = values.get("name", "")
        if name and not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", name):
            issue(errors, "skill_frontmatter", path, "name must use lowercase hyphen-case")


def json_pointer_exists(document: Any, fragment: str) -> bool:
    if fragment in ("", "#"):
        return True
    if fragment.startswith("#"):
        fragment = fragment[1:]
    if not fragment.startswith("/"):
        return False
    current = document
    for raw in fragment[1:].split("/"):
        key = raw.replace("~1", "/").replace("~0", "~")
        if isinstance(current, dict) and key in current:
            current = current[key]
        elif isinstance(current, list) and key.isdigit() and int(key) < len(current):
            current = current[int(key)]
        else:
            return False
    return True


def walk_refs(value: Any) -> list[str]:
    refs: list[str] = []
    if isinstance(value, dict):
        for key, child in value.items():
            if key == "$ref" and isinstance(child, str):
                refs.append(child)
            else:
                refs.extend(walk_refs(child))
    elif isinstance(value, list):
        for child in value:
            refs.extend(walk_refs(child))
    return refs


def schema_version_consts(value: Any) -> list[Any]:
    values: list[Any] = []
    if isinstance(value, dict):
        properties = value.get("properties")
        if isinstance(properties, dict) and isinstance(properties.get("schema_version"), dict) and "const" in properties["schema_version"]:
            values.append(properties["schema_version"]["const"])
        for child in value.values():
            values.extend(schema_version_consts(child))
    elif isinstance(value, list):
        for child in value:
            values.extend(schema_version_consts(child))
    return values


def check_json(root: Path, errors: list[dict[str, Any]], warnings: list[dict[str, Any]], counts: dict[str, int]) -> None:
    documents: dict[Path, Any] = {}
    for path in sorted(root.rglob("*.json")):
        if is_ignored(path):
            continue
        if is_legacy_artifact(path):
            issue(warnings, "legacy_reference", path, "archived legacy JSON is excluded from the active contract")
            continue
        counts["json"] += 1
        try:
            documents[path.resolve()] = json.loads(path.read_text(encoding="utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            issue(errors, "json_parse", path, str(exc))
            continue
        if path.name.endswith(".schema.json") and not isinstance(documents[path.resolve()], dict):
            issue(errors, "json_schema", path, "schema root must be an object")
        elif path.name.endswith(".schema.json") and "$schema" not in documents[path.resolve()]:
            issue(errors, "json_schema", path, "schema file lacks $schema")
        if path.name.endswith(".schema.json"):
            canonical = root / "shared" / path.name
            if path.name in CANONICAL_SCHEMAS and path.resolve() != canonical.resolve():
                issue(errors, "schema_ssot", path, f"duplicate canonical schema; use {canonical}")
            if path.resolve() == canonical.resolve():
                version_consts = set(schema_version_consts(documents[path.resolve()]))
                if version_consts != {"2.0.0"}:
                    issue(errors, "schema_version", path, f"canonical v2 schema versions must resolve only to 2.0.0, found {sorted(version_consts, key=str)}")

    # A renamed mirror such as ``brand_facts_schema.json`` can otherwise evade
    # the basename-only SSOT check while still claiming the canonical $id.
    schema_id_owners: dict[str, Path] = {}
    for path, document in sorted(documents.items(), key=lambda item: str(item[0])):
        if not isinstance(document, dict) or not isinstance(document.get("$id"), str):
            continue
        schema_id = document["$id"]
        owner = schema_id_owners.get(schema_id)
        if owner is None:
            schema_id_owners[schema_id] = path
            continue
        issue(
            errors,
            "schema_ssot",
            path,
            f"duplicate schema $id {schema_id!r}; canonical owner is {owner}",
        )

    for path, document in list(documents.items()):
        for raw in walk_refs(document):
            if raw.startswith(("http://", "https://")):
                continue
            file_part, separator, fragment = raw.partition("#")
            target = path if not file_part else (path.parent / file_part).resolve()
            if target not in documents:
                if target.exists():
                    try:
                        documents[target] = json.loads(target.read_text(encoding="utf-8"))
                    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
                        pass
                if target not in documents:
                    issue(errors, "json_ref", path, f"missing or invalid $ref target: {raw}")
                    continue
            if separator and not json_pointer_exists(documents[target], fragment):
                issue(errors, "json_ref", path, f"missing JSON pointer in $ref: {raw}")


def normalized_link(raw: str) -> str:
    value = raw.strip().strip("<>").split("#", 1)[0]
    if re.search(r":\d+$", value):
        value = value.rsplit(":", 1)[0]
    return value


def check_markdown(root: Path, errors: list[dict[str, Any]], warnings: list[dict[str, Any]], counts: dict[str, int]) -> None:
    for path in sorted(root.rglob("*.md")):
        if is_ignored(path):
            continue
        if is_legacy_artifact(path):
            issue(warnings, "legacy_reference", path, "archived legacy reference is excluded from the active contract")
            continue
        counts["markdown"] += 1
        text = path.read_text(encoding="utf-8")
        for match in MARKDOWN_LINK.finditer(text):
            raw = match.group(1)
            if raw.startswith(("http://", "https://", "mailto:", "#")):
                continue
            value = normalized_link(raw)
            if not value or "{" in value or "}" in value:
                continue
            target = Path(value) if Path(value).is_absolute() else path.parent / value
            counts["relative_links"] += 1
            if not target.exists():
                issue(errors, "markdown_link", path, f"missing relative target: {raw} -> {target.resolve()}", line_number(text, match.start()))

        for match in SCHEMA_REFERENCE.finditer(text):
            raw = match.group("path")
            target = Path(raw) if Path(raw).is_absolute() else (path.parent / raw).resolve()
            if target.name in CANONICAL_SCHEMAS and target != (root / "shared" / target.name).resolve():
                issue(errors, "schema_ssot", path, f"canonical schema {target.name} must resolve to root shared/, not {target}", line_number(text, match.start()))
        for match in LEGACY_SCHEMA_ALIASES.finditer(text):
            value = match.group(0)
            if value not in CANONICAL_SCHEMAS:
                issue(errors, "schema_ssot", path, f"legacy schema filename reference: {value}", line_number(text, match.start()))


def check_python(root: Path, errors: list[dict[str, Any]], warnings: list[dict[str, Any]], counts: dict[str, int]) -> None:
    with tempfile.TemporaryDirectory(prefix="frontmind-pycompile-") as temp_dir:
        for index, path in enumerate(sorted(root.rglob("*.py"))):
            if is_ignored(path):
                continue
            if is_legacy_artifact(path):
                # Compatibility assets are deliberately excluded from the active
                # runtime.  The legacy S1 copy must remain byte-identical for
                # migration traceability, including its original .py files.
                issue(warnings, "legacy_reference", path, "non-active compatibility Python is excluded from the v2 runtime")
                continue
            counts["python"] += 1
            try:
                py_compile.compile(str(path), cfile=str(Path(temp_dir) / f"{index}.pyc"), doraise=True)
            except py_compile.PyCompileError as exc:
                issue(errors, "python_compile", path, str(exc))


def check_schema_runtime(root: Path, errors: list[dict[str, Any]], counts: dict[str, int]) -> None:
    """Require and execute the stdlib schema and package trust-gate suites."""

    runtime = root / "shared" / "scripts" / "validate_json_instance.py"
    package_validator = root / "shared" / "scripts" / "validate_package.py"
    suites = [
        root / "shared" / "scripts" / "test_validate_json_instance.py",
        root / "shared" / "scripts" / "test_validate_package.py",
        root / "shared" / "scripts" / "test_validate_title_map.py",
        root / "shared" / "pattern-research" / "tests" / "test_validate_pattern_research.py",
        root / "shared" / "tests" / "test_content_route.py",
        root / "shared" / "tests" / "test_source_publication.py",
    ]
    for path in (runtime, package_validator, *suites):
        if not path.is_file():
            issue(errors, "schema_runtime", path, "required stdlib JSON Schema runtime artifact is missing")
            return
    environment = os.environ.copy()
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    for tests in suites:
        try:
            completed = subprocess.run(
                [sys.executable, "-B", str(tests)],
                cwd=str(tests.parent),
                env=environment,
                check=False,
                capture_output=True,
                text=True,
                timeout=45,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            issue(errors, "schema_runtime", tests, f"runtime regression suite could not complete: {exc}")
            continue
        counts["schema_runtime_suites"] += 1
        if completed.returncode != 0:
            output = (completed.stdout + "\n" + completed.stderr).strip()
            issue(errors, "schema_runtime", tests, f"runtime regression suite failed: {output[-4000:]}")


def check_prohibited(root: Path, errors: list[dict[str, Any]], counts: dict[str, int]) -> None:
    exclusions = {
        (root / "shared" / "workflow-migration-map.md").resolve(),
        (root / "shared" / "scripts" / "validate_workflow.py").resolve(),
        (root / "scripts" / "validate_workflow.py").resolve(),
        (root / "VALIDATION_REPORT.md").resolve(),
    }
    for path in sorted(root.rglob("*")):
        if not path.is_file() or is_ignored(path) or is_legacy_artifact(path) or path.resolve() in exclusions:
            continue
        if path.suffix.lower() not in {".md", ".json", ".py", ".txt"} and path.name != "SKILL.md":
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        counts["active_residual_files"] += 1
        for label, pattern in PROHIBITED_ACTIVE.items():
            for match in pattern.finditer(text):
                start = text.rfind("\n", 0, match.start()) + 1
                end = text.find("\n", match.end())
                if end == -1:
                    end = len(text)
                source_line = text[start:end]
                if any(marker in source_line for marker in NEGATION_MARKERS):
                    continue
                if label == "legacy_optimizer" and path.name in OUTPUT_GUARD_SCRIPTS:
                    continue
                issue(errors, "active_legacy_residual", path, f"{label}: {match.group(0)}", line_number(text, match.start()))


def required_values(value: Any) -> list[str]:
    result: list[str] = []
    if isinstance(value, dict):
        required = value.get("required")
        if isinstance(required, list):
            result.extend(item for item in required if isinstance(item, str))
        for child in value.values():
            result.extend(required_values(child))
    elif isinstance(value, list):
        for child in value:
            result.extend(required_values(child))
    return result


def check_contracts(root: Path, errors: list[dict[str, Any]], counts: dict[str, int]) -> None:
    shared = root / "shared"
    for name in sorted(CANONICAL_SCHEMAS):
        if not (shared / name).is_file():
            issue(errors, "canonical_contract", shared / name, "required canonical schema is missing")

    try:
        registry = json.loads((shared / "content-pattern-registry.json").read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        issue(errors, "pattern_registry", shared / "content-pattern-registry.json", str(exc))
        return
    category_ids = [item.get("id") for item in registry.get("canonical_content_entries", []) if isinstance(item, dict)]
    intent_ids = [item.get("id") for item in registry.get("question_intent_tags", []) if isinstance(item, dict)]
    pattern_ids = [item.get("id") for item in registry.get("patterns", []) if isinstance(item, dict)]
    if category_ids != CATEGORIES:
        issue(errors, "pattern_registry", shared / "content-pattern-registry.json", f"canonical categories must be {CATEGORIES}")
    if intent_ids != INTENTS:
        issue(errors, "pattern_registry", shared / "content-pattern-registry.json", f"intent tags must be {INTENTS}")
    if pattern_ids != PATTERNS:
        issue(errors, "pattern_registry", shared / "content-pattern-registry.json", "patterns must contain P01-P15 once and in order")
    aliases = {item.get("id"): item.get("aliases", []) for item in registry.get("canonical_content_entries", []) if isinstance(item, dict)}
    if aliases.get("industry_ranking") != ["industry"]:
        issue(errors, "pattern_registry", shared / "content-pattern-registry.json", "industry_ranking may have only the industry import alias")
    if registry.get("selection_contract", {}).get("exactly_one_pattern") is not True:
        issue(errors, "pattern_registry", shared / "content-pattern-registry.json", "selection_contract.exactly_one_pattern must be true")
    research_contract = registry.get("template_research_contract")
    expected_research_ids = ["P01-M", "P01-S", *PATTERNS[1:]]
    expected_research_refs = {"P01": ["P01-M", "P01-S"], **{pattern: [pattern] for pattern in PATTERNS[1:]}}
    if not isinstance(research_contract, dict):
        issue(errors, "pattern_registry", shared / "content-pattern-registry.json", "template_research_contract is required")
    else:
        if research_contract.get("index_path") != "shared/pattern-research/index.json":
            issue(errors, "pattern_registry", shared / "content-pattern-registry.json", "template research index path must be fixed inside the Pack")
        if research_contract.get("required_research_ids") != expected_research_ids:
            issue(errors, "pattern_registry", shared / "content-pattern-registry.json", f"template research IDs must be {expected_research_ids}")
        if research_contract.get("pattern_research_refs") != expected_research_refs:
            issue(errors, "pattern_registry", shared / "content-pattern-registry.json", "every runtime P pattern must map exactly to its audited research dossier")
    first_party = registry.get("first_party_publication_contract")
    if not isinstance(first_party, dict):
        issue(errors, "pattern_registry", shared / "content-pattern-registry.json", "first_party_publication_contract is required")
    elif first_party.get("outcomes") != ["passed", "passed_with_claim_limits", "blocked"]:
        issue(errors, "pattern_registry", shared / "content-pattern-registry.json", "first-party gate outcomes must be passed/passed_with_claim_limits/blocked")
    routing = registry.get("routing", {})
    for category in CATEGORIES:
        route = routing.get(category, {}) if isinstance(routing, dict) else {}
        primary = route.get("primary_patterns", []) if isinstance(route, dict) else []
        secondary = route.get("secondary_patterns", []) if isinstance(route, dict) else []
        if len(primary) != len(set(primary)) or len(secondary) != len(set(secondary)) or set(primary) & set(secondary):
            issue(errors, "pattern_registry", shared / "content-pattern-registry.json", f"routing.{category} contains duplicate or overlapping pattern IDs")
    for pattern in registry.get("patterns", []):
        if not isinstance(pattern, dict) or pattern.get("id") not in PATTERNS:
            continue
        pattern_id = pattern["id"]
        declared_primary = set(pattern.get("primary_categories", []))
        declared_secondary = set(pattern.get("secondary_categories", []))
        routed_primary = {
            category for category in CATEGORIES
            if pattern_id in (routing.get(category, {}).get("primary_patterns", []) if isinstance(routing.get(category), dict) else [])
        }
        routed_secondary = {
            category for category in CATEGORIES
            if pattern_id in (routing.get(category, {}).get("secondary_patterns", []) if isinstance(routing.get(category), dict) else [])
        }
        if declared_primary != routed_primary or declared_secondary != routed_secondary:
            issue(
                errors,
                "pattern_registry",
                shared / "content-pattern-registry.json",
                f"{pattern_id} category metadata disagrees with routing: "
                f"declared primary={sorted(declared_primary)}, secondary={sorted(declared_secondary)}; "
                f"routed primary={sorted(routed_primary)}, secondary={sorted(routed_secondary)}",
            )

    patterns_by_id = {
        item.get("id"): item for item in registry.get("patterns", []) if isinstance(item, dict)
    }
    p01_variants = [item.get("id") for item in patterns_by_id.get("P01", {}).get("variants", []) if isinstance(item, dict)]
    expected_variants = ["multi_brand_editorial_recommendation", "single_brand_recommendation"]
    if p01_variants != expected_variants:
        issue(errors, "pattern_registry", shared / "content-pattern-registry.json", f"P01 variants must be {expected_variants}")
    foundation_route = routing.get("foundation_start", {}) if isinstance(routing, dict) else {}
    if foundation_route.get("primary_patterns") != ["P13"] or foundation_route.get("secondary_patterns") != []:
        issue(errors, "pattern_registry", shared / "content-pattern-registry.json", "foundation_start must route only to P13")
    p13 = patterns_by_id.get("P13", {})
    if p13.get("primary_categories") != ["foundation_start"] or p13.get("secondary_categories") != []:
        issue(errors, "pattern_registry", shared / "content-pattern-registry.json", "P13 must belong only to foundation_start")

    # The v2 visual function vocabulary is intentionally small.  Fine-grained
    # asset eligibility stays in the image Registry and must not leak into the
    # article/blueprint role contract.
    expected_visual_functions = {"brand_editorial", "navigate", "explain", "prove"}
    for schema_name, pointer in (
        ("article_blueprint.schema.json", ("properties", "visual_plan", "items", "properties", "role", "enum")),
        ("content_model.schema.json", ("properties", "visual_placements", "items", "properties", "role", "enum")),
    ):
        document = json.loads((shared / schema_name).read_text(encoding="utf-8"))
        value: Any = document
        for key in pointer:
            value = value.get(key) if isinstance(value, dict) else None
        if set(value or []) != expected_visual_functions:
            issue(errors, "visual_contract", shared / schema_name, f"visual functions must be exactly {sorted(expected_visual_functions)}")

    reference_schema = json.loads((shared / "reference_pack.schema.json").read_text(encoding="utf-8"))
    required = set(reference_schema.get("required", []))
    for field in ("profile", "approval_receipt_path", "content_pattern_research_index_path"):
        if field not in required:
            issue(errors, "reference_pack_contract", shared / "reference_pack.schema.json", f"{field} must be required")
    profile_const = reference_schema.get("properties", {}).get("profile", {}).get("const")
    if profile_const != "frontmind-content-reference-pack-v2":
        issue(errors, "reference_pack_contract", shared / "reference_pack.schema.json", "Reference Pack profile must be frontmind-content-reference-pack-v2")
    pdf_fields = sorted({value for value in required_values(reference_schema) if "pdf" in value.lower()})
    if pdf_fields:
        issue(errors, "reference_pack_contract", shared / "reference_pack.schema.json", f"PDF cannot be required: {pdf_fields}")

    registries_schema = json.loads((shared / "registries.schema.json").read_text(encoding="utf-8"))
    image_contract = registries_schema.get("$defs", {}).get("image", {})
    image_required = set(image_contract.get("required", [])) if isinstance(image_contract, dict) else set()
    image_properties = image_contract.get("properties", {}) if isinstance(image_contract, dict) else {}
    if "asset_kind" not in image_required:
        issue(errors, "image_registry_contract", shared / "registries.schema.json", "image.asset_kind must be required so an approved decorative image cannot masquerade as a Logo")
    if "attribution_text" not in image_properties:
        issue(errors, "image_registry_contract", shared / "registries.schema.json", "image.attribution_text is required by the approved_with_credit workflow")

    architecture_schema = json.loads((shared / "information_evidence_architecture.schema.json").read_text(encoding="utf-8"))
    architecture_required = set(architecture_schema.get("required", []))
    for field in ("positioning_anchor", "value_structure", "differentiation_evidence_map", "proof_bundles", "brand_priority_angles", "entry_tone_guidance"):
        if field not in architecture_required:
            issue(errors, "information_evidence_contract", shared / "information_evidence_architecture.schema.json", f"{field} must be required")
    proof_required = set(
        architecture_schema.get("properties", {}).get("proof_bundles", {})
        .get("items", {}).get("required", [])
    )
    for field in ("statement", "claim_ids", "source_ids", "necessary_qualification", "applicable_patterns"):
        if field not in proof_required:
            issue(errors, "information_evidence_contract", shared / "information_evidence_architecture.schema.json", f"proof_bundles[].{field} must be required")

    monitoring_schema = json.loads((shared / "monitoring_input.schema.json").read_text(encoding="utf-8"))
    if "input_files" not in set(monitoring_schema.get("required", [])):
        issue(errors, "monitoring_contract", shared / "monitoring_input.schema.json", "input_files must be required")
    if "derived" not in set(monitoring_schema.get("required", [])):
        issue(errors, "monitoring_contract", shared / "monitoring_input.schema.json", "derived analysis must be required")
    for key in ("answers", "source_observations"):
        if monitoring_schema.get("properties", {}).get(key, {}).get("minItems") != 1:
            issue(errors, "monitoring_contract", shared / "monitoring_input.schema.json", f"{key}.minItems must be 1")
    observation_properties = (
        monitoring_schema.get("properties", {})
        .get("source_observations", {})
        .get("items", {})
        .get("properties", {})
    )
    for key in ("author", "citation_context", "cited_claim", "source_type", "primary_source_status", "freshness_risk", "accessed_at"):
        if key not in observation_properties:
            issue(errors, "monitoring_contract", shared / "monitoring_input.schema.json", f"source_observations.{key} is required to preserve Micro Tracking evidence context")
    derived_properties = monitoring_schema.get("properties", {}).get("derived", {}).get("properties", {})
    for key in ("excluded_observations", "answer_landscape", "benchmark_pages", "supplementary_primary_sources"):
        if key not in derived_properties:
            issue(errors, "monitoring_contract", shared / "monitoring_input.schema.json", f"derived.{key} is required by Micro Tracking")

    content_job_schema = json.loads((shared / "content_job.schema.json").read_text(encoding="utf-8"))
    job_properties = content_job_schema.get("properties", {})
    job_required = set(content_job_schema.get("required", []))
    if "entry_category" not in job_required or "scope_analysis_path" not in job_required:
        issue(errors, "content_job_contract", shared / "content_job.schema.json", "entry_category and scope_analysis_path must be required")
    leaked_scope_inputs = {"target_region", "target_audience", "time_scope"} & set(job_properties)
    if leaked_scope_inputs:
        issue(errors, "content_job_contract", shared / "content_job.schema.json", f"user job must not expose adaptive scope fields: {sorted(leaked_scope_inputs)}")
    task_properties = job_properties.get("task", {}).get("properties", {})
    expected_variant_enum = [None, "multi_brand_editorial_recommendation", "single_brand_recommendation"]
    if task_properties.get("requested_pattern_variant", {}).get("enum") != expected_variant_enum:
        issue(errors, "content_job_contract", shared / "content_job.schema.json", "Content Job must expose exactly the two P01 variants plus null")

    model_schema = json.loads((shared / "content_model.schema.json").read_text(encoding="utf-8"))
    model_properties = model_schema.get("properties", {})
    if "entry_category" not in model_properties or "question_category" in model_properties:
        issue(errors, "content_model_contract", shared / "content_model.schema.json", "v2 model must use entry_category only")
    metadata_properties = model_properties.get("metadata", {}).get("properties", {})
    forbidden_title_fields = {"title", "h1", "title_candidates", "meta_description"} & set(metadata_properties)
    if forbidden_title_fields:
        issue(errors, "content_model_contract", shared / "content_model.schema.json", f"title-free metadata forbids {sorted(forbidden_title_fields)}")
    lead = model_schema.get("properties", {}).get("lead", {}).get("properties", {})
    expected = {"direct_answer_sentence": (40, 80), "micro_answer": (200, 300)}
    for key, (minimum, maximum) in expected.items():
        if lead.get(key, {}).get("minLength") != minimum or lead.get(key, {}).get("maxLength") != maximum:
            issue(errors, "content_model_contract", shared / "content_model.schema.json", f"{key} must be {minimum}-{maximum} Unicode characters")
    sections = model_schema.get("properties", {}).get("sections", {})
    if (sections.get("minItems"), sections.get("maxItems")) != (5, 8):
        issue(errors, "content_model_contract", shared / "content_model.schema.json", "sections must be 5-8")
    section_item_properties = sections.get("items", {}).get("properties", {})
    if section_item_properties.get("h2_question", {}).get("pattern") != "[？?]$":
        issue(errors, "content_model_contract", shared / "content_model.schema.json", "H2 questions must end with a question mark")

    blueprint_schema = json.loads((shared / "article_blueprint.schema.json").read_text(encoding="utf-8"))
    if "title_plan" in blueprint_schema.get("properties", {}) or "title_formula_plan" not in blueprint_schema.get("properties", {}):
        issue(errors, "article_blueprint_contract", shared / "article_blueprint.schema.json", "blueprint may keep title_formula_plan but not title candidates")
    section_plan = blueprint_schema.get("properties", {}).get("section_plan", {})
    if (section_plan.get("minItems"), section_plan.get("maxItems")) != (5, 8):
        issue(errors, "article_blueprint_contract", shared / "article_blueprint.schema.json", "section_plan must be 5-8")
    for key in ("lead_plan", "conclusion_plan"):
        if key not in set(blueprint_schema.get("required", [])):
            issue(errors, "article_blueprint_contract", shared / "article_blueprint.schema.json", f"{key} must be required")

    for title_schema_name in ("title_count_receipt.schema.json", "title_map.schema.json"):
        title_schema = json.loads((shared / title_schema_name).read_text(encoding="utf-8"))
        if title_schema.get("properties", {}).get("approved_body_sha256", {}).get("pattern") != "^[a-f0-9]{64}$":
            issue(errors, "title_contract", shared / title_schema_name, "title artifact must bind the final body SHA-256")
    count_schema = json.loads((shared / "title_count_receipt.schema.json").read_text(encoding="utf-8"))
    count_contract = count_schema.get("properties", {}).get("requested_count", {})
    if count_contract.get("minimum") != 1 or count_contract.get("maximum") != 20 or count_contract.get("type") != "integer":
        issue(errors, "title_contract", shared / "title_count_receipt.schema.json", "title_count must be an integer from 1 through 20")

    actual_e1 = root / "Execution_Workflow" / "E1.单篇任务建档师.skill" / "SKILL.md"
    if not actual_e1.is_file():
        issue(errors, "router_contract", actual_e1, "canonical E1 task-entry target is missing")
    active_skills = [path for path in root.rglob("SKILL.md") if not is_ignored(path) and not is_legacy_artifact(path)]
    if len(active_skills) != 20:
        issue(errors, "single_entry_contract", root, f"expected 20 active Skills (root 1 + Strategy 9 + Execution 10), found {len(active_skills)}")
    strategy_ids = sorted(path.parent.name.split(".", 1)[0] for path in active_skills if "Strategy_Workflow" in path.parts)
    execution_ids = sorted(path.parent.name.split(".", 1)[0] for path in active_skills if "Execution_Workflow" in path.parts)
    if strategy_ids != [f"S{i}" for i in range(1, 10)]:
        issue(errors, "stage_sequence", root / "Strategy_Workflow", f"active strategy stages must be S1-S9, found {strategy_ids}")
    if execution_ids != ["E1", "E10", "E2", "E3", "E4", "E5", "E6", "E7", "E8", "E9"]:
        issue(errors, "stage_sequence", root / "Execution_Workflow", f"active execution stages must be E1-E10, found {execution_ids}")
    root_router = root / "00.FrontMind内容制作总控.skill" / "SKILL.md"
    if not root_router.is_file():
        issue(errors, "single_entry_contract", root_router, "the unique root router is missing")
    master_files = sorted((root / "Master_Control").glob("*.md"))
    canonical_master = root / "Master_Control" / "FrontMind_Content_Workflow_Master.md"
    if master_files != [canonical_master]:
        issue(errors, "single_master_contract", root / "Master_Control", f"Master_Control must contain only {canonical_master.name}")
    counts["contracts"] = len(CANONICAL_SCHEMAS) + 1


def validate(root: Path) -> dict[str, Any]:
    errors: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []
    counts = {
        "skills": 0,
        "json": 0,
        "markdown": 0,
        "relative_links": 0,
        "python": 0,
        "schema_runtime_suites": 0,
        "active_residual_files": 0,
        "contracts": 0,
    }
    check_package_hygiene(root, errors)
    check_skill_frontmatter(root, errors, counts)
    check_json(root, errors, warnings, counts)
    check_markdown(root, errors, warnings, counts)
    check_python(root, errors, warnings, counts)
    check_schema_runtime(root, errors, counts)
    check_prohibited(root, errors, counts)
    check_contracts(root, errors, counts)
    archived = [value for value in warnings if value.get("check") == "legacy_reference"]
    actionable_warnings = [value for value in warnings if value.get("check") != "legacy_reference"]
    return {
        "status": "pass" if not errors else "fail",
        "root": str(root),
        "counts": counts,
        "error_count": len(errors),
        "warning_count": len(actionable_warnings),
        "archived_reference_count": len(archived),
        "errors": errors,
        "warnings": actionable_warnings,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("root", nargs="?", default=str(Path(__file__).resolve().parents[2]))
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    report = validate(Path(args.root).resolve())
    rendered = json.dumps(report, ensure_ascii=False, indent=2)
    print(rendered)
    if args.report:
        args.report.write_text(rendered + "\n", encoding="utf-8")
    return 0 if report["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
