#!/usr/bin/env python3
"""Canonical v2 source publication state machine.

The file is deliberately dependency-free so S9 and E3/E6/E8/E10 can import
the same rules.  File/hash/approval-receipt verification remains the caller's
responsibility; this module only decides whether a source record's declared
origin and authorization are coherent for its storage context.
"""

from __future__ import annotations

from typing import Any, Literal


StorageContext = Literal["base_pack", "runtime"]


def authorization_states(contract: Any, key: str) -> set[str]:
    if not isinstance(contract, dict):
        return set()
    machine = contract.get("authorization_state_machine")
    if not isinstance(machine, dict):
        return set()
    values = machine.get(key)
    return {str(value) for value in values} if isinstance(values, list) else set()


def validate_source_publication(source: Any, storage_context: StorageContext, contract: Any) -> list[str]:
    if not isinstance(source, dict):
        return ["source must be an object"]
    source_id = str(source.get("source_id") or "<unknown>")
    source_type = source.get("source_type")
    origin_class = source.get("source_origin_class")
    authorization = source.get("publication_authorization")
    errors: list[str] = []

    if storage_context not in {"base_pack", "runtime"}:
        return [f"{source_id}: unknown storage context {storage_context!r}"]
    required_states = {
        "base_pack_first_party_official",
        "base_pack_first_party_internal",
        "base_pack_third_party_public",
        "runtime_approved",
    }
    machine = contract.get("authorization_state_machine") if isinstance(contract, dict) else None
    if not isinstance(machine, dict) or not required_states.issubset(machine):
        return [f"{source_id}: publication contract lacks the canonical authorization state machine"]

    if source_type == "first_party_official":
        if origin_class != "first_party_official":
            errors.append(f"{source_id}: first_party_official source has a mismatched origin class")
        if storage_context != "base_pack":
            errors.append(f"{source_id}: runtime material cannot self-identify as base first_party_official")
        if authorization not in authorization_states(contract, "base_pack_first_party_official"):
            errors.append(f"{source_id}: base first-party official source lacks public approval")
    elif source_type == "first_party_internal":
        if (
            origin_class != "first_party_internal"
            or authorization not in authorization_states(contract, "base_pack_first_party_internal")
        ):
            errors.append(f"{source_id}: internal first-party source must remain internal_only")
    elif storage_context == "runtime":
        if (
            origin_class != "runtime_approved"
            or authorization not in authorization_states(contract, "runtime_approved")
        ):
            errors.append(f"{source_id}: runtime source lacks runtime approval")
    else:
        if origin_class != "third_party_public":
            errors.append(f"{source_id}: base third-party source must use third_party_public origin class")
        if authorization not in authorization_states(contract, "base_pack_third_party_public"):
            errors.append(f"{source_id}: base third-party source has a non-publishable authorization")

    if authorization == "not_applicable" and source_type in {"first_party_official", "first_party_internal"}:
        errors.append(f"{source_id}: not_applicable is forbidden for first-party material")
    return errors


def source_is_publishable(source: Any, storage_context: StorageContext, contract: Any) -> bool:
    return (
        not validate_source_publication(source, storage_context, contract)
        and isinstance(source, dict)
        and source.get("source_type") != "first_party_internal"
    )
