#!/usr/bin/env python3

from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path

SHARED = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SHARED))
from content_route import validate_entry_pattern_route, validate_p01_candidate_contract

REGISTRY = json.loads((SHARED / "content-pattern-registry.json").read_text(encoding="utf-8"))


def p01(variant: str, names: list[str], dimensions: list[str]) -> dict:
    return {
        "entry_category": "industry_ranking",
        "pattern_id": "P01",
        "pattern_variant": variant,
        "product_scenario_subintent": None,
        "candidate_contract": {
            "featured_brand_name": "示例品牌",
            "ordered_candidates": [
                {"entity_name": name, "role": "featured_brand" if index == 0 else "other_candidate", "source_ids": [f"src_{index}abc"]}
                for index, name in enumerate(names)
            ],
            "common_dimensions": dimensions,
            "list_semantics": "editorial_recommendation",
        },
    }


class ContentRouteTests(unittest.TestCase):
    def test_illegal_entry_pattern_is_rejected(self) -> None:
        attack = {"entry_category": "industry_ranking", "pattern_id": "P02", "pattern_variant": None, "product_scenario_subintent": None}
        self.assertTrue(validate_entry_pattern_route(attack, REGISTRY))

    def test_foundation_is_strict_two_way(self) -> None:
        self.assertEqual(validate_entry_pattern_route({"entry_category": "foundation_start", "pattern_id": "P13", "pattern_variant": None, "product_scenario_subintent": None}, REGISTRY), [])
        self.assertTrue(validate_entry_pattern_route({"entry_category": "reputation", "pattern_id": "P13", "pattern_variant": None, "product_scenario_subintent": None}, REGISTRY))

    def test_product_subintent_constrains_primary_but_not_approved_secondary_patterns(self) -> None:
        wrong_primary = {
            "entry_category": "product_scenario",
            "pattern_id": "P04",
            "pattern_variant": None,
            "product_scenario_subintent": "price_selection",
        }
        allowed_secondary = {
            "entry_category": "product_scenario",
            "pattern_id": "P09",
            "pattern_variant": None,
            "product_scenario_subintent": "price_selection",
        }
        self.assertTrue(validate_entry_pattern_route(wrong_primary, REGISTRY))
        self.assertEqual(validate_entry_pattern_route(allowed_secondary, REGISTRY), [])

    def test_p01_multi_and_single_positive(self) -> None:
        multi = p01("multi_brand_editorial_recommendation", ["示例品牌", "乙品牌", "丙品牌"], ["功能", "限制"])
        single = p01("single_brand_recommendation", ["示例品牌"], [])
        self.assertEqual(validate_entry_pattern_route(multi, REGISTRY), [])
        self.assertEqual(validate_p01_candidate_contract(multi, "示例品牌"), [])
        self.assertEqual(validate_p01_candidate_contract(single, "示例品牌"), [])

    def test_p01_customer_first_and_candidate_counts_are_hard_gates(self) -> None:
        wrong_first = p01("multi_brand_editorial_recommendation", ["乙品牌", "示例品牌", "丙品牌"], ["功能"])
        self.assertTrue(validate_p01_candidate_contract(wrong_first, "示例品牌"))
        too_few = p01("multi_brand_editorial_recommendation", ["示例品牌", "乙品牌"], ["功能"])
        self.assertTrue(validate_p01_candidate_contract(too_few, "示例品牌"))
        single_with_competitor = p01("single_brand_recommendation", ["示例品牌", "乙品牌"], [])
        self.assertTrue(validate_p01_candidate_contract(single_with_competitor, "示例品牌"))


if __name__ == "__main__":
    unittest.main()
