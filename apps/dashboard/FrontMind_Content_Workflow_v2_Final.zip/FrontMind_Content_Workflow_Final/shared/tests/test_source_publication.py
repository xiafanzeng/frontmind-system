#!/usr/bin/env python3

from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from source_publication import source_is_publishable, validate_source_publication

CONTRACT = json.loads((Path(__file__).resolve().parents[1] / "content-pattern-registry.json").read_text(encoding="utf-8"))["first_party_publication_contract"]


def source(source_type: str, origin: str, authorization: str) -> dict:
    return {
        "source_id": "src_fixture_001",
        "source_type": source_type,
        "source_origin_class": origin,
        "publication_authorization": authorization,
    }


class SourcePublicationTests(unittest.TestCase):
    def test_base_first_party_public_or_anonymized_passes(self) -> None:
        for authorization in ("public_approved", "anonymized_approved"):
            self.assertEqual(
                validate_source_publication(source("first_party_official", "first_party_official", authorization), "base_pack", CONTRACT),
                [],
            )

    def test_first_party_not_applicable_and_internal_are_blocked(self) -> None:
        self.assertTrue(validate_source_publication(source("first_party_official", "first_party_official", "not_applicable"), "base_pack", CONTRACT))
        internal = source("first_party_internal", "first_party_internal", "internal_only")
        self.assertEqual(validate_source_publication(internal, "base_pack", CONTRACT), [])
        self.assertFalse(source_is_publishable(internal, "base_pack", CONTRACT))

    def test_runtime_requires_runtime_pair(self) -> None:
        self.assertEqual(
            validate_source_publication(source("editorial_media", "runtime_approved", "runtime_approved"), "runtime", CONTRACT),
            [],
        )
        self.assertTrue(validate_source_publication(source("editorial_media", "third_party_public", "not_applicable"), "runtime", CONTRACT))
        self.assertTrue(validate_source_publication(source("first_party_official", "first_party_official", "public_approved"), "runtime", CONTRACT))

    def test_base_third_party_cannot_claim_runtime_or_pending(self) -> None:
        self.assertEqual(
            validate_source_publication(source("editorial_media", "third_party_public", "not_applicable"), "base_pack", CONTRACT),
            [],
        )
        self.assertTrue(validate_source_publication(source("editorial_media", "runtime_approved", "runtime_approved"), "base_pack", CONTRACT))


if __name__ == "__main__":
    unittest.main()
