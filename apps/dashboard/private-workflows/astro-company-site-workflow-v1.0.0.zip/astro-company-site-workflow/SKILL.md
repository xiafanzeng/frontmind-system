---
name: astro-company-site-workflow
description: Build an original, production-ready company marketing website in native Astro from a verified brief, using Prompt-bearing visual references from the existing 21st.dev catalog and one visual choice of up to nine real previews. Use for company sites, product landing pages, and institutional websites that must avoid manual Prompt copying and provider code reuse.
---

# Astro Company Site Workflow

Create the complete site in the same run after one visual-direction choice. Treat 21st.dev as a visual Prompt source, not a source-code dependency.

## Non-negotiable contract

- Use only existing 21st.dev catalog items reached through an authorized 21st MCP connection. Do not call 21st generation, iteration, or publishing tools.
- Use the 18/12/9 target funnel: seek 18 unique search results, retrieve in rank order until 12 Prompt-bearing items are valid or the pool is exhausted, and present up to 9 real catalog previews in one visual selection. If the catalog is smaller, show every valid option and record the degraded counts; never fabricate or generate fillers.
- Keep one unique provider item ID, canonical source URL, and provider preview URL per presented option. A normal nine-option board must include meaningful compositional diversity, not cosmetic variants.
- The user's one A–I choice selects the Foundation direction. Afterward, the agent may automatically choose zero to two already retrieved Prompt-bearing supporting sources, scoped only to a section pattern or motion behavior; they cannot alter Foundation color, typography, or density.
- A retrieved item is usable only when the MCP result contains a nonempty Prompt. Never reinterpret code, demo text, descriptions, or install instructions as that Prompt.
- Keep raw provider Prompt/code only in host memory or a protected operating-system temporary location long enough to hash and normalize it. Never persist raw provider payloads under `.site-build`, in the selection, or in the build contract.
- Do not install, paste, translate, or derive implementation code from a provider component. Rebuild the selected visual language as original native Astro and native CSS.
- Do not use ImageGen to create, redraw, improve, or fill any UI reference, moodboard, wireframe, or selection option. Every displayed option must show provider-returned preview media.
- Keep credentials in the host's secret store or environment. Never write API keys, bearer tokens, OAuth tokens, or credential files into the skill, project, artifacts, logs, or Prompt.
- Use verified company facts only. Never copy demo claims, logos, names, metrics, testimonials, or media from a catalog item.
- When the brief contains visual references, both query composition and result normalization require the matching validated visual observation; neither stage may silently omit it.
- Treat the packaged Workflow as read-only. Define absolute `WORKFLOW_ROOT` and `SITE_PROJECT_ROOT`, run site commands from `SITE_PROJECT_ROOT`, and write every runtime artifact only beneath the site's `.site-build/` or its normal project paths.

## Start here

1. Read [references/workflow.md](references/workflow.md) and [references/company-research.md](references/company-research.md).
2. Read [adapters/generic-http-mcp.md](adapters/generic-http-mcp.md), then only the adapter matching the active host:
   - [Codex](adapters/codex.md)
   - [Claude Code](adapters/claude-code.md)
   - [Claude Desktop](adapters/claude-desktop.md)
   - [Cursor](adapters/cursor.md)
   - [VS Code / GitHub Copilot](adapters/vscode-copilot.md)
   - [Windsurf](adapters/windsurf.md)
   - [21st CLI compatibility](adapters/21st-cli.md), only when native MCP cannot be exposed by the host
3. Before catalog work, read [references/21st-selection-policy.md](references/21st-selection-policy.md).
4. After the user selects A–I, read [references/prompt-compiler.md](references/prompt-compiler.md), [references/visual-system.md](references/visual-system.md), and [references/anti-patterns.md](references/anti-patterns.md).
5. Before implementation, read [references/astro-static-profile.md](references/astro-static-profile.md) and [references/seo-geo-policy.md](references/seo-geo-policy.md).
6. Before handoff, read [references/quality-gates.md](references/quality-gates.md).

## Execution boundary

Reject an individual malformed native-MCP catalog item and continue through the bounded search pool when the selection policy permits it. Stop with the documented blocking error when the connection/capability is unavailable, the CLI path lacks an explicit Prompt, a forbidden generation/mutation call is attempted, zero presentable options remain, the user selection is pending, or native-Astro validation cannot be satisfied. Do not silently switch providers, use the CLI as an undocumented data source, generate substitute UI imagery, or ask the user to copy a Prompt manually.

If the user explicitly changes a hard constraint, record the override in the build contract and provenance before proceeding. Provenance must identify this Workflow version and contain at least the selected Foundation source. Ordinary permission to build a site does not authorize publishing, deployment, account changes, or paid provider operations.
