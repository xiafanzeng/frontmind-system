# 21st CLI Compatibility Adapter

This is a constrained compatibility adapter, not the preferred Prompt path. Use native HTTP MCP whenever the host can expose it.

## Hard limitation

The documented CLI command `21st get <id> --json` retrieves component code and demo data. Official CLI help does not guarantee a Prompt. The CLI is conforming only when observed runtime JSON for every needed item includes a distinct, nonempty Prompt field.

If that field is absent or empty, emit `CLI_PROMPT_MISSING` and stop. Never derive a Prompt from code, demo text, description, install instructions, or a README. Never ask the user to copy it manually.

## Authentication

Prefer an existing CLI login stored by 21st or a host-injected `TWENTYFIRST_TOKEN` / `API_KEY_21ST` environment variable; current CLI help supports both. Although the CLI also accepts `--api-key`, this workflow forbids passing a literal secret on the command line. Do not put a key in a project `.env`, JSON capture, log, or script.

Confirm the active identity without printing credentials:

```bash
WORKFLOW_ROOT="/absolute/path/to/astro-company-site-workflow"
SITE_PROJECT_ROOT="/absolute/path/to/site-project"
cd "$SITE_PROJECT_ROOT"
npx @21st-dev/cli@latest whoami
```

## Existing-catalog operations

Use JSON output without printing provider Prompt/code to the terminal, a transcript, or any durable log. Route stdout directly into a host-memory pipe when the host can normalize it in memory. Otherwise create each raw capture with the operating system's secure temporary-file facility outside both roots, apply mode `0600`, and never use `tee`. This abbreviated retrieval example redirects the JSON instead of displaying it:

```bash
WORKFLOW_ROOT="/absolute/path/to/astro-company-site-workflow"
SITE_PROJECT_ROOT="/absolute/path/to/site-project"
cd "$SITE_PROJECT_ROOT"
umask 077
SEARCH_JSON="$(mktemp "${TMPDIR:-/tmp}/21st-search.XXXXXX")" || exit 1
ITEM_JSON="$(mktemp "${TMPDIR:-/tmp}/21st-item.XXXXXX")" || exit 1
chmod 600 "$SEARCH_JSON" "$ITEM_JSON"
npx @21st-dev/cli@latest search "<foundation-query>" --limit 18 --json >"$SEARCH_JSON"
npx @21st-dev/cli@latest get "<item-id>" --json >"$ITEM_JSON"
```

Ingest each capture into protected host memory, then unlink it immediately. Do not leave the sample files in place, copy them into `.site-build`, or preserve shell command output. If the host needs one combined normalizer input, create that file through the same `umask 077`/`0600` temporary lifecycle and delete it immediately after normalization, including on error.

These equivalents are allowed only for the same existing-catalog 18→12→9 funnel. Do not run `generate`, `iterate`, `take`, `add`, `publish`, or another mutation/install command.

```bash
WORKFLOW_ROOT="/absolute/path/to/astro-company-site-workflow"
SITE_PROJECT_ROOT="/absolute/path/to/site-project"
RUNTIME_JSON="/absolute/os-temp/21st-runtime-0600.json"
cd "$SITE_PROJECT_ROOT"
python3 -B "$WORKFLOW_ROOT/scripts/normalize_21st_result.py" \
  --input "$RUNTIME_JSON" \
  --brief "$SITE_PROJECT_ROOT/.site-build/company-brief.json" \
  --observation "$SITE_PROJECT_ROOT/.site-build/visual-observation.json" \
  --source cli \
  --output "$SITE_PROJECT_ROOT/.site-build/visual-selection.json"
```

Use `--observation` whenever the brief has visual references; the normalizer must fail rather than omit it in that case. Omit it only when the brief has none. The CLI compatibility path is blocking if any required retrieval lacks an explicit nonempty Prompt; unlike native MCP item rejection, do not silently continue a code/demo-only CLI path. Hash and compile a valid Prompt into normalized directives, then immediately close and unlink `RUNTIME_JSON` through the host's safe temporary-file lifecycle. Only provider metadata, preview evidence, Prompt SHA-256, and normalized directives may enter `visual-selection.json`. Provider code must not enter the build contract or implementation context.

Official references:

- [21st MCP and CLI usage](https://docs.21st.dev/mcp)
- [21st CLI overview](https://21st.dev/blog/introducing-agents-cli)

Record the CLI version and runtime JSON field used for Prompt extraction in provenance. A successful `get` exit code is not proof that Prompt retrieval succeeded.
