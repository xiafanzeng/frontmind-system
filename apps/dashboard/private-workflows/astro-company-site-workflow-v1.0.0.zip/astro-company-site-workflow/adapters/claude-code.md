# Claude Code Adapter

Read [generic-http-mcp.md](generic-http-mcp.md) first.

## Configuration

21st documents Claude Code as a supported MCP client. Its initializer can create or merge the project MCP configuration:

```bash
WORKFLOW_ROOT="/absolute/path/to/astro-company-site-workflow"
SITE_PROJECT_ROOT="/absolute/path/to/site-project"
cd "$SITE_PROJECT_ROOT"
npx @21st-dev/cli@latest init --client claude --write
```

Configuration is an adapter/setup concern only; it is not part of the site workflow. Inspect generated configuration before use. It must reference a host-provided environment variable or approved secret source and must not contain a literal API key. Keep any project `.mcp.json` out of the portable package and do not commit credentials.

When an existing 21st connection is present, skip initialization. Discover the native `search` and `get_component` schemas exposed to Claude Code and map them to the portable operations.

Claude Code is normally a structured-text MCP client. Do not require MCP Apps cards. Use provider preview URLs from the structured result to create the single board of up to nine options, preserving an honest degraded count when the exhausted catalog pool yields fewer than nine.

Official references:

- [21st MCP setup](https://docs.21st.dev/mcp)
- [21st client initializer behavior](https://21st.dev/blog/introducing-agents-cli)

## Secret rule

Do not pass the key as a literal CLI argument or paste it into `.mcp.json`. If the host cannot inject a secret reference securely, stop with `MCP_AUTH_FAILED` and ask the user to complete host-level setup; do not request the key in chat.
