# Claude Desktop Adapter

Read [generic-http-mcp.md](generic-http-mcp.md) first.

## Configuration

Use the official Claude Desktop OAuth connector flow for 21st when available. OAuth keeps the credential in the host and avoids putting an API key in a file or Prompt. If the connector is already authorized, do not reconnect it or change the account.

The workflow consumes structured `search` and `get_component` results. Claude Desktop may enhance them with MCP Apps cards, but cards are presentation only. The recorded item IDs, Prompt hashes, and preview URLs must come from the structured tool result.

Official references:

- [21st client and OAuth setup](https://21st.dev/blog/introducing-agents-cli)
- [21st MCP Apps behavior](https://21st.dev/blog/introducing-mcp-apps)

## Selection presentation

MCP Apps may render individual result galleries, but the workflow still requires one simultaneous board containing up to nine finalists. Use sequential A–I labels for the available options, compose the board from returned preview media, and ask once. Nine is the normal target; after the bounded pool is exhausted, present every valid option with the documented degraded count instead of inventing fillers. Do not treat a card's “get code” action as Prompt retrieval, and do not install or copy code.

If OAuth succeeds but `get_component` does not expose a nonempty Prompt, emit `MCP_PROMPT_MISSING`; a clickable card or code result does not satisfy the contract.
