# Codex Adapter

Read [generic-http-mcp.md](generic-http-mcp.md) first. This file only describes the Codex host boundary.

## Configuration

Keep the connection in the user's Codex configuration, outside this package and every generated site. The official equivalent configuration is:

```toml
[mcp_servers.21st]
url = "https://21st.dev/api/mcp"
bearer_token_env_var = "API_KEY_21ST"
```

Store `API_KEY_21ST` in the environment or secret facility used to launch Codex. Do not put its value in `config.toml`, a repository `.env` file, skill metadata, a shell command transcript, or an artifact.

If 21st is already connected, do not reinstall it or alter account settings. Verify the exposed server identity and discover the runtime schemas for `search` and `get_component`. Codex may surface namespaced tool names; the portable core maps by capability.

The optional official 21st Codex plugin is not a portable-core dependency and must not be installed merely to run an already connected server.

Official references:

- [21st Codex plugin and MCP configuration](https://github.com/21st-dev/codex-plugin)
- [21st client setup](https://21st.dev/blog/introducing-agents-cli)

## Selection presentation

If the Codex host can display provider previews inline, present the available sequential A–I options together, up to nine. Otherwise create a local non-generative HTML/Markdown board that references the provider-returned preview URLs. Preserve any documented catalog shortfall; do not use ImageGen and do not depend on MCP Apps UI controls.
