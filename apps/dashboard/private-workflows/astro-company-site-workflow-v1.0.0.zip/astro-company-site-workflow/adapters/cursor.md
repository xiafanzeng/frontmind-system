# Cursor Adapter

Read [generic-http-mcp.md](generic-http-mcp.md) first.

## Configuration

21st supports Cursor through its setup page and CLI initializer:

```bash
WORKFLOW_ROOT="/absolute/path/to/astro-company-site-workflow"
SITE_PROJECT_ROOT="/absolute/path/to/site-project"
cd "$SITE_PROJECT_ROOT"
npx @21st-dev/cli@latest init --client cursor --write
```

The initializer targets the user's Cursor MCP configuration. Treat the result as host configuration, not a package artifact. Before use, verify that authentication is supplied through a host secret or environment reference. Never commit a literal key or copy it into the generated website.

If Cursor already exposes the 21st MCP, skip setup. Discover the server's `search` and `get_component` schemas and use only existing-catalog read operations.

Official references:

- [21st MCP setup](https://docs.21st.dev/mcp)
- [21st client setup](https://21st.dev/blog/introducing-agents-cli)

## Selection presentation

Use returned preview media for one board of up to nine sequential A–I options. Cursor browser or preview features may display the board, but the adapter must not scrape the 21st website, invoke code-install actions, generate replacement UI images, or hide a documented catalog shortfall.
