# Generic HTTP MCP Adapter

Use this as the common adapter contract for every host. Then read the host-specific adapter for configuration placement and credential handling.

## Endpoint and transport

The current 21st server is a remote HTTP MCP endpoint:

```text
https://21st.dev/api/mcp
```

Configure it in the host's MCP settings, not inside the workflow package or generated website. A generic shape is:

```json
{
  "mcpServers": {
    "21st": {
      "url": "https://21st.dev/api/mcp",
      "headers": {
        "x-api-key": "${API_KEY_21ST}"
      }
    }
  }
}
```

This is an abstract example. Use it only when the host expands the environment reference or injects the value from its secret store. Never replace the reference with a literal key in a project file. If the host cannot inject secrets securely, use its OAuth connector or another documented host-level secret mechanism.

Official setup references:

- [21st MCP setup](https://docs.21st.dev/mcp)
- [21st agent and client setup](https://21st.dev/blog/introducing-agents-cli)
- [Unified 21st MCP compatibility repository](https://github.com/21st-dev/magic-mcp)

## Required runtime capabilities

Discover the active server's tool schema. The portable operations normally map to:

| Portable operation | Current native MCP capability |
|---|---|
| Search existing catalog | `search` |
| Retrieve existing item and Prompt | `get_component` |
| Optional read-only usage/entitlement check | `get_usage` when exposed |
| Optional read-only theme context | `get_theme` when exposed |

Names may be host-namespaced. Match by advertised server and schema, not by fuzzy tool-name guessing.

Before the 18→12→9 funnel, make a low-cost capability probe. If `get_usage` is exposed, call it read-only to confirm that the current account/session can use the catalog operations. Treat the returned real-time entitlement as evidence; never infer permissions or billing behavior from a plan name. Absence of `get_usage` is not a failure when `search` and `get_component` work. `get_theme` is likewise optional context and may never become a retrieval or implementation dependency.

A conforming connection must:

1. authenticate without exposing the credential;
2. return structured existing-catalog search results;
3. retrieve an existing item by stable ID;
4. expose a nonempty allowlisted Prompt field in the independent `get_component` response and provider preview media.

`get_component` may also return code. Do not install it, write it to the site, or pass it to implementation. A Prompt or `systemPrompt` present only in `search` output does not satisfy retrieval; bind each accepted Prompt to a separate same-ID `get_component` response and retain only its response hash, Prompt hash, operation name, and safe normalized taxonomy tokens. Keep raw Prompt/code only in host memory or protected OS temporary storage. Discard the retrieval payload, then reacquire only selected exact Prompts ephemerally if the contract composer needs hash proof. Follow [the 21st selection policy](../references/21st-selection-policy.md).

Do not call `generate`, `iterate_generation`, `get_take`, publish tools, mutation tools, or catalog installation actions. Discovery or attempted use of one is a blocking workflow-policy failure, never an item-level rejection that permits the call to continue.

## Structured results and UI extensions

MCP Apps cards are optional presentation. A text-only client must still consume the structured result. Never make the core depend on a `ui://` resource, a card button, clipboard access, or a browser click.

For the A–I selection board, use preview media returned in structured MCP data. An adapter may render those previews with native cards when available, but it must preserve every available option, up to nine, and the same recorded item IDs. It must not merge options that share a source or preview, alter sequential `option_label` values, or mark `board_ready` before Foundation-role, uniqueness, completeness, and diversity checks pass. A depleted bounded pool is shown honestly with fewer options. Persist `selection_evidence` for the user's exact choice or explicit delegation rather than inferring a default.

## Failure behavior

- Endpoint or transport failure: `MCP_UNAVAILABLE`.
- Authentication failure: `MCP_AUTH_FAILED`; do not echo request headers or environment values.
- Missing `search` or `get_component`: `MCP_CAPABILITY_MISSING`.
- Missing explicit Prompt on one native-MCP item: record `MCP_PROMPT_MISSING`, reject that item, and continue in rank order through the bounded pool.
- Missing provider preview or stable source URL on one native-MCP item: record `PREVIEW_MISSING` or `SOURCE_URL_MISSING`, reject it from presentation, and continue through the bounded pool.
- Any generation/mutation attempt: `GENERATE_FORBIDDEN`; stop the workflow without using its output.

Native-MCP item-level evidence failures do not invalidate other valid catalog items. Transport/auth/capability failures, a forbidden generation attempt, zero presentable items, and `CLI_PROMPT_MISSING` on the compatibility path are blocking. Do not fall back to another provider or ask the user to copy a Prompt.
