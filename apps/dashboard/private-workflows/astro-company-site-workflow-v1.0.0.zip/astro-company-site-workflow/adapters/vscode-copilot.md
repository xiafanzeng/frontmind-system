# VS Code / GitHub Copilot Adapter

Read [generic-http-mcp.md](generic-http-mcp.md) first.

## Configuration

The current 21st initializer lists VS Code as a supported client:

```bash
WORKFLOW_ROOT="/absolute/path/to/astro-company-site-workflow"
SITE_PROJECT_ROOT="/absolute/path/to/site-project"
cd "$SITE_PROJECT_ROOT"
npx @21st-dev/cli@latest init --client vscode --write
```

Use the VS Code or GitHub Copilot MCP configuration surface supported by the installed version. Keep the connection outside the portable package. Store authentication in the editor's secret/input facility or an environment reference; reject any generated configuration that embeds a literal key in workspace settings.

MCP support and configuration placement can vary by VS Code/Copilot version. Do not invent a path or setting name. Confirm that the active agent session exposes 21st `search` and `get_component` with structured results before starting the catalog funnel.

Official references:

- [Unified 21st MCP client list](https://github.com/21st-dev/magic-mcp)
- [21st MCP setup](https://docs.21st.dev/mcp)

## Selection presentation

Use an editor preview, Markdown, or local HTML to show all available provider previews together, up to nine sequential A–I options. If the bounded pool yields fewer than nine, retain the degraded count and show every valid option. The presentation may not redraw, fabricate, or generate UI imagery.
