# Windsurf Adapter

Read [generic-http-mcp.md](generic-http-mcp.md) first.

## Configuration

The current unified 21st initializer lists Windsurf as a supported client:

```bash
WORKFLOW_ROOT="/absolute/path/to/astro-company-site-workflow"
SITE_PROJECT_ROOT="/absolute/path/to/site-project"
cd "$SITE_PROJECT_ROOT"
npx @21st-dev/cli@latest init --client windsurf --write
```

Keep the generated connection in the host's MCP settings, outside the portable package and site repository. Verify that credentials are injected by the host or environment and that no literal key is stored in a project file.

When the server is already connected, do not rerun setup. Discover the runtime schemas and map 21st `search` and `get_component` to the portable operations. Use only existing-catalog reads.

Official references:

- [Unified 21st MCP compatibility repository](https://github.com/21st-dev/magic-mcp)
- [21st MCP setup](https://docs.21st.dev/mcp)

## Selection presentation

Render one board of up to nine sequential A–I options from provider preview URLs using Windsurf's supported preview surface or a local non-generative page. Preserve the documented degraded count when fewer are available. Do not use ImageGen or provider code to fabricate the options.
