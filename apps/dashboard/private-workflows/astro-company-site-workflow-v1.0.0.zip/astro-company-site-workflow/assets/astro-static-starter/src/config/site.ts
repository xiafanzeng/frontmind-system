export const site = {
  name: "Northstar Works",
  legalName: "Northstar Works",
  description:
    "A clear digital foundation for companies with something substantial to say.",
  language: "en",
  locale: "en_US",
  email: "hello@example.invalid",
  themeColor: "#11151d",
  socialImage: "/social-card.svg",
  navigation: [
    { label: "Approach", href: "/#approach" },
    { label: "Capabilities", href: "/#capabilities" },
    { label: "About", href: "/about/" },
    { label: "Contact", href: "/contact/" },
  ],
  features: {
    llmsTxt: false,
  },
} as const;

export type SiteConfig = typeof site;
