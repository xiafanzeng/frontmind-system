# 21st Existing-Catalog Selection Policy

Use 21st only as an existing-catalog visual Prompt source. The normal targets are 18 searched, 12 valid Prompt-bearing retrievals, and 9 presented. Counts may degrade only when the available catalog pool cannot satisfy them; always record actual counts and never fabricate a candidate.

## Portable MCP capabilities

Every native adapter must expose these semantic operations:

```text
search_existing_catalog(query, filters, limit)
get_existing_component(provider_item_id)
```

They normally map to the current 21st MCP tools `search` and `get_component`; a host may namespace the names. Discover the runtime schemas instead of guessing arguments.

If the runtime also exposes `get_usage`, call it read-only before the funnel to confirm current catalog entitlement. It is optional: its absence does not block a working `search`/`get_component` path, and a returned plan name is not proof of actual permissions or pricing. `get_theme` is also an optional read-only aid; selection, compilation, and Astro implementation must remain complete without it.

Normalize search results to stable item ID, title, kind, author when returned, source URL, preview URL, tags, metadata, and the query role that produced the result. A valid retrieval must be a separate, per-item `get_component` call envelope for the same stable ID and expose a distinct nonempty provider Prompt; a Prompt or `systemPrompt` embedded only in a search result never qualifies. Persist `retrieval_operation: "get_component"` only after validating the envelope, and set `retrieval_response_sha256` to the SHA-256 of the response payload—not the envelope or search item. Hash and compile the Prompt into safe normalized-directive taxonomy tokens while it is transient. Provider code is always ignored.

Adapters must emit each retrieval in this portable envelope before normalization:

```json
{
  "operation": "get_component",
  "requested_provider_item_id": "provider-item-123",
  "response": {
    "provider_item_id": "provider-item-123",
    "prompt": "transient provider Prompt",
    "preview_url": "https://media.example/preview.png"
  }
}
```

`toolName` may replace `operation` when it is exactly `get_component` or a host namespace whose final segment is `get_component`, such as `mcp__21st__get_component`. The explicit requested ID, the response payload's provider ID, and the corresponding search-result ID must all match. A bare result object, a list labeled `getComponentResults`, a missing request ID, an ID mismatch, or an envelope whose operation is `search`, `generate`, or anything other than `get_component` cannot count as retrieval evidence even if it contains a Prompt.

Accept only a nonempty allowlisted Prompt/copy-Prompt/design-Prompt field in the independent `get_component` response. Never accept `systemPrompt`, synthesize from code, demo text, description, README, screenshot, or install command, or persist free-form Prompt sentences as directives. Normalized directives must come from the fixed safe taxonomy defined by the schema/runtime compiler.

## Eligibility and deduplication

A search result can enter the 18 when it:

- comes from authorized 21st `search` structured data;
- has a stable provider item ID and source URL;
- represents a website template, full page, landing-page block, or broad composition rather than an atomic control;
- has provider-returned preview media or a preview reference expected to resolve during retrieval;
- materially relates to the company, audience, page job, or requested tone.

Deduplicate by provider item ID, canonical source URL, and preview URL. Every presented candidate must have a unique nonempty value for all three. Source and preview URLs must use HTTP(S), contain no URL userinfo, and contain no credential-like query parameters. A provider `source_url` must be hosted on `21st.dev` or one of its subdomains so persisted provenance cannot falsely label another provider as 21st; preview media may use an external host. Do not count aliases, themes without a page composition, duplicated preview media, or variants of the same result separately.

## Search 18

Create the query plan from the brief:

```bash
WORKFLOW_ROOT="/absolute/path/to/astro-company-site-workflow"
SITE_PROJECT_ROOT="/absolute/path/to/site-project"
cd "$SITE_PROJECT_ROOT"
python3 -B "$WORKFLOW_ROOT/scripts/compose_21st_query.py" \
  --brief "$SITE_PROJECT_ROOT/.site-build/company-brief.json" \
  --observation "$SITE_PROJECT_ROOT/.site-build/visual-observation.json" \
  --output "$SITE_PROJECT_ROOT/.site-build/21st-query.json"
```

When `brief.visual_references` is nonempty, `--observation` is mandatory for this query composer, later for `normalize_21st_result.py`, and again for `compose_build_contract.py`. All three reject omission, invalidity, brief-hash mismatch, or reference identity/location mismatch where applicable, and the final contract records the observation SHA-256. The query composer may use only each asset's declared `influence_dimensions` and evidence-backed seven-axis observations; it must not infer permission to copy its content.

The output records `observation_sha256` and three English query groups: Foundation, Section, and Motion. For a Chinese/non-English brief, use the verified `visual_direction.business_context_en`; reject a generic “company website” translation that omits industry, audience, or conversion. Queries combine company category and buyer, conversion job, required page/section, and authorized structure/typography/surface/color/imagery/motion/tone signals. They do not prescribe React, Tailwind, or another implementation stack. Tag every ingested result with its plan role. Only candidates with `query_role: "foundation"` may appear on the visual choice board; Section/Motion candidates may become scoped supports after Foundation selection.

Execute the minimum searches needed to accumulate up to 18 unique eligible items. Follow the plan in order and stop at 18 or when the bounded existing-catalog plan is exhausted. Do not pad with irrelevant results, scrape 21st pages, add manual URLs, call generation, or switch providers. Below 18, record `SEARCH_RESULTS_INSUFFICIENT` and continue with the real pool when at least one valid candidate remains.

## Rank the pool and retrieve toward 12

Score the available pool, up to 18, from search metadata and actual preview evidence:

| Dimension | `score_breakdown` field | Weight |
|---|---|---:|
| Reference-image/style match | `reference_style` | 30 |
| Business goal and section-function fit | `business_function` | 25 |
| Visual distinctiveness | `distinctiveness` | 20 |
| Feasibility with the company's real assets | `owned_asset_feasibility` | 10 |
| Responsive and accessibility feasibility | `responsive_accessibility` | 10 |
| Native-Astro translation feasibility | `native_astro_translatability` | 5 |

When there is no authorized reference asset, score the first dimension against verified brand constraints and declared visual direction rather than inventing a reference. Break ties by style match, business/function fit, then stable item ID. Popularity alone never decides.

Call `get_component` in rank order. Invalid or Prompt-less results do not count toward the 12 valid retrieval target: skip them and continue through ranks 13–18 until 12 valid Prompt-bearing results exist or the searched pool is exhausted. Do not write raw output under `.site-build`. If the adapter must materialize combined runtime JSON for the normalizer, use a protected operating-system temporary input and delete it immediately after the prompt-free selection record is written:

```bash
WORKFLOW_ROOT="/absolute/path/to/astro-company-site-workflow"
SITE_PROJECT_ROOT="/absolute/path/to/site-project"
RUNTIME_JSON="/absolute/os-temp/21st-runtime-0600.json"
cd "$SITE_PROJECT_ROOT"
python3 -B "$WORKFLOW_ROOT/scripts/normalize_21st_result.py" \
  --input "$RUNTIME_JSON" \
  --brief "$SITE_PROJECT_ROOT/.site-build/company-brief.json" \
  --observation "$SITE_PROJECT_ROOT/.site-build/visual-observation.json" \
  --source mcp \
  --output "$SITE_PROJECT_ROOT/.site-build/visual-selection.json"
```

Use `--observation` when the brief has visual references; the normalizer must reject its omission or a brief-hash mismatch. Otherwise omit it. The output is prompt-free and may persist. The raw input must not. `RUNTIME_JSON` must be a `0600` OS-temporary file or equivalent host-memory pipe and must be closed and unlinked immediately after normalization, including on failure.

On native MCP, reject any individual item without an explicit nonempty Prompt, stable source URL, provider preview, Foundation query role, or unique source/preview identity; record the item-level reason and continue to the next ranked search result. Do not apply this recovery rule to CLI Prompt failure: `CLI_PROMPT_MISSING` blocks that compatibility path. Any payload or attempted call indicating `generate`/iteration/mutation is `GENERATE_FORBIDDEN` and blocks the workflow; its output may not enter the pool. When the full searched pool yields fewer than 12 valid retrievals, add `RETRIEVAL_RESULTS_INSUFFICIENT`. When it yields fewer than 9 presentable results, display every valid result and add `PRESENTATION_RESULTS_INSUFFICIENT`; do not generate fillers. Zero presentable results is blocking.

## Present 9 once

Choose up to nine finalists while keeping the highest scores and real diversity. For a full nine, allow no more than three effectively identical hero structures and vary at least three meaningful axes such as density, typography, grid, imagery, contrast, surfaces, or motion restraint. The filled `visual_axes` values—including distinct structure/surface/typography signatures—are the persistent evidence used to validate board diversity. Apply the same intent proportionally to a degraded board. Do not set `board_ready: true` until diversity and identity checks pass and one to nine complete finalists exist.

Write `visual-selection/v1`, not `visual-observation`, for the catalog funnel. The normalizer emits `board_ready: false`; the Agent may change it to true only after filling and validating every option's fit reason, score, seven axes, identity, and diversity evidence. Its `targets` remain 18/12/9 and `actual` records honest achieved counts. `searched_candidates` contains the available search-pool evidence and each candidate's `query_role`; `retrieval_shortlist` contains up to 12 valid Prompt-bearing IDs; `presented_candidates` contains up to 9 Foundation options with sequential `option_label` values `A` through `I`. Each persistent candidate stores provider metadata, independent retrieval evidence, preview evidence, Prompt SHA-256, and normalized taxonomy directives—never raw Prompt/code. Set `brief_sha256` and `reference_observation_sha256` to the exact input hashes, and keep `generate_used` and `provider_code_reuse` false.

Display all finalists simultaneously, up to A–I, in a consistent board. Use only provider preview media. Uniform labels, framing, and non-generative resizing are allowed; repainting, fabricated missing areas, and ImageGen UI mockups are not.

Each option includes its `option_label`, actual preview, title, author/source when returned, source link, and one neutral `fit_reason`. Ask once: choose A–I. If the user explicitly delegates the choice, select the highest-scoring finalist; otherwise pause with `USER_SELECTION_REQUIRED`.

Before user choice, save `stage: "normalized"`, `selected: null`, and `board_ready: true` only when the complete available board has passed all readiness checks. After a full-count choice, write `stage: "selected"`; after a documented count shortfall, write `stage: "selected-degraded"`. In either case the Foundation stores item identity, `query_role: "foundation"`, source URL, Prompt SHA-256, normalized directives, score/rationale, and no raw Prompt. Set `selection_evidence` to `user_choice` for the user's exact A–I choice or `explicit_delegation` for the user's explicit delegation to the agent; an inferred/default choice or another value is invalid.

The agent may then add zero to two `supporting_sources` from the already retrieved Prompt-bearing candidates—never from a new search or generation call. Choose a support only when it fills an explicit gap, and assign exactly one `role`:

- `section`: informs a named section's composition or interaction pattern; set both `target_page_path` and `target_section` to real values rather than defaulting to the first section;
- `motion`: informs a bounded motion behavior and reduced-motion fallback; set both target fields to null.

Support sources do not receive a user vote. They store `role`, a matching `query_role`, identity, source URL, Prompt SHA-256, normalized directives, rationale, `target_page_path`, and `target_section`. A section support must come from a `query_role: "section"` candidate and a motion support from `query_role: "motion"`. Foundation directives remain authoritative for global color roles, font roles, density, and overall tone. Reject or trim any support directive that conflicts with them. Keep `generate_used: false` and `provider_code_reuse: false`.

## Blocking errors

| Code | Required action |
|---|---|
| `MCP_UNAVAILABLE` | Stop and point to the matching host adapter. |
| `MCP_AUTH_FAILED` | Stop without exposing headers, tokens, or environment values. |
| `MCP_CAPABILITY_MISSING` | Stop when native `search` or `get_component` is unavailable. |
| `SEARCH_RESULTS_INSUFFICIENT` | Record the search count/reasons below 18; continue with the real pool when nonempty. |
| `MCP_PROMPT_MISSING` | Reject that native-MCP item and continue in rank order. |
| `GET_COMPONENT_CALL_EVIDENCE_INVALID` | Reject the detail; only a validated per-item `get_component` envelope with matching requested/response/search IDs may count. |
| `CLI_PROMPT_MISSING` | Stop the CLI compatibility path; code/demo-only output cannot satisfy the required Prompt contract. |
| `SOURCE_URL_MISSING` | Reject the item; every displayed or supporting source needs a stable provider source link. |
| `PREVIEW_MISSING` | Reject that item from presentation and continue in rank order. |
| `GENERATE_FORBIDDEN` | Stop immediately; discard generation/iteration/mutation output and do not resume from it. |
| `RETRIEVAL_RESULTS_INSUFFICIENT` | Fewer than twelve valid Prompt-bearing retrievals remain after exhausting the pool; record the count and continue when presentable options remain. |
| `PRESENTATION_RESULTS_INSUFFICIENT` | Fewer than nine valid presentable results remain after exhausting the pool; show all valid and state the count. Zero blocks. |
| `USER_SELECTION_REQUIRED` | Pause only after the complete available board exists. |

No error authorizes generation, another provider, manual Prompt copying, provider code reuse, or credential disclosure.
