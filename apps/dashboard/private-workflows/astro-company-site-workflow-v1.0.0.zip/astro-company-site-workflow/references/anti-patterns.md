# Anti-Patterns

Reject these patterns during selection, compilation, implementation, and QA.

## Source and workflow

- Switching to another provider, registry, scraped gallery, or generated UI when 21st retrieval fails.
- Calling 21st generation/iteration tools instead of existing-catalog `search` and `get_component`.
- Treating source code, demo copy, a description, or install instructions as the required Prompt.
- Stopping after invalid results among ranks 1–12 instead of continuing through ranks 13–18 toward twelve valid Prompt-bearing retrievals.
- Asking the user to copy a Prompt manually, fabricating fillers to reach nine, or hiding a degraded candidate count.
- Using ImageGen to create, redraw, repair, or vary UI references.
- Embedding API keys or tokens in skills, repositories, MCP configs, Prompts, logs, or artifacts.
- Persisting raw 21st Prompt/code under `.site-build`, in selection/build-contract JSON, or in the handoff.
- Running site commands from the Workflow package, installing dependencies there, or writing `.site-build`, screenshots, caches, raw payloads, or generated output beneath `WORKFLOW_ROOT`.
- Printing CLI JSON/Prompt/code to terminal transcripts, piping it through `tee`, or leaving a raw capture outside a protected `0600` OS-temporary/host-memory lifecycle.

## Visual design

- Nine near-identical finalists with cosmetic color changes.
- Reusing a provider item ID, canonical source URL, or preview URL across board options; assigning nonsequential A–I labels; or declaring the board ready without recorded diversity evidence.
- Blending several Foundation styles, asking the user to choose support sources, or letting a section/motion support change global palette, fonts, or density.
- Pills for every label, endless rounded bordered cards, and centered alignment for every section.
- Gratuitous rainbow headline gradients, glass on every surface, glow without hierarchy, or animation without meaning.
- Literal AI clichés such as glowing brains, robot hands, neural-network wallpaper, or fake dashboards.
- Guessing an exact font, breakpoint, hidden interaction, or animation from a still preview.
- Copying provider preview media into production or forcing company content into a composition it cannot support.

## Content and entity integrity

- Importing provider demo names, metrics, customers, testimonials, links, logos, or stock images.
- Filling research gaps with plausible claims, locations, credentials, pricing, or contact details.
- Duplicating generic value propositions across every page.
- Hiding core facts in images, decorative canvases, or client-only UI.

## Astro implementation

- Adding React/Vue/Svelte/Preact/Solid or framework islands for ordinary marketing UI.
- Installing shadcn, 21st packages, registry code, online themes, or a third-party starter.
- Translating provider JSX/Tailwind line by line and calling it original.
- Adding Tailwind to a new project, unnecessary runtime JavaScript, scroll hijacking, cursor replacement, or inaccessible marquees.
- Simulating form success or external integrations that do not exist.

## SEO, GEO, and QA

- Inventing a canonical domain, `lastmod`, social identity, schema type, review score, or crawler rule.
- Enabling `llms.txt` by default or promising rankings/citations.
- Declaring accessibility or responsive QA from source inspection alone.
- Treating a dev server as a production build, skipping built-HTML SEO checks, or reporting tools that were not run.
- Hiding unresolved failures instead of recording them in the QA report.
