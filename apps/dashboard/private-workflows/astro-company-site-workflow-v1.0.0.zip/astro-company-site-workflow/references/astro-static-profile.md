# Astro Static Profile

Implement the approved contract as an original static-first Astro site. Native Astro means `.astro` components, native CSS, `astro:assets`, and minimal browser JavaScript—not React rendered inside Astro.

## Project route

- Existing Astro project: inspect its package manager, configuration, content conventions, and user changes. Preserve compatible conventions and avoid unrelated rewrites.
- New or empty target: run `$WORKFLOW_ROOT/scripts/scaffold_astro.py` against the packaged static starter. Do not replace it with an online theme or third-party starter.
- Non-Astro, nonempty target: stop for an explicit destination or migration decision. Do not overwrite it.

```bash
WORKFLOW_ROOT="/absolute/path/to/astro-company-site-workflow"
SITE_PROJECT_ROOT="/absolute/path/to/new-or-empty-site"
cd "$SITE_PROJECT_ROOT"
python3 -B "$WORKFLOW_ROOT/scripts/scaffold_astro.py" \
  --target "$SITE_PROJECT_ROOT" \
  --site-name "Example Company" \
  --language en \
  --contact-email hello@example.com
```

The target directory must already exist and be empty before `cd`. Add `--site-url https://example.com` only when the verified production origin is known.

## Stack invariants

- Use `.astro` layouts, pages, and components with semantic HTML.
- Use CSS custom properties from `design_system`; choose scoped/global native CSS according to project conventions.
- Use `astro:assets` for owned local images and responsive optimization.
- Use minimal vanilla JavaScript only when HTML/CSS cannot provide the behavior; prefer progressive enhancement.
- Do not add React, Preact, Vue, Svelte, Solid, another client UI framework, shadcn, a 21st package, or provider source files.
- Do not add Tailwind to a new project. If an existing Astro site already uses it, it may remain when removal would be unrelated; record the exception and still create original native Astro components.
- Do not create fake integrations, submissions, customer claims, dashboards, or metrics.

## Page requirements

Build only routes supported by the brief and contract. Every route needs one clear purpose and primary action, valid heading order, keyboard-accessible navigation, visible focus, useful image alternatives, responsive behavior without horizontal overflow, and a no-script baseline for essential content.

For a static contact form, never imply successful delivery without a real authorized endpoint. Use a documented contact fallback or leave integration as an explicit handoff item.

Recreate the selected visual grammar—not its pixels. Composition, hierarchy, density, type contrast, surface treatment, and motion restraint may carry through while markup, CSS, content, and assets remain original.

Respect `prefers-reduced-motion`. Avoid scroll hijacking, cursor replacement, inaccessible marquees, layout-shifting entrance effects, and motion required to understand content.

## Native validation

After a successful production build:

```bash
WORKFLOW_ROOT="/absolute/path/to/astro-company-site-workflow"
SITE_PROJECT_ROOT="/absolute/path/to/site-project"
cd "$SITE_PROJECT_ROOT"
python3 -B "$WORKFLOW_ROOT/scripts/validate_native_astro.py" \
  --project "$SITE_PROJECT_ROOT" \
  --output "$SITE_PROJECT_ROOT/.site-build/native-astro.validation.json"
```

Any forbidden integration, provider code reuse, or framework-hydrated UI introduced by this run is `ASTRO_NATIVE_VIOLATION`. Repair within Astro; do not change provider or selected direction.
