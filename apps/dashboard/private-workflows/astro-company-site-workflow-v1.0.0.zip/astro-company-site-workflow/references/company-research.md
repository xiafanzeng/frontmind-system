# Company Research

Research enough to make the website accurate, differentiated, and useful. Do not turn missing facts into plausible marketing copy.

## Evidence hierarchy

Prefer sources in this order:

1. files, brand assets, and facts supplied by the user;
2. the company's current official website, official documentation, filings, and owned profiles;
3. authoritative registries, standards bodies, or first-party partner pages;
4. reputable secondary reporting for context only.

Record each usable statement in `verified_facts` with a stable ID, exact claim, source description, optional URL, and verification date. Put contradictions, missing facts, and unresolved decisions in `unknowns`. A competitor's claim, catalog demo, search snippet, or inferred capability is not a company fact.

## Build the brief

Populate `schemas/company-brief.schema.json` with:

- canonical company name, legal/alternate names when verified, sector, business model, and concise summary;
- site scope, canonical origin when known, locale policy, host policy, and trailing-slash policy;
- distinct audiences and one primary conversion with a real destination when known;
- required pages, purpose, locale, indexability, and section intent;
- verified facts, unknowns, constraints, and official source URLs;
- only confirmed visual assets and brand constraints.

For each authorized reference image or screenshot, add a `visual_references[]` item with `reference_id`, location, optional matching `asset_id`, allowed `influence_dimensions`, and notes. A nonempty `visual_references` array makes `visual-observation.json` mandatory; the query composer, result normalizer, and build-contract composer must each receive the exact validated observation through `--observation` and reject an absent or mismatched record.

For a Chinese or otherwise non-English brief, the agent must add a faithful `visual_direction.business_context_en` array of 2–10 concise English/ASCII context strings. Together they must name the verified industry/offer, audience, and primary conversion so 21st retrieval is specific; they may translate and compress but cannot add claims or reduce the context to a generic “company website.”

Do not invent a canonical origin, contact channel, office, team member, customer, metric, certification, price, legal promise, testimonial, or social profile. When the user has not supplied enough information, use factual neutral copy and preserve the gap in `unknowns`.

Validate the brief before catalog search:

```bash
WORKFLOW_ROOT="/absolute/path/to/astro-company-site-workflow"
SITE_PROJECT_ROOT="/absolute/path/to/site-project"
cd "$SITE_PROJECT_ROOT"
python3 -B "$WORKFLOW_ROOT/scripts/validate_inputs.py" \
  --schema company-brief \
  --input "$SITE_PROJECT_ROOT/.site-build/company-brief.json" \
  --output "$SITE_PROJECT_ROOT/.site-build/company-brief.validation.json"
```

## Observe supplied visual references

Create one `visual-observation/v1` record for user-owned brand files, screenshots, reference images, and other authorized visual inputs. Each `assets[]` entry records:

- `asset_id`, role, location, ownership, and license;
- `influence_dimensions`, limited to aspects the asset is allowed to influence;
- observations for structure, typography, surface, color, imagery, motion, and tone;
- evidence that distinguishes visible facts from inference.

For an asset with `role: "visual_reference"`, add 3–12 concise ASCII-English `search_terms_en` derived only from its allowed influence dimensions and visible evidence. These terms guide 21st retrieval; they must not name copied content, infer hidden behavior, or collapse to generic “modern website” language.

Do not place 21st search results in this record. Do not treat a user reference as permission to copy its code, text, logo, or media. If an asset's rights or intended influence are unknown, record that limitation rather than silently using it.

## Content model

For each page, define:

- the audience question it answers;
- the one action it should advance;
- the verified facts it may use;
- the claims it must not make;
- the proof or asset needed;
- the route's relationship to the company's core entity.

Use specific language from verified offerings and customer problems. Avoid generic claims such as “leading,” “revolutionary,” “best-in-class,” or “trusted by thousands” without evidence.

## Research-to-visual query boundary

The 21st query may include sector, audience, page job, information architecture, and desired tone. It must not include confidential material, API credentials, unsupported claims, or personal data. Search for a composition that serves the company; do not search for a competitor clone.

Company and brand facts always override provider Prompt/demo content. Research ends in the brief; provider data never flows back into `verified_facts`.
