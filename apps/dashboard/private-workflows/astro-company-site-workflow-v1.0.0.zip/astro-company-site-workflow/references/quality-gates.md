# Quality Gates

Complete each gate in order. A downstream success never cancels an upstream failure.

## Gate 1: package and brief

- `$WORKFLOW_ROOT/scripts/doctor.py` and `$WORKFLOW_ROOT/scripts/self_check.py` pass for the package and active environment while the current directory is `SITE_PROJECT_ROOT`.
- `VERSION` is `1.0.0`; `MANIFEST` declares the same package version, records SHA-256 for every packaged file except itself, and declares `build-contract.json` as the single top-level execution contract.
- `company-brief.json` validates against `company-brief/v2`.
- Company claims have sources; unknowns and forbidden assumptions remain explicit.

## Gate 2: visual source

- `visual-observation.json` hashes the brief and records only authorized user/brand/reference assets across structure, typography, surface, color, imagery, motion, and tone.
- `visual-selection.json` keeps targets at 18/12/9 and records honest actual counts. Invalid retrievals are skipped in rank order through the available pool.
- Every displayed option—normally nine, fewer only when the pool is exhausted—uses actual provider preview media.
- Any shortfall records `SEARCH_RESULTS_INSUFFICIENT`, `RETRIEVAL_RESULTS_INSUFFICIENT`, and/or `PRESENTATION_RESULTS_INSUFFICIENT` as applicable; zero presentable candidates blocks.
- The user made one A–I choice or explicitly delegated it.
- `visual-selection.json` has `board_ready: true`, `stage: "selected"` for full counts or `stage: "selected-degraded"` for a documented shortfall, one to nine presented candidates, one selected Prompt SHA-256 plus normalized directives, no raw Prompt/code, `generate_used: false`, and `provider_code_reuse: false`.
- Every presented candidate resolves to a searched candidate with `query_role: "foundation"`; every presented record has a sequential `option_label` from A through I and nonempty `fit_reason`. Provider item IDs, source URLs, and preview URLs are each unique across the board. The full board satisfies the recorded compositional-diversity evidence; a degraded board satisfies the proportional rule.
- The selected Foundation's `selection_evidence` is `user_choice` for the user's exact option choice or `explicit_delegation` for the user's explicit delegation. A silent default does not pass.
- Every presented candidate has the approved six-part `score_breakdown`, and its non-null values sum to its 0–100 score.
- `supporting_sources` contains zero to two already retrieved Prompt-bearing candidates. Each is scoped to `section` or `motion`, has a matching `query_role`, stores only a Prompt hash plus normalized directives, and does not override Foundation color, typography, or density. A `section` source sets a real `target_page_path` and `target_section`; a `motion` source sets both fields to null.

## Gate 3: contract

- Brief, selection, and SEO manifest validate before composition.
- Agent-authored `design-system.json` strictly matches the build-contract `design_system` subschema; it contains exact, evidence-based values and no generic fallback theme.
- `build-contract.json` validates; its brief, selection, SEO, design-system, and (when references exist) visual-observation hashes match the exact source artifacts.
- `design_system` has `style_profile`, `design_tokens`, `layout_grammar`, `imagery_plan`, `motion`, at least three `responsive_rules`, and `component_adaptation`.
- The composer verified the Foundation Prompt and every supporting Prompt against their stored SHA-256 using ephemeral inputs; no raw Prompt/code appears in any persistent artifact, and all temporary Prompt files are removed after composition.
- The contract contains only verified facts and explicit acceptance checks.

## Gate 4: production and native Astro

Use the detected package manager to run the production build and Astro check when configured. Then run:

```bash
WORKFLOW_ROOT="/absolute/path/to/astro-company-site-workflow"
SITE_PROJECT_ROOT="/absolute/path/to/site-project"
cd "$SITE_PROJECT_ROOT"
python3 -B "$WORKFLOW_ROOT/scripts/validate_native_astro.py" \
  --project "$SITE_PROJECT_ROOT" \
  --output "$SITE_PROJECT_ROOT/.site-build/native-astro.validation.json"

python3 -B "$WORKFLOW_ROOT/scripts/validate_dist_seo.py" \
  --dist "$SITE_PROJECT_ROOT/dist" \
  --manifest "$SITE_PROJECT_ROOT/.site-build/seo-manifest.json" \
  --output "$SITE_PROJECT_ROOT/.site-build/seo.validation.json"
```

The build must contain no forbidden client UI framework introduced by this run, provider source code, demo company, or broken internal route. A placeholder/unresolved origin is tolerated only for a local non-launch build when `launch_ready: false` and the manifest/QA report names it as a warning plus `external_pending`; it is forbidden in a production-ready handoff. Use `validate_dist_seo.py --strict-warnings` for the launch gate, not for an intentionally local-only QA pass.

## Gate 5: responsive visual QA

Start a production-equivalent local preview and run only the routes in the contract:

```bash
WORKFLOW_ROOT="/absolute/path/to/astro-company-site-workflow"
SITE_PROJECT_ROOT="/absolute/path/to/site-project"
cd "$SITE_PROJECT_ROOT"
node "$WORKFLOW_ROOT/scripts/visual_qa.mjs" \
  --url http://127.0.0.1:4321 \
  --output "$SITE_PROJECT_ROOT/.site-build/visual-qa" \
  --path / \
  --path /about \
  --path /contact \
  --timeout 15000
```

`visual_qa.mjs` must run with `SITE_PROJECT_ROOT` as the current working directory so Node resolves the site's installed `playwright` and `@axe-core/playwright` dependencies. `--output` must name a new or empty directory under the site; the QA runner never overwrites an existing evidence set and must never write screenshots or dependency state into `WORKFLOW_ROOT`.

The tool writes `.site-build/visual-qa/report.json` with `schemaVersion: "company-site-visual-qa/v1"`. Inspect every required route at mobile, tablet, and desktop widths, including approximately 390, 768, and 1440 CSS pixels. It also runs Lighthouse against the first supplied route using the locally pinned `lighthouse` package and the Playwright Chromium executable. The gate requires Performance >= 85, Accessibility >= 95, Best Practices >= 90, SEO >= 95, and cumulative layout shift below 0.1. A missing Lighthouse runtime or report is a failure, not a skipped check.

Check clipping, overflow, collisions, focus, type legibility, navigation, CTA hierarchy, image crops, motion, long copy, missing assets, and relevant form/error states. Perform keyboard navigation and practical accessibility checks for contrast, landmarks, labels, focus order, reduced motion, and heading structure.

Fix failures in native Astro and rerun affected gates. Use at most three bounded repair passes before returning `QA_FAILED` with evidence.

## Gate 6: provenance and handoff

Create `provenance.json` conforming to `provenance/v1`. Record `workflow_version` exactly matching the package `VERSION`, `visual_selection_sha256`, and exactly the selected 21st Foundation plus any selected support sources. Every source records its role, candidate ID, 21st item ID, source URL, `retrieval_method`, non-null Prompt SHA-256, `license_status`, and hashed get_component response payload. Record asset sources/rights as applicable. Do not record raw Prompt/code. Keep top-level `generate_used: false` and `provider_code_reuse: false`. The provider preview is decision evidence, never a production asset. Validate the binding rather than the provenance file in isolation:

```bash
python3 -B "$WORKFLOW_ROOT/scripts/validate_inputs.py" \
  --schema provenance \
  --input "$SITE_PROJECT_ROOT/.site-build/provenance.json" \
  --selection "$SITE_PROJECT_ROOT/.site-build/visual-selection.json" \
  --output "$SITE_PROJECT_ROOT/.site-build/provenance.validation.json"
```

Omitting `--selection`, supplying a different selection hash, using a non-21st source, or omitting the Foundation Prompt/payload hash is a hard failure.

Create `qa-report.json` conforming to `qa-report/v1`, validate both records, and rerun `self_check.py`. At the final package gate, scan both the target project and the exact final Workflow ZIP:

```bash
WORKFLOW_ROOT="/absolute/path/to/astro-company-site-workflow"
SITE_PROJECT_ROOT="/absolute/path/to/site-project"
FINAL_ZIP="/absolute/path/to/astro-company-site-workflow-v1.zip"
cd "$SITE_PROJECT_ROOT"
python3 -B "$WORKFLOW_ROOT/scripts/self_check.py" \
  --root "$WORKFLOW_ROOT" \
  --output "$SITE_PROJECT_ROOT/.site-build/self-check.final.json"
python3 -B "$WORKFLOW_ROOT/scripts/doctor.py" \
  --root "$WORKFLOW_ROOT" \
  --scan "$SITE_PROJECT_ROOT" \
  --scan "$FINAL_ZIP" \
  --output "$SITE_PROJECT_ROOT/.site-build/doctor.final.json"
```

The doctor intentionally ignores the recognized dependency/build directories `node_modules`, `.astro`, `dist`, `.git`, and `__pycache__` during a project secret scan while still scanning authored files, `.site-build` text evidence, and the ZIP for credentials and integrity faults. These ignored directories remain under the site or an external cache and must never be copied into the Workflow or final ZIP. The final handoff reports only tests actually performed and identifies unresolved external work such as form delivery, analytics, DNS, or deployment.

Do not publish or deploy unless separately authorized.
