# SEO and GEO Policy

Make the static site easy for search engines and answer engines to identify, crawl, understand, and cite without manufacturing facts or promising rankings.

## Manifest first

Create `seo-manifest.json` before composing the build contract. It must conform to `schemas/seo-manifest.schema.json` and define:

- an HTTPS `canonical_origin` when known, plus host policy, trailing-slash policy, and default locale;
- stable Organization and WebSite entity identity; absolute `@id` values only when the origin is known;
- each route's path, locale, indexability, unique title/description, canonical when resolvable, alternates, schema types, and truthful `lastmod` or null;
- explicit crawler policies with official sources and a verification date;
- experimental outputs such as `llms.txt` disabled by default.

If the brief leaves the host unresolved, set `launch_ready: false`, add a specific `launch_blockers` entry, use `canonical_origin: null` and `host_policy: "unresolved"`, and leave dependent entity/route URLs null where the schema permits. Local static build and visual QA may continue: dist SEO reports a warning plus `external_pending`. Publishing, production SEO sign-off, absolute canonical/social URLs, sitemap host verification, and entity `@id` finalization cannot pass until the blocker is resolved; run the validator with `--strict-warnings` for that launch gate.

## Technical SEO

- Once the origin is known, emit one canonical per indexable page and keep host/trailing-slash behavior consistent. Before then, do not emit a fake production canonical.
- Generate sitemap and robots output from the same manifest intent.
- Use unique, descriptive titles and summaries grounded in visible page content.
- Keep meaningful content server-rendered in built HTML.
- Provide Open Graph/social metadata only with valid owned assets and absolute URLs.
- Use `hreflang` only for real alternate locales and include self-references.
- Use page-specific structured data only when visible content and verified facts support it.
- Never use FAQ, Review, Rating, Product, LocalBusiness, Person, or certification markup merely to seek rich results.

## GEO content

Create clear entity signals rather than keyword stuffing:

- state what the company is, who it serves, what it offers, and where claims come from;
- use descriptive headings, concise definitions, scannable comparison/process content, and stable internal links;
- keep organization name, legal name, URL, logo, contact details, and `sameAs` consistent where verified;
- make important facts visible in HTML, not only images or animation;
- separate verified facts from opinion and avoid unsupported superlatives.

Do not claim guaranteed rankings, citations, or model inclusion. `llms.txt` and Markdown alternates are experimental, not default requirements; enable them only when explicitly requested and recorded in the manifest.

## Crawler policy

Public search indexing, AI search/retrieval, model training, and user-initiated fetch are distinct choices. Record each separately. Check current official bot documentation when the user requests non-default controls, record the sources/date, and avoid assuming that `robots.txt` directives create contractual guarantees.

Validate the built output, not just source metadata:

```bash
WORKFLOW_ROOT="/absolute/path/to/astro-company-site-workflow"
SITE_PROJECT_ROOT="/absolute/path/to/site-project"
cd "$SITE_PROJECT_ROOT"
python3 -B "$WORKFLOW_ROOT/scripts/validate_dist_seo.py" \
  --dist "$SITE_PROJECT_ROOT/dist" \
  --manifest "$SITE_PROJECT_ROOT/.site-build/seo-manifest.json" \
  --output "$SITE_PROJECT_ROOT/.site-build/seo.validation.json"
```
