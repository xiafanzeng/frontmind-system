# Visual System

Use this reference after selection to turn the chosen direction into a coherent, responsive design language rather than a loose collection of styles.

## Seven observation axes

Use the same seven axes for user/brand/reference assets and for normalized 21st directives:

- structure: grid, density, rhythm, hierarchy, alignment, and shape behavior;
- typography: neutral grotesk, geometric sans, humanist sans, editorial serif, mono accent, or verified brand type;
- surface: flat, outlined, elevated, translucent, textured, or hard-shadowed;
- color: light/dark basis, neutral temperature, accent intensity, and contrast model;
- imagery: documentary, product-led, diagrammatic, illustrative, abstract, or type-led;
- motion: static, feedback-only, reveal, ambient, or continuous;
- tone: the emotional and commercial impression supported by the other six axes.

When an observed asset has `role: "visual_reference"`, translate its permitted evidence into 3–12 `search_terms_en` phrases. Keep them concrete—such as “asymmetric editorial grid” or “restrained hard-shadow surfaces”—and exclude unverified brands, claims, and implementation stacks.

A useful visual thesis names the dominant axes and business effect in one sentence. Example form: “A spacious editorial grid with restrained industrial color and documentary imagery that makes technical proof feel calm and credible.”

## Semantic tokens

The contract must assign exact values to reusable roles:

- colors: canvas, surface, raised surface, text, muted text, border, primary, accent, focus, success, warning, error;
- typography: display, heading, body, utility, and code only when needed; include size, weight, line height, tracking, and readable measure;
- spacing: a compact scale plus page gutter, container widths, section rhythm, and component gaps;
- shape/elevation: border widths, radii by role, shadows, blur policy, and z-index layers;
- motion: duration, easing, distance/scale, choreography limit, and reduced-motion fallback;
- imagery: aspect ratios, focal point, crop mode, resolution, and responsive art direction.

Use semantic role names, not page-specific literals. Verify contrast for every actual foreground/background pair. If a confirmed brand color fails contrast as text, preserve it in a non-text role or adjust the supporting surface.

## Prompt/preview mapping

| Evidence | Contract decision |
|---|---|
| Large type and few elements | Wider type ratio, bounded line length, generous section rhythm—not indiscriminate empty space |
| Dense modular grid | Tighter spacing scale, clear group hierarchy, mobile serialization order |
| Editorial serif contrast | Serif display role plus highly legible body fallback; preserve hierarchy, not a guessed font |
| Dark luminous surface | Dark canvas, controlled accent luminance, explicit text/border contrast, restrained glow budget |
| Hard borders and offset shadows | Role-based border/shadow tokens, strong focus treatment, limited use by hierarchy |
| Translucent layers | Opaque fallback, contrast check after blur, reduced layering on low-power/mobile contexts |
| Image-led composition | Owned/licensed asset plan, aspect ratios and focal rules before layout lock |
| Motion-led preview | Recreate intent with minimal native behavior; never infer unavailable animations from a still image |

## Page grammar

Define one header/footer model, page grid, hero conversion hierarchy, proof pattern, offer/process pattern, and final CTA pattern. Repetition establishes coherence; deliberate exceptions create emphasis.

The selected Foundation supplies the global grammar and tokens. Apply any supporting source as a local modifier only: one named section pattern or one bounded motion behavior. Never average palettes, alternate font systems, or change density between sources.

For mobile, specify order and simplification rather than merely “stack everything.” Protect the primary action, reading order, media focal point, and tap targets. For wide screens, cap readable text and prevent decorative elements from dominating evidence.

Use [anti-patterns.md](anti-patterns.md) as a rejection checklist before implementation.

## Selection-board diversity

The selection board compares genuinely different Foundation directions, not nine colorways. Every option needs a unique provider item ID, canonical source URL, and preview URL. For a full board, vary at least three evidenced axes across the set and allow no more than three effectively identical hero structures; persist the diversity evidence used to declare `board_ready: true`. Apply the same intent proportionally when the exhausted pool yields fewer than nine options.
