# Canonical Workflow

This is the portable execution sequence. Host adapters only translate MCP configuration and tool calls; they do not change the workflow or its artifacts.

In every command below, set `WORKFLOW_ROOT` to the absolute unpacked Workflow directory and `SITE_PROJECT_ROOT` to the absolute target website directory. Change into `SITE_PROJECT_ROOT` before execution, resolve scripts through `$WORKFLOW_ROOT/scripts/...`, and resolve evidence through `$SITE_PROJECT_ROOT/.site-build/...`. Keep those roots separate: the packaged Workflow is read-only at runtime, and all run evidence belongs under the target project's gitignored `.site-build/` directory. Dependency caches and generated site output also belong to the site or an external cache, never the Workflow.

## 1. Preflight and brief

1. Resolve the package root and target project directory. Do not overwrite a nonempty, unrelated directory.
2. Run the environment/package doctor and self-check:

   ```bash
   WORKFLOW_ROOT="/absolute/path/to/astro-company-site-workflow"
   SITE_PROJECT_ROOT="/absolute/path/to/site-project"
   cd "$SITE_PROJECT_ROOT"
   python3 -B "$WORKFLOW_ROOT/scripts/doctor.py" \
     --root "$WORKFLOW_ROOT" \
     --scan "$SITE_PROJECT_ROOT" \
     --output "$SITE_PROJECT_ROOT/.site-build/doctor.json"
   python3 -B "$WORKFLOW_ROOT/scripts/self_check.py" \
     --root "$WORKFLOW_ROOT" \
     --output "$SITE_PROJECT_ROOT/.site-build/self-check.json"
   ```

3. Follow [company-research.md](company-research.md) for all company-provided files, URLs, claims, and unknowns.
4. Create a brief conforming to `schemas/company-brief.schema.json`, then validate it:

   ```bash
   WORKFLOW_ROOT="/absolute/path/to/astro-company-site-workflow"
   SITE_PROJECT_ROOT="/absolute/path/to/site-project"
   cd "$SITE_PROJECT_ROOT"
   python3 -B "$WORKFLOW_ROOT/scripts/validate_inputs.py" \
     --schema company-brief \
     --input "$SITE_PROJECT_ROOT/.site-build/company-brief.json" \
     --output "$SITE_PROJECT_ROOT/.site-build/company-brief.validation.json"
   ```

   For a Chinese or other non-English brief, include an Agent-authored `visual_direction.business_context_en` array containing 2–10 concise English/ASCII strings with the same verified industry, audience, and conversion context before validation/query composition.

5. Inspect user-owned brand/reference assets and write `.site-build/visual-observation.json` according to [visual-system.md](visual-system.md). This record observes each asset across seven axes—structure, typography, surface, color, imagery, motion, and tone—and records ownership, license, influence dimensions, and evidence. It does not contain 21st catalog candidates.
6. Validate `visual-observation.json`, then confirm that the selected host adapter can invoke existing-catalog `search` and `get_component` and can keep credentials outside the workspace:

   ```bash
   WORKFLOW_ROOT="/absolute/path/to/astro-company-site-workflow"
   SITE_PROJECT_ROOT="/absolute/path/to/site-project"
   cd "$SITE_PROJECT_ROOT"
   python3 -B "$WORKFLOW_ROOT/scripts/validate_inputs.py" \
     --schema visual-observation \
     --input "$SITE_PROJECT_ROOT/.site-build/visual-observation.json" \
     --output "$SITE_PROJECT_ROOT/.site-build/visual-observation.validation.json"
   ```

Do not begin implementation before the visual selection is complete.

## 2. Query and fixed catalog funnel

Create the search plan from the normalized brief:

```bash
WORKFLOW_ROOT="/absolute/path/to/astro-company-site-workflow"
SITE_PROJECT_ROOT="/absolute/path/to/site-project"
cd "$SITE_PROJECT_ROOT"
python3 -B "$WORKFLOW_ROOT/scripts/compose_21st_query.py" \
  --brief "$SITE_PROJECT_ROOT/.site-build/company-brief.json" \
  --observation "$SITE_PROJECT_ROOT/.site-build/visual-observation.json" \
  --output "$SITE_PROJECT_ROOT/.site-build/21st-query.json"
```

When `brief.visual_references` is nonempty, `--observation` is required at query composition, result normalization, and final build-contract composition so its authorized seven-axis influence shapes catalog retrieval and its exact hash remains bound to the contract. Every command must fail if that input is omitted or does not match the brief/reference assets. Omit the option only when that brief array is empty. The plan emits English Foundation, Section, and Motion query groups; every board candidate records `query_role: "foundation"`, while Section/Motion results are eligible only as later scoped supports.

Follow [21st-selection-policy.md](21st-selection-policy.md) exactly:

1. Search the existing 21st catalog toward a target of 18 unique eligible results.
2. Rank those 18 using metadata and preview evidence only.
3. Retrieve in rank order with `get_component`, skipping invalid results and continuing through ranks 13–18 until 12 Prompt-bearing items are valid or the searched pool is exhausted.
4. In host memory or a protected operating-system temporary directory, hash and normalize every Prompt-bearing result. Persist only Prompt hashes, normalized directives, provider metadata, and preview references; discard the raw retrieval batch immediately after normalization. Reacquire only the finally selected Foundation/support Prompts ephemerally when the contract composer verifies their hashes.
5. From Prompt-bearing, preview-bearing Foundation results, choose up to 9 diverse finalists. Each finalist must have a unique provider item ID, canonical source URL, and preview URL; a full board must satisfy the diversity policy.
6. Present one board made from actual preview media and ask the user to choose once. The normal board is A–I; when fewer than nine valid items exist, show all valid items and record the degraded count/error.

Do not call `generate`, `iterate_generation`, `get_take`, or any tool that creates new 21st content.

## 3. Record the one selection

The board must display all finalists at the same time, up to nine. Each option persists its sequential A–I `option_label` and `fit_reason`, and includes its catalog title, author or source identity when returned, actual preview, source link, and a neutral one-line fit note. Do not show provider code or expose internal credentials.

Write `.site-build/visual-selection.json` conforming to `schemas/visual-selection.schema.json`. Before choice it uses `stage: "normalized"` with `selected: null`; `board_ready` becomes true only after the bounded pool has been evaluated and one to nine complete, uniquely sourced, sequentially labeled Foundation options are ready for simultaneous display. After a full-count choice use `stage: "selected"`, and after a documented shortfall use `stage: "selected-degraded"`. Its targets remain 18/12/9, while `actual` records honest achieved counts. It holds searched candidates, the valid retrieval shortlist, up to nine presented candidates, the selected Foundation item, Prompt SHA-256, normalized directives, and any degraded/error records. The selected item records `selection_evidence: "user_choice"` for a direct option choice or `selection_evidence: "explicit_delegation"` when the user delegated the choice; no other value or silent default is valid.

After the user chooses the Foundation, the agent may select zero to two `supporting_sources` from the same already retrieved Prompt-bearing shortlist. Each uses `role: "section"` or `role: "motion"` and an identical `query_role`, stores only identity, Prompt hash, normalized directives, rationale, `target_page_path`, and `target_section`, and must solve a concrete gap. A section support requires a real target page and named section from the brief/contract; never default it to the first section. A motion support sets both target fields to null and remains bounded by its directives/rationale. A supporting source cannot change global brand color, font roles, or density. Do not make a second user selection. The file never contains raw Prompt or code; keep `generate_used: false` and `provider_code_reuse: false`.

There is no second style confirmation. A later explicit user revision is a new decision, not an automatic second round.

## 4. Compile the selected directives

Read [prompt-compiler.md](prompt-compiler.md), [visual-system.md](visual-system.md), and [anti-patterns.md](anti-patterns.md). Convert the selected Foundation hash/directives and any scoped supporting directives, together with the reference observation, into a deterministic design system and page plan. Raw provider text is no longer required and must not be reloaded from project artifacts.

First write `.site-build/design-system.json` as the exact `design_system` object required by `schemas/build-contract.schema.json`; the agent derives it from Foundation directives, authorized reference observations, and scoped support. Do not use a generic palette or script-generated default.

Create and validate the SEO manifest. Then provide ephemeral raw Prompt proofs so the composer can verify that their hashes match the selection. Use host memory/`--prompt-stdin` when possible; the file-based form is shown for a Foundation plus optional supports:

```bash
WORKFLOW_ROOT="/absolute/path/to/astro-company-site-workflow"
SITE_PROJECT_ROOT="/absolute/path/to/site-project"
FOUNDATION_PROMPT_FILE="/absolute/os-temp/foundation-prompt-0600.txt"
SUPPORT_PROMPT_FILE="/absolute/os-temp/support-prompt-0600.txt"
cd "$SITE_PROJECT_ROOT"
python3 -B "$WORKFLOW_ROOT/scripts/validate_inputs.py" \
  --schema seo-manifest \
  --input "$SITE_PROJECT_ROOT/.site-build/seo-manifest.json" \
  --output "$SITE_PROJECT_ROOT/.site-build/seo-manifest.validation.json"

python3 -B "$WORKFLOW_ROOT/scripts/compose_build_contract.py" \
  --brief "$SITE_PROJECT_ROOT/.site-build/company-brief.json" \
  --selection "$SITE_PROJECT_ROOT/.site-build/visual-selection.json" \
  --seo-manifest "$SITE_PROJECT_ROOT/.site-build/seo-manifest.json" \
  --design-system "$SITE_PROJECT_ROOT/.site-build/design-system.json" \
  --observation "$SITE_PROJECT_ROOT/.site-build/visual-observation.json" \
  --prompt-file "$FOUNDATION_PROMPT_FILE" \
  --supporting-prompt-file "21st-support-id=$SUPPORT_PROMPT_FILE" \
  --output "$SITE_PROJECT_ROOT/.site-build/build-contract.json" \
  --markdown-output "$SITE_PROJECT_ROOT/.site-build/BUILD_CONTRACT.md"
```

Omit `--supporting-prompt-file` when no support exists and repeat it exactly once per selected support. Its candidate ID must match `supporting_sources`. The alternative `--prompt-stdin` applies to the Foundation only. Include `--observation` whenever the brief has visual references; the composer verifies its brief hash, authorized reference identity/location, and exact SHA-256 before writing `inputs.visual_observation_sha256`. Omit it only when the brief has none. Acquire the exact selected existing-catalog Prompt from retained host memory or a fresh `get_component` read, verify it against the stored hash, and keep any file only in protected OS temporary storage. After successful composition, close and delete every Prompt proof through the host's safe temporary-file lifecycle.

The composer validates and copies `design-system.json` unchanged, records `design_system_sha256`, and never writes raw Prompt text. `build-contract.json` is the machine-readable source of truth; Markdown is a derived review surface.

## 5. Implement in native Astro

Read [astro-static-profile.md](astro-static-profile.md) and [seo-geo-policy.md](seo-geo-policy.md). Preserve an existing Astro project's conventions when compatible. For a new or empty directory, use the packaged static starter:

```bash
WORKFLOW_ROOT="/absolute/path/to/astro-company-site-workflow"
SITE_PROJECT_ROOT="/absolute/path/to/site-project"
cd "$SITE_PROJECT_ROOT"
python3 -B "$WORKFLOW_ROOT/scripts/scaffold_astro.py" \
  --target "$SITE_PROJECT_ROOT" \
  --site-name "Example Company" \
  --language en \
  --contact-email "hello@example.com"
```

Pass `--site-url` only when the production canonical origin is known.

Implement the contract with `.astro` components, native CSS, `astro:assets`, and minimal vanilla JavaScript. Do not add a UI framework, shadcn, or provider source files.

## 6. Verify and hand off

Read [quality-gates.md](quality-gates.md). Build the production output, validate native-Astro and SEO invariants, run responsive visual QA, and create provenance and QA records conforming to:

- `schemas/provenance.schema.json`
- `schemas/qa-report.schema.json`

The final handoff identifies the selected A–I option, source item, Prompt hash, implemented pages, build and QA results, unresolved limitations, and whether deployment remains outstanding. `provenance.json` must include `workflow_version` matching the package `VERSION`, the exact `visual_selection_sha256`, and a 21st Foundation source whose candidate/item/source/Prompt/payload hashes match the selected record; validate it with `validate_inputs.py --schema provenance --selection ...`. Zero-source, arbitrary-source, unbound, or null-hash provenance is invalid. Do not publish unless the user separately requested it.

## Portable artifact contract

| Artifact | Schema | Purpose |
|---|---|---|
| `.site-build/company-brief.json` | `schemas/company-brief.schema.json` | Verified facts, audiences, conversion goal, pages, constraints, and unknowns |
| `.site-build/visual-observation.json` | `schemas/visual-observation.schema.json` | User/brand/reference assets observed across seven visual axes |
| `.site-build/visual-selection.json` | `schemas/visual-selection.schema.json` | The 18/12/9 target funnel, board readiness/diversity, sequential A–I labels, actual/degraded counts, selection evidence, Prompt hashes, and normalized directives |
| `.site-build/seo-manifest.json` | `schemas/seo-manifest.schema.json` | Canonical, entity, route, crawler, sitemap, and experimental-output policy |
| `.site-build/design-system.json` | Build-contract `properties.design_system` | Agent-authored exact style profile, tokens, layout, imagery, motion, responsive rules, and component adaptation |
| `.site-build/build-contract.json` | `schemas/build-contract.schema.json` | Immutable input hashes, design system, page plan, implementation profile, and acceptance checks |
| `.site-build/provenance.json` | `schemas/provenance.schema.json` | Workflow version, at least the Foundation source, Prompt hash, asset rights, and no-code-reuse record |
| `.site-build/qa-report.json` | `schemas/qa-report.schema.json` | Deterministic and visual QA evidence |

Raw MCP Prompt/code may exist only in host memory or a protected operating-system temporary location. Remove the retrieval batch immediately after normalization; if exact selected Prompts are reacquired as contract proofs, remove them immediately after successful composition. Raw payloads must never appear under `.site-build`. Persistent artifacts never contain credentials. `build-contract.json` is the single top-level execution contract; all other files are its inputs or evidence.
