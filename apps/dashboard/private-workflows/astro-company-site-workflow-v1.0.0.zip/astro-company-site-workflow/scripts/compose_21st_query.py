#!/usr/bin/env python3
"""Compose a deterministic, non-generative 21st catalog query plan."""

from __future__ import annotations

import argparse
import json
import re
import sys

sys.dont_write_bytecode = True
from pathlib import Path
from typing import Any, Sequence

from validate_inputs import InputError, load_json, resolve_schema, sha256_file, validate_instance, write_json


TARGETS = {"search": 18, "retrieve": 12, "present": 9}
SENSITIVE_VALUE_PATTERNS = (
    re.compile("21" + r"st_sk_[A-Za-z0-9_-]{12,}"),
    re.compile("s" + r"k-[A-Za-z0-9_-]{20,}"),
    re.compile("g" + r"hp_[A-Za-z0-9]{30,}"),
    re.compile("github" + r"_pat_[A-Za-z0-9_]{30,}"),
    re.compile("A" + r"KIA[0-9A-Z]{16}"),
    re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    re.compile(r"\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b"),
    re.compile(r"https?://[^\s/@:]+:[^\s/@]+@[^\s/]+", re.IGNORECASE),
)
BEARER_VALUE_RE = re.compile(r"\bAuthorization\s*:\s*Bearer\s+(?P<value>[^\s\"',;]+)", re.IGNORECASE)
CREDENTIAL_QUERY_RE = re.compile(
    r"[?&](?:api[_-]?key|access[_-]?token|auth[_-]?token|token|authorization|auth)=(?P<value>[^&#\s\"']+)",
    re.IGNORECASE,
)
CREDENTIAL_ASSIGNMENT_RE = re.compile(
    r"(?:^|[\s,{])['\"]?(?:API_KEY_21ST|TWENTYFIRST_TOKEN|api[_-]?key|access[_-]?token|auth[_-]?token|token|authorization)['\"]?"
    r"\s*[:=]\s*['\"]?(?P<value>[^\s\"',;\]}]+)",
    re.IGNORECASE | re.MULTILINE,
)
SENSITIVE_KEYS = {
    "apikey",
    "apikey21st",
    "twentyfirsttoken",
    "token",
    "accesstoken",
    "authtoken",
    "bearertoken",
    "authorization",
    "credential",
    "credentials",
    "secret",
    "clientsecret",
    "password",
}


def _is_placeholder_credential(value: str) -> bool:
    candidate = value.strip().strip("'\"")
    upper = candidate.upper()
    return (
        not candidate
        or candidate.startswith(("$", "<", "{", "["))
        or upper.startswith(("YOUR_", "REPLACE_", "EXAMPLE_", "REDACTED", "PLACEHOLDER"))
        or upper in {"YOUR-KEY", "YOUR_KEY", "TOKEN_HERE", "API_KEY_HERE", "CHANGEME"}
    )


def _string_contains_sensitive_context(value: str) -> bool:
    if any(pattern.search(value) for pattern in SENSITIVE_VALUE_PATTERNS):
        return True
    for pattern in (BEARER_VALUE_RE, CREDENTIAL_QUERY_RE, CREDENTIAL_ASSIGNMENT_RE):
        for match in pattern.finditer(value):
            if not _is_placeholder_credential(match.group("value")):
                return True
    return False


def _contains_sensitive_context(value: Any, key_hint: str | None = None) -> bool:
    if isinstance(value, str):
        normalized_key = re.sub(r"[^a-z0-9]", "", (key_hint or "").casefold())
        if normalized_key in SENSITIVE_KEYS and not _is_placeholder_credential(value):
            return True
        return _string_contains_sensitive_context(value)
    if isinstance(value, dict):
        return any(
            _string_contains_sensitive_context(str(key))
            or _contains_sensitive_context(child, str(key))
            for key, child in value.items()
        )
    if isinstance(value, list):
        return any(_contains_sensitive_context(child, key_hint) for child in value)
    return False


def _reject_sensitive_context(*values: Any) -> None:
    if any(_contains_sensitive_context(value) for value in values):
        raise InputError(
            "SENSITIVE_CONTEXT_REJECTED: input or composed query contains credential-like material; "
            "remove it before provider query composition (value redacted)"
        )


def _compact(value: Any) -> str:
    if isinstance(value, str):
        return re.sub(r"\s+", " ", value).strip()
    return ""


def _unique(values: Sequence[str]) -> list[str]:
    seen: set[str] = set()
    output: list[str] = []
    for value in values:
        cleaned = _compact(value)
        key = cleaned.casefold()
        if cleaned and key not in seen:
            seen.add(key)
            output.append(cleaned)
    return output


def _english_style_terms(
    observation: dict[str, Any] | None,
) -> tuple[dict[str, list[str]], list[dict[str, Any]], list[dict[str, str]]]:
    if not observation:
        return {}, [], []
    keyword_map = {
        "minimal": ("minimal", "极简", "简洁", "克制"),
        "editorial": ("editorial", "杂志", "编辑"),
        "technical": ("technical", "技术", "工业", "精密"),
        "premium": ("premium", "luxury", "高级", "奢华"),
        "playful": ("playful", "活泼", "趣味"),
        "bold": ("bold", "大胆", "强烈"),
        "soft": ("soft", "柔和", "温暖"),
        "dark": ("dark", "深色", "暗色"),
        "light": ("light", "浅色", "明亮"),
        "asymmetric": ("asymmetric", "不对称"),
        "modular": ("modular", "模块", "卡片"),
        "photographic": ("photo", "photographic", "摄影", "照片"),
        "illustrative": ("illustration", "illustrative", "插画"),
        "kinetic": ("kinetic", "dynamic", "动态", "动效"),
    }
    terms_by_dimension: dict[str, list[str]] = {}
    influences: list[dict[str, Any]] = []
    warnings: list[dict[str, str]] = []
    for asset in observation.get("assets", []):
        if not isinstance(asset, dict):
            continue
        dimensions = list(asset.get("influence_dimensions", []))
        supplied = _unique([str(value) for value in asset.get("search_terms_en", [])])
        if asset.get("role") == "visual_reference" and not supplied:
            text = " ".join(str(value) for value in (asset.get("observation") or {}).values()).casefold()
            supplied = [
                english
                for english, needles in keyword_map.items()
                if any(needle.casefold() in text for needle in needles)
            ]
            warnings.append({
                "code": "REFERENCE_SEARCH_TERMS_FALLBACK",
                "message": f"{asset.get('asset_id')} lacked concrete search_terms_en; a narrow observation keyword fallback was used",
            })
        for dimension in dimensions:
            terms_by_dimension.setdefault(str(dimension), []).extend(supplied)
        influences.append({
            "asset_id": asset.get("asset_id"),
            "dimensions": dimensions,
            "search_terms_en": supplied,
        })
    return {key: _unique(value) for key, value in terms_by_dimension.items()}, influences, warnings


def _negative_terms(values: Sequence[str]) -> list[str]:
    output: list[str] = []
    for value in _unique(values):
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9 ._-]{1,39}", value):
            continue
        phrase = re.sub(r"\s+", " ", value).strip()
        output.append(f"avoid {phrase}")
    return output


def _validate_observation_authorization(brief: dict[str, Any], observation: dict[str, Any] | None) -> None:
    if not observation:
        return
    authorized_assets = {
        item.get("asset_id"): item
        for item in brief.get("assets", [])
        if isinstance(item, dict) and item.get("asset_id")
    }
    reference_by_asset = {
        item.get("asset_id"): item
        for item in brief.get("visual_references", [])
        if isinstance(item, dict) and item.get("asset_id")
    }
    observed_assets = {
        item.get("asset_id"): item
        for item in observation.get("assets", [])
        if isinstance(item, dict) and item.get("asset_id")
    }
    unexpected = sorted(set(observed_assets) - set(authorized_assets))
    if unexpected:
        raise InputError(f"OBSERVATION_ASSET_UNAUTHORIZED: observation contains assets absent from the brief: {unexpected}")
    missing_references = sorted(set(reference_by_asset) - set(observed_assets))
    if missing_references:
        raise InputError(f"REFERENCE_OBSERVATION_MISSING: visual references were not observed: {missing_references}")
    for asset_id, observed in observed_assets.items():
        authorized = authorized_assets[asset_id]
        for field in ("role", "location", "ownership", "license"):
            if observed.get(field) != authorized.get(field):
                raise InputError(f"OBSERVATION_ASSET_MISMATCH: {field} differs from the brief for {asset_id}")
        reference = reference_by_asset.get(asset_id)
        if observed.get("role") == "visual_reference":
            if not reference:
                raise InputError(f"OBSERVATION_REFERENCE_UNAUTHORIZED: visual reference {asset_id} is absent from brief.visual_references")
            if set(observed.get("influence_dimensions", [])) != set(reference.get("influence_dimensions", [])):
                raise InputError(f"OBSERVATION_INFLUENCE_MISMATCH: influence dimensions differ for {asset_id}")


def compose(brief: dict[str, Any], observation: dict[str, Any] | None = None) -> dict[str, Any]:
    _reject_sensitive_context(brief, observation)
    _validate_observation_authorization(brief, observation)
    company = brief["company"]
    site = brief["site"]
    visual = brief.get("visual_direction") or {}
    business_context_en = _unique([str(item) for item in visual.get("business_context_en", [])])
    tone = [str(item) for item in visual.get("tone", [])]
    page_purposes = [str(page.get("purpose", "")) for page in brief["pages"]]
    section_terms: list[str] = []
    for page in brief["pages"]:
        section_terms.extend(str(item) for item in page.get("sections", []))
    offering_terms = [str(item.get("name", "")) for item in brief.get("offerings", [])]
    observation_terms, reference_influence, warnings = _english_style_terms(observation)
    concrete_reference_terms = _unique([
        *observation_terms.get("structure", []),
        *observation_terms.get("typography", []),
        *observation_terms.get("surface", []),
        *observation_terms.get("color", []),
        *observation_terms.get("imagery", []),
        *observation_terms.get("tone", []),
    ])
    facets = _unique(
        [
            *business_context_en,
            company.get("sector", ""),
            company.get("business_model", ""),
            site.get("scope", ""),
            *tone[:4],
            *offering_terms[:4],
            *page_purposes[:4],
            *section_terms[:8],
            brief["primary_conversion"].get("goal", ""),
            *concrete_reference_terms,
        ]
    )
    ascii_facets = [value for value in facets if re.fullmatch(r"[A-Za-z0-9 /&+._-]+", value)]
    business_core = [company.get("sector", ""), *offering_terms, *page_purposes]
    business_core_ascii = [value for value in business_core if re.fullmatch(r"[A-Za-z0-9 /&+._-]+", value)]
    if not business_context_en and not business_core_ascii:
        raise InputError(
            "ENGLISH_BUSINESS_CONTEXT_REQUIRED: sector, offerings, and page purposes contain no usable English terms; "
            "add 2–10 concrete visual_direction.business_context_en phrases"
        )
    anti_patterns = _negative_terms([str(value) for value in visual.get("must_avoid", [])])
    foundation_query = " ".join(_unique([
        *ascii_facets[:6],
        *concrete_reference_terms[:10],
        "responsive company website",
        *anti_patterns[:4],
    ]))
    section_ascii = [value for value in section_terms if re.fullmatch(r"[A-Za-z0-9 /&+._-]+", value)]
    section_visual_terms = _unique([
        *observation_terms.get("structure", []),
        *observation_terms.get("surface", []),
        *observation_terms.get("imagery", []),
        *observation_terms.get("typography", []),
    ])
    section_query = " ".join(_unique([
        *section_ascii[:6],
        *section_visual_terms[:8],
        "hero features proof contact website sections",
        *anti_patterns[:4],
    ]))
    motion_terms = observation_terms.get("motion", [])
    motion_query = " ".join(_unique([
        *motion_terms[:8],
        "accessible micro interaction reduced motion landing page",
        *anti_patterns[:4],
    ]))
    if not foundation_query:
        raise InputError("brief did not produce any safe search terms")
    variants = _unique([foundation_query, section_query, motion_query])
    plan = {
        "schema_version": "21st-query/v1",
        "brief_sha256": None,
        "observation_sha256": None,
        "provider": "21st",
        "intent": {
            "company_name": company["name"],
            "sector": company["sector"],
            "business_model": company["business_model"],
            "site_scope": site["scope"],
            "visual_tone": tone,
            "facets": facets,
        },
        "queries": variants,
        "query_groups": [
            {"role": "foundation", "query": foundation_query, "target_unique_results": 10},
            {"role": "section", "query": section_query, "target_unique_results": 6},
            {"role": "motion", "query": motion_query, "target_unique_results": 2},
        ],
        "reference_influence": reference_influence,
        "negative_terms": anti_patterns,
        "warnings": warnings,
        "targets": TARGETS,
        "preferred_transport": {
            "kind": "mcp",
            "search_capability": "search",
            "retrieve_capability": "get_component",
            "prompt_requirement": "Every one of the 12 retrieved results must contain a nonempty native prompt field.",
            "missing_prompt_error": "MCP_PROMPT_MISSING",
        },
        "cli_fallback": {
            "allowed_only_when_native_mcp_unavailable": True,
            "command_shape": "21st get <item-id> --json",
            "documented_payload_caveat": "The documented CLI payload is code and demo; it is usable only if runtime JSON also contains a nonempty prompt.",
            "missing_prompt_error": "CLI_PROMPT_MISSING",
        },
        "selection_rules": {
            "unique_catalog_items": True,
            "actual_preview_required_for_presented_candidates": True,
            "raw_prompt_persistence_allowed": False,
            "provider_code_reuse": False,
            "generate_allowed": False,
            "forbidden_operations": ["generate", "iterate_generation", "get_take", "publish"],
        },
        "required_runtime_fields": ["item_id", "title", "source_url", "preview_url", "prompt"],
    }
    _reject_sensitive_context(plan)
    return plan


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Compose the fixed 18-search/12-retrieve/9-present 21st catalog query plan from company-brief/v2."
    )
    parser.add_argument("--brief", required=True, help="Validated company-brief/v2 JSON path")
    parser.add_argument(
        "--observation",
        help="visual-observation/v1 JSON; required whenever brief.visual_references is nonempty",
    )
    parser.add_argument("--output", required=True, help="Explicit output path for the query plan JSON")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        brief_path = Path(args.brief).expanduser().resolve()
        brief = load_json(brief_path, "company brief")
        schema = load_json(resolve_schema("company-brief"), "company brief schema")
        issues = validate_instance(brief, schema)
        if issues:
            first = issues[0]
            raise InputError(
                f"company brief failed validation ({len(issues)} issue(s)); first: {first['path']} {first['code']}: {first['message']}"
            )
        observation: dict[str, Any] | None = None
        observation_hash: str | None = None
        if brief.get("visual_references") and not args.observation:
            raise InputError("brief contains visual_references; --observation is required so seven-axis evidence affects search")
        if args.observation:
            observation_path = Path(args.observation).expanduser().resolve()
            observation = load_json(observation_path, "visual observation")
            observation_schema = load_json(resolve_schema("visual-observation"), "visual observation schema")
            observation_issues = validate_instance(observation, observation_schema)
            if observation_issues:
                first = observation_issues[0]
                raise InputError(f"visual observation is invalid: {first['path']} {first['code']}: {first['message']}")
            if observation.get("brief_sha256") != sha256_file(brief_path):
                raise InputError("OBSERVATION_BRIEF_HASH_MISMATCH: observation was not produced for this exact brief")
            expected_references = {
                item["asset_id"]: item
                for item in brief.get("visual_references", [])
                if isinstance(item, dict)
            }
            observed_references = {
                item.get("asset_id"): item
                for item in observation.get("assets", [])
                if isinstance(item, dict) and item.get("role") == "visual_reference"
            }
            missing_references = sorted(set(expected_references) - set(observed_references))
            if missing_references:
                raise InputError(f"REFERENCE_OBSERVATION_MISSING: visual references were not observed: {missing_references}")
            for asset_id, reference in expected_references.items():
                if observed_references[asset_id].get("location") != reference.get("location"):
                    raise InputError(f"REFERENCE_LOCATION_MISMATCH: observation location differs for {asset_id}")
            observation_hash = sha256_file(observation_path)
        plan = compose(brief, observation)
        plan["brief_sha256"] = sha256_file(brief_path)
        plan["observation_sha256"] = observation_hash
        write_json(args.output, plan)
    except InputError as error:
        print(f"compose_21st_query.py: {error}", file=sys.stderr)
        return 2
    print(json.dumps({"ok": True, "output": str(Path(args.output).expanduser()), "targets": TARGETS}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
