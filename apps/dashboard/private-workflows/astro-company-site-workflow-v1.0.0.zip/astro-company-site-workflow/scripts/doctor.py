#!/usr/bin/env python3
"""Audit workflow packaging, references, prompt transport, and secret hygiene."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import stat
import sys

sys.dont_write_bytecode = True
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any, Iterable, Sequence

from validate_inputs import (
    InputError,
    load_json,
    make_report,
    output_report,
)


REQUIRED_FILES = (
    "SKILL.md",
    "VERSION",
    "schemas/company-brief.schema.json",
    "schemas/visual-observation.schema.json",
    "schemas/visual-selection.schema.json",
    "schemas/build-contract.schema.json",
    "schemas/seo-manifest.schema.json",
    "schemas/provenance.schema.json",
    "schemas/qa-report.schema.json",
    "scripts/doctor.py",
    "scripts/validate_inputs.py",
    "scripts/compose_21st_query.py",
    "scripts/normalize_21st_result.py",
    "scripts/compose_build_contract.py",
    "scripts/validate_native_astro.py",
    "scripts/validate_dist_seo.py",
    "scripts/self_check.py",
)
LINK_RE = re.compile(r"!?\[[^\]]*\]\(([^)\s]+)(?:\s+['\"][^'\"]*['\"])?\)")
EXPECTED_MANIFEST_RUNTIME_CONTRACT = {
    "canonical_artifact": ".site-build/build-contract.json",
    "schema": "schemas/build-contract.schema.json",
    "markdown_is_derived": True,
}
EXPECTED_MANIFEST_FIELDS = {
    "schema": "portable-agent-workflow-manifest/v1",
    "name": "astro-company-site-workflow",
    "entrypoint": "SKILL.md",
    "hash_scope": "all regular files except MANIFEST.json",
}
TEXT_SUFFIXES = {
    "",
    ".astro",
    ".css",
    ".html",
    ".js",
    ".json",
    ".jsx",
    ".md",
    ".mjs",
    ".py",
    ".sh",
    ".svg",
    ".toml",
    ".ts",
    ".tsx",
    ".txt",
    ".yaml",
    ".yml",
}
DEPENDENCY_OR_BUILD_DIRS = {".git", ".astro", "dist", "node_modules", "__pycache__"}
SITE_BUILD_TEXT_SUFFIXES = {".json", ".md"}
MAX_SECRET_SCAN_BYTES = 16_000_000
PROMPT_FIELD_NAMES = {"prompt", "copyprompt", "designprompt", "componentprompt", "nativeprompt"}
ITEM_ID_FIELD_NAMES = {"id", "itemid", "componentid"}
MCP_PROBE_SCHEMA_VERSION = "21st-mcp-probe/v1"

# These expressions intentionally report only a code, path, and line number.
# Never include the matched value in a diagnostic.
KNOWN_SECRET_PATTERNS = (
    ("TWENTY_FIRST_SECRET", re.compile("21" + r"st_sk_[A-Za-z0-9_-]{12,}")),
    ("OPENAI_SECRET", re.compile("s" + r"k-[A-Za-z0-9_-]{20,}")),
    ("GITHUB_TOKEN", re.compile("g" + r"hp_[A-Za-z0-9]{30,}")),
    ("GITHUB_FINE_GRAINED_TOKEN", re.compile("github" + r"_pat_[A-Za-z0-9_]{30,}")),
    ("AWS_ACCESS_KEY", re.compile("A" + r"KIA[0-9A-Z]{16}")),
    ("PRIVATE_KEY", re.compile("-----BEGIN " + r"(?:RSA |EC |OPENSSH )?PRIVATE KEY-----")),
    ("JWT_SECRET", re.compile(r"\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b")),
    ("GOOGLE_OAUTH_TOKEN", re.compile(r"\bya29\.[A-Za-z0-9_-]{20,}\b")),
    ("SLACK_TOKEN", re.compile(r"\bxox(?:b|p|a|r|s)-[A-Za-z0-9-]{20,}\b", re.IGNORECASE)),
    ("GITLAB_TOKEN", re.compile(r"\bglpat-[A-Za-z0-9_-]{20,}\b")),
    ("STRIPE_LIVE_SECRET", re.compile(r"\bsk_live_[A-Za-z0-9]{16,}\b")),
    (
        "AUTHORIZATION_BEARER_SECRET",
        re.compile(
            r"(?:^|[\s{,])['\"]?(?:authorization|authorization[_-]?header|auth[_-]?header)['\"]?"
            r"\s*[:=]\s*['\"]?Bearer\s+(?P<value>[^\s\"',;\]}]+)",
            re.IGNORECASE | re.MULTILINE,
        ),
    ),
    (
        "CREDENTIAL_URL_USERINFO",
        re.compile(r"https?://[^\s/@:]+:[^\s/@]+@[^\s/]+", re.IGNORECASE),
    ),
)
NAMED_CREDENTIAL_ASSIGNMENT_RE = re.compile(
    r"(?:^|[\s,{])['\"]?(?P<key>API_KEY_21ST|TWENTYFIRST_TOKEN|api[_-]?key|access[_-]?token|auth[_-]?token|token|authorization|client[_-]?secret|credential|signature|jwt)['\"]?"
    r"\s*[:=]\s*['\"]?(?P<value>[A-Za-z0-9][A-Za-z0-9._~-]{11,})",
    re.IGNORECASE | re.MULTILINE,
)
CREDENTIAL_QUERY_RE = re.compile(
    r"[?&](?P<key>api[_-]?key|access[_-]?token|auth[_-]?token|token|authorization|auth|client[_-]?secret|credential|signature|jwt)=(?P<value>[^&#\s\"']+)",
    re.IGNORECASE,
)


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _is_placeholder_secret(value: str) -> bool:
    candidate = value.strip().strip("'\"")
    upper = candidate.upper()
    return (
        not candidate
        or candidate.startswith(("$", "<", "{", "["))
        or upper.startswith(("YOUR_", "REPLACE_", "EXAMPLE_", "REDACTED", "PLACEHOLDER"))
        or upper in {"YOUR-KEY", "YOUR_KEY", "TOKEN_HERE", "API_KEY_HERE", "CHANGEME"}
    )


def _scan_text_secrets(text: str, label: str) -> list[dict[str, str]]:
    findings: list[dict[str, str]] = []

    def add(code: str, offset: int) -> None:
        line = text.count("\n", 0, offset) + 1
        findings.append({
            "code": code,
            "path": label,
            "message": f"possible secret at line {line}; value redacted",
        })

    for code, pattern in KNOWN_SECRET_PATTERNS:
        for match in pattern.finditer(text):
            value = match.groupdict().get("value")
            if value is not None and _is_placeholder_secret(value):
                continue
            add(code, match.start())
    for match in NAMED_CREDENTIAL_ASSIGNMENT_RE.finditer(text):
        if not _is_placeholder_secret(match.group("value")):
            add("NAMED_CREDENTIAL_ASSIGNMENT", match.start())
    for match in CREDENTIAL_QUERY_RE.finditer(text):
        if not _is_placeholder_secret(match.group("value")):
            add("CREDENTIAL_QUERY_VALUE", match.start())
    return findings


def _scan_file_secrets(path: Path, label: str | None = None) -> list[dict[str, str]]:
    if path.suffix.lower() not in TEXT_SUFFIXES:
        return []
    try:
        text = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return []
    return _scan_text_secrets(text, label or str(path))


def _should_scan_relative(relative: Path) -> bool:
    parts = relative.parts
    if any(part in DEPENDENCY_OR_BUILD_DIRS for part in parts):
        return False
    if ".site-build" in parts:
        return relative.suffix.lower() in SITE_BUILD_TEXT_SUFFIXES
    return relative.suffix.lower() in TEXT_SUFFIXES


def _project_scan_files(root: Path) -> list[Path]:
    files: list[Path] = []
    for directory, child_dirs, child_files in os.walk(root, followlinks=False):
        current = Path(directory)
        child_dirs[:] = [
            name
            for name in child_dirs
            if name not in DEPENDENCY_OR_BUILD_DIRS and not (current / name).is_symlink()
        ]
        for name in child_files:
            path = current / name
            if path.is_symlink() or not path.is_file():
                continue
            relative = path.relative_to(root)
            if _should_scan_relative(relative):
                files.append(path)
    return sorted(files, key=str)


def _all_files(root: Path) -> list[Path]:
    return sorted(
        (path for path in root.rglob("*") if path.is_file()),
        key=lambda path: str(path),
    )


def _has_nonempty_prompt(value: Any) -> bool:
    if isinstance(value, dict):
        for key, child in value.items():
            normalized = re.sub(r"[^a-z0-9]", "", str(key).casefold())
            if normalized in PROMPT_FIELD_NAMES and isinstance(child, str) and child.strip():
                return True
        return any(_has_nonempty_prompt(child) for child in value.values())
    if isinstance(value, list):
        return any(_has_nonempty_prompt(child) for child in value)
    return False


def _contains_declared_capability(value: Any, wanted: str) -> bool:
    target = re.sub(r"[^a-z0-9]", "", wanted.casefold())
    if not isinstance(value, dict):
        return False
    declarations: list[Any] = []
    for key in ("capabilities", "tools"):
        candidate = value.get(key)
        if isinstance(candidate, list):
            declarations.extend(candidate)
        elif isinstance(candidate, dict):
            declarations.extend(candidate.keys())
            declarations.extend(candidate.values())
    for declaration in declarations:
        name: Any = declaration
        if isinstance(declaration, dict):
            name = declaration.get("name") or declaration.get("operation")
        if isinstance(name, str):
            normalized = re.sub(r"[^a-z0-9]", "", name.casefold())
            if normalized == target or normalized.endswith(target):
                return True
    return False


def _direct_string_field(value: Any, names: set[str]) -> str | None:
    if not isinstance(value, dict):
        return None
    for key, child in value.items():
        normalized = re.sub(r"[^a-z0-9]", "", str(key).casefold())
        if normalized in names and isinstance(child, str) and child.strip():
            return child.strip()
    return None


def _mcp_probe_envelope_valid(value: Any) -> bool:
    if not isinstance(value, dict) or value.get("schema_version") != MCP_PROBE_SCHEMA_VERSION:
        return False
    capabilities = value.get("capabilities")
    calls = value.get("calls")
    return isinstance(capabilities, list) and isinstance(calls, list)


def _has_id_bound_get_component_prompt(value: Any) -> bool:
    """Accept Prompt only from a matching request/response in a get_component call.

    Portable probe envelope:
    {
      "schema_version": "21st-mcp-probe/v1",
      "capabilities": ["search", "get_component"],
      "calls": [{
        "operation": "get_component",
        "request": {"item_id": "..."},
        "response": {"item_id": "...", "prompt": "..."}
      }]
    }
    A response may place that same ID and Prompt directly in one nested `result`
    object. No other subtree is searched.
    """

    if not _mcp_probe_envelope_valid(value):
        return False
    for call in value["calls"]:
        if not isinstance(call, dict):
            continue
        operation = call.get("operation")
        if not isinstance(operation, str):
            continue
        if re.sub(r"[^a-z0-9]", "", operation.casefold()) != "getcomponent":
            continue
        request_id = _direct_string_field(call.get("request"), ITEM_ID_FIELD_NAMES)
        response = call.get("response")
        response_candidates: list[Any] = [response]
        if isinstance(response, dict) and isinstance(response.get("result"), dict):
            response_candidates.append(response["result"])
        for candidate in response_candidates:
            response_id = _direct_string_field(candidate, ITEM_ID_FIELD_NAMES)
            prompt = _direct_string_field(candidate, PROMPT_FIELD_NAMES)
            if request_id is not None and response_id == request_id and prompt is not None:
                return True
    return False


def _sha256_zip_member(archive: zipfile.ZipFile, info: zipfile.ZipInfo) -> str:
    digest = hashlib.sha256()
    with archive.open(info, "r") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _zip_appears_to_be_workflow(
    archive: zipfile.ZipFile,
    regular_infos: Sequence[tuple[PurePosixPath, zipfile.ZipInfo]],
    all_safe_members: Sequence[PurePosixPath],
) -> bool:
    expected_prefix = EXPECTED_MANIFEST_FIELDS["name"]
    if any(member.parts and member.parts[0] == expected_prefix for member in all_safe_members):
        return True
    for member, info in regular_infos:
        if member.name != "MANIFEST.json" or info.file_size > MAX_SECRET_SCAN_BYTES:
            continue
        try:
            value = json.loads(archive.read(info).decode("utf-8"))
        except (OSError, UnicodeDecodeError, RuntimeError, json.JSONDecodeError):
            continue
        if isinstance(value, dict) and value.get("name") == expected_prefix:
            return True
    return False


def _zip_workflow_integrity_checks(
    archive: zipfile.ZipFile,
    zip_path: Path,
    regular_infos: Sequence[tuple[PurePosixPath, zipfile.ZipInfo]],
    all_safe_members: Sequence[PurePosixPath],
    root: Path | None,
) -> list[dict[str, Any]]:
    checks: list[dict[str, Any]] = []
    expected_prefix = EXPECTED_MANIFEST_FIELDS["name"]
    top_levels = {member.parts[0] for member in all_safe_members if member.parts}
    file_paths_have_prefix = all(len(member.parts) >= 2 for member, _ in regular_infos)
    prefix_valid = top_levels == {expected_prefix} and file_paths_have_prefix
    checks.append({
        "code": "ZIP_WORKFLOW_SINGLE_ROOT",
        "status": "pass" if prefix_valid else "fail",
        "message": "workflow ZIP has exactly one expected top-level prefix" if prefix_valid else "workflow ZIP must contain only the astro-company-site-workflow/ top-level prefix",
        "path": str(zip_path),
    })
    if not prefix_valid:
        return checks

    relative_infos: dict[str, zipfile.ZipInfo] = {}
    for member, info in regular_infos:
        relative = PurePosixPath(*member.parts[1:]).as_posix()
        if relative in relative_infos:
            checks.append({
                "code": "ZIP_WORKFLOW_DUPLICATE_MEMBER",
                "status": "fail",
                "message": f"workflow ZIP contains a duplicate regular member: {relative}",
                "path": str(zip_path),
            })
            continue
        relative_infos[relative] = info

    manifest_info = relative_infos.get("MANIFEST.json")
    version_info = relative_infos.get("VERSION")
    required_present = manifest_info is not None and version_info is not None
    checks.append({
        "code": "ZIP_WORKFLOW_METADATA_PRESENT",
        "status": "pass" if required_present else "fail",
        "message": "workflow ZIP contains VERSION and MANIFEST.json" if required_present else "workflow ZIP must contain VERSION and MANIFEST.json",
        "path": str(zip_path),
    })
    if not required_present:
        return checks
    if manifest_info.file_size > MAX_SECRET_SCAN_BYTES or version_info.file_size > 1024:
        checks.append({
            "code": "ZIP_WORKFLOW_METADATA_INVALID",
            "status": "fail",
            "message": "workflow ZIP metadata exceeds bounded validation size",
            "path": str(zip_path),
        })
        return checks
    try:
        manifest = json.loads(archive.read(manifest_info).decode("utf-8"))
        version = archive.read(version_info).decode("utf-8").strip()
    except (OSError, UnicodeDecodeError, RuntimeError, json.JSONDecodeError):
        checks.append({
            "code": "ZIP_WORKFLOW_METADATA_INVALID",
            "status": "fail",
            "message": "workflow ZIP VERSION or MANIFEST.json is unreadable or invalid",
            "path": str(zip_path),
        })
        return checks
    if not isinstance(manifest, dict):
        checks.append({"code": "ZIP_WORKFLOW_MANIFEST_INVALID", "status": "fail", "message": "workflow ZIP MANIFEST.json must be an object", "path": str(zip_path)})
        return checks

    contract_valid = (
        all(manifest.get(field) == expected for field, expected in EXPECTED_MANIFEST_FIELDS.items())
        and manifest.get("runtime_contract") == EXPECTED_MANIFEST_RUNTIME_CONTRACT
    )
    checks.append({
        "code": "ZIP_WORKFLOW_MANIFEST_CONTRACT",
        "status": "pass" if contract_valid else "fail",
        "message": "workflow ZIP manifest contract is fixed and valid" if contract_valid else "workflow ZIP manifest contract does not match the portable package contract",
        "path": str(zip_path),
    })
    version_valid = bool(version) and manifest.get("version") == version
    checks.append({
        "code": "ZIP_WORKFLOW_VERSION_MATCH",
        "status": "pass" if version_valid else "fail",
        "message": "workflow ZIP VERSION matches its manifest" if version_valid else "workflow ZIP manifest version must match VERSION",
        "path": str(zip_path),
    })

    raw_entries = manifest.get("files")
    if not isinstance(raw_entries, list):
        checks.append({"code": "ZIP_WORKFLOW_MANIFEST_FILES_INVALID", "status": "fail", "message": "workflow ZIP manifest files must be an array", "path": str(zip_path)})
        return checks
    listed: dict[str, dict[str, Any]] = {}
    entries_valid = True
    for entry in raw_entries:
        if not isinstance(entry, dict):
            entries_valid = False
            continue
        relative = entry.get("path")
        byte_count = entry.get("bytes")
        digest = entry.get("sha256")
        safe_path = False
        if isinstance(relative, str) and relative and "\\" not in relative:
            pure = PurePosixPath(relative)
            safe_path = not pure.is_absolute() and pure.as_posix() == relative and ".." not in pure.parts and relative != "MANIFEST.json"
        shape_valid = (
            safe_path
            and isinstance(byte_count, int)
            and not isinstance(byte_count, bool)
            and byte_count >= 0
            and isinstance(digest, str)
            and re.fullmatch(r"[a-f0-9]{64}", digest) is not None
            and relative not in listed
        )
        if not shape_valid:
            entries_valid = False
            continue
        listed[relative] = entry
    checks.append({
        "code": "ZIP_WORKFLOW_MANIFEST_ENTRY_SHAPES",
        "status": "pass" if entries_valid else "fail",
        "message": "workflow ZIP manifest entries have unique safe paths, bytes, and SHA-256" if entries_valid else "workflow ZIP manifest contains malformed or duplicate file entries",
        "path": str(zip_path),
    })

    actual_without_manifest = set(relative_infos) - {"MANIFEST.json"}
    fileset_valid = set(listed) == actual_without_manifest
    checks.append({
        "code": "ZIP_WORKFLOW_FILESET_COMPLETE",
        "status": "pass" if fileset_valid else "fail",
        "message": "workflow ZIP manifest covers its complete regular fileset" if fileset_valid else "workflow ZIP manifest file set differs from archive regular members",
        "path": str(zip_path),
    })
    for relative in sorted(set(listed).intersection(actual_without_manifest)):
        info = relative_infos[relative]
        entry = listed[relative]
        bytes_match = info.file_size == entry["bytes"]
        checks.append({
            "code": "ZIP_WORKFLOW_BYTES_MATCH",
            "status": "pass" if bytes_match else "fail",
            "message": f"workflow ZIP byte count {'matches' if bytes_match else 'is stale for'} {relative}",
            "path": str(zip_path),
        })
        try:
            sha_matches = _sha256_zip_member(archive, info) == entry["sha256"]
        except (OSError, RuntimeError, zipfile.BadZipFile):
            sha_matches = False
        checks.append({
            "code": "ZIP_WORKFLOW_SHA256_MATCH",
            "status": "pass" if sha_matches else "fail",
            "message": f"workflow ZIP SHA-256 {'matches' if sha_matches else 'is stale for'} {relative}",
            "path": str(zip_path),
        })

    if root is not None:
        resolved_root = root.resolve()
        root_files = {
            path.relative_to(resolved_root).as_posix(): path
            for path in _all_files(resolved_root)
            if not path.is_symlink()
        }
        snapshot_set_matches = set(root_files) == set(relative_infos)
        checks.append({
            "code": "ZIP_ROOT_SNAPSHOT_FILESET",
            "status": "pass" if snapshot_set_matches else "fail",
            "message": "workflow ZIP and --root contain the same regular-file snapshot" if snapshot_set_matches else "workflow ZIP regular-file set does not exactly match --root",
            "path": str(zip_path),
        })
        for relative in sorted(set(root_files).intersection(relative_infos)):
            root_file = root_files[relative]
            info = relative_infos[relative]
            bytes_match = root_file.stat().st_size == info.file_size
            try:
                sha_matches = _sha256_file(root_file) == _sha256_zip_member(archive, info)
            except (OSError, RuntimeError, zipfile.BadZipFile):
                sha_matches = False
            matches = bytes_match and sha_matches
            checks.append({
                "code": "ZIP_ROOT_SNAPSHOT_MATCH",
                "status": "pass" if matches else "fail",
                "message": f"workflow ZIP member {'matches' if matches else 'differs from'} --root: {relative}",
                "path": str(zip_path),
            })
    return checks


def _zip_secret_findings(path: Path, root: Path | None = None) -> tuple[list[dict[str, str]], list[dict[str, Any]]]:
    findings: list[dict[str, str]] = []
    checks: list[dict[str, Any]] = []
    try:
        with zipfile.ZipFile(path) as archive:
            regular_infos: list[tuple[PurePosixPath, zipfile.ZipInfo]] = []
            all_safe_members: list[PurePosixPath] = []
            seen_names: set[str] = set()
            for info in archive.infolist():
                member = PurePosixPath(info.filename)
                mode = info.external_attr >> 16
                if "\\" in info.filename or member.is_absolute() or ".." in member.parts:
                    checks.append({"code": "ZIP_PATH_UNSAFE", "status": "fail", "message": "ZIP contains an absolute or parent-traversal entry", "path": f"{path}!{info.filename}"})
                    continue
                all_safe_members.append(member)
                if stat.S_ISLNK(mode):
                    checks.append({"code": "ZIP_SYMLINK_FORBIDDEN", "status": "fail", "message": "ZIP contains a symbolic-link entry", "path": f"{path}!{info.filename}"})
                    continue
                if info.is_dir():
                    continue
                file_type = stat.S_IFMT(mode)
                if file_type not in {0, stat.S_IFREG}:
                    checks.append({"code": "ZIP_SPECIAL_FILE_FORBIDDEN", "status": "fail", "message": "ZIP contains a non-regular special entry", "path": f"{path}!{info.filename}"})
                    continue
                if info.filename in seen_names:
                    checks.append({"code": "ZIP_DUPLICATE_MEMBER", "status": "fail", "message": "ZIP contains a duplicate member name", "path": f"{path}!{info.filename}"})
                seen_names.add(info.filename)
                regular_infos.append((member, info))
                member_path = Path(*member.parts)
                if not _should_scan_relative(member_path):
                    continue
                if info.file_size > MAX_SECRET_SCAN_BYTES:
                    checks.append({
                        "code": "ZIP_TEXT_MEMBER_TOO_LARGE",
                        "status": "fail",
                        "message": "ZIP text member is too large for bounded secret inspection",
                        "path": f"{path}!{info.filename}",
                    })
                    continue
                try:
                    text = archive.read(info).decode("utf-8")
                except (OSError, UnicodeDecodeError, RuntimeError):
                    continue
                findings.extend(_scan_text_secrets(text, f"{path}!{info.filename}"))
            if _zip_appears_to_be_workflow(archive, regular_infos, all_safe_members):
                checks.extend(_zip_workflow_integrity_checks(archive, path, regular_infos, all_safe_members, root))
    except (OSError, zipfile.BadZipFile) as error:
        checks.append({"code": "ZIP_INVALID", "status": "fail", "message": f"cannot inspect ZIP: {error}", "path": str(path)})
    return findings, checks


def _manifest_integrity_checks(root: Path, package_files: Sequence[Path]) -> list[dict[str, Any]]:
    checks: list[dict[str, Any]] = []
    manifest_path = root / "MANIFEST.json"
    if not manifest_path.is_file() or manifest_path.is_symlink():
        return [{
            "code": "MANIFEST_REQUIRED",
            "status": "fail",
            "message": "MANIFEST.json is required and must be a regular non-symlink file",
            "path": "MANIFEST.json",
        }]
    try:
        manifest = load_json(manifest_path, "manifest")
    except InputError as error:
        return [{
            "code": "MANIFEST_INVALID",
            "status": "fail",
            "message": str(error),
            "path": "MANIFEST.json",
        }]
    if not isinstance(manifest, dict):
        return [{
            "code": "MANIFEST_INVALID",
            "status": "fail",
            "message": "MANIFEST.json must contain a JSON object",
            "path": "MANIFEST.json",
        }]

    for field, expected in EXPECTED_MANIFEST_FIELDS.items():
        matches = manifest.get(field) == expected
        checks.append({
            "code": "MANIFEST_CONTRACT_FIXED",
            "status": "pass" if matches else "fail",
            "message": f"manifest {field} {'matches' if matches else 'does not match'} the portable package contract",
            "path": "MANIFEST.json",
        })
    runtime_matches = manifest.get("runtime_contract") == EXPECTED_MANIFEST_RUNTIME_CONTRACT
    checks.append({
        "code": "MANIFEST_RUNTIME_CONTRACT_FIXED",
        "status": "pass" if runtime_matches else "fail",
        "message": "manifest runtime_contract matches the fixed build-contract artifact" if runtime_matches else "manifest runtime_contract must exactly name .site-build/build-contract.json, its bundled schema, and derived Markdown",
        "path": "MANIFEST.json",
    })

    version_path = root / "VERSION"
    try:
        package_version = version_path.read_text(encoding="utf-8").strip()
    except (OSError, UnicodeDecodeError):
        package_version = None
    version_matches = bool(package_version) and manifest.get("version") == package_version
    checks.append({
        "code": "MANIFEST_VERSION_MATCH",
        "status": "pass" if version_matches else "fail",
        "message": "manifest version matches VERSION" if version_matches else "manifest version must exactly match the nonempty VERSION file",
        "path": "MANIFEST.json",
    })

    raw_entries = manifest.get("files")
    if not isinstance(raw_entries, list):
        checks.append({
            "code": "MANIFEST_FILES_INVALID",
            "status": "fail",
            "message": "manifest files must be an array of path/bytes/sha256 records",
            "path": "MANIFEST.json",
        })
        return checks

    listed: dict[str, dict[str, Any]] = {}
    for index, entry in enumerate(raw_entries):
        entry_path = f"MANIFEST.json#files[{index}]"
        if not isinstance(entry, dict):
            checks.append({"code": "MANIFEST_ENTRY_INVALID", "status": "fail", "message": "manifest file entry must be an object", "path": entry_path})
            continue
        relative = entry.get("path")
        safe = False
        if isinstance(relative, str) and relative and "\\" not in relative:
            pure = PurePosixPath(relative)
            safe = not pure.is_absolute() and pure.as_posix() == relative and ".." not in pure.parts and relative != "MANIFEST.json"
        if not safe:
            checks.append({"code": "MANIFEST_ENTRY_PATH_INVALID", "status": "fail", "message": "manifest path must be a normalized relative non-MANIFEST path", "path": entry_path})
            continue
        if relative in listed:
            checks.append({"code": "MANIFEST_ENTRY_DUPLICATE", "status": "fail", "message": f"manifest path is duplicated: {relative}", "path": entry_path})
            continue
        byte_count = entry.get("bytes")
        digest = entry.get("sha256")
        fields_valid = (
            isinstance(byte_count, int)
            and not isinstance(byte_count, bool)
            and byte_count >= 0
            and isinstance(digest, str)
            and re.fullmatch(r"[a-f0-9]{64}", digest) is not None
        )
        checks.append({
            "code": "MANIFEST_ENTRY_SHAPE",
            "status": "pass" if fields_valid else "fail",
            "message": "manifest entry has valid bytes and sha256 fields" if fields_valid else "manifest entry requires nonnegative integer bytes and lowercase SHA-256",
            "path": entry_path,
        })
        if fields_valid:
            listed[relative] = entry

    actual = {
        path.relative_to(root).as_posix(): path
        for path in package_files
        if path != manifest_path and not path.is_symlink()
    }
    missing = sorted(set(actual) - set(listed))
    extra = sorted(set(listed) - set(actual))
    checks.append({
        "code": "MANIFEST_FILESET_COMPLETE",
        "status": "pass" if not missing and not extra else "fail",
        "message": "manifest lists every non-MANIFEST regular file exactly once" if not missing and not extra else f"manifest file set differs from package (missing={missing}, extra={extra})",
        "path": "MANIFEST.json",
    })
    for relative in sorted(set(actual).intersection(listed)):
        path = actual[relative]
        entry = listed[relative]
        bytes_match = path.stat().st_size == entry["bytes"]
        checks.append({
            "code": "MANIFEST_BYTES_MATCH",
            "status": "pass" if bytes_match else "fail",
            "message": f"manifest byte count {'matches' if bytes_match else 'is stale for'} {relative}",
            "path": "MANIFEST.json",
        })
        sha_matches = _sha256_file(path) == entry["sha256"]
        checks.append({
            "code": "MANIFEST_SHA256_MATCH",
            "status": "pass" if sha_matches else "fail",
            "message": f"manifest SHA-256 {'matches' if sha_matches else 'is stale for'} {relative}",
            "path": "MANIFEST.json",
        })
    return checks


def audit(
    root: Path,
    scan_paths: Iterable[Path],
    mcp_probe: Path | None,
    cli_probe: Path | None,
    require_provider_prompt: bool,
    allow_cli_fallback: bool,
) -> dict[str, Any]:
    checks: list[dict[str, Any]] = []
    if not root.exists() or not root.is_dir():
        raise InputError(f"workflow root is missing or not a directory: {root}")
    if root.is_symlink():
        raise InputError(f"workflow root must not be a symbolic link: {root}")
    root = root.resolve()

    for relative in REQUIRED_FILES:
        path = root / relative
        checks.append({
            "code": "PACKAGE_FILE_PRESENT",
            "status": "pass" if path.is_file() and not path.is_symlink() else "fail",
            "message": f"required package file {'is present' if path.is_file() and not path.is_symlink() else 'is missing or symlinked'}: {relative}",
            "path": relative,
        })

    package_files = _all_files(root)
    for path in package_files:
        relative = path.relative_to(root)
        if path.is_symlink():
            checks.append({"code": "PACKAGE_SYMLINK_FORBIDDEN", "status": "fail", "message": "package files must not be symbolic links", "path": str(relative)})

    schema_files = sorted((root / "schemas").glob("*.schema.json")) if (root / "schemas").is_dir() else []
    schema_ids: set[str] = set()
    for path in schema_files:
        try:
            value = load_json(path, "schema")
            schema_id = value.get("$id") if isinstance(value, dict) else None
            valid = isinstance(schema_id, str) and schema_id and schema_id not in schema_ids
            checks.append({"code": "SCHEMA_JSON_VALID", "status": "pass" if valid else "fail", "message": "schema JSON has a unique nonempty $id" if valid else "schema must be an object with a unique nonempty $id", "path": str(path.relative_to(root))})
            if isinstance(schema_id, str):
                schema_ids.add(schema_id)
        except InputError as error:
            checks.append({"code": "SCHEMA_JSON_VALID", "status": "fail", "message": str(error), "path": str(path.relative_to(root))})

    for document in [path for path in package_files if path.suffix.lower() == ".md"]:
        try:
            text = document.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError) as error:
            checks.append({"code": "REFERENCE_READ_ERROR", "status": "fail", "message": str(error), "path": str(document.relative_to(root))})
            continue
        for raw_target in LINK_RE.findall(text):
            target = raw_target.split("#", 1)[0]
            if not target or target.startswith(("https://", "http://", "mailto:", "#")):
                continue
            candidate = (document.parent / target).resolve()
            try:
                candidate.relative_to(root)
            except ValueError:
                checks.append({"code": "REFERENCE_PATH_ESCAPE", "status": "fail", "message": f"local reference escapes package root: {raw_target}", "path": str(document.relative_to(root))})
                continue
            checks.append({"code": "REFERENCE_TARGET_PRESENT", "status": "pass" if candidate.exists() else "fail", "message": f"local reference target {'exists' if candidate.exists() else 'is missing'}: {raw_target}", "path": str(document.relative_to(root))})

    checks.extend(_manifest_integrity_checks(root, package_files))

    all_scan_files = [
        path
        for path in package_files
        if not path.is_symlink() and _should_scan_relative(path.relative_to(root))
    ]
    for requested in scan_paths:
        if not requested.exists():
            checks.append({"code": "SCAN_PATH_MISSING", "status": "fail", "message": "requested secret-scan path does not exist", "path": str(requested)})
        elif requested.is_dir():
            all_scan_files.extend(_project_scan_files(requested))
        elif requested.is_file() and not requested.is_symlink():
            all_scan_files.append(requested)
        else:
            checks.append({"code": "SCAN_PATH_UNSAFE", "status": "fail", "message": "requested secret-scan path must be a regular file or real directory", "path": str(requested)})
    for probe in (mcp_probe, cli_probe):
        if probe is not None and probe.is_file() and not probe.is_symlink():
            all_scan_files.append(probe)
    ordinary = [path for path in all_scan_files if path.suffix.lower() != ".zip"]
    findings: list[dict[str, str]] = []
    for path in sorted(set(ordinary), key=str):
        findings.extend(_scan_file_secrets(path))
    zip_checks: list[dict[str, Any]] = []
    for zip_path in sorted({path for path in all_scan_files if path.suffix.lower() == ".zip"}, key=str):
        zip_findings, extra = _zip_secret_findings(zip_path, root)
        findings.extend(zip_findings)
        zip_checks.extend(extra)
    checks.extend(zip_checks)
    for finding in findings:
        checks.append({"code": finding["code"], "status": "fail", "message": finding["message"], "path": finding["path"]})
    if not findings:
        checks.append({"code": "SECRET_SCAN_CLEAN", "status": "pass", "message": "no recognized secret patterns found in scanned text or ZIP members"})

    mcp_value = load_json(mcp_probe, "MCP runtime probe") if mcp_probe else None
    cli_value = load_json(cli_probe, "CLI runtime probe") if cli_probe else None
    mcp_envelope_valid = _mcp_probe_envelope_valid(mcp_value)
    mcp_capable = bool(
        mcp_envelope_valid
        and _contains_declared_capability(mcp_value, "search")
        and _contains_declared_capability(mcp_value, "get_component")
    )
    mcp_prompt = _has_id_bound_get_component_prompt(mcp_value)
    cli_prompt = _has_nonempty_prompt(cli_value)
    if mcp_value is not None:
        checks.append({
            "code": "MCP_PROBE_ENVELOPE_VALID",
            "status": "pass" if mcp_envelope_valid else "fail",
            "message": "MCP probe uses the portable 21st-mcp-probe/v1 capabilities/calls envelope" if mcp_envelope_valid else "MCP probe must use 21st-mcp-probe/v1 with separate capabilities and calls arrays",
            "path": str(mcp_probe),
        })
        checks.append({"code": "MCP_CAPABILITIES_PRESENT", "status": "pass" if mcp_capable else "fail", "message": "MCP probe exposes search and get_component" if mcp_capable else "MCP probe must expose native search and get_component capabilities", "path": str(mcp_probe)})
    if require_provider_prompt:
        if mcp_capable and mcp_prompt:
            checks.append({"code": "MCP_PROMPT_AVAILABLE", "status": "pass", "message": "native MCP retrieval returned a nonempty prompt", "path": str(mcp_probe)})
        elif allow_cli_fallback and cli_value is not None and cli_prompt:
            checks.append({"code": "MCP_PROMPT_MISSING", "status": "warn", "message": "native MCP prompt unavailable; explicitly allowed CLI fallback is being verified", "path": str(mcp_probe) if mcp_probe else None})
            checks.append({"code": "CLI_PROMPT_AVAILABLE", "status": "pass", "message": "runtime CLI JSON contains a nonempty prompt despite the documented code+demo-only shape", "path": str(cli_probe)})
        else:
            code = "CLI_PROMPT_MISSING" if allow_cli_fallback and cli_value is not None else "MCP_PROMPT_MISSING"
            path = cli_probe if code == "CLI_PROMPT_MISSING" else mcp_probe
            checks.append({"code": code, "status": "fail", "message": "a nonempty provider prompt is required; documented CLI code/demo fields do not satisfy this gate", "path": str(path) if path else None})
    elif mcp_value is None and cli_value is None:
        checks.append({"code": "PROVIDER_RUNTIME_NOT_PROBED", "status": "warn", "message": "provider runtime prompt capability was not probed; use --require-provider-prompt during an actual run"})

    return make_report(
        "package-doctor",
        checks,
        artifacts={"root": str(root), "scanned_files": len(set(all_scan_files)), "secret_findings": len(findings)},
        external_pending=[] if require_provider_prompt else ["21st native MCP search/get_component prompt capability"],
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Audit workflow package structure, references, secrets, and 21st prompt runtime capability.")
    parser.add_argument("--root", default=str(Path(__file__).resolve().parents[1]), help="Workflow package root")
    parser.add_argument("--scan", action="append", default=[], help="Additional project/file/ZIP path to secret-scan; repeat as needed")
    parser.add_argument("--mcp-probe", help="Runtime MCP JSON proving search/get_component and a nonempty prompt")
    parser.add_argument("--cli-probe", help="Runtime `21st get --json` payload to inspect for a nonempty prompt")
    parser.add_argument("--require-provider-prompt", action="store_true", help="Fail unless native MCP (or explicitly allowed CLI fallback) provides a nonempty prompt")
    parser.add_argument("--allow-cli-fallback", action="store_true", help="Allow CLI only when runtime JSON unexpectedly includes a nonempty prompt")
    parser.add_argument("--strict-warnings", action="store_true", help="Return nonzero when the report contains warnings")
    parser.add_argument("--output", help="Optional explicit qa-report/v1 JSON output; otherwise print it")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        report = audit(
            Path(args.root).expanduser(),
            [Path(value).expanduser() for value in args.scan],
            Path(args.mcp_probe).expanduser() if args.mcp_probe else None,
            Path(args.cli_probe).expanduser() if args.cli_probe else None,
            args.require_provider_prompt,
            args.allow_cli_fallback,
        )
        output_report(report, args.output)
    except InputError as error:
        print(f"doctor.py: {error}", file=sys.stderr)
        return 2
    if not report["passed"] or (args.strict_warnings and report["summary"]["warnings"]):
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
