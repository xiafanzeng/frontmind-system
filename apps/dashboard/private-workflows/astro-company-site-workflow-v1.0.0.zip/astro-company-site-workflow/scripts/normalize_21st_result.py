#!/usr/bin/env python3
"""Normalize 21st runtime results without persisting provider Prompt or code.

The raw input is treated as untrusted transport data.  Prompt text is held only
in memory long enough to verify presence, hash it, and extract conservative
visual directives.  The output is a visual-selection/v1 record at the
``normalized`` stage; a human/agent later records the nine visual evaluations
and the single selection.
"""

from __future__ import annotations

import argparse
import json
import re
import sys

sys.dont_write_bytecode = True
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence
from urllib.parse import parse_qsl, unquote, urlparse, urlunparse

from validate_inputs import (
    InputError,
    load_json,
    resolve_schema,
    sha256_file,
    sha256_json,
    sha256_text,
    validate_instance,
    write_json,
)


TARGETS = {"search": 18, "retrieve": 12, "present": 9}
VISUAL_AXES = ("structure", "typography", "surface", "color", "imagery", "motion", "tone")
QUERY_ROLES = {"foundation", "section", "motion"}
PROMPT_KEYS = {"prompt", "copyprompt", "designprompt", "componentprompt", "nativeprompt"}
PROMPT_CONTAINERS = {"data", "result", "component", "detail", "payload", "structuredcontent"}
SENSITIVE_QUERY_KEYS = re.compile(r"(?:api.?key|token|secret|credential|authorization|auth|signature|jwt)", re.IGNORECASE)
SENSITIVE_URL_VALUE = re.compile(
    r"(?:21st_sk_[A-Za-z0-9_-]{12,}|\bBearer\s+[A-Za-z0-9._~+/-]{12,}|"
    r"\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,})",
    re.IGNORECASE,
)
_UNSAFE_PROMPT_PATTERNS = (
    ("credential", re.compile(r"(?:\bBearer\s+[A-Za-z0-9._~+/-]{12,}|21st_sk_[A-Za-z0-9_-]{12,}|\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}|api[-_ ]?key\s*[:=])", re.IGNORECASE)),
    (
        "instruction-injection",
        re.compile(
            r"(?:ignore\s+(?:all\s+)?(?:previous|system|developer)|"
            r"reveal\s+(?:the\s+)?(?:system|developer)\s+(?:prompt|message)|"
            r"modify\s+(?:the\s+)?(?:host|agent|mcp)\s+(?:config|configuration)|"
            r"exfiltrat(?:e|ion))",
            re.IGNORECASE,
        ),
    ),
)
_UNSAFE_METADATA_PATTERN = re.compile(
    r"(?:<\s*/?\s*[A-Za-z][^>]*>|```|[\"']use client[\"']|"
    r"\b(?:npm\s+(?:i|install)|npx\s+|pnpm\s+(?:add|install)|yarn\s+add|bun\s+add)\b|"
    r"\bimport\s+.+\bfrom\b|\brequire\s*\(|\bfunction\s+[A-Za-z_$]|=>|\bclassName\s*=)",
    re.IGNORECASE,
)

# Values, not source sentences, are persisted.  Every emitted directive is a
# member of this fixed taxonomy so untrusted Prompt text cannot become an
# instruction channel in the selection record or build contract.
DIRECTIVE_TAXONOMY: tuple[tuple[str, re.Pattern[str]], ...] = (
    ("structure:asymmetric-grid", re.compile(r"\basymmetr(?:y|ic)|offset\s+grid", re.I)),
    ("structure:modular-grid", re.compile(r"\bmodular\b|\bbento\b|card\s+grid", re.I)),
    ("structure:hero-led-hierarchy", re.compile(r"\bhero\b|above[- ]the[- ]fold", re.I)),
    ("structure:split-layout", re.compile(r"split[- ](?:screen|layout)|two[- ]column", re.I)),
    ("structure:editorial-rhythm", re.compile(r"\beditorial\b|magazine|rhythm", re.I)),
    ("typography:display-led-hierarchy", re.compile(r"display\s+(?:type|font)|oversized\s+(?:type|heading)|headline", re.I)),
    ("typography:condensed-technical", re.compile(r"condensed|technical\s+(?:type|font|typography)", re.I)),
    ("typography:serif-editorial", re.compile(r"\bserif\b", re.I)),
    ("typography:neutral-sans", re.compile(r"sans[- ]serif|neutral\s+sans", re.I)),
    ("surface:border-defined", re.compile(r"\bborder(?:ed|s)?\b|divider", re.I)),
    ("surface:soft-shadow-depth", re.compile(r"soft\s+shadow|drop\s+shadow|layered\s+depth", re.I)),
    ("surface:glass-like-layering", re.compile(r"glass(?:morphism)?|frosted|backdrop\s+blur", re.I)),
    ("surface:rounded-containers", re.compile(r"rounded|corner\s+radius|pill", re.I)),
    ("color:dark-canvas", re.compile(r"dark\s+(?:mode|canvas|background)|near[- ]black", re.I)),
    ("color:light-canvas", re.compile(r"light\s+(?:mode|canvas|background)|off[- ]white", re.I)),
    ("color:muted-palette", re.compile(r"muted|desaturated|low[- ]saturation", re.I)),
    ("color:high-contrast", re.compile(r"high[- ]contrast|strong\s+contrast", re.I)),
    ("color:single-accent", re.compile(r"single\s+accent|one\s+accent|accent\s+color", re.I)),
    ("imagery:photography-led", re.compile(r"photograph|photo[- ]led|camera", re.I)),
    ("imagery:product-ui-led", re.compile(r"product\s+(?:ui|screen)|interface\s+(?:image|preview)|dashboard", re.I)),
    ("imagery:illustration-led", re.compile(r"illustration|illustrative", re.I)),
    ("imagery:wide-crop", re.compile(r"wide\s+crop|cinematic\s+crop|panoramic", re.I)),
    ("imagery:masked-media", re.compile(r"image\s+mask|masked\s+(?:image|media)|clip[- ]path", re.I)),
    ("motion:controlled-reveal", re.compile(r"masked?\s+reveal|controlled\s+reveal|fade[- ]?in|reveal", re.I)),
    ("motion:short-transition", re.compile(r"short\s+transition|micro[- ]?interaction|transition", re.I)),
    ("motion:scroll-triggered", re.compile(r"scroll[- ]trigger|on\s+scroll|parallax", re.I)),
    ("motion:hover-depth", re.compile(r"hover\s+(?:depth|lift|state)|on\s+hover", re.I)),
    ("tone:technical-precise", re.compile(r"technical|precise|engineering|industrial", re.I)),
    ("tone:warm-human", re.compile(r"warm|human|approachable|friendly", re.I)),
    ("tone:premium-restrained", re.compile(r"premium|luxury|restrained|refined", re.I)),
    ("tone:bold-graphic", re.compile(r"bold|graphic|brutalist", re.I)),
    ("responsive:mobile-reflow", re.compile(r"responsive|mobile|small[- ]screen|stack", re.I)),
)
DIRECTIVE_VALUES = {value for value, _ in DIRECTIVE_TAXONOMY} | {
    "structure:preview-led-original-translation",
    "motion:reduced-motion-required",
}


def _canonical_key(value: Any) -> str:
    """Match snake_case, kebab-case, and camelCase transport keys."""

    return re.sub(r"[^a-z0-9]", "", str(value).casefold())


def _first_string(value: Any, keys: Iterable[str]) -> str | None:
    if isinstance(value, list):
        for child in value:
            found = _first_string(child, keys)
            if found:
                return found
        return None
    if not isinstance(value, Mapping):
        return None
    lowered = {_canonical_key(key): item for key, item in value.items()}
    for key in keys:
        item = lowered.get(_canonical_key(key))
        if isinstance(item, str) and item.strip():
            return item.strip()
    for container_key in ("data", "result", "component", "metadata", "detail"):
        child = lowered.get(_canonical_key(container_key))
        found = _first_string(child, keys)
        if found:
            return found
    return None


def _string_list(value: Any, keys: Iterable[str]) -> list[str]:
    if not isinstance(value, Mapping):
        return []
    canonical_items = {_canonical_key(key): child for key, child in value.items()}
    for key in keys:
        child = canonical_items.get(_canonical_key(key))
        if isinstance(child, list):
            return list(dict.fromkeys(str(item).strip() for item in child if str(item).strip()))[:32]
        if isinstance(child, Mapping):
            return list(dict.fromkeys(str(item).strip() for item in child if str(item).strip()))[:32]
    for container in ("data", "result", "component", "metadata", "detail"):
        child = canonical_items.get(_canonical_key(container))
        found = _string_list(child, keys)
        if found:
            return found
    return []


def _find_prompt(value: Any) -> str | None:
    """Return only explicitly named provider Prompt fields.

    Deliberately do not accept suffix matches such as ``systemPrompt`` or
    ``instructionPrompt``.  Container recursion is also allowlisted.
    """

    if isinstance(value, list):
        for child in value:
            found = _find_prompt(child)
            if found:
                return found
        return None
    if isinstance(value, Mapping):
        for key, child in value.items():
            normalized = _canonical_key(key)
            if normalized in PROMPT_KEYS and isinstance(child, str) and child.strip():
                return child.strip()
        canonical_items = {_canonical_key(key): child for key, child in value.items()}
        for container in PROMPT_CONTAINERS:
            child = canonical_items.get(container)
            if child is not None:
                found = _find_prompt(child)
                if found:
                    return found
    return None


def _contains_generate(value: Any) -> bool:
    if isinstance(value, Mapping):
        for key, child in value.items():
            normalized = _canonical_key(key)
            if normalized in {"generateused", "generated", "usedgenerate"} and child is True:
                return True
            if normalized in {"operation", "action", "tool", "method"} and isinstance(child, str):
                if _canonical_key(child) in {"generate", "iterategeneration", "gettake", "publish"}:
                    return True
            if _contains_generate(child):
                return True
    elif isinstance(value, list):
        return any(_contains_generate(child) for child in value)
    return False


def _candidate_list(raw: Any, names: Sequence[str]) -> list[Any]:
    if isinstance(raw, list):
        return raw
    if not isinstance(raw, Mapping):
        return []
    canonical_items = {_canonical_key(key): value for key, value in raw.items()}
    for name in names:
        value = canonical_items.get(_canonical_key(name))
        if isinstance(value, list):
            return value
        if isinstance(value, Mapping):
            nested_items = {_canonical_key(key): child for key, child in value.items()}
            for nested in ("results", "items", "components"):
                child = nested_items.get(_canonical_key(nested))
                if isinstance(child, list):
                    return child
    return []


def _item_id(item: Any) -> str | None:
    # Display names are mutable and therefore cannot serve as provider IDs.
    return _first_string(item, ("item_id", "component_id", "id", "slug"))


def _valid_item_id(value: str | None) -> bool:
    if not value or len(value) > 192:
        return False
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:/-]*", value):
        return False
    return _unsafe_prompt_reason(value) is None


def _candidate_id(item_id: str) -> str:
    safe = re.sub(r"[^A-Za-z0-9._-]+", "-", item_id).strip("-.") or sha256_text(item_id)[:12]
    return "21st-" + safe


def _unsafe_prompt_reason(prompt: str) -> str | None:
    for reason, pattern in _UNSAFE_PROMPT_PATTERNS:
        if pattern.search(prompt):
            return reason
    return None


def _normalize_directives(prompt: str) -> list[str]:
    directives = [value for value, pattern in DIRECTIVE_TAXONOMY if pattern.search(prompt)]
    if not directives:
        directives.append("structure:preview-led-original-translation")
    directives = [value for value in directives if value != "motion:reduced-motion-required"][:11]
    directives.append("motion:reduced-motion-required")
    return directives


def _query_role(item: Any) -> str | None:
    value = _first_string(item, ("query_role", "query_group_role", "search_role"))
    return value.casefold() if value and value.casefold() in QUERY_ROLES else None


def _safe_url(value: str | None, *, source: bool) -> tuple[str | None, str | None]:
    if not value:
        return None, "missing"
    parsed = urlparse(value)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        return None, "source URL must use http(s)" if source else "preview URL must use http(s)"
    hostname = (parsed.hostname or "").casefold()
    if source and hostname != "21st.dev" and not hostname.endswith(".21st.dev"):
        return None, "provider source URL host must be 21st.dev or a subdomain"
    try:
        parsed_port = parsed.port
    except ValueError:
        return None, "URL contains an invalid port"
    if parsed.username is not None or parsed.password is not None:
        return None, "URL userinfo is forbidden"
    query_pairs = parse_qsl(parsed.query, keep_blank_values=True)
    if any(SENSITIVE_QUERY_KEYS.search(key) for key, _ in query_pairs):
        return None, "URL contains a sensitive credential-like query parameter"
    decoded_url = unquote(value)
    if SENSITIVE_URL_VALUE.search(decoded_url) or any(SENSITIVE_URL_VALUE.search(item) for _, item in query_pairs):
        return None, "URL contains a credential-like value"
    if parsed_port is not None and not (1 <= parsed_port <= 65535):
        return None, "URL contains an invalid port"
    return value, None


def _canonical_provider_url(value: str) -> str:
    parsed = urlparse(value)
    host = (parsed.hostname or "").casefold()
    port = parsed.port
    if port and not ((parsed.scheme == "http" and port == 80) or (parsed.scheme == "https" and port == 443)):
        host = f"{host}:{port}"
    path = parsed.path.rstrip("/") or "/"
    return urlunparse((parsed.scheme.casefold(), host, path, "", parsed.query, ""))


def _safe_metadata(value: str | None, fallback: str | None = None) -> str | None:
    if value is None:
        return fallback
    if _UNSAFE_METADATA_PATTERN.search(value):
        return fallback
    cleaned = re.sub(r"<[^>]*>", " ", value)
    cleaned = re.sub(r"(?:\bBearer\s+\S+|21st_sk_[A-Za-z0-9_-]+|\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+)", "[redacted]", cleaned, flags=re.I)
    cleaned = re.sub(r"(?i)\b(?:api[-_ ]?key|API_KEY_21ST|TWENTYFIRST_TOKEN)\b\s*[:=]\s*\S+", "[redacted]", cleaned)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    return cleaned[:300] or fallback


def _direct_string(value: Any, keys: Iterable[str]) -> str | None:
    if not isinstance(value, Mapping):
        return None
    items = {_canonical_key(key): child for key, child in value.items()}
    for key in keys:
        child = items.get(_canonical_key(key))
        if isinstance(child, str) and child.strip():
            return child.strip()
    return None


def _get_component_operation(envelope: Any) -> bool:
    """Validate explicit call identity without trusting a result-list label.

    ``operation`` must be exactly get_component. ``toolName`` may be exactly
    that name or a namespace-delimited host name whose final segment is
    get_component, for example ``mcp__21st__get_component``.
    """

    if not isinstance(envelope, Mapping):
        return False
    items = {_canonical_key(key): child for key, child in envelope.items()}
    identities: list[bool] = []
    operation = items.get("operation")
    if operation is not None:
        identities.append(isinstance(operation, str) and _canonical_key(operation) == "getcomponent")
    tool_name = items.get("toolname")
    if tool_name is not None:
        if not isinstance(tool_name, str):
            identities.append(False)
        else:
            segments = re.split(r"__+|[:/.]+", tool_name.strip())
            identities.append(bool(segments) and _canonical_key(segments[-1]) == "getcomponent")
    return bool(identities) and all(identities)


def _requested_provider_id(envelope: Any) -> str | None:
    requested = _direct_string(envelope, ("requested_provider_item_id", "requested_item_id"))
    if requested:
        return requested
    if not isinstance(envelope, Mapping):
        return None
    items = {_canonical_key(key): child for key, child in envelope.items()}
    for key in ("request", "arguments", "args"):
        child = items.get(_canonical_key(key))
        requested = _direct_string(child, ("provider_item_id", "item_id", "component_id", "id"))
        if requested:
            return requested
    return None


def _response_payload(envelope: Any) -> Mapping[str, Any] | None:
    if not isinstance(envelope, Mapping):
        return None
    items = {_canonical_key(key): child for key, child in envelope.items()}
    for key in ("response", "response_payload", "result"):
        child = items.get(_canonical_key(key))
        if isinstance(child, Mapping):
            return child
    return None


def _validated_detail_envelope(envelope: Any) -> tuple[str | None, Mapping[str, Any] | None, str | None]:
    if not _get_component_operation(envelope):
        return None, None, "detail envelope must explicitly identify operation/toolName as get_component"
    requested_id = _requested_provider_id(envelope)
    if not _valid_item_id(requested_id):
        return None, None, "get_component envelope lacks a safe explicit requested provider item ID"
    response = _response_payload(envelope)
    if response is None:
        return requested_id, None, "get_component envelope lacks a mapping response payload"
    response_id = _item_id(response)
    if not _valid_item_id(response_id) or response_id != requested_id:
        return requested_id, None, "get_component response provider ID does not match the requested provider item ID"
    return requested_id, response, None


def _merge_search_and_details(raw: Any) -> tuple[list[tuple[str, Any, Any | None]], list[dict[str, Any]]]:
    errors: list[dict[str, Any]] = []
    if isinstance(raw, list):
        search = raw
        details: list[Any] = []
    else:
        search = _candidate_list(raw, ("search_results", "results", "items", "components"))
        details = _candidate_list(raw, ("retrieved_results", "retrieved", "details", "get_component_results"))
    detail_by_id: dict[str, Any] = {}
    ambiguous_detail_ids: set[str] = set()
    for detail in details:
        identifier, response, envelope_error = _validated_detail_envelope(detail)
        if envelope_error:
            errors.append({
                "code": "GET_COMPONENT_CALL_EVIDENCE_INVALID",
                "message": envelope_error,
                "candidate_id": _candidate_id(identifier) if identifier else None,
            })
            continue
        assert identifier is not None and response is not None
        if identifier in detail_by_id:
            ambiguous_detail_ids.add(identifier)
            errors.append({"code": "DUPLICATE_RETRIEVAL_ID", "message": f"get_component returned duplicate provider ID {identifier!r}", "candidate_id": _candidate_id(identifier)})
            continue
        detail_by_id[identifier] = response
    for identifier in ambiguous_detail_ids:
        detail_by_id.pop(identifier, None)
    merged: list[tuple[str, Any, Any | None]] = []
    seen: set[str] = set()
    seen_sources: set[str] = set()
    for item in search:
        identifier = _item_id(item)
        if not _valid_item_id(identifier):
            errors.append({"code": "PROVIDER_ITEM_ID_MISSING", "message": "search result lacks a safe stable provider item ID", "candidate_id": None})
            continue
        query_role = _query_role(item)
        if not query_role:
            errors.append({
                "code": "QUERY_ROLE_MISSING",
                "message": "search result must be tagged foundation, section, or motion by its query group",
                "candidate_id": _candidate_id(identifier),
            })
            continue
        source_value = _first_string(item, ("source_url", "url", "component_url", "catalog_url"))
        source_url, source_error = _safe_url(source_value, source=True)
        if source_error or not source_url:
            errors.append({
                "code": "SOURCE_URL_MISSING",
                "message": "search result lacks a safe stable provider source URL and is ineligible",
                "candidate_id": _candidate_id(identifier),
            })
            continue
        if identifier in seen:
            errors.append({"code": "DUPLICATE_PROVIDER_ITEM", "message": f"duplicate search provider ID {identifier!r} was rejected", "candidate_id": _candidate_id(identifier)})
            continue
        canonical_source = _canonical_provider_url(source_url)
        if canonical_source in seen_sources:
            errors.append({
                "code": "DUPLICATE_SOURCE_URL",
                "message": "duplicate canonical provider source URL was rejected",
                "candidate_id": _candidate_id(identifier),
            })
            continue
        seen.add(identifier)
        seen_sources.add(canonical_source)
        merged.append((identifier, item, detail_by_id.get(identifier)))
        if len(merged) == TARGETS["search"]:
            break
    return merged, errors


def normalize(raw: Any, source: str, brief_sha256: str, observation_sha256: str | None) -> dict[str, Any]:
    errors: list[dict[str, Any]] = []
    if _contains_generate(raw):
        errors.append({"code": "GENERATE_FORBIDDEN", "message": "runtime payload indicates a forbidden generation operation", "candidate_id": None})
    merged, merge_errors = _merge_search_and_details(raw)
    errors.extend(merge_errors)
    if len(merged) < TARGETS["search"]:
        errors.append({
            "code": "SEARCH_RESULTS_INSUFFICIENT",
            "message": f"expected 18 unique catalog results, received {len(merged)}",
            "candidate_id": None,
        })

    candidates: list[dict[str, Any]] = []
    prompt_successes: list[str] = []
    foundation_preview_successes: list[str] = []
    for index, (identifier, search_item, detail_item) in enumerate(merged):
        candidate_id = _candidate_id(identifier)
        combined = detail_item if detail_item is not None else {}
        query_role = _query_role(search_item)
        prompt: str | None = None
        retrieval_attempted = (
            len(prompt_successes) < TARGETS["retrieve"]
            or len(foundation_preview_successes) < TARGETS["present"]
        )
        if retrieval_attempted:
            if detail_item is None:
                errors.append({
                    "code": "GET_COMPONENT_RESULT_MISSING",
                    "message": f"search item {identifier!r} has no independent get_component result",
                    "candidate_id": candidate_id,
                })
            else:
                prompt = _find_prompt(detail_item)
            if prompt:
                unsafe_reason = _unsafe_prompt_reason(prompt)
                if unsafe_reason:
                    errors.append({
                        "code": "PROMPT_UNSAFE_CONTENT",
                        "message": f"retrieved item {identifier!r} Prompt was rejected as {unsafe_reason}; no text or hash was persisted",
                        "candidate_id": candidate_id,
                    })
                    prompt = None
            if not prompt and not any(
                item.get("code") == "PROMPT_UNSAFE_CONTENT" and item.get("candidate_id") == candidate_id
                for item in errors
            ):
                errors.append({
                    "code": "MCP_PROMPT_MISSING" if source == "mcp" else "CLI_PROMPT_MISSING",
                    "message": f"get_component item {identifier!r} lacks an explicitly allowlisted nonempty native Prompt; search Prompt, systemPrompt, code, demo, and description are not substitutes",
                    "candidate_id": candidate_id,
                })
        source_value = _first_string(search_item, ("source_url", "url", "component_url", "catalog_url"))
        preview_value = _first_string(combined, ("preview_url", "preview", "screenshot_url", "image_url", "demo_url"))
        preview_value = preview_value or _first_string(search_item, ("preview_url", "preview", "screenshot_url", "image_url", "demo_url"))
        source_url, source_url_error = _safe_url(source_value, source=True)
        preview_url, preview_url_error = _safe_url(preview_value, source=False)
        if retrieval_attempted and source_url_error:
            errors.append({
                "code": "SOURCE_URL_MISSING",
                "message": f"retrieved item {identifier!r} lacks a safe stable provider source URL ({source_url_error}) and is ineligible",
                "candidate_id": candidate_id,
            })
        if retrieval_attempted and preview_url_error:
            errors.append({
                "code": "PREVIEW_MISSING",
                "message": f"retrieved item {identifier!r} lacks safe provider preview media ({preview_url_error})",
                "candidate_id": candidate_id,
            })
        prompt_hash = sha256_text(prompt) if prompt else None
        directives = _normalize_directives(prompt) if prompt else []
        valid_prompt = bool(
            retrieval_attempted
            and detail_item is not None
            and prompt
            and source_url
            and query_role
        )
        if valid_prompt:
            prompt_successes.append(candidate_id)
        if valid_prompt and preview_url and query_role == "foundation":
            foundation_preview_successes.append(candidate_id)
        candidates.append({
            "candidate_id": candidate_id,
            "provider_item_id": identifier,
            "query_role": query_role,
            "search_rank": index + 1,
            "title": _safe_metadata(_first_string(combined, ("title", "name")) or _first_string(search_item, ("title", "name")), identifier),
            "author": _safe_metadata(_first_string(combined, ("author", "author_name", "username", "creator"))
            or _first_string(search_item, ("author", "author_name", "username", "creator"))),
            "source_url": source_url,
            "preview_url": preview_url,
            "dependencies": [
                value for value in (
                    _safe_metadata(item) for item in _string_list(combined, ("dependencies", "registry_dependencies", "npm_dependencies"))
                ) if value and re.fullmatch(r"[A-Za-z0-9@/._-]{1,128}", value)
            ],
            "license_note": _safe_metadata(_first_string(combined, ("license_note", "license", "licence"))),
            "retrieval_status": "prompt-retrieved" if valid_prompt else ("error" if retrieval_attempted else "search-only"),
            "retrieval_operation": "get_component" if valid_prompt else None,
            "retrieval_response_sha256": sha256_json(detail_item) if valid_prompt else None,
            "prompt_sha256": prompt_hash,
            "normalized_directives": directives,
            "code_ignored": True,
        })

    retrieval_shortlist = [
        *foundation_preview_successes[: TARGETS["present"]],
        *[
            candidate_id
            for candidate_id in prompt_successes
            if candidate_id not in set(foundation_preview_successes[: TARGETS["present"]])
        ],
    ][: TARGETS["retrieve"]]
    if len(retrieval_shortlist) < TARGETS["retrieve"]:
        errors.append({
            "code": "RETRIEVAL_RESULTS_INSUFFICIENT",
            "message": f"expected 12 prompt-bearing details after exhausting available retrieval attempts, received {len(retrieval_shortlist)}",
            "candidate_id": None,
        })
    by_id = {candidate["candidate_id"]: candidate for candidate in candidates}
    presented_ids = foundation_preview_successes[: TARGETS["present"]]
    if len(presented_ids) < TARGETS["present"]:
        for candidate_id in prompt_successes:
            if by_id[candidate_id]["query_role"] == "foundation" and not by_id[candidate_id]["preview_url"] and not any(
                item.get("code") == "PREVIEW_MISSING" and item.get("candidate_id") == candidate_id
                for item in errors
            ):
                errors.append({
                    "code": "PREVIEW_MISSING",
                    "message": "prompt-bearing candidate cannot be presented without actual provider preview media",
                    "candidate_id": candidate_id,
                })
        errors.append({
            "code": "PRESENTATION_RESULTS_INSUFFICIENT",
            "message": f"expected 9 prompt-and-preview candidates, received {len(presented_ids)}",
            "candidate_id": None,
        })
    presented = [
        {
            "candidate_id": candidate_id,
            "option_label": chr(ord("A") + index),
            "presentation_rank": index + 1,
            "fit_reason": None,
            "score": None,
            "score_breakdown": {
                "reference_style": None,
                "business_function": None,
                "distinctiveness": None,
                "owned_asset_feasibility": None,
                "responsive_accessibility": None,
                "native_astro_translatability": None,
            },
            "rationale": None,
            "visual_axes": {axis: None for axis in VISUAL_AXES},
        }
        for index, candidate_id in enumerate(presented_ids[: TARGETS["present"]])
    ]
    return {
        "schema_version": "visual-selection/v1",
        "stage": "normalized",
        "board_ready": False,
        "brief_sha256": brief_sha256,
        "reference_observation_sha256": observation_sha256,
        "provider": "21st",
        "source": source,
        "targets": TARGETS,
        "actual": {
            "searched": len(candidates),
            "prompt_retrieved": len(retrieval_shortlist),
            "presented": len(presented),
        },
        "searched_candidates": candidates,
        "retrieval_shortlist": retrieval_shortlist,
        "presented_candidates": presented,
        "selected": None,
        "supporting_sources": [],
        "errors": errors,
        "generate_used": False,
        "provider_code_reuse": False,
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Normalize untrusted 21st MCP/CLI runtime JSON into a prompt-free visual-selection/v1 funnel record."
    )
    parser.add_argument("--input", required=True, help="Raw runtime JSON containing search and retrieved results")
    parser.add_argument("--brief", required=True, help="Exact company brief used to create the search plan")
    parser.add_argument("--observation", help="Optional visual-observation/v1 JSON used as reference evidence")
    parser.add_argument("--source", choices=("mcp", "cli"), help="Runtime transport; otherwise read from input.source")
    parser.add_argument("--output", required=True, help="Explicit output visual-selection JSON path")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        input_path = Path(args.input).expanduser().resolve()
        brief_path = Path(args.brief).expanduser().resolve()
        raw = load_json(input_path, "21st runtime result")
        brief = load_json(brief_path, "company brief")
        brief_schema = load_json(resolve_schema("company-brief"), "company brief schema")
        brief_issues = validate_instance(brief, brief_schema)
        if brief_issues:
            first = brief_issues[0]
            raise InputError(f"company brief is invalid: {first['path']} {first['code']}: {first['message']}")
        raw_source = raw.get("source") if isinstance(raw, Mapping) else None
        source = args.source or (raw_source if raw_source in {"mcp", "cli"} else None)
        if source is None:
            raise InputError("runtime source is ambiguous; pass --source mcp or --source cli")
        observation_hash: str | None = None
        brief_hash = sha256_file(brief_path)
        if brief.get("visual_references") and not args.observation:
            raise InputError("brief contains visual_references; --observation is required for selection normalization")
        if args.observation:
            observation_path = Path(args.observation).expanduser().resolve()
            observation = load_json(observation_path, "visual observation")
            observation_schema = load_json(resolve_schema("visual-observation"), "visual observation schema")
            observation_issues = validate_instance(observation, observation_schema)
            if observation_issues:
                first = observation_issues[0]
                raise InputError(f"visual observation is invalid: {first['path']} {first['code']}: {first['message']}")
            if observation.get("brief_sha256") != brief_hash:
                raise InputError("OBSERVATION_BRIEF_HASH_MISMATCH: observation was not produced for this exact brief")
            expected_references = {
                item["asset_id"]: item
                for item in brief.get("visual_references", [])
                if isinstance(item, dict)
            }
            observed_references = {
                item.get("asset_id"): item
                for item in observation.get("assets", [])
                if isinstance(item, dict) and item.get("role") == "visual_reference"
            }
            missing_references = sorted(set(expected_references) - set(observed_references))
            if missing_references:
                raise InputError(f"REFERENCE_OBSERVATION_MISSING: visual references were not observed: {missing_references}")
            for asset_id, reference in expected_references.items():
                if observed_references[asset_id].get("location") != reference.get("location"):
                    raise InputError(f"REFERENCE_LOCATION_MISMATCH: observation location differs for {asset_id}")
            observation_hash = sha256_file(observation_path)
        result = normalize(raw, source, brief_hash, observation_hash)
        schema = load_json(resolve_schema("visual-selection"), "visual selection schema")
        issues = validate_instance(result, schema)
        if issues:
            first = issues[0]
            raise InputError(f"normalized record violated its contract: {first['path']} {first['code']}: {first['message']}")
        write_json(args.output, result)
    except InputError as error:
        print(f"normalize_21st_result.py: {error}", file=sys.stderr)
        return 2
    error_codes = {item["code"] for item in result["errors"]}
    fatal_codes = {"GENERATE_FORBIDDEN", "CLI_PROMPT_MISSING"}
    if source == "cli":
        fatal_codes.add("PROMPT_UNSAFE_CONTENT")
    no_presentable_result = result["actual"]["presented"] == 0
    degraded = any(
        result["actual"][actual_key] < TARGETS[target_key]
        for actual_key, target_key in (
            ("searched", "search"),
            ("prompt_retrieved", "retrieve"),
            ("presented", "present"),
        )
    )
    summary = {
        "ok": not bool(error_codes & fatal_codes) and not no_presentable_result,
        "degraded": degraded,
        "output": str(Path(args.output).expanduser()),
        "actual": result["actual"],
        "error_codes": sorted(error_codes),
        "blocking_error_codes": sorted(error_codes & fatal_codes)
        + (["NO_PRESENTABLE_CANDIDATE"] if no_presentable_result else []),
        "raw_prompt_persisted": False,
    }
    print(json.dumps(summary, sort_keys=True))
    return 0 if summary["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
