#!/usr/bin/env python3
"""Copy the bundled Astro starter into a new or empty directory without overwriting."""

from __future__ import annotations

import argparse
import html
import json
import os
import re
import shutil
import sys

sys.dont_write_bytecode = True
import tempfile
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit


SCRIPT_DIR = Path(__file__).resolve().parent
STARTER_DIR = SCRIPT_DIR.parent / "assets" / "astro-static-starter"
IGNORED_NAMES = {"node_modules", "dist", ".astro", ".site-build", ".DS_Store"}
PLACEHOLDER_NAME = "Northstar Works"
PLACEHOLDER_URL = "https://example.invalid"
PLACEHOLDER_EMAIL = "hello@example.invalid"


class ScaffoldError(RuntimeError):
    """Raised when scaffolding cannot proceed safely."""


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Copy the original Astro company-site starter into a new or empty target.",
    )
    parser.add_argument("--target", required=True, help="New or existing empty destination directory.")
    parser.add_argument("--site-name", help="Company or site name to replace the starter brand.")
    parser.add_argument("--site-url", help="Canonical site origin, for example https://www.example.org.")
    parser.add_argument("--language", help="BCP 47 language tag, for example en or zh-CN.")
    parser.add_argument("--contact-email", help="Public contact email address.")
    parser.add_argument(
        "--strict-launch",
        action="store_true",
        help="Refuse to scaffold while placeholder brand, domain, or email values remain.",
    )
    return parser.parse_args()


def normalize_url(value: str) -> str:
    parsed = urlsplit(value.strip())
    if parsed.scheme != "https" or not parsed.hostname:
        raise ScaffoldError("--site-url must be an absolute HTTPS URL with a hostname")
    if parsed.username or parsed.password:
        raise ScaffoldError("--site-url must not contain credentials")
    if parsed.query or parsed.fragment:
        raise ScaffoldError("--site-url must not contain a query string or fragment")
    if parsed.path not in {"", "/"}:
        raise ScaffoldError("--site-url must be an origin without a path")
    hostname = parsed.hostname.lower()
    if hostname in {"localhost", "127.0.0.1", "::1"}:
        raise ScaffoldError("--site-url must be a public canonical origin, not localhost")
    netloc = hostname
    if parsed.port:
        netloc = f"{hostname}:{parsed.port}"
    return urlunsplit((parsed.scheme.lower(), netloc, "", "", ""))


def validate_language(value: str) -> str:
    language = value.strip()
    if not re.fullmatch(r"[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*", language):
        raise ScaffoldError("--language must be a simple BCP 47 tag such as en or zh-CN")
    parts = language.split("-")
    normalized = [parts[0].lower()]
    normalized.extend(part.upper() if len(part) == 2 else part for part in parts[1:])
    return "-".join(normalized)


def validate_email(value: str) -> str:
    email = value.strip()
    if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
        raise ScaffoldError("--contact-email must be a valid email address")
    return email


def npm_slug(value: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return (slug or "company-site")[:80]


def replace_ts_string(text: str, key: str, value: str) -> str:
    pattern = re.compile(rf"(\b{re.escape(key)}\s*:\s*)\"(?:[^\"\\]|\\.)*\"")
    replacement = json.dumps(value, ensure_ascii=False)
    updated, count = pattern.subn(lambda match: f"{match.group(1)}{replacement}", text, count=1)
    if count != 1:
        raise ScaffoldError(f"starter config is missing the expected {key!r} field")
    return updated


def validate_source() -> None:
    if not STARTER_DIR.is_dir():
        raise ScaffoldError(f"starter directory is missing: {STARTER_DIR}")
    for path in STARTER_DIR.rglob("*"):
        relative = path.relative_to(STARTER_DIR)
        if any(part in IGNORED_NAMES for part in relative.parts):
            continue
        if path.is_symlink():
            raise ScaffoldError(f"starter contains a symbolic link and cannot be copied safely: {path}")


def validate_target(raw_target: Path) -> tuple[Path, bool]:
    if raw_target.is_symlink():
        raise ScaffoldError("target must not be a symbolic link")
    target = raw_target.expanduser().resolve(strict=False)
    starter = STARTER_DIR.resolve()
    if target == starter or starter in target.parents:
        raise ScaffoldError("target must not be the bundled starter or a directory inside it")
    if target.exists() and not target.is_dir():
        raise ScaffoldError("target exists and is not a directory")
    if target.exists() and any(target.iterdir()):
        raise ScaffoldError("target directory is not empty; no files were changed")
    return target, target.exists()


def copy_starter(destination: Path) -> None:
    shutil.copytree(
        STARTER_DIR,
        destination,
        ignore=shutil.ignore_patterns(*IGNORED_NAMES),
        copy_function=shutil.copy2,
    )


def customize_starter(
    root: Path,
    *,
    site_name: str,
    site_url: str,
    language: str,
    contact_email: str,
) -> None:
    config_path = root / "src" / "config" / "site.ts"
    config = config_path.read_text(encoding="utf-8")
    config = replace_ts_string(config, "name", site_name)
    config = replace_ts_string(config, "legalName", site_name)
    config = replace_ts_string(config, "language", language)
    locale = "en_US" if language == "en" else language.replace("-", "_")
    config = replace_ts_string(config, "locale", locale)
    config = replace_ts_string(config, "email", contact_email)
    config_path.write_text(config, encoding="utf-8")

    for relative in ("astro.config.mjs", "src/pages/robots.txt.ts"):
        path = root / relative
        text = path.read_text(encoding="utf-8")
        if PLACEHOLDER_URL not in text:
            raise ScaffoldError(f"starter file is missing the expected URL marker: {relative}")
        path.write_text(text.replace(PLACEHOLDER_URL, site_url), encoding="utf-8")

    package_path = root / "package.json"
    package = json.loads(package_path.read_text(encoding="utf-8"))
    package_name = npm_slug(site_name)
    package["name"] = package_name
    package_path.write_text(json.dumps(package, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    lock_path = root / "package-lock.json"
    if lock_path.exists():
        lock = json.loads(lock_path.read_text(encoding="utf-8"))
        lock["name"] = package_name
        if isinstance(lock.get("packages"), dict) and isinstance(lock["packages"].get(""), dict):
            lock["packages"][""]["name"] = package_name
        lock_path.write_text(json.dumps(lock, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    escaped_name = html.escape(site_name, quote=True)
    favicon_path = root / "public" / "favicon.svg"
    favicon = favicon_path.read_text(encoding="utf-8")
    favicon_path.write_text(favicon.replace(PLACEHOLDER_NAME, escaped_name), encoding="utf-8")

    social_path = root / "public" / "social-card.svg"
    social = social_path.read_text(encoding="utf-8")
    social = social.replace(PLACEHOLDER_NAME, escaped_name)
    social = social.replace("NORTHSTAR / WORKS", html.escape(site_name.upper(), quote=True))
    social_path.write_text(social, encoding="utf-8")


def launch_blockers(site_name: str, site_url: str, contact_email: str) -> list[str]:
    blockers: list[str] = []
    if site_name == PLACEHOLDER_NAME:
        blockers.append("Replace the placeholder brand name Northstar Works.")
    hostname = urlsplit(site_url).hostname or ""
    if hostname.endswith(".invalid"):
        blockers.append("Set a real canonical site URL; .invalid domains cannot be launched.")
    if contact_email.endswith("@example.invalid"):
        blockers.append("Set a real public contact email address.")
    return blockers


def main() -> int:
    args = parse_args()
    try:
        validate_source()
        target, target_existed = validate_target(Path(args.target))
        site_name = (args.site_name or PLACEHOLDER_NAME).strip()
        if not site_name:
            raise ScaffoldError("--site-name must not be empty")
        site_url = normalize_url(args.site_url) if args.site_url else PLACEHOLDER_URL
        language = validate_language(args.language) if args.language else "en"
        contact_email = validate_email(args.contact_email) if args.contact_email else PLACEHOLDER_EMAIL
        blockers = launch_blockers(site_name, site_url, contact_email)
        if args.strict_launch and blockers:
            raise ScaffoldError("launch readiness check failed: " + " ".join(blockers))

        target.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix=".astro-company-site-", dir=target.parent) as temp_dir:
            staged = Path(temp_dir) / "site"
            copy_starter(staged)
            customize_starter(
                staged,
                site_name=site_name,
                site_url=site_url,
                language=language,
                contact_email=contact_email,
            )
            if target_existed:
                for child in staged.iterdir():
                    destination = target / child.name
                    if destination.exists():
                        raise ScaffoldError(f"refusing to overwrite target path: {destination}")
                    os.replace(child, destination)
            else:
                os.replace(staged, target)

        result = {
            "schemaVersion": "company-site-scaffold/v1",
            "status": "created",
            "target": str(target),
            "siteName": site_name,
            "siteUrl": site_url,
            "language": language,
            "contactEmail": contact_email,
            "readyForLaunch": not blockers,
            "launchBlockers": blockers,
            "nextCommands": ["npm ci", "npm run build", "npm run dev"],
        }
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (OSError, ValueError, json.JSONDecodeError, ScaffoldError) as exc:
        print(f"scaffold_astro: ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
