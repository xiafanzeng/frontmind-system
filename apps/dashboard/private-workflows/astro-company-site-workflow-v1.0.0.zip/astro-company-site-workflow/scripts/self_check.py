#!/usr/bin/env python3
"""Run portable positive and negative fixtures for every deterministic gate."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys

sys.dont_write_bytecode = True
import tempfile
import zipfile
from pathlib import Path
from typing import Any, Callable, Sequence

import doctor
from compose_21st_query import compose as compose_query
from compose_build_contract import compose_contract
from normalize_21st_result import normalize
from validate_dist_seo import audit as audit_dist
from validate_inputs import (
    InputError,
    load_json,
    make_report,
    output_report,
    resolve_schema,
    scan_secrets,
    sha256_file,
    sha256_text,
    validate_instance,
    write_json,
)
from validate_native_astro import audit as audit_astro


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_NAMES = (
    "doctor.py",
    "validate_inputs.py",
    "compose_21st_query.py",
    "normalize_21st_result.py",
    "compose_build_contract.py",
    "scaffold_astro.py",
    "validate_native_astro.py",
    "validate_dist_seo.py",
    "self_check.py",
)
HASH = "a" * 64


def _brief() -> dict[str, Any]:
    return {
        "schema_version": "company-brief/v2",
        "company": {"name": "Acme", "sector": "工业自动化", "business_model": "B2B", "summary": "Verified automation services."},
        "site": {"scope": "company marketing site", "canonical_origin": None, "default_locale": "en", "locales": ["en"], "host_policy": "unresolved", "trailing_slash": "always", "social_image": None},
        "audiences": ["operations leaders"],
        "primary_conversion": {"goal": "request a consultation", "cta_label": "Talk to us", "destination": "/contact/"},
        "offerings": [{"name": "自动化集成", "description": "Integration based on verified requirements.", "fact_ids": ["f1"]}],
        "pages": [{"path": "/", "title": "Acme Automation", "purpose": "介绍能力并转化咨询", "locale": "en", "indexable": True, "sections": ["Hero", "Capabilities"]}],
        "visual_direction": {"tone": ["precise"], "colors": [], "fonts": [], "business_context_en": ["industrial automation", "operations consulting"], "logo_path_or_url": None, "must_avoid": ["generic card wall"]},
        "assets": [{"asset_id": "ref-1", "role": "visual_reference", "location": "reference://board-1", "ownership": "unknown", "license": None, "description": "Style observation only; never a production asset."}],
        "visual_references": [{"reference_id": "reference-1", "location": "reference://board-1", "asset_id": "ref-1", "influence_dimensions": ["structure", "surface", "motion"], "notes": "Style only."}],
        "verified_facts": [{"id": "f1", "claim": "Acme provides automation integration.", "source": "user brief", "source_url": None, "last_verified": "2026-08-22"}],
        "unknowns": ["Production domain is not selected."],
        "constraints": ["Native Astro static output."],
        "source_urls": [],
    }


def _observation(brief_hash: str) -> dict[str, Any]:
    return {
        "schema_version": "visual-observation/v1",
        "brief_sha256": brief_hash,
        "assets": [{
            "asset_id": "ref-1",
            "role": "visual_reference",
            "location": "reference://board-1",
            "ownership": "unknown",
            "license": None,
            "influence_dimensions": ["structure", "surface", "motion"],
            "search_terms_en": ["asymmetric editorial grid", "soft luminous surfaces", "measured parallax reveal"],
            "observation": {
                "structure": "Asymmetric editorial grid with one dominant proof rail.",
                "typography": "Condensed display headings with readable sans-serif body copy.",
                "surface": "Soft luminous panels with thin technical dividers.",
                "color": "Near-black canvas with a restrained electric-cyan signal.",
                "imagery": "Macro industrial details with wide negative space.",
                "motion": "Measured masked reveals and short parallax transitions.",
                "tone": "Precise, confident, and calm.",
            },
            "evidence": [{"kind": "visible-detail", "reference": "reference://board-1#frame"}],
        }],
    }


def _score() -> dict[str, int]:
    return {"reference_style": 30, "business_function": 25, "distinctiveness": 20, "owned_asset_feasibility": 10, "responsive_accessibility": 10, "native_astro_translatability": 5}


def _get_component_detail(item_id: str, response: dict[str, Any], *, tool_name: bool = False) -> dict[str, Any]:
    """Portable proof that a response came from a per-item get_component call."""

    identity = {"toolName": "mcp__21st__get_component"} if tool_name else {"operation": "get_component"}
    return {
        **identity,
        "requestedProviderItemId": item_id,
        "response": {"componentId": item_id, **response},
    }


def _selection(brief_hash: str, observation_hash: str, prompt_hash: str) -> dict[str, Any]:
    candidate = {
        "candidate_id": "21st-foundation",
        "provider_item_id": "foundation",
        "query_role": "foundation",
        "search_rank": 1,
        "title": "Industrial editorial foundation",
        "author": "fixture-author",
        "source_url": "https://21st.dev/catalog/foundation",
        "preview_url": "https://21st.dev/preview/foundation.png",
        "dependencies": [],
        "license_note": "Prompt-only visual reference; provider code and demo assets are not reused.",
        "retrieval_status": "prompt-retrieved",
        "retrieval_operation": "get_component",
        "retrieval_response_sha256": "b" * 64,
        "prompt_sha256": prompt_hash,
        "normalized_directives": ["structure:asymmetric-grid", "typography:condensed-technical", "motion:reduced-motion-required"],
        "code_ignored": True,
    }
    return {
        "schema_version": "visual-selection/v1",
        "stage": "selected-degraded",
        "board_ready": True,
        "brief_sha256": brief_hash,
        "reference_observation_sha256": observation_hash,
        "provider": "21st",
        "source": "mcp",
        "targets": {"search": 18, "retrieve": 12, "present": 9},
        "actual": {"searched": 1, "prompt_retrieved": 1, "presented": 1},
        "searched_candidates": [candidate],
        "retrieval_shortlist": ["21st-foundation"],
        "presented_candidates": [{
            "candidate_id": "21st-foundation",
            "option_label": "A",
            "presentation_rank": 1,
            "fit_reason": "The strongest verified match for the reference structure and enterprise conversion job.",
            "score": 100,
            "score_breakdown": _score(),
            "rationale": "Best evidence-backed fit among all valid results.",
            "visual_axes": {
                "structure": "Asymmetric proof-led grid.",
                "typography": "Condensed display with neutral sans body.",
                "surface": "Luminous technical panels.",
                "color": "Dark canvas with cyan signal color.",
                "imagery": "Owned industrial macro imagery.",
                "motion": "Masked reveal and measured parallax.",
                "tone": "Precise and assured.",
            },
        }],
        "selected": {"candidate_id": "21st-foundation", "option_label": "A", "provider_item_id": "foundation", "query_role": "foundation", "source_url": "https://21st.dev/catalog/foundation", "prompt_sha256": prompt_hash, "normalized_directives": candidate["normalized_directives"], "rationale": "Best valid foundation.", "selection_evidence": "user_choice"},
        "supporting_sources": [],
        "errors": [
            {"code": "SEARCH_RESULTS_INSUFFICIENT", "message": "Only one eligible catalog item was available.", "candidate_id": None},
            {"code": "RETRIEVAL_RESULTS_INSUFFICIENT", "message": "Only one independent Prompt-bearing retrieval was available.", "candidate_id": None},
            {"code": "PRESENTATION_RESULTS_INSUFFICIENT", "message": "Only one real preview could be presented.", "candidate_id": None}
        ],
        "generate_used": False,
        "provider_code_reuse": False,
    }


def _seo(origin: str | None = None) -> dict[str, Any]:
    ready = origin is not None
    canonical = f"{origin}/" if origin else None
    return {
        "schema_version": "seo-manifest/v1",
        "launch_ready": ready,
        "launch_blockers": [] if ready else ["Production canonical origin is unresolved."],
        "canonical_origin": origin,
        "host_policy": "apex" if ready else "unresolved",
        "trailing_slash": "always",
        "default_locale": "en",
        "entity": {"organization_id": f"{origin}/#organization" if ready else None, "website_id": f"{origin}/#website" if ready else None, "name": "Acme", "legal_name": None, "type": "Organization", "url": canonical, "logo": None, "same_as": [], "contact": []},
        "routes": [{"path": "/", "locale": "en", "indexable": True, "title": "Acme Automation", "description": "Verified industrial automation integration services.", "canonical": canonical, "social_image": f"{origin}/social.png" if ready else None, "alternates": [], "schema_types": ["Organization", "WebSite"], "lastmod": "2026-08-22"}],
        "crawler_policy": {"public_search": "allow", "ai_search": "unset", "model_training": "unset", "user_fetch": "unset", "official_sources": [], "checked_at": None},
        "experimental": {"llms_txt": False, "markdown_alternates": False, "notes": ["llms.txt is not a Google ranking or AI visibility requirement."]},
    }


def _design_system() -> dict[str, Any]:
    return {
        "style_profile": {
            "structure": "Asymmetric two-track editorial grid with a proof rail.",
            "typography": "Condensed display face paired with a neutral readable sans-serif.",
            "surface": "Near-black panels with thin luminous technical dividers.",
            "color": "Graphite canvas, warm white text, and one electric-cyan signal.",
            "imagery": "Owned industrial macro photography with controlled wide crops.",
            "motion": "Short masked reveals with restrained depth and no looping ornament.",
            "tone": "Precise, calm, technically confident, and commercially direct.",
        },
        "design_tokens": {
            "colors": {"canvas": "#090d12", "ink": "#f4f7fa", "signal": "#35d7ff"},
            "typography": {"display": "Arial Narrow, sans-serif", "body": "Inter, sans-serif", "measure": "64ch"},
            "spacing": {"unit": "0.5rem", "gutter": "clamp(1rem, 3vw, 3rem)", "section": "clamp(5rem, 10vw, 10rem)"},
            "radii": {"panel": "0.25rem"},
            "shadows": {"signal": "0 0 32px rgb(53 215 255 / 0.18)"},
        },
        "layout_grammar": ["Use a 5/7 asymmetric desktop grid anchored by a persistent proof rail.", "Let one full-bleed industrial crop interrupt the grid after the capability proof.", "On small screens, preserve order as proposition, evidence, capability, and conversion."],
        "imagery_plan": ["Use only user-owned or separately licensed production images, never preview media.", "Hero image uses a 16:10 macro crop with the mechanical focal point at 68% inline.", "Capability images use fixed 4:3 crops with explicit dimensions and factual alt text."],
        "motion": {"principles": ["Reveal proof labels through a 180ms vertical mask after their section enters.", "Use a single 6px depth shift on hero media and never scroll-hijack."], "reduced_motion": "Render every element immediately with transforms and smooth scrolling disabled."},
        "responsive_rules": [{"viewport": 390, "rule": "Stack the proof rail below the proposition and keep every control at least 44px."}, {"viewport": 768, "rule": "Use a 4/8 grid while keeping evidence adjacent to the claim it supports."}, {"viewport": 1440, "rule": "Use the full 5/7 composition and cap body copy at a 64-character measure."}],
        "component_adaptation": ["Compile the foundation direction into original Astro structure and project-owned CSS tokens.", "Apply any section source only to its declared page and section without changing global tokens."],
    }


def _record(checks: list[dict[str, Any]], code: str, passed: bool, message: str) -> None:
    checks.append({"code": code, "status": "pass" if passed else "fail", "message": message})


def run(root: Path) -> dict[str, Any]:
    checks: list[dict[str, Any]] = []
    schema_names = ("company-brief", "visual-observation", "visual-selection", "build-contract", "seo-manifest", "provenance", "qa-report")
    with tempfile.TemporaryDirectory(prefix="astro-company-site-self-check-") as raw_temp:
        temp = Path(raw_temp)
        brief_path = temp / "brief.json"
        write_json(brief_path, _brief())
        brief_hash = sha256_file(brief_path)
        observation = _observation(brief_hash)
        observation_path = temp / "observation.json"
        write_json(observation_path, observation)
        prompt_text = "Use an asymmetric layout grid with condensed typography, luminous surfaces, industrial imagery, and restrained motion."
        prompt_path = temp / "foundation-prompt.txt"
        prompt_path.write_text(prompt_text, encoding="utf-8")
        observation_hash = sha256_file(observation_path)
        selection = _selection(brief_hash, observation_hash, sha256_text(prompt_text))
        selection_path = temp / "selection.json"
        write_json(selection_path, selection)
        seo = _seo()
        seo_path = temp / "seo.json"
        write_json(seo_path, seo)
        design = _design_system()
        design_path = temp / "design-system.json"
        write_json(design_path, design)
        contract = compose_contract(
            _brief(),
            selection,
            seo,
            design,
            {"company_brief_sha256": brief_hash, "visual_observation_sha256": observation_hash, "visual_selection_sha256": sha256_file(selection_path), "seo_manifest_sha256": sha256_file(seo_path), "design_system_sha256": sha256_file(design_path)},
        )
        positive: dict[str, Any] = {
            "company-brief": _brief(),
            "visual-observation": observation,
            "visual-selection": selection,
            "build-contract": contract,
            "seo-manifest": seo,
            "provenance": {"schema_version": "provenance/v1", "workflow_version": "1.0.0", "visual_selection_sha256": sha256_file(selection_path), "provider_code_reuse": False, "generate_used": False, "sources": [{"role": "foundation", "candidate_id": "21st-foundation", "provider": "21st", "item_id": "foundation", "source_url": "https://21st.dev/catalog/foundation", "retrieval_method": "mcp", "prompt_sha256": sha256_text(prompt_text), "license_status": "not-applicable-prompt-only", "license": None, "version_or_commit": None, "payload_sha256": "b" * 64, "notes": ["Prompt direction only; provider code ignored."]}], "assets": []},
            "qa-report": make_report("self-check", [{"code": "FIXTURE", "status": "pass", "message": "fixture"}]),
        }
        for name in schema_names:
            schema = load_json(resolve_schema(name), f"{name} schema")
            issues = validate_instance(positive[name], schema)
            _record(checks, "SCHEMA_POSITIVE", not issues, f"{name} positive fixture {'passed' if not issues else 'failed: ' + str(issues[0])}")

        provenance_path = temp / "provenance.json"
        write_json(provenance_path, positive["provenance"])
        provenance_command = [sys.executable, "-B", str(root / "scripts" / "validate_inputs.py"), "--schema", "provenance", "--input", str(provenance_path), "--selection", str(selection_path)]
        provenance_valid = subprocess.run(provenance_command, text=True, capture_output=True, check=False, timeout=20)
        _record(checks, "PROVENANCE_SELECTION_BINDING", provenance_valid.returncode == 0, "provenance validation binds the exact workflow version and selected 21st Foundation evidence")
        provenance_without_selection = subprocess.run(provenance_command[:-2], text=True, capture_output=True, check=False, timeout=20)
        _record(checks, "PROVENANCE_SELECTION_REQUIRED", provenance_without_selection.returncode != 0 and "PROVENANCE_SELECTION_REQUIRED" in provenance_without_selection.stdout, "provenance cannot validate without the exact final visual-selection input")
        wrong_version = json.loads(json.dumps(positive["provenance"]))
        wrong_version["workflow_version"] = "9.9.9"
        write_json(provenance_path, wrong_version)
        wrong_version_result = subprocess.run(provenance_command, text=True, capture_output=True, check=False, timeout=20)
        _record(checks, "PROVENANCE_VERSION_REJECTED", wrong_version_result.returncode != 0, "provenance workflow_version must exactly match the packaged VERSION")
        arbitrary_source = json.loads(json.dumps(positive["provenance"]))
        arbitrary_source["sources"][0]["provider"] = "internal"
        write_json(provenance_path, arbitrary_source)
        arbitrary_result = subprocess.run(provenance_command, text=True, capture_output=True, check=False, timeout=20)
        _record(checks, "PROVENANCE_ARBITRARY_SOURCE_REJECTED", arbitrary_result.returncode != 0, "an arbitrary non-21st source cannot impersonate the selected Foundation")
        null_prompt = json.loads(json.dumps(positive["provenance"]))
        null_prompt["sources"][0]["prompt_sha256"] = None
        write_json(provenance_path, null_prompt)
        null_prompt_result = subprocess.run(provenance_command, text=True, capture_output=True, check=False, timeout=20)
        _record(checks, "PROVENANCE_PROMPT_HASH_REQUIRED", null_prompt_result.returncode != 0, "the selected Foundation provenance requires a non-null Prompt hash")
        write_json(provenance_path, positive["provenance"])

        raw_prompt = json.loads(json.dumps(selection))
        raw_prompt["selected"]["prompt"] = prompt_text
        raw_issues = validate_instance(raw_prompt, load_json(resolve_schema("visual-selection")))
        _record(checks, "RAW_PROMPT_NEGATIVE", any(item["code"] in {"RAW_PROMPT_PERSISTED", "ADDITIONAL_PROPERTY"} for item in raw_issues), "visual-selection rejects persisted raw Prompt text")
        bad_score = json.loads(json.dumps(selection))
        bad_score["presented_candidates"][0]["score"] = 99
        score_issues = validate_instance(bad_score, load_json(resolve_schema("visual-selection")))
        _record(checks, "SCORE_SUM_NEGATIVE", any(item["code"] == "SCORE_SUM_MISMATCH" for item in score_issues), "score must equal all six bounded dimensions")
        bad_seo = _seo()
        bad_seo["launch_blockers"] = []
        seo_issues = validate_instance(bad_seo, load_json(resolve_schema("seo-manifest")))
        _record(checks, "SEO_BLOCKER_NEGATIVE", any(item["code"] == "LAUNCH_BLOCKER_REQUIRED" for item in seo_issues), "unresolved canonical origin requires an explicit launch blocker")

        query = compose_query(_brief(), observation)
        _record(checks, "QUERY_REFERENCE_TERMS", all(term in " ".join(query["queries"]) for term in ("asymmetric editorial grid", "soft luminous surfaces", "measured parallax reveal")), "Foundation/Section/Motion queries carry concrete reference phrases")
        _record(checks, "QUERY_NATURAL_NEGATIVE", "avoid generic card wall" in " ".join(query["queries"]), "anti-pattern is expressed as a natural-language avoidance phrase")
        chinese_without_context = _brief()
        chinese_without_context["visual_direction"].pop("business_context_en")
        rejected = False
        try:
            compose_query(chinese_without_context, observation)
        except InputError as error:
            rejected = "ENGLISH_BUSINESS_CONTEXT_REQUIRED" in str(error)
        _record(checks, "ENGLISH_CONTEXT_NEGATIVE", rejected, "non-English business context cannot silently degrade into a generic query")
        sensitive_context = _brief()
        outbound_secret = "21" + "st_sk_" + ("Q" * 24)
        sensitive_context["visual_direction"]["business_context_en"] = [outbound_secret]
        sensitive_rejected = False
        sensitive_message = ""
        try:
            compose_query(sensitive_context, observation)
        except InputError as error:
            sensitive_message = str(error)
            sensitive_rejected = "SENSITIVE_CONTEXT_REJECTED" in sensitive_message
        _record(checks, "QUERY_SECRET_GATE", sensitive_rejected and outbound_secret not in sensitive_message, "credential-like company context is blocked before outbound query composition without echoing the value")
        unauthorized_observation = json.loads(json.dumps(observation))
        unauthorized_observation["assets"].append({
            **unauthorized_observation["assets"][0],
            "asset_id": "unapproved-reference",
            "location": "reference://unapproved",
            "search_terms_en": ["unapproved visual term", "unapproved surface term", "unapproved motion term"],
        })
        observation_blocked = False
        try:
            compose_query(_brief(), unauthorized_observation)
        except InputError as error:
            observation_blocked = "OBSERVATION_ASSET_UNAUTHORIZED" in str(error)
        _record(checks, "OBSERVATION_AUTHORIZATION_GATE", observation_blocked, "visual observations cannot add assets or search influence absent from the exact company brief")

        search = []
        details = []
        for index in range(18):
            item_id = f"item-{index + 1}"
            query_role = "foundation" if index < 12 else ("section" if index < 16 else "motion")
            search.append({"id": item_id, "query_role": query_role, "title": item_id, "url": f"https://21st.dev/{item_id}", "preview_url": f"https://21st.dev/{item_id}.png"})
            detail_response: dict[str, Any] = {}
            if index not in {0, 1, 4}:
                detail_response["prompt"] = f"Use a responsive asymmetric grid, restrained typography, and controlled reveal for catalog direction {index + 1}."
            details.append(_get_component_detail(item_id, detail_response))
        normalized = normalize({"search_results": search, "retrieved_results": details}, "mcp", brief_hash, observation_hash)
        persisted = json.dumps(normalized, sort_keys=True)
        _record(checks, "RETRIEVAL_CONTINUES", normalized["actual"]["prompt_retrieved"] == 12, "retrieval continues past missing prompts until 12 successes across the 18-result pool")
        raw_runtime_prompts = [item["response"].get("prompt") for item in details if item["response"].get("prompt")]
        _record(checks, "NORMALIZER_PROMPT_FREE", all(value not in persisted for value in raw_runtime_prompts) and '"prompt"' not in persisted, "normalizer persists fixed taxonomy and hashes but no raw Prompt key or source sentence")

        full_selected = json.loads(json.dumps(normalized))
        full_selected["stage"] = "selected"
        full_selected["board_ready"] = True
        candidate_by_id = {item["candidate_id"]: item for item in full_selected["searched_candidates"]}
        diversity = (
            ("Asymmetric editorial grid.", "Hairline technical surface.", "Condensed technical display."),
            ("Split proof-led grid.", "Soft layered surface.", "Neutral sans hierarchy."),
            ("Modular hero-led grid.", "Flat high-contrast surface.", "Serif editorial display."),
        )
        for index, item in enumerate(full_selected["presented_candidates"]):
            structure, surface, typography = diversity[index % len(diversity)]
            item.update({
                "fit_reason": "Verified business, reference, and conversion fit.",
                "score": 100,
                "score_breakdown": _score(),
                "rationale": "Selected for a distinct, implementable native-Astro visual mechanism.",
                "visual_axes": {
                    "structure": structure,
                    "typography": typography,
                    "surface": surface,
                    "color": f"Controlled single-accent palette {index + 1}.",
                    "imagery": f"Owned industrial imagery crop {index + 1}.",
                    "motion": f"Bounded reveal behavior {index + 1}.",
                    "tone": f"Precise enterprise tone {index + 1}.",
                },
            })
        first_presented = full_selected["presented_candidates"][0]
        first_candidate = candidate_by_id[first_presented["candidate_id"]]
        full_selected["selected"] = {
            "candidate_id": first_candidate["candidate_id"],
            "option_label": first_presented["option_label"],
            "provider_item_id": first_candidate["provider_item_id"],
            "query_role": "foundation",
            "source_url": first_candidate["source_url"],
            "prompt_sha256": first_candidate["prompt_sha256"],
            "normalized_directives": first_candidate["normalized_directives"],
            "rationale": "User selected option A from the complete comparison board.",
            "selection_evidence": "user_choice",
        }
        selection_schema = load_json(resolve_schema("visual-selection"))
        full_selection_issues = validate_instance(full_selected, selection_schema)
        _record(checks, "FULL_FUNNEL_REJECTIONS_NONBLOCKING", not full_selection_issues, "a complete 18/12/9 selection may retain truthful item-level MCP rejections after later candidates fill the funnel")
        false_degraded = json.loads(json.dumps(full_selected))
        false_degraded["stage"] = "selected-degraded"
        false_degraded_issues = validate_instance(false_degraded, selection_schema)
        _record(checks, "FALSE_DEGRADED_REJECTED", any(item["code"] == "DEGRADED_WITHOUT_SHORTFALL" for item in false_degraded_issues), "selected-degraded is rejected when all 18/12/9 targets were met")
        blocking_selection = json.loads(json.dumps(full_selected))
        blocking_selection["errors"].append({"code": "GENERATE_FORBIDDEN", "message": "fixture", "candidate_id": None})
        blocking_issues = validate_instance(blocking_selection, selection_schema)
        _record(checks, "BLOCKING_SELECTION_ERROR", any(item["code"] == "BLOCKING_PROVIDER_ERROR" for item in blocking_issues), "generation and provider-level failures remain blocking even when the board is full")

        system_prompt_only = normalize({"search_results": [{"id": "sys-1", "query_role": "foundation", "source_url": "https://21st.dev/sys-1", "preview_url": "https://21st.dev/sys-1.png"}], "retrieved_results": [_get_component_detail("sys-1", {"systemPrompt": "Use a grid."})]}, "mcp", brief_hash, observation_hash)
        _record(checks, "SYSTEM_PROMPT_REJECTED", system_prompt_only["actual"]["prompt_retrieved"] == 0 and any(item["code"] == "MCP_PROMPT_MISSING" for item in system_prompt_only["errors"]), "systemPrompt cannot satisfy the provider Prompt contract")
        search_prompt_only = normalize({"search_results": [{"id": "search-1", "query_role": "foundation", "source_url": "https://21st.dev/search-1", "preview_url": "https://21st.dev/search-1.png", "prompt": "Use a grid."}]}, "mcp", brief_hash, observation_hash)
        _record(checks, "GET_COMPONENT_REQUIRED", search_prompt_only["actual"]["prompt_retrieved"] == 0 and any(item["code"] == "GET_COMPONENT_RESULT_MISSING" for item in search_prompt_only["errors"]), "search metadata cannot impersonate an independent get_component retrieval")
        fake_search_detail = normalize({
            "search_results": [{"id": "fake-1", "query_role": "foundation", "source_url": "https://21st.dev/fake-1", "preview_url": "https://21st.dev/fake-1.png"}],
            "retrieved_results": [{
                "operation": "search",
                "requested_provider_item_id": "fake-1",
                "response": {"id": "fake-1", "prompt": "Use an asymmetric editorial grid."},
            }],
        }, "mcp", brief_hash, observation_hash)
        _record(
            checks,
            "GET_COMPONENT_CALL_EVIDENCE_NEGATIVE",
            fake_search_detail["actual"]["prompt_retrieved"] == 0
            and any(item["code"] == "GET_COMPONENT_CALL_EVIDENCE_INVALID" for item in fake_search_detail["errors"]),
            "a search-operation envelope with a matching ID and Prompt cannot impersonate a get_component call",
        )
        code_rich_prompt = "Use an asymmetric responsive grid and controlled reveal. Implement with React, Tailwind, npm install, and a TSX code block."
        code_rich = normalize({"search_results": [{"id": "code-1", "query_role": "foundation", "source_url": "https://21st.dev/code-1", "preview_url": "https://21st.dev/code-1.png"}], "retrieved_results": [_get_component_detail("code-1", {"prompt": code_rich_prompt})]}, "mcp", brief_hash, observation_hash)
        _record(checks, "IMPLEMENTATION_HINTS_FILTERED", code_rich["actual"]["prompt_retrieved"] == 1 and code_rich_prompt not in json.dumps(code_rich) and all(value in candidate_by_id[first_candidate["candidate_id"]]["normalized_directives"] or ":" in value for value in code_rich["searched_candidates"][0]["normalized_directives"]), "React/Tailwind/install hints are ignored while safe visual taxonomy remains usable")
        credential_prompt = (
            "Use a grid with Authorization: "
            + "Bearer "
            + "eyJhbGciOiJIUzI1NiJ9."
            + "payloadvalue.signaturevalue"
        )
        credential_result = normalize({"search_results": [{"id": "secret-1", "query_role": "foundation", "source_url": "https://21st.dev/secret-1", "preview_url": "https://21st.dev/secret-1.png"}], "retrieved_results": [_get_component_detail("secret-1", {"prompt": credential_prompt})]}, "mcp", brief_hash, observation_hash)
        credential_serialized = json.dumps(credential_result)
        _record(checks, "PROMPT_CREDENTIAL_BLOCKED", credential_prompt not in credential_serialized and "payloadvalue" not in credential_serialized and any(item["code"] == "PROMPT_UNSAFE_CONTENT" for item in credential_result["errors"]), "credential-bearing Prompt text is rejected without persistence")
        credential_url = "https://21st.dev/url-1?access_token=" + ("U" * 20)
        signed_url = normalize({"search_results": [{"id": "url-1", "query_role": "foundation", "source_url": credential_url, "preview_url": "https://21st.dev/url-1.png"}], "retrieved_results": [_get_component_detail("url-1", {"prompt": "Use an asymmetric grid."})]}, "mcp", brief_hash, observation_hash)
        _record(checks, "CREDENTIAL_URL_REJECTED", not signed_url["searched_candidates"] and any(item["code"] == "SOURCE_URL_MISSING" for item in signed_url["errors"]), "credential-bearing provider URLs are rejected before persistence")
        disguised_secret = "21st" + "_sk_" + ("D" * 20)
        disguised_url = "https://21st.dev/url-2?preview=" + disguised_secret
        disguised_result = normalize({"search_results": [{"id": "url-2", "query_role": "foundation", "source_url": disguised_url, "preview_url": "https://21st.dev/url-2.png"}], "retrieved_results": [_get_component_detail("url-2", {"prompt": "Use an asymmetric grid."})]}, "mcp", brief_hash, observation_hash)
        disguised_serialized = json.dumps(disguised_result)
        _record(checks, "CREDENTIAL_URL_VALUE_REJECTED", not disguised_result["searched_candidates"] and disguised_secret not in disguised_serialized and any(item["code"] == "SOURCE_URL_MISSING" for item in disguised_result["errors"]), "credential signatures are rejected even when hidden under a non-sensitive URL parameter name")
        foreign_source = normalize({"search_results": [{"id": "foreign-1", "query_role": "foundation", "source_url": "https://example.com/foreign-1", "preview_url": "https://media.example/foreign-1.png"}], "retrieved_results": [_get_component_detail("foreign-1", {"prompt": "Use an asymmetric grid."})]}, "mcp", brief_hash, observation_hash)
        _record(checks, "PROVIDER_SOURCE_HOST_REJECTED", not foreign_source["searched_candidates"] and any(item["code"] == "SOURCE_URL_MISSING" for item in foreign_source["errors"]), "provider source provenance must resolve to 21st.dev or a subdomain while preview media may remain external")
        camel_case_runtime = {
            "searchResults": [
                {
                    "componentId": f"camel-{index + 1}",
                    "queryRole": "foundation" if index < 12 else "section",
                    "title": f"Camel item {index + 1}",
                    "sourceUrl": f"https://21st.dev/camel-{index + 1}",
                    "previewUrl": f"https://21st.dev/camel-{index + 1}.png",
                }
                for index in range(18)
            ],
            "getComponentResults": [
                _get_component_detail(
                    f"camel-{index + 1}",
                    {"copyPrompt": f"Use a responsive grid, precise typography, and restrained motion for option {index + 1}."},
                    tool_name=True,
                )
                for index in range(12)
            ],
        }
        camel_normalized = normalize(camel_case_runtime, "mcp", brief_hash, observation_hash)
        _record(
            checks,
            "CAMEL_CASE_RUNTIME_FIELDS",
            camel_normalized["actual"] == {"searched": 18, "prompt_retrieved": 12, "presented": 9},
            "normalizer accepts common camelCase item IDs, URLs, result containers, and copyPrompt fields",
        )
        cli_missing = normalize({"search_results": [{"id": "only", "query_role": "foundation", "source_url": "https://21st.dev/only", "preview_url": "https://21st.dev/only.png"}], "retrieved_results": [_get_component_detail("only", {"code": "demo"})]}, "cli", brief_hash, observation_hash)
        _record(checks, "CLI_PROMPT_MISSING_EXACT", any(item["code"] == "CLI_PROMPT_MISSING" for item in cli_missing["errors"]), "CLI code/demo-only payload fails with CLI_PROMPT_MISSING")

        secret = "21" + "st_sk_" + ("X" * 16)
        workflow_fixture = temp / "workflow-fixture"
        project_fixture = temp / "project-fixture"
        workflow_fixture.mkdir()
        project_fixture.mkdir()
        (workflow_fixture / "notes.md").write_text(f"token={secret}\n", encoding="utf-8")
        (project_fixture / ".env").write_text(f"KEY={secret}\n", encoding="utf-8")
        workflow_findings = scan_secrets([workflow_fixture / "notes.md"])
        project_findings = scan_secrets([project_fixture / ".env"])
        zip_path = temp / "secret-fixture.zip"
        with zipfile.ZipFile(zip_path, "w") as archive:
            archive.writestr("config.txt", f"KEY={secret}\n")
        zip_findings, zip_checks = doctor._zip_secret_findings(zip_path)
        combined_findings = workflow_findings + project_findings + zip_findings
        serialized_findings = json.dumps(combined_findings)
        _record(checks, "SECRET_SCAN_SURFACES", len(workflow_findings) == len(project_findings) == len(zip_findings) == 1 and not zip_checks, "workflow, project, and ZIP fixtures each detect the 21st secret pattern")
        _record(checks, "SECRET_SCAN_REDACTED", secret not in serialized_findings and all("redacted" in item["message"] for item in combined_findings), "secret reports are redacted and never echo the credential")
        snapshot_root = temp / "workflow-snapshot"
        snapshot_root.mkdir()
        snapshot_payloads = {"VERSION": "1.0.0\n", "SKILL.md": "ok\n"}
        for relative, payload in snapshot_payloads.items():
            (snapshot_root / relative).write_text(payload, encoding="utf-8")
        snapshot_manifest = {
            **doctor.EXPECTED_MANIFEST_FIELDS,
            "version": "1.0.0",
            "runtime_contract": doctor.EXPECTED_MANIFEST_RUNTIME_CONTRACT,
            "files": [
                {"path": relative, "bytes": len(payload.encode("utf-8")), "sha256": sha256_text(payload)}
                for relative, payload in sorted(snapshot_payloads.items())
            ],
        }
        write_json(snapshot_root / "MANIFEST.json", snapshot_manifest)
        snapshot_zip = temp / "workflow-snapshot.zip"
        with zipfile.ZipFile(snapshot_zip, "w") as archive:
            for path in sorted(snapshot_root.iterdir()):
                archive.writestr("astro-company-site-workflow/" + path.name, path.read_bytes())
        snapshot_findings, snapshot_checks = doctor._zip_secret_findings(snapshot_zip, snapshot_root)
        _record(checks, "ZIP_WORKFLOW_INTEGRITY_POSITIVE", not snapshot_findings and snapshot_checks and all(item["status"] == "pass" for item in snapshot_checks), "workflow ZIP validates its single root, manifest, hashes, and exact --root snapshot")
        tampered_zip = temp / "workflow-snapshot-tampered.zip"
        with zipfile.ZipFile(tampered_zip, "w") as archive:
            archive.writestr("astro-company-site-workflow/VERSION", (snapshot_root / "VERSION").read_bytes())
            archive.writestr("astro-company-site-workflow/SKILL.md", b"no\n")
            archive.writestr("astro-company-site-workflow/MANIFEST.json", (snapshot_root / "MANIFEST.json").read_bytes())
        _, tampered_checks = doctor._zip_secret_findings(tampered_zip, snapshot_root)
        _record(checks, "ZIP_SAME_SIZE_TAMPER_REJECTED", any(item["code"] == "ZIP_WORKFLOW_SHA256_MATCH" and item["status"] == "fail" for item in tampered_checks) and any(item["code"] == "ZIP_ROOT_SNAPSHOT_MATCH" and item["status"] == "fail" for item in tampered_checks), "same-size ZIP tampering fails both manifest SHA and exact --root snapshot checks")
        credential_matrix = temp / "credential-matrix.txt"
        named_value = "plain" + ("N" * 24)
        bearer_value = "bearer" + ("B" * 24)
        jwt_value = "eyJ" + ("A" * 12) + "." + ("P" * 12) + "." + ("S" * 12)
        query_value = "query" + ("T" * 24)
        credential_matrix.write_text(
            "API_KEY_21ST=" + named_value + "\n"
            "Authorization: Bearer " + bearer_value + "\n"
            + jwt_value + "\n"
            "https://example.test/preview?access_token=" + query_value + "\n",
            encoding="utf-8",
        )
        matrix_findings = scan_secrets([credential_matrix])
        matrix_serialized = json.dumps(matrix_findings)
        matrix_codes = {item["code"] for item in matrix_findings}
        _record(checks, "SECRET_PATTERN_MATRIX", {"TWENTY_FIRST_ENV_VALUE", "AUTHORIZATION_BEARER", "JWT_TOKEN", "CREDENTIAL_QUERY_PARAMETER"}.issubset(matrix_codes), "named 21st credentials, Bearer values, JWTs, and credential query parameters are detected")
        _record(checks, "SECRET_MATRIX_REDACTED", all(value not in matrix_serialized for value in (named_value, bearer_value, jwt_value, query_value)), "expanded secret diagnostics never echo detected values")
        structured_secret = "structured" + ("S" * 20)
        structured_matrix = (
            '{"Authorization":"Bearer ' + structured_secret + '"}\n'
            "authorization = 'Bearer " + structured_secret + "'\n"
            "https://example.test/?client_secret=" + structured_secret
            + "&credential=" + structured_secret
            + "&signature=" + structured_secret
            + "&jwt=" + structured_secret
        )
        structured_findings = doctor._scan_text_secrets(structured_matrix, "structured-credential-fixture")
        structured_serialized = json.dumps(structured_findings)
        _record(checks, "STRUCTURED_BEARER_AND_QUERY_KEYS", any(item["code"] == "AUTHORIZATION_BEARER_SECRET" for item in structured_findings) and sum(item["code"] == "CREDENTIAL_QUERY_VALUE" for item in structured_findings) >= 4, "quoted JSON/TOML Bearer values and client_secret/credential/signature/jwt query values are detected")
        _record(checks, "STRUCTURED_SECRET_REDACTED", structured_secret not in structured_serialized and all("redacted" in item["message"] for item in structured_findings), "structured credential diagnostics remain redacted")
        placeholder_file = temp / "placeholder.txt"
        placeholder_file.write_text("x-api-key: ${API_KEY_21ST}\n", encoding="utf-8")
        _record(checks, "SECRET_PLACEHOLDER_ALLOWED", not scan_secrets([placeholder_file]), "host-level environment placeholders are not mistaken for literal secrets")

        mcp_probe = temp / "mcp-probe.json"
        cli_probe = temp / "cli-probe.json"
        write_json(mcp_probe, {
            "schema_version": "21st-mcp-probe/v1",
            "capabilities": ["search", "get_component"],
            "calls": [{
                "operation": "get_component",
                "request": {"item_id": "probe-1"},
                "response": {"item_id": "probe-1", "copy_prompt": "Use an asymmetric responsive grid."},
            }],
        })
        write_json(cli_probe, {"code": "demo only"})
        mcp_report = doctor.audit(root, [], mcp_probe, None, True, False)
        _record(checks, "MCP_PROMPT_GATE_POSITIVE", mcp_report["passed"] and any(item["code"] == "MCP_PROMPT_AVAILABLE" for item in mcp_report["checks"]), "native MCP search/get_component with copy_prompt satisfies the provider gate")
        write_json(mcp_probe, {
            "schema_version": "21st-mcp-probe/v1",
            "capabilities": ["search", "get_component"],
            "calls": [{
                "operation": "search",
                "request": {"query": "industrial site"},
                "response": {"results": [{"item_id": "search-1", "prompt": "Must not count."}]},
            }],
        })
        search_prompt_report = doctor.audit(root, [], mcp_probe, None, True, False)
        _record(checks, "MCP_SEARCH_PROMPT_REJECTED", any(item["code"] == "MCP_PROMPT_MISSING" and item["status"] == "fail" for item in search_prompt_report["checks"]), "a Prompt nested in search results cannot impersonate get_component retrieval")
        write_json(mcp_probe, {
            "schema_version": "21st-mcp-probe/v1",
            "capabilities": ["search", "get_component"],
            "calls": [{
                "operation": "get_component",
                "request": {"item_id": "probe-1"},
                "response": {"item_id": "other-item", "prompt": "Must not count."},
            }],
        })
        mismatched_report = doctor.audit(root, [], mcp_probe, None, True, False)
        _record(checks, "MCP_RESPONSE_ID_BOUND", any(item["code"] == "MCP_PROMPT_MISSING" and item["status"] == "fail" for item in mismatched_report["checks"]), "get_component request and response IDs must match before Prompt is accepted")
        write_json(mcp_probe, {
            "schema_version": "21st-mcp-probe/v1",
            "capabilities": ["search", "get_component"],
            "calls": [{
                "operation": "get_component",
                "request": {"item_id": "probe-1"},
                "response": {"item_id": "probe-1", "systemPrompt": "Use a grid."},
            }],
        })
        system_probe_report = doctor.audit(root, [], mcp_probe, None, True, False)
        _record(checks, "MCP_SYSTEM_PROMPT_GATE", not system_probe_report["passed"] and any(item["code"] == "MCP_PROMPT_MISSING" for item in system_probe_report["checks"]), "systemPrompt is not accepted by the runtime capability gate")
        write_json(mcp_probe, {
            "schema_version": "21st-mcp-probe/v1",
            "capabilities": ["search", "get_component"],
            "calls": [{
                "operation": "get_component",
                "request": {"item_id": "probe-1"},
                "response": {"item_id": "probe-1", "code": "demo only"},
            }],
        })
        cli_report = doctor.audit(root, [], mcp_probe, cli_probe, True, True)
        _record(checks, "CLI_PROMPT_GATE_NEGATIVE", not cli_report["passed"] and any(item["code"] == "CLI_PROMPT_MISSING" for item in cli_report["checks"]), "CLI code/demo-only runtime payload fails with exact CLI_PROMPT_MISSING")

        astro = temp / "astro-project"
        (astro / "src" / "pages").mkdir(parents=True)
        (astro / "package.json").write_text(json.dumps({"scripts": {"build": "astro build"}, "devDependencies": {"astro": "^5.0.0"}}), encoding="utf-8")
        (astro / "package-lock.json").write_text("{}\n", encoding="utf-8")
        (astro / "astro.config.mjs").write_text("import { defineConfig } from 'astro/config';\nexport default defineConfig({ site: 'https://acme.invalid' });\n", encoding="utf-8")
        (astro / "src" / "pages" / "index.astro").write_text("---\n---\n<html lang=\"en\"><body><h1>Acme</h1></body></html>\n", encoding="utf-8")
        astro_report = audit_astro(astro)
        _record(checks, "NATIVE_ASTRO_POSITIVE", astro_report["passed"], "minimal native Astro static fixture passes static project validation")
        bad_package = json.loads((astro / "package.json").read_text(encoding="utf-8"))
        bad_package["dependencies"] = {"react": "latest"}
        (astro / "package.json").write_text(json.dumps(bad_package), encoding="utf-8")
        bad_astro = audit_astro(astro)
        _record(checks, "NATIVE_ASTRO_NEGATIVE", any(item["code"] == "FORBIDDEN_UI_DEPENDENCIES" and item["status"] == "fail" for item in bad_astro["checks"]), "React dependency is rejected by the native Astro gate")

        dist = temp / "dist"
        dist.mkdir()
        ready_seo = _seo("https://acme.invalid")
        ready_manifest = temp / "seo-ready.json"
        write_json(ready_manifest, ready_seo)
        html = """<!doctype html><html lang=\"en\"><head><title>Acme Automation</title><meta name=\"description\" content=\"Verified industrial automation integration services.\"><meta name=\"robots\" content=\"index,follow\"><link rel=\"canonical\" href=\"https://acme.invalid/\"><meta property=\"og:title\" content=\"Acme Automation\"><meta property=\"og:description\" content=\"Verified industrial automation integration services.\"><meta property=\"og:url\" content=\"https://acme.invalid/\"><meta property=\"og:image\" content=\"https://acme.invalid/social.png\"><meta property=\"og:image:alt\" content=\"Acme industrial automation equipment\"><meta name=\"twitter:card\" content=\"summary_large_image\"><meta name=\"twitter:title\" content=\"Acme Automation\"><meta name=\"twitter:description\" content=\"Verified industrial automation integration services.\"><meta name=\"twitter:image\" content=\"https://acme.invalid/social.png\"><meta name=\"twitter:image:alt\" content=\"Acme industrial automation equipment\"><script type=\"application/ld+json\">{\"@context\":\"https://schema.org\",\"@graph\":[{\"@type\":\"Organization\",\"@id\":\"https://acme.invalid/#organization\"},{\"@type\":\"WebSite\",\"@id\":\"https://acme.invalid/#website\"}]}</script></head><body></body></html>"""
        (dist / "index.html").write_text(html, encoding="utf-8")
        (dist / "sitemap.xml").write_text("<?xml version=\"1.0\"?><urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\"><url><loc>https://acme.invalid/</loc><lastmod>2026-08-22</lastmod></url></urlset>", encoding="utf-8")
        (dist / "robots.txt").write_text("User-agent: *\nAllow: /\nSitemap: https://acme.invalid/sitemap.xml\n", encoding="utf-8")
        dist_report = audit_dist(dist, ready_manifest)
        _record(checks, "DIST_SEO_POSITIVE", dist_report["passed"], "launch-ready static SEO fixture passes HTML, JSON-LD, sitemap, and robots validation")
        (dist / "index.html").write_text(html.replace("<link rel=\"canonical\" href=\"https://acme.invalid/\">", ""), encoding="utf-8")
        bad_dist = audit_dist(dist, ready_manifest)
        _record(checks, "DIST_SEO_NEGATIVE", any(item["code"] == "CANONICAL_MATCH" and item["status"] == "fail" for item in bad_dist["checks"]), "missing launch-ready canonical is rejected")

        compose_output = temp / "contract.json"
        command = [sys.executable, "-B", str(root / "scripts" / "compose_build_contract.py"), "--brief", str(brief_path), "--observation", str(observation_path), "--selection", str(selection_path), "--seo-manifest", str(seo_path), "--design-system", str(design_path), "--prompt-file", str(prompt_path), "--output", str(compose_output)]
        result = subprocess.run(command, text=True, capture_output=True, check=False, timeout=20)
        _record(checks, "COMPOSE_CONTRACT_CLI", result.returncode == 0 and compose_output.is_file(), "compose_build_contract validates explicit design-system and ephemeral Prompt hash")
        if compose_output.is_file():
            composed_text = compose_output.read_text(encoding="utf-8")
            _record(checks, "CONTRACT_PROMPT_FREE", prompt_text not in composed_text and '"prompt"' not in composed_text, "build contract contains no raw Prompt text or key")

        for name in SCRIPT_NAMES:
            result = subprocess.run([sys.executable, "-B", str(root / "scripts" / name), "--help"], text=True, capture_output=True, check=False, timeout=20)
            _record(checks, "CLI_HELP", result.returncode == 0 and "usage:" in result.stdout.lower(), f"{name} exposes a working --help interface")
        visual_help = subprocess.run(["node", str(root / "scripts" / "visual_qa.mjs"), "--help"], text=True, capture_output=True, check=False, timeout=20)
        _record(checks, "CLI_HELP", visual_help.returncode == 0 and "usage:" in visual_help.stdout.lower(), "visual_qa.mjs exposes a working --help interface")

        package_report = doctor.audit(root, [], None, None, False, False)
        _record(checks, "PACKAGE_DOCTOR", package_report["passed"], "package/path/schema/reference/secret checks pass (optional warnings allowed)")

    report = make_report("self-check", checks, artifacts={"root": str(root), "positive_schemas": len(schema_names), "temporary_fixtures_removed": True})
    report_schema = load_json(resolve_schema("qa-report"), "QA report schema")
    report_issues = validate_instance(report, report_schema)
    if report_issues:
        raise InputError(f"self-check report violated qa-report/v1: {report_issues[0]}")
    return report


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run positive/negative workflow fixtures without network access or persistent test outputs.")
    parser.add_argument("--root", default=str(PACKAGE_ROOT), help="Workflow package root")
    parser.add_argument("--output", help="Optional explicit qa-report/v1 JSON output; otherwise print it")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        report = run(Path(args.root).expanduser().resolve())
        output_report(report, args.output)
    except (InputError, OSError, subprocess.SubprocessError) as error:
        print(f"self_check.py: {error}", file=sys.stderr)
        return 2
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
