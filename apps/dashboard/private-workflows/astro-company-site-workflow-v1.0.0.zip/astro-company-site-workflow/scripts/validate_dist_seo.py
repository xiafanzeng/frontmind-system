#!/usr/bin/env python3
"""Validate built static HTML, sitemap, robots, hreflang, and JSON-LD."""

from __future__ import annotations

import argparse
import datetime as dt
import json
import sys

sys.dont_write_bytecode = True
import xml.etree.ElementTree as ET
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Sequence
from urllib.parse import urlparse

from validate_inputs import InputError, load_json, make_report, output_report, resolve_schema, validate_instance


class PageParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.html_lang: str | None = None
        self.title_parts: list[str] = []
        self.title_count = 0
        self._in_head = False
        self._in_title = False
        self.meta: dict[str, str] = {}
        self.meta_counts: dict[str, int] = {}
        self.canonicals: list[str] = []
        self.alternates: list[dict[str, str]] = []
        self._in_jsonld = False
        self._jsonld_buffer: list[str] = []
        self.jsonld_texts: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        values = {key.lower(): value or "" for key, value in attrs}
        lowered = tag.lower()
        if lowered == "html":
            self.html_lang = values.get("lang") or None
        elif lowered == "head":
            self._in_head = True
        elif lowered == "title" and self._in_head:
            self.title_count += 1
            self._in_title = True
        elif lowered == "meta" and self._in_head:
            key = (values.get("name") or values.get("property") or "").lower()
            if key:
                self.meta_counts[key] = self.meta_counts.get(key, 0) + 1
                if key not in self.meta:
                    self.meta[key] = values.get("content", "").strip()
        elif lowered == "link" and self._in_head:
            rels = set(values.get("rel", "").lower().split())
            if "canonical" in rels:
                self.canonicals.append(values.get("href", "").strip())
            if "alternate" in rels and values.get("hreflang"):
                self.alternates.append({"hreflang": values["hreflang"], "url": values.get("href", "").strip()})
        elif lowered == "script" and values.get("type", "").lower() == "application/ld+json":
            self._in_jsonld = True
            self._jsonld_buffer = []

    def handle_endtag(self, tag: str) -> None:
        lowered = tag.lower()
        if lowered == "title" and self._in_title:
            self._in_title = False
        elif lowered == "head":
            self._in_head = False
        elif lowered == "script" and self._in_jsonld:
            self.jsonld_texts.append("".join(self._jsonld_buffer).strip())
            self._in_jsonld = False
            self._jsonld_buffer = []

    def handle_data(self, data: str) -> None:
        if self._in_title:
            self.title_parts.append(data)
        if self._in_jsonld:
            self._jsonld_buffer.append(data)

    @property
    def title(self) -> str:
        return " ".join("".join(self.title_parts).split())


def _check(code: str, passed: bool, message: str, path: str | None = None, warn: bool = False) -> dict[str, Any]:
    item: dict[str, Any] = {"code": code, "status": "pass" if passed else ("warn" if warn else "fail"), "message": message}
    if path is not None:
        item["path"] = path
    return item


def _route_file(dist: Path, route: str) -> Path:
    clean = route.split("?", 1)[0].split("#", 1)[0].strip("/")
    if not clean:
        return dist / "index.html"
    directory_index = dist / clean / "index.html"
    flat_html = dist / f"{clean}.html"
    return directory_index if directory_index.exists() or not flat_html.exists() else flat_html


def _jsonld_nodes(value: Any) -> list[dict[str, Any]]:
    nodes: list[dict[str, Any]] = []
    if isinstance(value, dict):
        nodes.append(value)
        graph = value.get("@graph")
        if isinstance(graph, list):
            for child in graph:
                nodes.extend(_jsonld_nodes(child))
    elif isinstance(value, list):
        for child in value:
            nodes.extend(_jsonld_nodes(child))
    return nodes


def _type_values(value: Any) -> set[str]:
    output: set[str] = set()
    for node in _jsonld_nodes(value):
        raw = node.get("@type")
        if isinstance(raw, str):
            output.add(raw)
        elif isinstance(raw, list):
            output.update(item for item in raw if isinstance(item, str))
    return output


def _parse_sitemap(path: Path, seen: set[Path] | None = None) -> tuple[set[str], list[str]]:
    seen = seen or set()
    urls: set[str] = set()
    errors: list[str] = []
    resolved = path.resolve()
    if resolved in seen:
        return urls, errors
    seen.add(resolved)
    try:
        root = ET.parse(path).getroot()
    except (OSError, ET.ParseError) as error:
        return urls, [f"cannot parse {path.name}: {error}"]
    local = root.tag.rsplit("}", 1)[-1]
    locs = [element.text.strip() for element in root.iter() if element.tag.rsplit("}", 1)[-1] == "loc" and element.text and element.text.strip()]
    if local == "sitemapindex":
        for loc in locs:
            candidate = path.parent / Path(urlparse(loc).path).name
            if not candidate.is_file():
                errors.append(f"sitemap index target is missing: {loc}")
                continue
            child_urls, child_errors = _parse_sitemap(candidate, seen)
            urls.update(child_urls)
            errors.extend(child_errors)
    elif local == "urlset":
        if len(locs) != len(set(locs)):
            errors.append("sitemap contains duplicate URL entries")
        urls.update(locs)
    else:
        errors.append(f"unexpected sitemap root element: {local}")
    return urls, errors


def audit(dist: Path, manifest_path: Path) -> dict[str, Any]:
    if not dist.exists() or not dist.is_dir():
        raise InputError(f"dist is missing or not a directory: {dist}")
    if dist.is_symlink():
        raise InputError(f"dist must not be a symbolic link: {dist}")
    dist = dist.resolve()
    manifest = load_json(manifest_path, "SEO manifest")
    if not isinstance(manifest, dict):
        raise InputError("SEO manifest root must be an object")
    schema = load_json(resolve_schema("seo-manifest"), "SEO manifest schema")
    issues = validate_instance(manifest, schema)
    if issues:
        first = issues[0]
        raise InputError(f"SEO manifest is invalid ({len(issues)} issue(s)); first: {first['path']} {first['code']}: {first['message']}")
    checks: list[dict[str, Any]] = []
    launch_ready = bool(manifest["launch_ready"])
    origin = manifest.get("canonical_origin")
    if launch_ready:
        checks.append(_check("SEO_LAUNCH_READY", True, "canonical origin and host policy are resolved for launch"))
    else:
        checks.append(_check("SEO_LAUNCH_BLOCKED", False, "SEO launch is blocked: " + "; ".join(manifest["launch_blockers"]), warn=True))
    if origin and origin.endswith(".invalid"):
        checks.append(_check("PLACEHOLDER_ORIGIN", False, "reserved .invalid canonical origin is a launch placeholder", warn=True))

    parsed_pages: dict[str, PageParser] = {}
    for route in manifest["routes"]:
        route_path = route["path"]
        page_path = _route_file(dist, route_path)
        relative = str(page_path.relative_to(dist))
        exists = page_path.is_file() and not page_path.is_symlink()
        checks.append(_check("ROUTE_HTML_PRESENT", exists, f"built HTML {'exists' if exists else 'is missing'} for {route_path}", relative))
        if not exists:
            continue
        try:
            html = page_path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError) as error:
            checks.append(_check("ROUTE_HTML_READ", False, f"cannot read built HTML: {error}", relative))
            continue
        parser = PageParser()
        try:
            parser.feed(html)
        except Exception as error:
            checks.append(_check("HTML_PARSE", False, f"cannot parse HTML: {error}", relative))
            continue
        parsed_pages[route_path] = parser
        title_ok = parser.title_count == 1 and parser.title == route["title"]
        checks.append(_check("TITLE_MATCH", title_ok, "exactly one document title matches manifest" if title_ok else f"expected one matching title; count={parser.title_count}, value={parser.title!r}", relative))
        description_ok = parser.meta_counts.get("description", 0) == 1 and parser.meta.get("description") == route["description"]
        checks.append(_check("DESCRIPTION_MATCH", description_ok, "exactly one meta description matches manifest" if description_ok else f"expected exactly one matching meta description; count={parser.meta_counts.get('description', 0)}", relative))
        if "Northstar Works".casefold() in html.casefold() or "@example.invalid".casefold() in html.casefold():
            checks.append(_check("STARTER_PLACEHOLDER", False, "built HTML still contains a starter company/contact placeholder", relative, warn=True))
        checks.append(_check("HTML_LANG_MATCH", parser.html_lang == route["locale"], "html lang matches route locale" if parser.html_lang == route["locale"] else f"html lang {parser.html_lang!r} does not match {route['locale']!r}", relative))
        if launch_ready and route["indexable"]:
            checks.append(_check("CANONICAL_MATCH", parser.canonicals == [route["canonical"]], "one canonical matches manifest" if parser.canonicals == [route["canonical"]] else f"expected one canonical {route['canonical']!r}, found {parser.canonicals!r}", relative))
            robots_value = parser.meta.get("robots", "").lower()
            checks.append(_check("INDEXABLE_NOT_NOINDEX", "noindex" not in robots_value, "indexable route is not marked noindex" if "noindex" not in robots_value else "indexable route contains noindex", relative))
        elif not route["indexable"]:
            robots_value = parser.meta.get("robots", "").lower()
            checks.append(_check("NONINDEXABLE_NOINDEX", "noindex" in robots_value, "non-indexable route has noindex" if "noindex" in robots_value else "non-indexable route must have a noindex meta directive", relative))
        if launch_ready:
            expected_social = {
                "og:title": route["title"],
                "og:description": route["description"],
                "og:url": route["canonical"],
                "twitter:title": route["title"],
                "twitter:description": route["description"],
            }
            for field, expected in expected_social.items():
                checks.append(_check("SOCIAL_META_MATCH", parser.meta.get(field) == expected, f"{field} matches manifest" if parser.meta.get(field) == expected else f"{field} is missing or mismatched", relative))
            expected_image = route.get("social_image")
            if expected_image:
                parsed_image = urlparse(expected_image)
                image_absolute = parsed_image.scheme == "https" and bool(parsed_image.netloc)
                checks.append(_check("SOCIAL_IMAGE_MATCH", image_absolute and parser.meta.get("og:image") == expected_image and parser.meta.get("twitter:image") == expected_image, "absolute Open Graph and Twitter images match manifest" if image_absolute and parser.meta.get("og:image") == expected_image and parser.meta.get("twitter:image") == expected_image else "social image URLs are relative, missing, or mismatched", relative))
                checks.append(_check("SOCIAL_IMAGE_ALT", bool(parser.meta.get("og:image:alt")) and bool(parser.meta.get("twitter:image:alt")), "Open Graph and Twitter image alt metadata is present" if parser.meta.get("og:image:alt") and parser.meta.get("twitter:image:alt") else "social image alt metadata is missing", relative))
            checks.append(_check("TWITTER_CARD_PRESENT", bool(parser.meta.get("twitter:card")), "twitter:card is present" if parser.meta.get("twitter:card") else "twitter:card is missing", relative))

        expected_alternates = sorted((item["hreflang"], item["url"]) for item in route["alternates"] if item["url"] is not None)
        actual_alternates = sorted((item["hreflang"], item["url"]) for item in parser.alternates)
        if launch_ready:
            checks.append(_check("HREFLANG_MATCH", actual_alternates == expected_alternates, "hreflang links match manifest" if actual_alternates == expected_alternates else f"expected {expected_alternates!r}, found {actual_alternates!r}", relative))

        json_values: list[Any] = []
        for index, raw in enumerate(parser.jsonld_texts):
            try:
                json_values.append(json.loads(raw))
            except json.JSONDecodeError as error:
                checks.append(_check("JSONLD_INVALID", False, f"JSON-LD block {index + 1} is invalid JSON: {error.msg}", relative))
        all_types: set[str] = set()
        all_ids: set[str] = set()
        schema_context_present = False
        for value in json_values:
            all_types.update(_type_values(value))
            for node in _jsonld_nodes(value):
                if isinstance(node.get("@id"), str):
                    all_ids.add(node["@id"])
                context = node.get("@context")
                if context == "https://schema.org":
                    schema_context_present = True
                if context is not None and context != "https://schema.org":
                    checks.append(_check("JSONLD_CONTEXT", False, "JSON-LD @context must be https://schema.org", relative))
        checks.append(_check("JSONLD_CONTEXT_PRESENT", schema_context_present, "JSON-LD declares https://schema.org context" if schema_context_present else "JSON-LD is missing the required https://schema.org context", relative))
        expected_types = set(route["schema_types"])
        checks.append(_check("JSONLD_TYPES_PRESENT", expected_types.issubset(all_types), "required schema types are present" if expected_types.issubset(all_types) else f"missing schema types: {sorted(expected_types - all_types)}", relative))
        if route_path == "/" and launch_ready:
            required_ids = {manifest["entity"]["organization_id"], manifest["entity"]["website_id"]} - {None}
            checks.append(_check("ENTITY_IDS_PRESENT", required_ids.issubset(all_ids), "home JSON-LD contains stable Organization/WebSite IDs" if required_ids.issubset(all_ids) else f"missing entity IDs: {sorted(required_ids - all_ids)}", relative))

    sitemap_entry: Path | None = None
    if (dist / "sitemap-index.xml").is_file():
        sitemap_entry = dist / "sitemap-index.xml"
    elif (dist / "sitemap.xml").is_file():
        sitemap_entry = dist / "sitemap.xml"
    else:
        shards = sorted(dist.glob("sitemap-*.xml"))
        if len(shards) == 1:
            sitemap_entry = shards[0]
    if launch_ready:
        checks.append(_check("SITEMAP_PRESENT", sitemap_entry is not None, f"sitemap entry file found: {sitemap_entry.name}" if sitemap_entry else "no sitemap index, sitemap.xml, or single sitemap shard found"))
        sitemap_urls: set[str] = set()
        if sitemap_entry is not None:
            sitemap_urls, sitemap_errors = _parse_sitemap(sitemap_entry)
            for error in sitemap_errors:
                checks.append(_check("SITEMAP_INVALID", False, error, sitemap_entry.name))
            expected_urls = {route["canonical"] for route in manifest["routes"] if route["indexable"]}
            checks.append(_check("SITEMAP_URL_SET", sitemap_urls == expected_urls, "sitemap URL set exactly matches indexable canonical routes" if sitemap_urls == expected_urls else f"sitemap missing={sorted(expected_urls - sitemap_urls)}, extra={sorted(sitemap_urls - expected_urls)}", sitemap_entry.name))
        robots_path = dist / "robots.txt"
        robots_exists = robots_path.is_file() and not robots_path.is_symlink()
        checks.append(_check("ROBOTS_PRESENT", robots_exists, "robots.txt is present" if robots_exists else "robots.txt is missing", "robots.txt"))
        if robots_exists and sitemap_entry is not None:
            robots_text = robots_path.read_text(encoding="utf-8")
            expected_sitemap = f"{origin}/{sitemap_entry.name}"
            listed = [line.split(":", 1)[1].strip() for line in robots_text.splitlines() if line.lower().startswith("sitemap:")]
            checks.append(_check("ROBOTS_SITEMAP_MATCH", listed == [expected_sitemap], "robots.txt lists the exact sitemap URL" if listed == [expected_sitemap] else f"expected {[expected_sitemap]!r}, found {listed!r}", "robots.txt"))

    llms_path = dist / "llms.txt"
    if manifest["experimental"].get("llms_txt") and not llms_path.is_file():
        checks.append(_check("LLMS_TXT_EXPERIMENT_MISSING", False, "experimental llms.txt was requested but not emitted; it is not a Google visibility requirement", "llms.txt", warn=True))
    elif llms_path.is_file():
        checks.append(_check("LLMS_TXT_EXPERIMENTAL", False, "llms.txt is present as an experiment only and must not be represented as affecting Google Search or AI visibility", "llms.txt", warn=True))

    return make_report(
        "dist-seo",
        checks,
        artifacts={"dist": str(dist), "manifest": str(manifest_path.resolve()), "routes_checked": len(manifest["routes"]), "launch_ready": launch_ready},
        external_pending=manifest["launch_blockers"] if not launch_ready else [],
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Validate built static SEO artifacts against seo-manifest/v1.")
    parser.add_argument("--dist", required=True, help="Built Astro dist directory")
    parser.add_argument("--manifest", required=True, help="seo-manifest/v1 JSON path")
    parser.add_argument("--strict-warnings", action="store_true", help="Return nonzero when warnings remain")
    parser.add_argument("--output", help="Optional explicit qa-report/v1 JSON output; otherwise print it")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        report = audit(Path(args.dist).expanduser(), Path(args.manifest).expanduser())
        output_report(report, args.output)
    except (InputError, OSError) as error:
        print(f"validate_dist_seo.py: {error}", file=sys.stderr)
        return 2
    if not report["passed"] or (args.strict_warnings and report["summary"]["warnings"]):
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
