#!/usr/bin/env python3
"""Validate workflow JSON inputs without third-party Python packages.

The module also exposes deterministic JSON, hashing, reporting, and secret-scan
helpers used by the other workflow scripts.  It intentionally implements only
the JSON Schema 2020-12 keywords used by this package's own contracts.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import re
import sys

sys.dont_write_bytecode = True
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence
from urllib.parse import parse_qsl, unquote, urlparse, urlunparse


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
SCHEMA_DIR = PACKAGE_ROOT / "schemas"
SCHEMA_ALIASES = {
    "company-brief": "company-brief.schema.json",
    "company-brief/v2": "company-brief.schema.json",
    "visual-observation": "visual-observation.schema.json",
    "visual-observation/v1": "visual-observation.schema.json",
    "visual-selection": "visual-selection.schema.json",
    "visual-selection/v1": "visual-selection.schema.json",
    "build-contract": "build-contract.schema.json",
    "build-contract/v1": "build-contract.schema.json",
    "seo-manifest": "seo-manifest.schema.json",
    "seo-manifest/v1": "seo-manifest.schema.json",
    "provenance": "provenance.schema.json",
    "provenance/v1": "provenance.schema.json",
    "qa-report": "qa-report.schema.json",
    "qa-report/v1": "qa-report.schema.json",
}

_SAFE_DIRECTIVE_VALUES = {
    "structure:asymmetric-grid", "structure:modular-grid", "structure:hero-led-hierarchy",
    "structure:split-layout", "structure:editorial-rhythm", "structure:preview-led-original-translation",
    "typography:display-led-hierarchy", "typography:condensed-technical", "typography:serif-editorial",
    "typography:neutral-sans", "surface:border-defined", "surface:soft-shadow-depth",
    "surface:glass-like-layering", "surface:rounded-containers", "color:dark-canvas",
    "color:light-canvas", "color:muted-palette", "color:high-contrast", "color:single-accent",
    "imagery:photography-led", "imagery:product-ui-led", "imagery:illustration-led", "imagery:wide-crop",
    "imagery:masked-media", "motion:controlled-reveal", "motion:short-transition",
    "motion:scroll-triggered", "motion:hover-depth", "motion:reduced-motion-required",
    "tone:technical-precise", "tone:warm-human", "tone:premium-restrained", "tone:bold-graphic",
    "responsive:mobile-reflow",
}
_SENSITIVE_QUERY_KEYS = re.compile(r"(?:api.?key|token|secret|credential|authorization|auth|signature|jwt)", re.I)
_SENSITIVE_URL_VALUE = re.compile(
    r"(?:21st_sk_[A-Za-z0-9_-]{12,}|\bBearer\s+[A-Za-z0-9._~+/-]{12,}|"
    r"\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,})",
    re.I,
)


def _provider_url_issue(value: Any, *, source: bool) -> str | None:
    if not isinstance(value, str) or not value:
        return "URL is missing"
    parsed = urlparse(value)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        return "provider source URL must use http(s)" if source else "provider preview URL must use http(s)"
    try:
        parsed_port = parsed.port
    except ValueError:
        return "URL contains an invalid port"
    if parsed.username is not None or parsed.password is not None:
        return "URL userinfo is forbidden"
    hostname = (parsed.hostname or "").casefold()
    if source and hostname != "21st.dev" and not hostname.endswith(".21st.dev"):
        return "provider source URL must use the official 21st.dev host"
    query_pairs = parse_qsl(parsed.query, keep_blank_values=True)
    if any(_SENSITIVE_QUERY_KEYS.search(key) for key, _ in query_pairs):
        return "credential-like URL query parameters are forbidden"
    decoded_url = unquote(value)
    if _SENSITIVE_URL_VALUE.search(decoded_url) or any(_SENSITIVE_URL_VALUE.search(item) for _, item in query_pairs):
        return "credential-like URL values are forbidden"
    if parsed_port is not None and not (1 <= parsed_port <= 65535):
        return "URL contains an invalid port"
    return None


def _canonical_provider_url(value: str) -> str:
    parsed = urlparse(value)
    host = (parsed.hostname or "").casefold()
    port = parsed.port
    if port and not ((parsed.scheme == "http" and port == 80) or (parsed.scheme == "https" and port == 443)):
        host = f"{host}:{port}"
    path = parsed.path.rstrip("/") or "/"
    return urlunparse((parsed.scheme.casefold(), host, path, "", parsed.query, ""))


class InputError(ValueError):
    """An actionable input or contract error."""


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_json(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_json(path: str | Path, label: str = "JSON input") -> Any:
    resolved = Path(path).expanduser()
    if not resolved.exists():
        raise InputError(f"{label} does not exist: {resolved}")
    if not resolved.is_file():
        raise InputError(f"{label} is not a regular file: {resolved}")
    try:
        return json.loads(resolved.read_text(encoding="utf-8"))
    except UnicodeDecodeError as error:
        raise InputError(f"{label} is not UTF-8: {resolved}: {error}") from error
    except json.JSONDecodeError as error:
        raise InputError(
            f"{label} is invalid JSON at line {error.lineno}, column {error.colno}: {resolved}: {error.msg}"
        ) from error


def write_json(path: str | Path, value: Any) -> None:
    """Write exactly one explicitly requested JSON output."""

    resolved = Path(path).expanduser()
    if resolved.exists() and resolved.is_dir():
        raise InputError(f"output path is a directory: {resolved}")
    resolved.parent.mkdir(parents=True, exist_ok=True)
    resolved.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")


def resolve_schema(value: str | Path) -> Path:
    raw = str(value)
    alias = SCHEMA_ALIASES.get(raw)
    candidate = SCHEMA_DIR / alias if alias else Path(raw).expanduser()
    if not candidate.is_absolute() and not alias:
        candidate = Path.cwd() / candidate
    if not candidate.exists():
        choices = ", ".join(sorted(SCHEMA_ALIASES))
        raise InputError(f"schema not found: {candidate}. Known schema names: {choices}")
    return candidate.resolve()


def _is_type(instance: Any, expected: str) -> bool:
    if expected == "null":
        return instance is None
    if expected == "boolean":
        return isinstance(instance, bool)
    if expected == "integer":
        return isinstance(instance, int) and not isinstance(instance, bool)
    if expected == "number":
        return isinstance(instance, (int, float)) and not isinstance(instance, bool)
    if expected == "string":
        return isinstance(instance, str)
    if expected == "array":
        return isinstance(instance, list)
    if expected == "object":
        return isinstance(instance, dict)
    return False


def _json_pointer(root: Any, pointer: str) -> Any:
    if pointer == "#":
        return root
    if not pointer.startswith("#/"):
        raise InputError(f"only local JSON Schema references are supported, got: {pointer}")
    current = root
    for token in pointer[2:].split("/"):
        key = token.replace("~1", "/").replace("~0", "~")
        if not isinstance(current, Mapping) or key not in current:
            raise InputError(f"unresolvable JSON Schema reference: {pointer}")
        current = current[key]
    return current


def _format_valid(value: str, format_name: str) -> bool:
    if format_name == "date":
        try:
            dt.date.fromisoformat(value)
            return bool(re.fullmatch(r"\d{4}-\d{2}-\d{2}", value))
        except ValueError:
            return False
    if format_name == "date-time":
        try:
            dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
            return "T" in value
        except ValueError:
            return False
    if format_name in {"uri", "uri-reference"}:
        parsed = urlparse(value)
        return bool(parsed.scheme and (parsed.netloc or parsed.scheme == "file"))
    if format_name == "email":
        return bool(re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", value))
    return True


def validate_instance(instance: Any, schema: Mapping[str, Any], root_schema: Mapping[str, Any] | None = None) -> list[dict[str, str]]:
    """Return deterministic validation issues for this package's schema subset."""

    root = root_schema or schema
    issues: list[dict[str, str]] = []

    def add(path: str, code: str, message: str) -> None:
        issues.append({"path": path, "code": code, "message": message})

    def visit(value: Any, rule: Any, path: str) -> None:
        if rule is True or rule == {}:
            return
        if rule is False:
            add(path, "SCHEMA_FALSE", "value is forbidden by the schema")
            return
        if not isinstance(rule, Mapping):
            add(path, "SCHEMA_INVALID", "schema rule must be an object or boolean")
            return
        if "$ref" in rule:
            try:
                target = _json_pointer(root, str(rule["$ref"]))
            except InputError as error:
                add(path, "SCHEMA_REF_INVALID", str(error))
                return
            visit(value, target, path)
            sibling = {key: item for key, item in rule.items() if key != "$ref"}
            if sibling:
                visit(value, sibling, path)
            return

        if "allOf" in rule:
            for branch in rule["allOf"]:
                visit(value, branch, path)
        if "anyOf" in rule:
            branches = [validate_instance(value, branch, root) for branch in rule["anyOf"]]
            if not any(not branch for branch in branches):
                add(path, "ANY_OF", "value does not satisfy any allowed schema branch")
                return
        if "oneOf" in rule:
            branches = [validate_instance(value, branch, root) for branch in rule["oneOf"]]
            if sum(1 for branch in branches if not branch) != 1:
                add(path, "ONE_OF", "value must satisfy exactly one schema branch")
                return

        expected = rule.get("type")
        if expected is not None:
            allowed = [expected] if isinstance(expected, str) else list(expected)
            if not any(_is_type(value, item) for item in allowed):
                add(path, "TYPE", f"expected {' or '.join(allowed)}, got {type(value).__name__}")
                return
        if "const" in rule and value != rule["const"]:
            add(path, "CONST", f"expected constant {rule['const']!r}")
        if "enum" in rule and value not in rule["enum"]:
            add(path, "ENUM", f"expected one of {rule['enum']!r}")

        if isinstance(value, dict):
            required = rule.get("required", [])
            for key in required:
                if key not in value:
                    add(f"{path}.{key}", "REQUIRED", "required property is missing")
            properties = rule.get("properties", {})
            if isinstance(properties, Mapping):
                for key, child in value.items():
                    child_path = f"{path}.{key}"
                    if key in properties:
                        visit(child, properties[key], child_path)
                    elif rule.get("additionalProperties") is False:
                        add(child_path, "ADDITIONAL_PROPERTY", "property is not allowed")
                    elif isinstance(rule.get("additionalProperties"), Mapping):
                        visit(child, rule["additionalProperties"], child_path)
            if "minProperties" in rule and len(value) < int(rule["minProperties"]):
                add(path, "MIN_PROPERTIES", f"expected at least {rule['minProperties']} properties")
            if "maxProperties" in rule and len(value) > int(rule["maxProperties"]):
                add(path, "MAX_PROPERTIES", f"expected at most {rule['maxProperties']} properties")

        if isinstance(value, list):
            if "minItems" in rule and len(value) < int(rule["minItems"]):
                add(path, "MIN_ITEMS", f"expected at least {rule['minItems']} items")
            if "maxItems" in rule and len(value) > int(rule["maxItems"]):
                add(path, "MAX_ITEMS", f"expected at most {rule['maxItems']} items")
            if rule.get("uniqueItems"):
                encoded = [canonical_json(item) for item in value]
                if len(encoded) != len(set(encoded)):
                    add(path, "UNIQUE_ITEMS", "array items must be unique")
            items_rule = rule.get("items")
            if items_rule is not None:
                for index, child in enumerate(value):
                    visit(child, items_rule, f"{path}[{index}]")

        if isinstance(value, str):
            if "minLength" in rule and len(value) < int(rule["minLength"]):
                add(path, "MIN_LENGTH", f"expected at least {rule['minLength']} characters")
            if "maxLength" in rule and len(value) > int(rule["maxLength"]):
                add(path, "MAX_LENGTH", f"expected at most {rule['maxLength']} characters")
            if "pattern" in rule:
                try:
                    matched = re.search(str(rule["pattern"]), value)
                except re.error as error:
                    add(path, "SCHEMA_PATTERN_INVALID", f"invalid schema regex: {error}")
                else:
                    if not matched:
                        add(path, "PATTERN", f"value does not match {rule['pattern']!r}")
            if "format" in rule and not _format_valid(value, str(rule["format"])):
                add(path, "FORMAT", f"value is not a valid {rule['format']}")

        if isinstance(value, (int, float)) and not isinstance(value, bool):
            if "minimum" in rule and value < rule["minimum"]:
                add(path, "MINIMUM", f"expected value >= {rule['minimum']}")
            if "maximum" in rule and value > rule["maximum"]:
                add(path, "MAXIMUM", f"expected value <= {rule['maximum']}")

    visit(instance, schema, "$")
    issues.extend(_semantic_issues(instance))
    return sorted(issues, key=lambda item: (item["path"], item["code"], item["message"]))


def _semantic_issues(instance: Any) -> list[dict[str, str]]:
    if not isinstance(instance, dict):
        return []
    version = instance.get("schema_version")
    issues: list[dict[str, str]] = []

    def add(path: str, code: str, message: str) -> None:
        issues.append({"path": path, "code": code, "message": message})

    if version == "company-brief/v2":
        site = instance.get("site") or {}
        origin = site.get("canonical_origin")
        if origin:
            parsed_origin = urlparse(origin)
            if (
                parsed_origin.scheme != "https"
                or not parsed_origin.netloc
                or parsed_origin.username is not None
                or parsed_origin.password is not None
                or parsed_origin.path
                or parsed_origin.params
                or parsed_origin.query
                or parsed_origin.fragment
            ):
                add(
                    "$.site.canonical_origin",
                    "CANONICAL_ORIGIN_INVALID",
                    "canonical_origin must be a credential-free HTTPS origin with no path, query, or fragment",
                )
        locales = site.get("locales") or []
        if site.get("default_locale") not in locales:
            add("$.site.default_locale", "DEFAULT_LOCALE_MISSING", "default_locale must occur in site.locales")
        if site.get("host_policy") != "unresolved" and not site.get("canonical_origin"):
            add("$.site.canonical_origin", "CANONICAL_ORIGIN_REQUIRED", "resolved host policy requires canonical_origin")
        pages = instance.get("pages") or []
        paths = [page.get("path") for page in pages if isinstance(page, dict)]
        if len(paths) != len(set(paths)):
            add("$.pages", "DUPLICATE_ROUTE", "page paths must be unique")
        for index, page in enumerate(pages):
            if isinstance(page, dict) and page.get("locale") not in locales:
                add(f"$.pages[{index}].locale", "UNKNOWN_LOCALE", "page locale must occur in site.locales")
        fact_ids = {fact.get("id") for fact in instance.get("verified_facts", []) if isinstance(fact, dict)}
        for offering_index, offering in enumerate(instance.get("offerings", [])):
            if not isinstance(offering, dict):
                continue
            for fact_index, fact_id in enumerate(offering.get("fact_ids", [])):
                if fact_id not in fact_ids:
                    add(
                        f"$.offerings[{offering_index}].fact_ids[{fact_index}]",
                        "UNKNOWN_FACT",
                        "offering fact_id must identify a verified fact",
                    )
        asset_by_id = {
            asset.get("asset_id"): asset
            for asset in instance.get("assets", [])
            if isinstance(asset, dict)
        }
        asset_ids = set(asset_by_id)
        if len(asset_ids) != len(instance.get("assets", [])):
            add("$.assets", "DUPLICATE_ASSET", "asset IDs must be unique")
        for reference_index, reference in enumerate(instance.get("visual_references", [])):
            if not isinstance(reference, dict):
                continue
            reference_asset_id = reference.get("asset_id")
            if reference_asset_id not in asset_ids:
                add(
                    f"$.visual_references[{reference_index}].asset_id",
                    "UNKNOWN_ASSET",
                    "visual reference asset_id must identify an asset",
                )
                continue
            source_asset = asset_by_id[reference_asset_id]
            if source_asset.get("role") != "visual_reference":
                add(
                    f"$.visual_references[{reference_index}].asset_id",
                    "REFERENCE_ROLE_MISMATCH",
                    "visual reference must identify an asset whose role is visual_reference",
                )
            if source_asset.get("location") != reference.get("location"):
                add(
                    f"$.visual_references[{reference_index}].location",
                    "REFERENCE_LOCATION_MISMATCH",
                    "visual reference location must match its source asset location",
                )

    elif version == "visual-observation/v1":
        assets = instance.get("assets") or []
        asset_ids = [asset.get("asset_id") for asset in assets if isinstance(asset, dict)]
        if len(asset_ids) != len(set(asset_ids)):
            add("$.assets", "DUPLICATE_ASSET", "observed asset IDs must be unique")
        for index, asset in enumerate(assets):
            if not isinstance(asset, dict):
                continue
            search_terms = asset.get("search_terms_en")
            if asset.get("role") == "visual_reference" and not search_terms:
                add(
                    f"$.assets[{index}].search_terms_en",
                    "SEARCH_TERMS_REQUIRED",
                    "every visual_reference observation needs 3–12 concrete English search phrases",
                )

    elif version == "visual-selection/v1":
        candidates = instance.get("searched_candidates") or []
        ids = [item.get("candidate_id") for item in candidates if isinstance(item, dict)]
        by_id = {item.get("candidate_id"): item for item in candidates if isinstance(item, dict)}
        if len(ids) != len(set(ids)):
            add("$.searched_candidates", "DUPLICATE_CANDIDATE", "candidate IDs must be unique")
        provider_ids = [item.get("provider_item_id") for item in candidates if isinstance(item, dict)]
        if len(provider_ids) != len(set(provider_ids)):
            add("$.searched_candidates", "DUPLICATE_PROVIDER_ITEM", "provider item IDs must be stable and unique")
        search_ranks = [item.get("search_rank") for item in candidates if isinstance(item, dict)]
        if sorted(search_ranks) != list(range(1, len(search_ranks) + 1)):
            add("$.searched_candidates", "RANK_SEQUENCE", "search ranks must be contiguous starting at 1")
        for index, candidate in enumerate(candidates):
            if not isinstance(candidate, dict):
                continue
            for field, source_url in (("source_url", True), ("preview_url", False)):
                value = candidate.get(field)
                if value is None:
                    continue
                url_issue = _provider_url_issue(value, source=source_url)
                if url_issue:
                    add(f"$.searched_candidates[{index}].{field}", "PROVIDER_URL_INVALID", url_issue)
            directives = candidate.get("normalized_directives") or []
            if any(value not in _SAFE_DIRECTIVE_VALUES for value in directives):
                add(f"$.searched_candidates[{index}].normalized_directives", "UNSAFE_DIRECTIVE", "directives must be rewritten fixed-taxonomy values")
            if candidate.get("retrieval_status") == "prompt-retrieved":
                if candidate.get("retrieval_operation") != "get_component" or not candidate.get("retrieval_response_sha256"):
                    add(
                        f"$.searched_candidates[{index}]",
                        "INDEPENDENT_RETRIEVAL_REQUIRED",
                        "prompt-retrieved requires an independently hashed get_component result",
                    )
                if not candidate.get("provider_item_id"):
                    add(f"$.searched_candidates[{index}].provider_item_id", "PROVIDER_ITEM_ID_REQUIRED", "prompt retrieval requires a stable provider item ID")
                if not candidate.get("source_url"):
                    add(f"$.searched_candidates[{index}].source_url", "SOURCE_URL_REQUIRED", "prompt retrieval requires a safe stable provider source URL")
            elif candidate.get("retrieval_operation") is not None or candidate.get("retrieval_response_sha256") is not None:
                add(f"$.searched_candidates[{index}]", "RETRIEVAL_PROOF_INCONSISTENT", "non-retrieved candidates cannot claim get_component proof")
        canonical_sources = [
            _canonical_provider_url(str(candidate["source_url"]))
            for candidate in candidates
            if isinstance(candidate, dict) and candidate.get("source_url") and not _provider_url_issue(candidate.get("source_url"), source=True)
        ]
        if len(canonical_sources) != len(candidates) or len(canonical_sources) != len(set(canonical_sources)):
            add("$.searched_candidates", "DUPLICATE_SOURCE_URL", "eligible searched candidates require unique canonical provider source URLs")
        retrieval = instance.get("retrieval_shortlist") or []
        presented = instance.get("presented_candidates") or []
        presented_ids = [item.get("candidate_id") for item in presented if isinstance(item, dict)]
        actual = instance.get("actual") or {}
        expected_counts = {
            "searched": len(candidates),
            "prompt_retrieved": len(retrieval),
            "presented": len(presented),
        }
        for key, expected_count in expected_counts.items():
            if actual.get(key) != expected_count:
                add(f"$.actual.{key}", "COUNT_MISMATCH", f"expected {expected_count} from funnel arrays")
        for index, candidate_id in enumerate(retrieval):
            candidate = by_id.get(candidate_id)
            if candidate is None:
                add(f"$.retrieval_shortlist[{index}]", "UNKNOWN_CANDIDATE", "retrieval candidate is absent from searched_candidates")
            elif (
                candidate.get("retrieval_status") != "prompt-retrieved"
                or candidate.get("retrieval_operation") != "get_component"
                or not candidate.get("retrieval_response_sha256")
                or not candidate.get("prompt_sha256")
                or not candidate.get("normalized_directives")
            ):
                add(f"$.retrieval_shortlist[{index}]", "PROMPT_METADATA_MISSING", "retrieved candidate needs independent get_component proof, Prompt hash, and safe normalized directives")
        for index, candidate_id in enumerate(presented_ids):
            if candidate_id not in retrieval:
                add(f"$.presented_candidates[{index}].candidate_id", "NOT_RETRIEVED", "presented candidate must occur in retrieval_shortlist")
                continue
            candidate = by_id.get(candidate_id) or {}
            if not candidate.get("preview_url"):
                add(
                    f"$.presented_candidates[{index}].candidate_id",
                    "PREVIEW_REQUIRED",
                    "presented candidate must have provider-returned preview media",
                )
            if candidate.get("query_role") != "foundation":
                add(
                    f"$.presented_candidates[{index}].candidate_id",
                    "FOUNDATION_REQUIRED",
                    "every displayed option must come from a foundation query",
                )
        presentation_ranks = [item.get("presentation_rank") for item in presented if isinstance(item, dict)]
        if sorted(presentation_ranks) != list(range(1, len(presentation_ranks) + 1)):
            add("$.presented_candidates", "RANK_SEQUENCE", "presentation ranks must be contiguous starting at 1")
        option_labels = [item.get("option_label") for item in presented if isinstance(item, dict)]
        expected_labels = [chr(ord("A") + index) for index in range(len(option_labels))]
        if option_labels != expected_labels:
            add("$.presented_candidates", "OPTION_LABEL_SEQUENCE", "option labels must be contiguous A–I in presentation order")
        selected = instance.get("selected")
        stage = instance.get("stage")
        error_codes = {item.get("code") for item in instance.get("errors", []) if isinstance(item, dict)}
        always_blocking = {
            "GENERATE_FORBIDDEN",
            "CLI_PROMPT_MISSING",
            "MCP_AUTH_FAILED",
            "MCP_CAPABILITY_MISSING",
            "MCP_UNAVAILABLE",
        }
        if instance.get("source") == "cli":
            always_blocking.add("PROMPT_UNSAFE_CONTENT")
        blocking_present = sorted(error_codes & always_blocking)
        if blocking_present:
            add("$.errors", "BLOCKING_PROVIDER_ERROR", f"selection cannot proceed with blocking provider errors: {blocking_present}")

        target_counts = {"searched": 18, "prompt_retrieved": 12, "presented": 9}
        shortfalls = {key: target_counts[key] - expected_counts[key] for key in target_counts if expected_counts[key] < target_counts[key]}
        global_shortfall_codes = {
            "searched": "SEARCH_RESULTS_INSUFFICIENT",
            "prompt_retrieved": "RETRIEVAL_RESULTS_INSUFFICIENT",
            "presented": "PRESENTATION_RESULTS_INSUFFICIENT",
        }
        if instance.get("stage") in {"selected", "selected-degraded"}:
            if not instance.get("board_ready"):
                add("$.board_ready", "BOARD_NOT_READY", "a selected stage requires a fully evaluated comparison board")
            if instance.get("stage") == "selected":
                if expected_counts != target_counts:
                    add("$.actual", "FUNNEL_INCOMPLETE", "normal selected stage requires search 18, retrieve 12, present 9")
                for key, code in global_shortfall_codes.items():
                    if code in error_codes:
                        add("$.errors", "INCONSISTENT_SHORTFALL_ERROR", f"{code} cannot remain when {key} reached its target")
            else:
                if not shortfalls:
                    add("$.stage", "DEGRADED_WITHOUT_SHORTFALL", "selected-degraded is allowed only when an actual funnel count is below target")
                if expected_counts["presented"] < 1 or expected_counts["presented"] > 9:
                    add("$.actual.presented", "DEGRADED_PRESENTATION_INVALID", "degraded selection must present between 1 and 9 valid candidates")
                for key in shortfalls:
                    required_code = global_shortfall_codes[key]
                    if required_code not in error_codes:
                        add("$.errors", "DEGRADED_REASON_MISSING", f"{key} shortfall requires {required_code}")
            if not isinstance(selected, dict):
                add("$.selected", "SELECTION_MISSING", "selected stage requires a selected candidate")
            else:
                if selected.get("candidate_id") not in presented_ids:
                    add("$.selected.candidate_id", "SELECTED_NOT_PRESENTED", "selected candidate must be presented")
                else:
                    presented_item = next(
                        item for item in presented if isinstance(item, dict) and item.get("candidate_id") == selected.get("candidate_id")
                    )
                    if selected.get("option_label") != presented_item.get("option_label"):
                        add("$.selected.option_label", "SELECTION_LABEL_MISMATCH", "selected option_label must match its A–I board label")
                source_candidate = by_id.get(selected.get("candidate_id"), {})
                if source_candidate.get("query_role") != "foundation" or selected.get("query_role") != "foundation":
                    add("$.selected.query_role", "FOUNDATION_REQUIRED", "the selected source must be a foundation-query candidate")
                if selected.get("prompt_sha256") != source_candidate.get("prompt_sha256"):
                    add("$.selected.prompt_sha256", "HASH_MISMATCH", "selected prompt hash must match candidate metadata")
                for field in ("provider_item_id", "query_role", "source_url", "normalized_directives"):
                    if selected.get(field) != source_candidate.get(field):
                        add(f"$.selected.{field}", "SELECTION_METADATA_MISMATCH", f"selected {field} must exactly match candidate metadata")
                selected_url_issue = _provider_url_issue(selected.get("source_url"), source=True)
                if selected_url_issue:
                    add("$.selected.source_url", "PROVIDER_URL_INVALID", selected_url_issue)
        if instance.get("board_ready") or stage in {"selected", "selected-degraded"}:
            if not presented:
                add("$.presented_candidates", "BOARD_EMPTY", "a ready board must contain at least one valid option")
            presented_provider_ids: list[Any] = []
            presented_sources: list[Any] = []
            presented_previews: list[Any] = []
            diversity_signatures: set[tuple[str, str, str]] = set()
            for index, item in enumerate(presented):
                if not isinstance(item, dict):
                    continue
                candidate = by_id.get(item.get("candidate_id")) or {}
                presented_provider_ids.append(candidate.get("provider_item_id"))
                presented_sources.append(candidate.get("source_url"))
                presented_previews.append(candidate.get("preview_url"))
                if item.get("score") is None or not item.get("rationale") or not item.get("fit_reason"):
                    add(f"$.presented_candidates[{index}]", "EVALUATION_MISSING", "a ready board requires fit_reason, score, and rationale")
                breakdown = item.get("score_breakdown") or {}
                values = list(breakdown.values()) if isinstance(breakdown, dict) else []
                if any(value is None for value in values) or len(values) != 6:
                    add(f"$.presented_candidates[{index}].score_breakdown", "SCORE_BREAKDOWN_MISSING", "selected stage requires all six scoring dimensions")
                elif item.get("score") is not None and abs(sum(float(value) for value in values) - float(item["score"])) > 1e-9:
                    add(f"$.presented_candidates[{index}].score", "SCORE_SUM_MISMATCH", "score must equal the six score_breakdown values")
                axes = item.get("visual_axes") or {}
                for axis in ("structure", "typography", "surface", "color", "imagery", "motion", "tone"):
                    if not axes.get(axis):
                        add(f"$.presented_candidates[{index}].visual_axes.{axis}", "VISUAL_AXIS_MISSING", "a ready board requires all seven visual axes")
                if all(axes.get(axis) for axis in ("structure", "surface", "typography")):
                    diversity_signatures.add(tuple(re.sub(r"\s+", " ", str(axes[axis]).casefold()).strip() for axis in ("structure", "surface", "typography")))
            for values, code, label in (
                (presented_provider_ids, "DUPLICATE_BOARD_PROVIDER_ITEM", "provider item IDs"),
                (presented_sources, "DUPLICATE_BOARD_SOURCE_URL", "source URLs"),
                (presented_previews, "DUPLICATE_BOARD_PREVIEW_URL", "preview URLs"),
            ):
                if any(value is None for value in values) or len(values) != len(set(values)):
                    add("$.presented_candidates", code, f"a ready board requires unique nonempty {label}")
            required_diversity = min(3, len(presented))
            if len(diversity_signatures) < required_diversity:
                add("$.presented_candidates", "BOARD_DIVERSITY_INSUFFICIENT", f"a ready board needs at least {required_diversity} distinct structure/surface/typography signatures")

        if stage in {"selected", "selected-degraded"}:
            support = instance.get("supporting_sources") or []
            roles = [item.get("role") for item in support if isinstance(item, dict)]
            if len(roles) != len(set(roles)):
                add("$.supporting_sources", "DUPLICATE_SUPPORT_ROLE", "at most one section and one motion supporting source are allowed")
            selected_id = selected.get("candidate_id") if isinstance(selected, dict) else None
            for index, item in enumerate(support):
                if not isinstance(item, dict):
                    continue
                candidate_id = item.get("candidate_id")
                candidate = by_id.get(candidate_id)
                if candidate is None or candidate_id not in retrieval:
                    add(f"$.supporting_sources[{index}].candidate_id", "SUPPORT_NOT_RETRIEVED", "supporting source must be a prompt-retrieved candidate")
                    continue
                if candidate_id == selected_id:
                    add(f"$.supporting_sources[{index}].candidate_id", "SUPPORT_DUPLICATES_FOUNDATION", "supporting source must differ from the foundation source")
                if item.get("query_role") != item.get("role") or candidate.get("query_role") != item.get("role"):
                    add(f"$.supporting_sources[{index}].query_role", "SUPPORT_ROLE_MISMATCH", "supporting source query_role must match its section or motion role")
                if item.get("prompt_sha256") != candidate.get("prompt_sha256"):
                    add(f"$.supporting_sources[{index}].prompt_sha256", "HASH_MISMATCH", "supporting prompt hash must match candidate metadata")
                for field in ("provider_item_id", "query_role", "source_url", "normalized_directives"):
                    if item.get(field) != candidate.get(field):
                        add(f"$.supporting_sources[{index}].{field}", "SUPPORT_METADATA_MISMATCH", f"supporting {field} must exactly match candidate metadata")
                if item.get("role") == "section":
                    if not item.get("target_page_path") or not item.get("target_section"):
                        add(
                            f"$.supporting_sources[{index}]",
                            "SECTION_TARGET_REQUIRED",
                            "section supporting source requires explicit target_page_path and target_section",
                        )
                elif item.get("target_page_path") is not None or item.get("target_section") is not None:
                    add(
                        f"$.supporting_sources[{index}]",
                        "MOTION_TARGET_FORBIDDEN",
                        "motion supporting source is site-wide motion guidance and must keep section targets null",
                    )
        elif selected is not None:
            add("$.selected", "PREMATURE_SELECTION", "normalized stage must keep selected null")
        elif instance.get("supporting_sources"):
            add("$.supporting_sources", "PREMATURE_SUPPORT", "normalized stage must keep supporting_sources empty")

        def contains_raw_prompt(value: Any) -> bool:
            if isinstance(value, dict):
                return any(
                    re.sub(r"[^a-z0-9]", "", str(key).casefold()).endswith("prompt")
                    or contains_raw_prompt(child)
                    for key, child in value.items()
                )
            if isinstance(value, list):
                return any(contains_raw_prompt(child) for child in value)
            return False

        if contains_raw_prompt(instance):
            add("$", "RAW_PROMPT_PERSISTED", "visual-selection must never persist a raw provider prompt")

    elif version == "seo-manifest/v1":
        origin = instance.get("canonical_origin")
        launch_ready = instance.get("launch_ready")
        blockers = instance.get("launch_blockers") or []
        if launch_ready:
            if not origin:
                add("$.canonical_origin", "CANONICAL_ORIGIN_REQUIRED", "launch-ready manifest requires canonical_origin")
            if instance.get("host_policy") == "unresolved":
                add("$.host_policy", "HOST_POLICY_UNRESOLVED", "launch-ready manifest needs a resolved host policy")
            if blockers:
                add("$.launch_blockers", "READY_WITH_BLOCKERS", "launch-ready manifest cannot contain blockers")
            entity = instance.get("entity") or {}
            for field in ("organization_id", "website_id", "url", "logo"):
                value = entity.get(field)
                if value is None and field == "logo":
                    continue
                if value is None:
                    add(f"$.entity.{field}", "ENTITY_URL_REQUIRED", f"launch-ready entity {field} is required")
                    continue
                parsed_value = urlparse(value)
                if (
                    parsed_value.scheme != "https"
                    or parsed_value.username is not None
                    or parsed_value.password is not None
                    or not origin
                    or f"{parsed_value.scheme}://{parsed_value.netloc}" != origin
                ):
                    add(f"$.entity.{field}", "ENTITY_ORIGIN_MISMATCH", f"launch-ready entity {field} must be credential-free HTTPS on canonical_origin")
        elif not blockers:
            add("$.launch_blockers", "LAUNCH_BLOCKER_REQUIRED", "non-ready manifest must explain at least one blocker")
        if origin:
            parsed_origin = urlparse(origin)
            if (
                parsed_origin.scheme != "https"
                or not parsed_origin.netloc
                or parsed_origin.username is not None
                or parsed_origin.password is not None
                or parsed_origin.path
                or parsed_origin.params
                or parsed_origin.query
                or parsed_origin.fragment
            ):
                add(
                    "$.canonical_origin",
                    "CANONICAL_ORIGIN_INVALID",
                    "canonical_origin must be a credential-free HTTPS origin with no path, query, or fragment",
                )
        routes = instance.get("routes") or []
        paths = [route.get("path") for route in routes if isinstance(route, dict)]
        canonicals = [
            route.get("canonical")
            for route in routes
            if isinstance(route, dict) and route.get("canonical") is not None
        ]
        if len(paths) != len(set(paths)):
            add("$.routes", "DUPLICATE_ROUTE", "SEO route paths must be unique")
        if len(canonicals) != len(set(canonicals)):
            add("$.routes", "DUPLICATE_CANONICAL", "SEO canonical URLs must be unique")
        by_canonical = {
            route.get("canonical"): route
            for route in routes
            if isinstance(route, dict) and route.get("canonical") is not None
        }
        for index, route in enumerate(routes):
            if not isinstance(route, dict):
                continue
            canonical = route.get("canonical", "")
            if launch_ready and canonical is None and route.get("indexable"):
                add(f"$.routes[{index}].canonical", "CANONICAL_REQUIRED", "launch-ready indexable route needs canonical")
            controlled_urls = [("canonical", canonical), ("social_image", route.get("social_image"))]
            for field, value in controlled_urls:
                if value is None:
                    continue
                parsed = urlparse(value)
                same_origin = bool(origin and f"{parsed.scheme}://{parsed.netloc}" == origin)
                if launch_ready and (
                    parsed.scheme != "https"
                    or parsed.username is not None
                    or parsed.password is not None
                    or not same_origin
                ):
                    add(
                        f"$.routes[{index}].{field}",
                        "CONTROLLED_URL_INVALID",
                        f"launch-ready {field} must be credential-free HTTPS on canonical_origin",
                    )
            alternates = route.get("alternates") or []
            for alt_index, alternate in enumerate(alternates):
                if not isinstance(alternate, dict):
                    continue
                alternate_url = alternate.get("url")
                if alternate_url is None and not launch_ready:
                    continue
                target = by_canonical.get(alternate_url)
                if launch_ready and alternate_url:
                    parsed_alternate = urlparse(alternate_url)
                    if (
                        parsed_alternate.scheme != "https"
                        or parsed_alternate.username is not None
                        or parsed_alternate.password is not None
                        or not origin
                        or f"{parsed_alternate.scheme}://{parsed_alternate.netloc}" != origin
                    ):
                        add(
                            f"$.routes[{index}].alternates[{alt_index}].url",
                            "CONTROLLED_URL_INVALID",
                            "launch-ready alternate must be credential-free HTTPS on canonical_origin",
                        )
                if target is None:
                    add(f"$.routes[{index}].alternates[{alt_index}].url", "ALTERNATE_UNKNOWN", "alternate URL must identify another manifest route")
                    continue
                reciprocal_urls = {item.get("url") for item in target.get("alternates", []) if isinstance(item, dict)}
                if canonical not in reciprocal_urls:
                    add(f"$.routes[{index}].alternates[{alt_index}]", "HREFLANG_NOT_RECIPROCAL", "alternate target must link back to this canonical")

    elif version == "build-contract/v1":
        def contains_raw_prompt(value: Any) -> bool:
            if isinstance(value, dict):
                return any(
                    re.sub(r"[^a-z0-9]", "", str(key).casefold()).endswith("prompt")
                    or contains_raw_prompt(child)
                    for key, child in value.items()
                )
            if isinstance(value, list):
                return any(contains_raw_prompt(child) for child in value)
            return False

        if contains_raw_prompt(instance):
            add("$", "RAW_PROMPT_PERSISTED", "build-contract must contain normalized directives and hash, never raw prompt")
        visual_source = instance.get("visual_source") or {}
        source_url_issue = _provider_url_issue(visual_source.get("source_url"), source=True)
        if source_url_issue:
            add("$.visual_source.source_url", "PROVIDER_URL_INVALID", source_url_issue)
        if any(value not in _SAFE_DIRECTIVE_VALUES for value in visual_source.get("normalized_directives", [])):
            add("$.visual_source.normalized_directives", "UNSAFE_DIRECTIVE", "visual source directives must use the fixed safe taxonomy")
        section_pairs = {
            (item.get("page_path"), item.get("id"))
            for item in instance.get("sections", [])
            if isinstance(item, dict)
        }
        support_roles: list[Any] = []
        for index, item in enumerate(instance.get("supporting_sources", [])):
            if not isinstance(item, dict):
                continue
            support_roles.append(item.get("role"))
            if item.get("query_role") != item.get("role"):
                add(f"$.supporting_sources[{index}].query_role", "SUPPORT_ROLE_MISMATCH", "support query_role must match its section or motion role")
            support_url_issue = _provider_url_issue(item.get("source_url"), source=True)
            if support_url_issue:
                add(f"$.supporting_sources[{index}].source_url", "PROVIDER_URL_INVALID", support_url_issue)
            if any(value not in _SAFE_DIRECTIVE_VALUES for value in item.get("normalized_directives", [])):
                add(f"$.supporting_sources[{index}].normalized_directives", "UNSAFE_DIRECTIVE", "support directives must use the fixed safe taxonomy")
            if item.get("role") == "section":
                target_section = str(item.get("target_section") or "").strip().lower().replace(" ", "-")
                if (item.get("target_page_path"), target_section) not in section_pairs:
                    add(f"$.supporting_sources[{index}]", "SECTION_TARGET_UNKNOWN", "section support target must identify an emitted contract section")
            elif item.get("target_page_path") is not None or item.get("target_section") is not None:
                add(f"$.supporting_sources[{index}]", "MOTION_TARGET_FORBIDDEN", "motion support must keep page and section targets null")
        if len(support_roles) != len(set(support_roles)):
            add("$.supporting_sources", "DUPLICATE_SUPPORT_ROLE", "build contract allows at most one section and one motion source")

    elif version == "provenance/v1":
        try:
            package_version = (PACKAGE_ROOT / "VERSION").read_text(encoding="utf-8").strip()
        except OSError:
            package_version = ""
        if not package_version or instance.get("workflow_version") != package_version:
            add("$.workflow_version", "WORKFLOW_VERSION_MISMATCH", "workflow_version must exactly match the package VERSION")
        sources = instance.get("sources") or []
        roles = [item.get("role") for item in sources if isinstance(item, dict)]
        candidate_ids = [item.get("candidate_id") for item in sources if isinstance(item, dict)]
        for index, source in enumerate(sources):
            if not isinstance(source, dict):
                continue
            url_issue = _provider_url_issue(source.get("source_url"), source=True)
            if url_issue:
                add(f"$.sources[{index}].source_url", "PROVIDER_URL_INVALID", url_issue)
        if roles.count("foundation") != 1:
            add("$.sources", "FOUNDATION_SOURCE_REQUIRED", "provenance must contain exactly one selected 21st Foundation source")
        if len(candidate_ids) != len(set(candidate_ids)):
            add("$.sources", "DUPLICATE_SOURCE_CANDIDATE", "provenance source candidate IDs must be unique")

    elif version == "qa-report/v1":
        checks = instance.get("checks") or []
        summary = instance.get("summary") or {}
        passed_count = sum(1 for item in checks if isinstance(item, dict) and item.get("status") == "pass")
        failed_count = sum(1 for item in checks if isinstance(item, dict) and item.get("status") == "fail")
        warning_count = sum(1 for item in checks if isinstance(item, dict) and item.get("status") == "warn")
        expected = {"checks": len(checks), "passed": passed_count, "failed": failed_count, "warnings": warning_count}
        for key, value in expected.items():
            if summary.get(key) != value:
                add(f"$.summary.{key}", "SUMMARY_MISMATCH", f"expected {value} from checks")
        if instance.get("passed") != (failed_count == 0):
            add("$.passed", "PASSED_MISMATCH", "passed must be true exactly when no check failed")

    return issues


def _provenance_binding_issues(
    provenance: Any,
    selection: Any,
    selection_sha256: str,
) -> list[dict[str, str]]:
    issues: list[dict[str, str]] = []

    def add(path: str, code: str, message: str) -> None:
        issues.append({"path": path, "code": code, "message": message})

    if not isinstance(provenance, dict) or provenance.get("schema_version") != "provenance/v1":
        return issues
    if not isinstance(selection, dict) or selection.get("schema_version") != "visual-selection/v1":
        add("$", "SELECTION_BINDING_INVALID", "provenance binding requires a valid visual-selection/v1 document")
        return issues
    if provenance.get("visual_selection_sha256") != selection_sha256:
        add("$.visual_selection_sha256", "SELECTION_HASH_MISMATCH", "provenance must hash the exact selected visual-selection file")
    selected = selection.get("selected")
    if selection.get("stage") not in {"selected", "selected-degraded"} or not isinstance(selected, dict):
        add("$", "SELECTION_NOT_FINAL", "provenance can bind only to a completed visual selection")
        return issues
    candidates = {
        item.get("candidate_id"): item
        for item in selection.get("searched_candidates", [])
        if isinstance(item, dict) and item.get("candidate_id")
    }
    expected: list[dict[str, Any]] = [{
        "role": "foundation",
        "candidate_id": selected.get("candidate_id"),
        "item_id": selected.get("provider_item_id"),
        "source_url": selected.get("source_url"),
        "prompt_sha256": selected.get("prompt_sha256"),
    }]
    for support in selection.get("supporting_sources", []):
        if not isinstance(support, dict):
            continue
        expected.append({
            "role": f"{support.get('role')}-support",
            "candidate_id": support.get("candidate_id"),
            "item_id": support.get("provider_item_id"),
            "source_url": support.get("source_url"),
            "prompt_sha256": support.get("prompt_sha256"),
        })
    sources = provenance.get("sources") or []
    by_role = {
        item.get("role"): item
        for item in sources
        if isinstance(item, dict) and item.get("role")
    }
    if len(sources) != len(expected) or set(by_role) != {item["role"] for item in expected}:
        add("$.sources", "SOURCE_SET_MISMATCH", "provenance sources must exactly match the selected Foundation and scoped supporting sources")
    retrieval_method = selection.get("source")
    for item in expected:
        source = by_role.get(item["role"])
        if not isinstance(source, dict):
            continue
        candidate = candidates.get(item["candidate_id"]) or {}
        expected_values = {
            "candidate_id": item["candidate_id"],
            "provider": "21st",
            "item_id": item["item_id"],
            "source_url": item["source_url"],
            "retrieval_method": retrieval_method,
            "prompt_sha256": item["prompt_sha256"],
            "payload_sha256": candidate.get("retrieval_response_sha256"),
        }
        for field, expected_value in expected_values.items():
            if source.get(field) != expected_value:
                add(f"$.sources[{item['role']}].{field}", "SOURCE_BINDING_MISMATCH", f"{field} must match the selected 21st retrieval evidence")
    return issues


def make_report(
    scope: str,
    checks: Sequence[Mapping[str, Any]],
    artifacts: Mapping[str, Any] | None = None,
    external_pending: Sequence[str] | None = None,
) -> dict[str, Any]:
    normalized: list[dict[str, Any]] = []
    errors: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []
    for raw in checks:
        item = {
            "code": str(raw.get("code", "CHECK")),
            "status": str(raw.get("status", "fail")),
            "message": str(raw.get("message", "No message supplied")),
        }
        if "path" in raw:
            item["path"] = raw.get("path")
        if "details" in raw:
            item["details"] = raw.get("details")
        normalized.append(item)
        compact = {"code": item["code"], "message": item["message"], "path": item.get("path")}
        if item["status"] == "fail":
            errors.append(compact)
        elif item["status"] == "warn":
            warnings.append(compact)
    return {
        "schema_version": "qa-report/v1",
        "scope": scope,
        "passed": not errors,
        "summary": {
            "checks": len(normalized),
            "passed": sum(1 for item in normalized if item["status"] == "pass"),
            "failed": len(errors),
            "warnings": len(warnings),
        },
        "checks": normalized,
        "errors": errors,
        "warnings": warnings,
        "artifacts": dict(artifacts or {}),
        **({"external_pending": list(external_pending)} if external_pending else {}),
    }


def output_report(report: Mapping[str, Any], output: str | Path | None) -> None:
    if output:
        write_json(output, report)
    else:
        print(json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2))


_SECRET_PATTERNS = (
    ("TWENTY_FIRST_SECRET", re.compile("21" + r"st_sk_[A-Za-z0-9_-]{12,}")),
    (
        "TWENTY_FIRST_ENV_VALUE",
        re.compile(
            r"(?im)\b(?:API_KEY_21ST|TWENTYFIRST_TOKEN)\b\s*[:=]\s*[\"']?"
            r"(?!(?:\$\{|<|YOUR_|REPLACE_|EXAMPLE_|CHANGEME|REDACTED))"
            r"[A-Za-z0-9._~-]{12,}"
        ),
    ),
    (
        "AUTHORIZATION_BEARER",
        re.compile(
            r"(?im)\bAuthorization\b\s*[:=]\s*[\"']?Bearer\s+"
            r"(?!(?:\$\{|<|YOUR_|REPLACE_|EXAMPLE_|CHANGEME|REDACTED))"
            r"[A-Za-z0-9._~+/-]{12,}"
        ),
    ),
    ("JWT_TOKEN", re.compile(r"\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b")),
    (
        "CREDENTIAL_QUERY_PARAMETER",
        re.compile(
            r"(?i)[?&](?:api[-_]?key|access[-_]?token|token|secret|credential|authorization|auth|signature|jwt)="
            r"(?!(?:\$\{|%24%7B|%3C|<|YOUR_|REPLACE_|EXAMPLE_|CHANGEME|REDACTED))"
            r"[^&#\s\"']{8,}"
        ),
    ),
    ("OPENAI_SECRET", re.compile("s" + r"k-[A-Za-z0-9_-]{20,}")),
    ("GITHUB_TOKEN", re.compile("g" + r"hp_[A-Za-z0-9]{30,}")),
    ("GITHUB_FINE_GRAINED_TOKEN", re.compile("github" + r"_pat_[A-Za-z0-9_]{30,}")),
    ("AWS_ACCESS_KEY", re.compile("A" + r"KIA[0-9A-Z]{16}")),
    ("PRIVATE_KEY", re.compile("-----BEGIN " + r"(?:RSA |EC |OPENSSH )?PRIVATE KEY-----")),
)
_TEXT_SUFFIXES = {
    "",
    ".astro",
    ".css",
    ".html",
    ".js",
    ".json",
    ".jsx",
    ".md",
    ".mjs",
    ".py",
    ".sh",
    ".svg",
    ".toml",
    ".ts",
    ".tsx",
    ".txt",
    ".yaml",
    ".yml",
}


def scan_text_secrets(text: str, label: str) -> list[dict[str, str]]:
    findings: list[dict[str, str]] = []
    safe_label = label
    for _, secret_pattern in _SECRET_PATTERNS:
        safe_label = secret_pattern.sub("[redacted]", safe_label)
    for code, pattern in _SECRET_PATTERNS:
        for match in pattern.finditer(text):
            line = text.count("\n", 0, match.start()) + 1
            findings.append({
                "code": code,
                "path": safe_label,
                "message": f"possible secret at line {line}; value redacted",
            })
    return findings


def scan_secrets(paths: Iterable[Path], max_bytes: int = 2_000_000) -> list[dict[str, str]]:
    findings: list[dict[str, str]] = []
    for path in sorted(set(paths), key=lambda item: str(item)):
        if not path.is_file() or path.suffix.lower() not in _TEXT_SUFFIXES:
            continue
        try:
            if path.stat().st_size > max_bytes:
                continue
            text = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        findings.extend(scan_text_secrets(text, str(path)))
    return findings


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Validate one or more workflow JSON files against a bundled schema.",
        epilog="Known schema names: " + ", ".join(sorted(SCHEMA_ALIASES)),
    )
    parser.add_argument("--schema", required=True, help="Bundled schema name/version or explicit schema path")
    parser.add_argument("--input", action="append", required=True, help="JSON input path; repeat for multiple files")
    parser.add_argument("--selection", help="Exact visual-selection/v1 file; required when validating provenance/v1")
    parser.add_argument("--output", help="Optional explicit JSON report path; otherwise report is printed")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    checks: list[dict[str, Any]] = []
    artifacts: dict[str, Any] = {"inputs": []}
    try:
        schema_path = resolve_schema(args.schema)
        schema = load_json(schema_path, "schema")
        if not isinstance(schema, dict):
            raise InputError(f"schema root must be a JSON object: {schema_path}")
        artifacts["schema"] = str(schema_path)
        artifacts["schema_sha256"] = sha256_file(schema_path)
        schema_id = str(schema.get("$id", ""))
        provenance_mode = schema_id.endswith("/provenance/v1")
        selection: dict[str, Any] | None = None
        selection_hash: str | None = None
        if provenance_mode:
            if not args.selection:
                raise InputError("PROVENANCE_SELECTION_REQUIRED: --selection must identify the exact final visual-selection/v1 file")
            selection_path = Path(args.selection).expanduser().resolve()
            selection = load_json(selection_path, "visual selection")
            selection_schema = load_json(resolve_schema("visual-selection"), "visual selection schema")
            selection_issues = validate_instance(selection, selection_schema)
            if selection_issues:
                first = selection_issues[0]
                raise InputError(f"provenance selection failed validation: {first['path']} {first['code']}: {first['message']}")
            selection_hash = sha256_file(selection_path)
            artifacts["selection"] = {"path": str(selection_path), "sha256": selection_hash}
        elif args.selection:
            raise InputError("--selection is valid only with the provenance/v1 schema")
        for raw_path in args.input:
            path = Path(raw_path).expanduser().resolve()
            value = load_json(path)
            issues = validate_instance(value, schema)
            if provenance_mode and selection is not None and selection_hash is not None:
                issues.extend(_provenance_binding_issues(value, selection, selection_hash))
            artifacts["inputs"].append({"path": str(path), "sha256": sha256_file(path)})
            if issues:
                for issue in issues:
                    checks.append({
                        "code": "INPUT_" + issue["code"],
                        "status": "fail",
                        "message": issue["message"],
                        "path": f"{path}:{issue['path']}",
                    })
            else:
                checks.append({"code": "INPUT_VALID", "status": "pass", "message": "input satisfies schema", "path": str(path)})
    except InputError as error:
        checks.append({"code": "INPUT_ERROR", "status": "fail", "message": str(error)})
    report = make_report("input-validation", checks, artifacts)
    try:
        output_report(report, args.output)
    except InputError as error:
        print(f"validate_inputs.py: {error}", file=sys.stderr)
        return 2
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
