#!/usr/bin/env python3
"""Statically verify a framework-free native Astro static-site project."""

from __future__ import annotations

import argparse
import json
import re
import sys

sys.dont_write_bytecode = True
from pathlib import Path
from typing import Any, Sequence

from validate_inputs import InputError, load_json, make_report, output_report


FORBIDDEN_PACKAGES = {
    "@astrojs/react",
    "@astrojs/solid-js",
    "@astrojs/svelte",
    "@astrojs/vue",
    "@vitejs/plugin-react",
    "next",
    "nuxt",
    "react",
    "react-dom",
    "framer-motion",
    "motion",
    "solid-js",
    "svelte",
    "tailwindcss",
    "@tailwindcss/vite",
    "@tailwindcss/postcss",
    "vue",
}
FORBIDDEN_SOURCE_PATTERNS = (
    ("FORBIDDEN_UI_IMPORT", re.compile(r"(?:from\s+|import\s*\()[\"'](?:react|react-dom|vue|svelte|solid-js|next|@astrojs/(?:react|vue|svelte|solid-js))")),
    ("PROVIDER_SOURCE_MARKER", re.compile(r"(?:21st\.dev|@21st|twenty[-_ ]first)", re.IGNORECASE)),
    ("SHADCN_MARKER", re.compile(r"(?:shadcn|components/ui/)", re.IGNORECASE)),
    ("TAILWIND_SOURCE_MARKER", re.compile(r"(?:@tailwind|@import\s+[\"']tailwindcss|\bclass:list=.*(?:bg-|text-|grid-cols-))", re.IGNORECASE)),
    ("FRAMEWORK_CLIENT_DIRECTIVE", re.compile(r"\bclient:(?:load|idle|visible|media|only)\b", re.IGNORECASE)),
)
TEXT_SUFFIXES = {".astro", ".css", ".js", ".jsx", ".mjs", ".ts", ".tsx"}


def _check(code: str, passed: bool, message: str, path: str | None = None, warn: bool = False) -> dict[str, Any]:
    item: dict[str, Any] = {"code": code, "status": "pass" if passed else ("warn" if warn else "fail"), "message": message}
    if path is not None:
        item["path"] = path
    return item


def audit(project: Path) -> dict[str, Any]:
    if not project.exists() or not project.is_dir():
        raise InputError(f"project is missing or not a directory: {project}")
    if project.is_symlink():
        raise InputError(f"project root must not be a symbolic link: {project}")
    project = project.resolve()
    checks: list[dict[str, Any]] = []

    package_path = project / "package.json"
    if not package_path.is_file() or package_path.is_symlink():
        checks.append(_check("PACKAGE_JSON_MISSING", False, "package.json must be a regular non-symlink file", "package.json"))
        package: dict[str, Any] = {}
    else:
        try:
            value = load_json(package_path, "package.json")
            package = value if isinstance(value, dict) else {}
            checks.append(_check("PACKAGE_JSON_VALID", isinstance(value, dict), "package.json is valid JSON object" if isinstance(value, dict) else "package.json root must be an object", "package.json"))
        except InputError as error:
            package = {}
            checks.append(_check("PACKAGE_JSON_VALID", False, str(error), "package.json"))
    dependencies: dict[str, Any] = {}
    for field in ("dependencies", "devDependencies"):
        value = package.get(field)
        if isinstance(value, dict):
            dependencies.update(value)
    checks.append(_check("ASTRO_DEPENDENCY_PRESENT", "astro" in dependencies, "Astro is declared as a dependency" if "astro" in dependencies else "package.json must declare astro", "package.json"))
    build_script = (package.get("scripts") or {}).get("build") if isinstance(package.get("scripts"), dict) else None
    checks.append(_check("ASTRO_BUILD_SCRIPT", isinstance(build_script, str) and bool(re.search(r"(?:^|\s)astro\s+build(?:\s|$)", build_script)), "build script invokes `astro build`" if isinstance(build_script, str) else "package.json scripts.build is missing", "package.json"))
    forbidden = sorted(FORBIDDEN_PACKAGES.intersection(dependencies))
    checks.append(_check("FORBIDDEN_UI_DEPENDENCIES", not forbidden, "no forbidden client UI framework dependencies found" if not forbidden else f"forbidden dependencies: {', '.join(forbidden)}", "package.json"))

    config_candidates = [project / name for name in ("astro.config.mjs", "astro.config.js", "astro.config.ts") if (project / name).exists()]
    checks.append(_check("ASTRO_CONFIG_SINGLE", len(config_candidates) == 1, "exactly one Astro config is present" if len(config_candidates) == 1 else f"expected exactly one Astro config, found {len(config_candidates)}"))
    config_text = ""
    if len(config_candidates) == 1:
        config_path = config_candidates[0]
        if config_path.is_symlink():
            checks.append(_check("ASTRO_CONFIG_SYMLINK", False, "Astro config must not be a symbolic link", str(config_path.relative_to(project))))
        else:
            try:
                config_text = config_path.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError) as error:
                checks.append(_check("ASTRO_CONFIG_READ", False, f"cannot read Astro config: {error}", str(config_path.relative_to(project))))
            if config_text:
                uses_define = bool(re.search(r"from\s+[\"']astro/config[\"']", config_text) and re.search(r"\bdefineConfig\s*\(", config_text))
                checks.append(_check("ASTRO_CONFIG_NATIVE", uses_define, "config imports defineConfig from astro/config" if uses_define else "config must use defineConfig from astro/config", str(config_path.relative_to(project))))
                server_output = bool(re.search(r"output\s*:\s*[\"']server[\"']", config_text))
                hybrid_output = bool(re.search(r"output\s*:\s*[\"']hybrid[\"']", config_text))
                checks.append(_check("ASTRO_STATIC_OUTPUT", not server_output and not hybrid_output, "Astro output is static (explicit or default)" if not server_output and not hybrid_output else "server/hybrid output is forbidden", str(config_path.relative_to(project))))
                has_site = bool(re.search(r"\bsite\s*:\s*[\"']https://", config_text))
                checks.append(_check("ASTRO_SITE_ORIGIN", has_site, "Astro config has an HTTPS site origin" if has_site else "Astro config has no production HTTPS site origin; canonical launch remains unresolved", str(config_path.relative_to(project)), warn=not has_site))

    pages_root = project / "src" / "pages"
    page_files = sorted(pages_root.rglob("*.astro")) if pages_root.is_dir() and not pages_root.is_symlink() else []
    checks.append(_check("ASTRO_PAGES_PRESENT", bool(page_files), "native .astro page routes are present" if page_files else "src/pages must contain at least one .astro page", "src/pages"))
    if pages_root.is_symlink():
        checks.append(_check("SOURCE_SYMLINK_FORBIDDEN", False, "src/pages must not be a symbolic link", "src/pages"))

    source_root = project / "src"
    source_files = sorted(
        (path for path in source_root.rglob("*") if path.is_file() and path.suffix.lower() in TEXT_SUFFIXES),
        key=lambda path: str(path),
    ) if source_root.is_dir() else []
    jsx_tsx = [path for path in source_root.rglob("*") if path.is_file() and path.suffix.lower() in {".jsx", ".tsx"}] if source_root.is_dir() else []
    checks.append(_check("JSX_TSX_FORBIDDEN", not jsx_tsx, "no JSX/TSX source files found" if not jsx_tsx else f"native Astro profile forbids JSX/TSX files: {[str(path.relative_to(project)) for path in jsx_tsx]}"))
    tailwind_configs = [path for pattern in ("tailwind.config.*", "postcss.config.*") for path in project.glob(pattern)]
    checks.append(_check("TAILWIND_CONFIG_FORBIDDEN", not tailwind_configs, "no Tailwind/PostCSS framework config found" if not tailwind_configs else f"native CSS profile forbids config files: {[path.name for path in tailwind_configs]}"))
    provider_hits = 0
    for path in source_files:
        relative = str(path.relative_to(project))
        if path.is_symlink():
            checks.append(_check("SOURCE_SYMLINK_FORBIDDEN", False, "source files must not be symbolic links", relative))
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError) as error:
            checks.append(_check("SOURCE_READ_ERROR", False, f"cannot read source: {error}", relative))
            continue
        for code, pattern in FORBIDDEN_SOURCE_PATTERNS:
            if pattern.search(text):
                provider_hits += 1
                checks.append(_check(code, False, "source contains a forbidden framework/provider reuse marker", relative))
    if not provider_hits:
        checks.append(_check("SOURCE_POLICY_CLEAN", True, "no client UI framework, shadcn, or provider-source markers found under src"))

    placeholder_patterns = (
        ("Northstar Works", "starter company name"),
        (".invalid", "reserved placeholder domain"),
        ("@example.invalid", "placeholder contact address"),
    )
    placeholder_hits: list[str] = []
    for path in [*source_files, *config_candidates]:
        if not path.is_file() or path.is_symlink():
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        for needle, label in placeholder_patterns:
            if needle.casefold() in text.casefold():
                placeholder_hits.append(f"{path.relative_to(project)}: {label}")
    checks.append(_check("STARTER_PLACEHOLDERS", not placeholder_hits, "no starter launch placeholders found" if not placeholder_hits else f"replace before launch: {placeholder_hits}", warn=bool(placeholder_hits)))

    lockfiles = [name for name in ("package-lock.json", "pnpm-lock.yaml", "yarn.lock", "bun.lock", "bun.lockb") if (project / name).exists()]
    checks.append(_check("PACKAGE_MANAGER_LOCK", len(lockfiles) == 1, f"one package-manager lockfile found: {lockfiles[0]}" if len(lockfiles) == 1 else f"expected exactly one lockfile, found: {lockfiles}"))

    return make_report(
        "native-astro",
        checks,
        artifacts={"project": str(project), "astro_pages": len(page_files), "source_files": len(source_files), "lockfiles": lockfiles},
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Statically validate a native Astro static site without installing or executing project code.")
    parser.add_argument("--project", required=True, help="Astro project root")
    parser.add_argument("--strict-warnings", action="store_true", help="Return nonzero when warnings remain")
    parser.add_argument("--output", help="Optional explicit qa-report/v1 JSON output; otherwise print it")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        report = audit(Path(args.project).expanduser())
        output_report(report, args.output)
    except InputError as error:
        print(f"validate_native_astro.py: {error}", file=sys.stderr)
        return 2
    if not report["passed"] or (args.strict_warnings and report["summary"]["warnings"]):
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
