#!/usr/bin/env node

import { existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from "node:fs";
import { spawnSync } from "node:child_process";
import { createRequire } from "node:module";
import path from "node:path";
import process from "node:process";
import { parseArgs } from "node:util";

const VIEWPORTS = [
  { name: "mobile", width: 390, height: 844 },
  { name: "tablet", width: 768, height: 1024 },
  { name: "desktop", width: 1440, height: 1000 },
];
const DEFAULT_ROUTES = ["/", "/about/", "/contact/"];
const LIGHTHOUSE_THRESHOLDS = {
  performance: 85,
  accessibility: 95,
  "best-practices": 90,
  seo: 95,
  cumulativeLayoutShift: 0.1,
};

function usage() {
  return [
    "Usage: node scripts/visual_qa.mjs [options]",
    "",
    "Options:",
    "  --url <origin>       Running local preview origin (default: http://127.0.0.1:4321)",
    "  --output <dir>       New or empty screenshot/report directory",
    "  --path <route>       Route to check; repeat for multiple routes",
    "  --timeout <ms>       Navigation timeout (default: 15000)",
    "                       The first route also receives a Lighthouse audit",
    "  --help               Show this help",
  ].join("\n");
}

function fatal(message, detail) {
  console.error(`visual_qa: ERROR: ${message}`);
  if (detail) console.error(String(detail));
  process.exitCode = 2;
}

function loadDependency(name) {
  const resolvers = [
    createRequire(path.join(process.cwd(), "package.json")),
    createRequire(import.meta.url),
  ];
  const failures = [];
  for (const resolver of resolvers) {
    try {
      return resolver(name);
    } catch (error) {
      failures.push(error instanceof Error ? error.message : String(error));
    }
  }
  throw new Error(failures.join("\n"));
}

function resolveDependency(name) {
  const resolvers = [
    createRequire(path.join(process.cwd(), "package.json")),
    createRequire(import.meta.url),
  ];
  const failures = [];
  for (const resolver of resolvers) {
    try {
      return resolver.resolve(name);
    } catch (error) {
      failures.push(error instanceof Error ? error.message : String(error));
    }
  }
  throw new Error(failures.join("\n"));
}

function runLighthouse({ baseUrl, route, outputDirectory, playwright, timeout }) {
  const auditUrl = new URL(route, baseUrl).href;
  const reportPath = path.join(outputDirectory, `lighthouse-${routeSlug(route)}.json`);
  const cliPath = resolveDependency("lighthouse/cli/index.js");
  const chromePath = playwright.chromium.executablePath();
  const result = spawnSync(
    process.execPath,
    [
      cliPath,
      auditUrl,
      "--quiet",
      "--output=json",
      `--output-path=${reportPath}`,
      "--only-categories=performance,accessibility,best-practices,seo",
      `--max-wait-for-load=${Math.max(timeout, 45000)}`,
      "--chrome-flags=--headless --no-sandbox --disable-gpu",
    ],
    {
      cwd: process.cwd(),
      env: { ...process.env, CHROME_PATH: chromePath },
      encoding: "utf8",
      timeout: Math.max(timeout * 6, 120000),
      maxBuffer: 1024 * 1024,
    },
  );
  if (result.error) {
    throw new Error(`Lighthouse could not run: ${result.error.message}`);
  }
  if (result.status !== 0 || !existsSync(reportPath)) {
    throw new Error(`Lighthouse exited with status ${result.status ?? "unknown"}`);
  }

  const lhr = JSON.parse(readFileSync(reportPath, "utf8"));
  const scores = Object.fromEntries(
    ["performance", "accessibility", "best-practices", "seo"].map((category) => [
      category,
      Math.round((lhr.categories?.[category]?.score ?? 0) * 100),
    ]),
  );
  const cumulativeLayoutShift = Number(lhr.audits?.["cumulative-layout-shift"]?.numericValue ?? Number.POSITIVE_INFINITY);
  const failures = [];
  for (const category of ["performance", "accessibility", "best-practices", "seo"]) {
    if (scores[category] < LIGHTHOUSE_THRESHOLDS[category]) {
      failures.push(`${category} score ${scores[category]} is below ${LIGHTHOUSE_THRESHOLDS[category]}`);
    }
  }
  if (!(cumulativeLayoutShift < LIGHTHOUSE_THRESHOLDS.cumulativeLayoutShift)) {
    failures.push(`cumulative layout shift ${cumulativeLayoutShift} is not below ${LIGHTHOUSE_THRESHOLDS.cumulativeLayoutShift}`);
  }
  return {
    route,
    url: auditUrl,
    report: reportPath,
    scores,
    cumulativeLayoutShift,
    thresholds: LIGHTHOUSE_THRESHOLDS,
    failures,
    passed: failures.length === 0,
  };
}

function normalizeBaseUrl(value) {
  const url = new URL(value);
  if (!['http:', 'https:'].includes(url.protocol)) {
    throw new Error("--url must use http or https");
  }
  url.pathname = "/";
  url.search = "";
  url.hash = "";
  return url.href;
}

function normalizeRoute(value) {
  const trimmed = value.trim();
  if (!trimmed || trimmed.includes("://")) {
    throw new Error(`invalid route: ${value}`);
  }
  const route = trimmed.startsWith("/") ? trimmed : `/${trimmed}`;
  return route.split("#", 1)[0].split("?", 1)[0] || "/";
}

function routeSlug(route) {
  const slug = route
    .replace(/^\/+|\/+$/g, "")
    .replace(/[^a-zA-Z0-9_-]+/g, "-")
    .replace(/^-+|-+$/g, "");
  return slug || "home";
}

function prepareOutput(outputDirectory) {
  if (existsSync(outputDirectory)) {
    if (readdirSync(outputDirectory).length > 0) {
      throw new Error(`output directory is not empty: ${outputDirectory}`);
    }
  } else {
    mkdirSync(outputDirectory, { recursive: true });
  }
}

async function inspectDocument(page) {
  return page.evaluate(() => {
    const headings = [...document.querySelectorAll("h1, h2, h3, h4, h5, h6")].map((heading) => ({
      level: Number(heading.tagName.slice(1)),
      text: (heading.textContent || "").trim().replace(/\s+/g, " ").slice(0, 120),
    }));
    const headingJumps = [];
    for (let index = 1; index < headings.length; index += 1) {
      if (headings[index].level > headings[index - 1].level + 1) {
        headingJumps.push(`${headings[index - 1].text} -> ${headings[index].text}`);
      }
    }

    const links = [...document.querySelectorAll("a")];
    const linkIssues = links.flatMap((link) => {
      const accessibleName =
        link.getAttribute("aria-label") ||
        link.getAttribute("title") ||
        link.textContent?.trim() ||
        link.querySelector("img")?.getAttribute("alt") ||
        "";
      const href = link.getAttribute("href") || "";
      const issues = [];
      if (!accessibleName) issues.push("link has no accessible name");
      if (!href || href === "#" || href.toLowerCase().startsWith("javascript:")) {
        issues.push("link has an empty, fragment-only, or javascript href");
      }
      return issues.map((issue) => ({ issue, text: accessibleName.slice(0, 80), href }));
    });

    const controlIssues = [...document.querySelectorAll("button, input, select, textarea")].flatMap((control) => {
      const id = control.getAttribute("id");
      const label =
        control.getAttribute("aria-label") ||
        control.getAttribute("aria-labelledby") ||
        (id ? document.querySelector(`label[for="${CSS.escape(id)}"]`)?.textContent?.trim() : "") ||
        control.textContent?.trim() ||
        "";
      return label ? [] : [{ tag: control.tagName.toLowerCase(), id, issue: "control has no accessible name" }];
    });

    const imageIssues = [...document.querySelectorAll("img")]
      .filter((image) => !image.hasAttribute("alt"))
      .map((image) => ({ src: image.getAttribute("src"), issue: "image is missing alt" }));

    const duplicateIds = [...document.querySelectorAll("[id]")]
      .map((element) => element.id)
      .filter((id, index, ids) => ids.indexOf(id) !== index);

    const viewportWidth = document.documentElement.clientWidth;
    const overflowAmount = Math.max(0, document.documentElement.scrollWidth - viewportWidth);
    const overflowElements = overflowAmount
      ? [...document.body.querySelectorAll("*")]
          .filter((element) => {
            const rect = element.getBoundingClientRect();
            return rect.right > viewportWidth + 1 || rect.left < -1;
          })
          .slice(0, 12)
          .map((element) => ({
            tag: element.tagName.toLowerCase(),
            className: typeof element.className === "string" ? element.className.slice(0, 100) : "",
            left: Math.round(element.getBoundingClientRect().left),
            right: Math.round(element.getBoundingClientRect().right),
          }))
      : [];

    return {
      metadata: {
        title: document.title.trim(),
        language: document.documentElement.lang,
        hasMain: Boolean(document.querySelector("main")),
      },
      headings: {
        count: headings.length,
        h1Count: headings.filter((heading) => heading.level === 1).length,
        jumps: headingJumps,
        outline: headings,
      },
      links: { count: links.length, issues: linkIssues },
      controls: { issues: controlIssues },
      images: { issues: imageIssues },
      duplicateIds: [...new Set(duplicateIds)],
      overflow: {
        documentWidth: document.documentElement.scrollWidth,
        viewportWidth,
        amount: overflowAmount,
        elements: overflowElements,
      },
    };
  });
}

async function inspectFocus(page) {
  await page.evaluate(() => {
    if (document.activeElement instanceof HTMLElement) document.activeElement.blur();
    window.scrollTo(0, 0);
  });
  await page.keyboard.press("Tab");
  return page.evaluate(() => {
    const active = document.activeElement;
    if (!(active instanceof HTMLElement) || active === document.body) {
      return { passed: false, reason: "Tab did not move focus to an interactive element" };
    }
    const style = getComputedStyle(active);
    const outlineVisible = style.outlineStyle !== "none" && Number.parseFloat(style.outlineWidth) > 0;
    const boxShadowVisible = style.boxShadow !== "none";
    return {
      passed: outlineVisible || boxShadowVisible,
      tag: active.tagName.toLowerCase(),
      text: (active.getAttribute("aria-label") || active.textContent || "").trim().replace(/\s+/g, " ").slice(0, 100),
      outline: `${style.outlineWidth} ${style.outlineStyle} ${style.outlineColor}`,
      boxShadow: style.boxShadow,
      reason: outlineVisible || boxShadowVisible ? null : "focused element has no visible outline or box shadow",
    };
  });
}

async function inspectReducedMotion(page) {
  await page.emulateMedia({ reducedMotion: "reduce" });
  const result = await page.evaluate(() => {
    const toMilliseconds = (token) => {
      const value = token.trim();
      if (value.endsWith("ms")) return Number.parseFloat(value);
      if (value.endsWith("s")) return Number.parseFloat(value) * 1000;
      return 0;
    };
    const offenders = [...document.body.querySelectorAll("*")]
      .flatMap((element) => {
        const style = getComputedStyle(element);
        const animationMax = Math.max(...style.animationDuration.split(",").map(toMilliseconds), 0);
        const transitionMax = Math.max(...style.transitionDuration.split(",").map(toMilliseconds), 0);
        if (animationMax <= 20 && transitionMax <= 20) return [];
        return [{
          tag: element.tagName.toLowerCase(),
          className: typeof element.className === "string" ? element.className.slice(0, 100) : "",
          animationDuration: style.animationDuration,
          transitionDuration: style.transitionDuration,
        }];
      })
      .slice(0, 12);
    return { passed: offenders.length === 0, offenders };
  });
  await page.emulateMedia({ reducedMotion: "no-preference" });
  return result;
}

function collectFailures(run) {
  const failures = [];
  if (!run.status || run.status >= 400) failures.push(`navigation returned HTTP ${run.status ?? "unknown"}`);
  if (!run.checks.metadata.title) failures.push("document title is empty");
  if (!run.checks.metadata.language) failures.push("html lang is missing");
  if (!run.checks.metadata.hasMain) failures.push("main landmark is missing");
  if (run.checks.headings.h1Count !== 1) failures.push(`expected one h1, found ${run.checks.headings.h1Count}`);
  if (run.checks.headings.jumps.length) failures.push("heading levels are skipped");
  if (run.checks.links.issues.length) failures.push("one or more links fail basic accessible-name or href checks");
  if (run.checks.controls.issues.length) failures.push("one or more controls have no accessible name");
  if (run.checks.images.issues.length) failures.push("one or more images are missing alt text");
  if (run.checks.duplicateIds.length) failures.push("duplicate element ids were found");
  if (run.checks.overflow.amount > 1) failures.push(`horizontal overflow is ${run.checks.overflow.amount}px`);
  if (!run.checks.focus.passed) failures.push(run.checks.focus.reason || "keyboard focus check failed");
  if (!run.checks.reducedMotion.passed) failures.push("motion is not sufficiently reduced under prefers-reduced-motion");
  if (run.checks.axe.seriousCritical.length) failures.push("axe found serious or critical accessibility violations");
  if (run.runtime.consoleErrors.length) failures.push("console errors were emitted");
  if (run.runtime.pageErrors.length) failures.push("uncaught page errors were emitted");
  if (run.runtime.failedRequests.length) failures.push("one or more network requests failed");
  if (run.runtime.errorResponses.length) failures.push("one or more resources returned HTTP 4xx/5xx");
  return failures;
}

async function main() {
  let parsed;
  try {
    parsed = parseArgs({
      options: {
        url: { type: "string", default: "http://127.0.0.1:4321" },
        output: { type: "string", default: ".site-build/visual-qa" },
        path: { type: "string", multiple: true },
        timeout: { type: "string", default: "15000" },
        help: { type: "boolean", short: "h", default: false },
      },
      allowPositionals: false,
      strict: true,
    });
  } catch (error) {
    fatal("invalid arguments", `${error instanceof Error ? error.message : error}\n\n${usage()}`);
    return;
  }

  if (parsed.values.help) {
    console.log(usage());
    return;
  }

  let baseUrl;
  let routes;
  const timeout = Number.parseInt(parsed.values.timeout, 10);
  try {
    baseUrl = normalizeBaseUrl(parsed.values.url);
    routes = (parsed.values.path?.length ? parsed.values.path : DEFAULT_ROUTES).map(normalizeRoute);
    if (!Number.isFinite(timeout) || timeout < 1000 || timeout > 120000) {
      throw new Error("--timeout must be an integer from 1000 to 120000 milliseconds");
    }
  } catch (error) {
    fatal("invalid configuration", error instanceof Error ? error.message : error);
    return;
  }

  let playwright;
  let AxeBuilder;
  try {
    playwright = loadDependency("playwright");
  } catch (error) {
    fatal(
      "Playwright is not installed. Run `npm install` in the site project, then retry.",
      error instanceof Error ? error.message : error,
    );
    return;
  }
  try {
    const axeModule = loadDependency("@axe-core/playwright");
    AxeBuilder = axeModule.default ?? axeModule;
  } catch (error) {
    fatal(
      "@axe-core/playwright is not installed. Run `npm install` in the site project, then retry.",
      error instanceof Error ? error.message : error,
    );
    return;
  }

  let browser;
  try {
    browser = await playwright.chromium.launch({ headless: true });
  } catch (error) {
    fatal(
      "Chromium is unavailable. Run `npx playwright install chromium`, then retry.",
      error instanceof Error ? error.message : error,
    );
    return;
  }

  try {
    const response = await fetch(baseUrl, { signal: AbortSignal.timeout(timeout) });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
  } catch (error) {
    await browser.close();
    fatal(
      `preview is not reachable at ${baseUrl}. Start the built site before running QA.`,
      error instanceof Error ? error.message : error,
    );
    return;
  }

  const outputDirectory = path.resolve(parsed.values.output);
  try {
    prepareOutput(outputDirectory);
  } catch (error) {
    await browser.close();
    fatal("cannot prepare output directory", error instanceof Error ? error.message : error);
    return;
  }

  const generatedAt = new Date().toISOString();
  const report = {
    schemaVersion: "company-site-visual-qa/v1",
    generatedAt,
    baseUrl,
    outputDirectory,
    viewports: VIEWPORTS,
    routes,
    prerequisites: {
      node: process.version,
      browser: "chromium",
      playwright: playwright.version ?? null,
      axe: true,
    },
    runs: [],
    summary: {},
    passed: false,
  };

  try {
    for (const viewport of VIEWPORTS) {
      const context = await browser.newContext({
        viewport: { width: viewport.width, height: viewport.height },
        colorScheme: "light",
        reducedMotion: "no-preference",
      });
      for (const route of routes) {
        const page = await context.newPage();
        const runtime = { consoleErrors: [], pageErrors: [], failedRequests: [], errorResponses: [] };
        page.on("console", (message) => {
          if (message.type() === "error") runtime.consoleErrors.push(message.text());
        });
        page.on("pageerror", (error) => runtime.pageErrors.push(error.message));
        page.on("requestfailed", (request) => {
          runtime.failedRequests.push({ url: request.url(), error: request.failure()?.errorText ?? "unknown" });
        });
        page.on("response", (response) => {
          if (response.status() >= 400) runtime.errorResponses.push({ url: response.url(), status: response.status() });
        });

        const url = new URL(route, baseUrl).href;
        const screenshotName = `${routeSlug(route)}-${viewport.width}.png`;
        const screenshot = path.join(outputDirectory, screenshotName);
        const run = {
          route,
          url,
          viewport,
          status: null,
          screenshot,
          checks: null,
          runtime,
          errors: [],
        };

        try {
          const navigation = await page.goto(url, { waitUntil: "networkidle", timeout });
          run.status = navigation?.status() ?? null;
          await page.screenshot({ path: screenshot, fullPage: true, animations: "disabled" });
          const documentChecks = await inspectDocument(page);
          const focus = await inspectFocus(page);
          const reducedMotion = await inspectReducedMotion(page);
          const axeResults = await new AxeBuilder({ page })
            .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa"])
            .analyze();
          const seriousCritical = axeResults.violations
            .filter((violation) => ["serious", "critical"].includes(violation.impact))
            .map((violation) => ({
              id: violation.id,
              impact: violation.impact,
              help: violation.help,
              nodes: violation.nodes.length,
              targets: violation.nodes.slice(0, 5).map((node) => node.target),
            }));
          const otherViolations = axeResults.violations
            .filter((violation) => !["serious", "critical"].includes(violation.impact))
            .map((violation) => ({
              id: violation.id,
              impact: violation.impact,
              help: violation.help,
              nodes: violation.nodes.length,
            }));
          run.checks = {
            ...documentChecks,
            focus,
            reducedMotion,
            axe: { seriousCritical, otherViolations },
          };
          run.errors = collectFailures(run);
        } catch (error) {
          run.errors.push(error instanceof Error ? error.message : String(error));
        } finally {
          report.runs.push(run);
          await page.close();
        }
      }
      await context.close();
    }
  } finally {
    await browser.close();
  }

  try {
    report.lighthouse = runLighthouse({
      baseUrl,
      route: routes[0],
      outputDirectory,
      playwright,
      timeout,
    });
  } catch (error) {
    report.lighthouse = {
      route: routes[0],
      failures: [error instanceof Error ? error.message : String(error)],
      passed: false,
    };
  }

  const totalFailures = report.runs.reduce((sum, run) => sum + run.errors.length, 0);
  const lighthouseFailures = report.lighthouse.failures.length;
  const axeSeriousCritical = report.runs.reduce(
    (sum, run) => sum + (run.checks?.axe.seriousCritical.length ?? 0),
    0,
  );
  const axeOther = report.runs.reduce(
    (sum, run) => sum + (run.checks?.axe.otherViolations.length ?? 0),
    0,
  );
  report.summary = {
    runCount: report.runs.length,
    screenshotCount: report.runs.filter((run) => existsSync(run.screenshot)).length,
    failureCount: totalFailures,
    lighthouseFailures,
    lighthouse: report.lighthouse.scores ?? null,
    cumulativeLayoutShift: report.lighthouse.cumulativeLayoutShift ?? null,
    axeSeriousCritical,
    axeOther,
  };
  report.passed = totalFailures === 0 && lighthouseFailures === 0;

  const reportPath = path.join(outputDirectory, "report.json");
  writeFileSync(reportPath, `${JSON.stringify(report, null, 2)}\n`, "utf8");
  console.log(JSON.stringify({ passed: report.passed, report: reportPath, summary: report.summary }, null, 2));
  process.exitCode = report.passed ? 0 : 1;
}

await main();
